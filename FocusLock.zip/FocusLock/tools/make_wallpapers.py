#!/usr/bin/env python3
"""Generates the 30 original lock-screen wallpapers shipped with Stay focused.
All artwork is procedural (math + code), text lines are original, fonts are open-licensed
(Poppins: SIL OFL, DejaVu Sans: free Bitstream Vera/DejaVu license). No third-party images.
Usage: python3 make_wallpapers.py <output_dir>"""
import math, random, sys, os, glob
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H, S = 720, 1280, 2
OUT = sys.argv[1] if len(sys.argv) > 1 else "out"
os.makedirs(OUT, exist_ok=True)
POPPINS = "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"
ARAB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
AR = dict(direction="rtl", language="ar")

P = {
 "dawn":   ["#12062b", "#5a1e7a", "#d9467f", "#ff9a5b", "#ffd98a"],
 "ocean":  ["#031a33", "#0a4f7a", "#1aa6b7", "#7fe0d2"],
 "forest": ["#04150f", "#0b4a30", "#2f9e5f", "#b9f2b0"],
 "violet": ["#0e0722", "#3b1c80", "#8a3ffc", "#ff6fb5"],
 "gold":   ["#0a0a0a", "#2b1d04", "#a66a00", "#ffd24a"],
 "steel":  ["#070d18", "#14305c", "#3f7fd9", "#a9d0ff"],
 "crimson":["#16040a", "#6b1226", "#e0455a", "#ffb085"],
 "mint":   ["#03181a", "#0a5a5a", "#25b8a5", "#c5fff0"],
 "cosmic": ["#04020d", "#201256", "#4a2fd0", "#27d3ff"],
 "sun":    ["#2b0f3a", "#c2336b", "#ff7a45", "#ffe29a"],
 "lime":   ["#07130a", "#12451f", "#46b34a", "#e4ff7a"],
}

def hx(h):
    h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

def vgrad(cols):
    cols = [hx(c) for c in cols]; n = len(cols)
    pos = [i / (n - 1) for i in range(n)]
    ys = np.linspace(0, 1, H)
    arr = np.stack([np.interp(ys, pos, [c[k] for c in cols]) for k in range(3)], axis=1)
    arr = np.repeat(arr[:, None, :], W, axis=1)
    return Image.fromarray(arr.astype("uint8"), "RGB").convert("RGBA")

def glow(img, cx, cy, r, col, strength=1.0):
    yy, xx = np.mgrid[0:H, 0:W]
    d = np.exp(-(((xx - cx) ** 2 + (yy - cy) ** 2) / (r * r))) * strength
    a = np.array(img.convert("RGB")).astype(float)
    c = np.array(hx(col) if isinstance(col, str) else col, float)
    a = a + (c - a) * np.clip(d, 0, 1)[..., None] * 0.9
    return Image.fromarray(np.clip(a, 0, 255).astype("uint8"), "RGB").convert("RGBA")

class Layer:
    def __init__(self):
        self.im = Image.new("RGBA", (W * S, H * S), (0, 0, 0, 0)); self.d = ImageDraw.Draw(self.im)
    def poly(self, pts, fill): self.d.polygon([(x * S, y * S) for x, y in pts], fill=fill)
    def circ(self, cx, cy, r, fill=None, outline=None, width=1):
        self.d.ellipse([(cx - r) * S, (cy - r) * S, (cx + r) * S, (cy + r) * S], fill=fill, outline=outline, width=max(1, int(width * S)))
    def line(self, pts, fill, width):
        self.d.line([(x * S, y * S) for x, y in pts], fill=fill, width=max(1, int(width * S)), joint="curve")
    def rect(self, x0, y0, x1, y1, fill, r=0):
        if r: self.d.rounded_rectangle([x0 * S, y0 * S, x1 * S, y1 * S], r * S, fill=fill)
        else: self.d.rectangle([x0 * S, y0 * S, x1 * S, y1 * S], fill=fill)
    def done(self, base, blur=0, rot=None):
        im = self.im
        if rot: im = im.rotate(rot[0], center=(rot[1] * S, rot[2] * S), resample=Image.BICUBIC)
        im = im.resize((W, H), Image.LANCZOS)
        if blur: im = im.filter(ImageFilter.GaussianBlur(blur))
        return Image.alpha_composite(base, im)

def ridge(rng, base, amp, n=4):
    ph = [rng.uniform(0, 6.28) for _ in range(n)]
    fr = [rng.uniform(0.004, 0.012) * (1.9 ** i) for i in range(n)]
    am = [amp / (1.7 ** i) for i in range(n)]
    return lambda x: base + sum(a * math.sin(f * x + p) for a, f, p in zip(am, fr, ph))

def stars(base, rng, n, ymax=0.7, col=(255, 255, 255)):
    L = Layer()
    for _ in range(n):
        x, y = rng.uniform(0, W), rng.uniform(0, H * ymax); r = rng.choice([0.8, 1, 1.2, 1.6, 2.2])
        L.circ(x, y, r, fill=col + (rng.randint(90, 230),))
    for _ in range(max(2, n // 40)):
        x, y = rng.uniform(40, W - 40), rng.uniform(40, H * ymax * 0.8); s = rng.uniform(7, 13)
        L.line([(x - s, y), (x + s, y)], col + (200,), 1.4); L.line([(x, y - s), (x, y + s)], col + (200,), 1.4)
    return L.done(base)

# ---------- مشاهد ----------
def sunrise_sea(pal, seed):
    rng = random.Random(seed); base = vgrad(pal); hz = H * 0.62
    sea = vgrad([pal[0], pal[1]]).crop((0, 0, W, H - int(hz))); 
    base.paste(sea, (0, int(hz)))
    base = glow(base, W / 2, hz - 30, 330, pal[-1], 0.85)
    L = Layer(); L.circ(W / 2, hz - 10, 105, fill=hx(pal[-1]) + (255,))
    L.rect(0, hz, W, H, hx(pal[1]) + (255,)); base = L.done(base)
    base = glow(base, W / 2, hz - 10, 240, pal[-1], 0.55)
    L = Layer()
    for i in range(46):
        y = hz + 8 + i * ((H - hz) / 46); w = (1 - i / 46) * 250 * rng.uniform(0.55, 1.0) + 20
        x = W / 2 + rng.uniform(-30, 30); a = int(210 * (1 - i / 46))
        L.line([(x - w / 2, y), (x + w / 2, y)], hx(pal[-1]) + (a,), 2.6)
    return L.done(base)

def mountains(pal, seed, flag=False):
    rng = random.Random(seed); base = vgrad(pal); n = 5
    sx, sy = rng.uniform(W * 0.25, W * 0.75), H * rng.uniform(0.2, 0.3)
    base = glow(base, sx, sy, 300, pal[-1], 0.6)
    L = Layer(); L.circ(sx, sy, 70, fill=hx(pal[-1]) + (255,)); base = L.done(base)
    sky = hx(pal[1]); dark = hx(pal[0]); top = None
    for k in range(n):
        f = ridge(rng, H * (0.50 + 0.085 * k), 120 - k * 12)
        col = mix(sky, dark, k / (n - 1)) if k else mix(sky, hx(pal[2]), 0.3)
        pts = [(x, f(x)) for x in range(0, W + 7, 6)]
        L = Layer(); L.poly(pts + [(W, H), (0, H)], col + (255,)); base = L.done(base)
        if k == 2: top = min(pts, key=lambda p: p[1])
    if flag and top:
        L = Layer(); x, y = top
        L.line([(x, y + 4), (x, y - 70)], (255, 255, 255, 255), 3.4)
        L.poly([(x, y - 70), (x + 42, y - 56), (x, y - 42)], hx(pal[-1]) + (255,)); base = L.done(base)
    return base

def starry_path(pal, seed):
    rng = random.Random(seed); base = vgrad(pal); base = stars(base, rng, 260)
    base = glow(base, W * 0.78, H * 0.18, 210, pal[-1], 0.5)
    L = Layer(); L.circ(W * 0.78, H * 0.18, 46, fill=(250, 250, 255, 255)); base = L.done(base)
    for w, a, bl in [(60, 60, 18), (26, 110, 8), (8, 230, 0)]:
        L = Layer(); pts = []
        for i in range(41):
            t = i / 40; x = W * 0.12 + t * W * 0.7 + 90 * math.sin(t * 5); y = H * 0.98 - t * H * 0.72
            pts.append((x, y))
        L.line(pts, hx(pal[-1]) + (a,), w); base = L.done(base, blur=bl)
    return base

def rings(pal, seed):
    rng = random.Random(seed); base = vgrad(pal); cx, cy = W / 2, H * 0.42
    base = glow(base, cx, cy, 300, pal[-2], 0.55); L = Layer()
    for i, r in enumerate(range(60, 340, 46)):
        L.circ(cx, cy, r, outline=hx(pal[-1]) + (max(40, 210 - i * 28),), width=3 + (i % 2) * 2)
    for _ in range(3):
        r = rng.choice([106, 198, 290]); a0 = rng.uniform(0, 360)
        L.d.arc([(cx - r) * S, (cy - r) * S, (cx + r) * S, (cy + r) * S], a0, a0 + rng.uniform(70, 150), fill=(255, 255, 255, 240), width=8 * S)
    L.circ(cx, cy, 14, fill=(255, 255, 255, 255)); base = L.done(base)
    return glow(base, cx, cy, 60, "#ffffff", 0.6)

def waves(pal, seed):
    rng = random.Random(seed); base = vgrad(pal[:2] + [pal[2]])
    base = glow(base, W * 0.5, H * 0.34, 250, pal[-1], 0.7)
    L = Layer(); L.circ(W * 0.5, H * 0.34, 80, fill=hx(pal[-1]) + (255,)); base = L.done(base)
    for k in range(7):
        f = ridge(rng, H * (0.52 + k * 0.07), 34, 3); col = mix(hx(pal[2]), hx(pal[0]), k / 6)
        L = Layer(); L.poly([(x, f(x)) for x in range(0, W + 7, 5)] + [(W, H), (0, H)], col + (255,)); base = L.done(base)
    return base

def skyline(pal, seed):
    rng = random.Random(seed); base = vgrad(pal); base = glow(base, W * 0.5, H * 0.72, 340, pal[-1], 0.8)
    for layer, (hh, shade) in enumerate([(430, 0.5), (300, 0.2)]):
        L = Layer(); x = -20; col = mix(hx(pal[1]), hx(pal[0]), 0.6 + layer * 0.4)
        while x < W:
            bw = rng.randint(46, 110); bh = rng.randint(int(hh * .4), hh)
            L.rect(x, H * 0.80 - bh, x + bw, H, col + (255,))
            if layer == 1:
                for wy in range(int(H * 0.80 - bh + 14), int(H * 0.80), 24):
                    for wx in range(int(x + 8), int(x + bw - 10), 18):
                        if rng.random() < 0.2: L.rect(wx, wy, wx + 7, wy + 11, (255, 214, 120, 240))
            x += bw + rng.randint(0, 8)
        base = L.done(base)
    return base

def rays(pal, seed):
    rng = random.Random(seed); base = vgrad(pal); cx, cy = W / 2, H * 0.6
    L = Layer()
    for i in range(26):
        a0 = i * (2 * math.pi / 26); a1 = a0 + math.pi / 26
        pts = [(cx, cy)] + [(cx + 1500 * math.cos(a), cy + 1500 * math.sin(a)) for a in (a0, a1)]
        L.poly(pts, hx(pal[-1]) + (38,))
    base = L.done(base, blur=2); base = glow(base, cx, cy, 280, pal[-1], 0.9)
    L = Layer(); L.circ(cx, cy, 78, fill=(255, 255, 255, 255)); base = L.done(base)
    f = ridge(rng, H * 0.78, 60, 3); L = Layer()
    L.poly([(x, f(x)) for x in range(0, W + 7, 6)] + [(W, H), (0, H)], hx(pal[0]) + (255,)); return L.done(base)

def stairs(pal, seed):
    base = vgrad(pal); base = glow(base, W * 0.8, H * 0.2, 330, pal[-1], 0.8)
    L = Layer(); L.circ(W * 0.8, H * 0.2, 78, fill=hx(pal[-1]) + (255,)); base = L.done(base); n = 8
    for i in range(n):
        x0 = i * (W / n) * 0.96; y = H * 0.9 - i * (H * 0.55 / n); col = mix(hx(pal[1]), hx(pal[-2]), i / n)
        L = Layer(); L.rect(x0, y, W, H, col + (255,)); L.rect(x0, y, W, y + 6, hx(pal[-1]) + (230,)); base = L.done(base)
    return base

def road(pal, seed):
    base = vgrad(pal); hz = H * 0.5; base = glow(base, W / 2, hz, 320, pal[-1], 0.85)
    L = Layer(); L.circ(W / 2, hz - 6, 90, fill=hx(pal[-1]) + (255,)); L.rect(0, hz, W, H, hx(pal[0]) + (255,))
    L.poly([(W * 0.02, H), (W * 0.98, H), (W * 0.53, hz), (W * 0.47, hz)], mix(hx(pal[0]), (40, 40, 48), 0.6) + (255,))
    for s in (-1, 1): L.line([(W / 2 + s * W * 0.47, H), (W / 2 + s * W * 0.03, hz)], hx(pal[-1]) + (230,), 4)
    for k in range(9):
        t0, t1 = (k / 9) ** 2, ((k + 0.5) / 9) ** 2; y0, y1 = hz + (H - hz) * t0, hz + (H - hz) * t1
        w0, w1 = 2 + 22 * t0, 2 + 22 * t1; L.poly([(W / 2 - w0, y0), (W / 2 + w0, y0), (W / 2 + w1, y1), (W / 2 - w1, y1)], (255, 255, 255, 235))
    return L.done(base)

def rocket(pal, seed):
    rng = random.Random(seed); base = vgrad(pal); base = stars(base, rng, 240, 0.95)
    base = glow(base, W * 0.5, H * 0.5, 260, pal[-2], 0.4)
    cx, cy = W / 2, H * 0.42; L = Layer()
    for k in range(6):
        wk = 20 + k * 14; L.poly([(cx - 16, cy + 140), (cx + 16, cy + 140), (cx + wk + 20, H + 200), (cx - wk - 20, H + 200)], (255, 190, 110, 26))
    L.poly([(cx - 24, cy + 118), (cx, cy + 250), (cx + 24, cy + 118)], (255, 150, 60, 255))
    L.poly([(cx - 12, cy + 118), (cx, cy + 190), (cx + 12, cy + 118)], (255, 230, 130, 255))
    L.poly([(cx - 48, cy + 30), (cx - 98, cy + 140), (cx - 48, cy + 112)], hx(pal[-2]) + (255,))
    L.poly([(cx + 48, cy + 30), (cx + 98, cy + 140), (cx + 48, cy + 112)], hx(pal[-2]) + (255,))
    L.rect(cx - 48, cy - 40, cx + 48, cy + 122, (236, 241, 255, 255)); L.d.ellipse([(cx - 48) * S, (cy - 160) * S, (cx + 48) * S, (cy + 60) * S], fill=(236, 241, 255, 255))
    L.circ(cx, cy - 20, 25, fill=hx(pal[-1]) + (255,)); L.circ(cx, cy - 20, 25, outline=(40, 50, 90, 255), width=5)
    L.rect(cx - 48, cy + 70, cx + 48, cy + 86, hx(pal[-2]) + (255,))
    return L.done(base, rot=(-18, cx, cy))

def aurora(pal, seed):
    rng = random.Random(seed); base = vgrad([pal[0], pal[0], pal[1]]); base = stars(base, rng, 200, 0.6)
    for k in range(4):
        ph = rng.uniform(0, 6); pts = [(x, H * (0.22 + 0.08 * k) + 80 * math.sin(x * 0.007 + k * 1.4 + ph) + 30 * math.sin(x * 0.02 + ph)) for x in range(-20, W + 30, 12)]
        L = Layer(); L.line(pts, hx(pal[2 + (k % 2) if len(pal) > 3 else 2]) + (150,), 100); base = L.done(base, blur=34)
    f = ridge(rng, H * 0.82, 70, 3); L = Layer()
    L.poly([(x, f(x)) for x in range(0, W + 7, 6)] + [(W, H), (0, H)], (3, 6, 10, 255)); return L.done(base)

def embers(pal, seed):
    rng = random.Random(seed); base = vgrad(pal); base = glow(base, W / 2, H * 0.95, 460, pal[-2], 0.7)
    for blur, sizes in [(9, (6, 16)), (0, (1.5, 6))]:
        L = Layer()
        for _ in range(110):
            x = rng.uniform(0, W); y = H - (rng.random() ** 1.7) * H * 0.95; r = rng.uniform(*sizes)
            L.circ(x, y, r, fill=mix(hx(pal[-2]), hx(pal[-1]), rng.random()) + (rng.randint(110, 240),))
        base = L.done(base, blur=blur)
    return base

def geo(pal, seed):
    rng = random.Random(seed); base = vgrad(pal[:3]); L = Layer()
    for _ in range(11):
        c = hx(rng.choice(pal[1:])); L.circ(rng.uniform(0, W), rng.uniform(0, H), rng.uniform(70, 250), fill=c + (rng.randint(35, 90),))
    for _ in range(5):
        x, y = rng.uniform(0, W), rng.uniform(0, H); s = rng.uniform(80, 200)
        L.poly([(x, y), (x + s, y + s * 0.4), (x + s * 0.3, y + s)], hx(pal[-1]) + (rng.randint(30, 70),))
    return L.done(base)

def dots(pal, seed):
    rng = random.Random(seed); base = vgrad(pal[:2]); L = Layer(); cols, rows = 14, 26
    for r in range(rows):
        t = 1 - r / (rows - 1)
        for c in range(cols):
            x = (c + 0.5) * W / cols; y = (r + 0.5) * H / rows; rad = 2 + t * 13 * rng.uniform(0.7, 1.0)
            L.circ(x, y, rad, fill=mix(hx(pal[2]), hx(pal[-1]), t) + (int(80 + 170 * t),))
    return L.done(base)

def lines(pal, seed):
    rng = random.Random(seed); base = vgrad(pal[:3]); L = Layer()
    for k in range(30):
        y0 = 60 + k * 40; ph = k * 0.35; amp = 28 + 30 * math.sin(k * 0.3) ** 2
        pts = [(x, y0 + amp * math.sin(x * 0.011 + ph) + 14 * math.sin(x * 0.03 + ph * 2)) for x in range(-10, W + 14, 8)]
        L.line(pts, mix(hx(pal[2]), hx(pal[-1]), k / 29) + (int(90 + 130 * (k / 29)),), 3)
    return L.done(base)

def target(pal, seed):
    base = vgrad(pal); cx, cy = W / 2, H * 0.4; base = glow(base, cx, cy, 300, pal[-2], 0.5); L = Layer()
    for i, r in enumerate([270, 210, 150, 92, 38]):
        L.circ(cx, cy, r, fill=(hx(pal[-1]) if i % 2 == 0 else hx(pal[0])) + (255,))
    base = L.done(base); L = Layer()
    L.line([(W * 0.9, H * 0.08), (cx + 8, cy - 8)], (245, 245, 250, 255), 9)
    for d in (0, 22, 44):
        L.poly([(W * 0.9 - d * 0.7, H * 0.08 + d * 0.7), (W * 0.9 + 26 - d * 0.7, H * 0.08 - 14 + d * 0.7), (W * 0.9 + 34 - d * 0.7, H * 0.08 + 6 + d * 0.7)], hx(pal[-2]) + (255,))
    return glow(L.done(base), cx, cy, 70, "#ffffff", 0.7)

def typo(word, pal, seed):
    rng = random.Random(seed); base = vgrad(pal); base = glow(base, W / 2, H * 0.46, 360, pal[-2], 0.5)
    size = 280; f = ImageFont.truetype(POPPINS, size, layout_engine=ImageFont.Layout.RAQM)
    while ImageDraw.Draw(base).textlength(word, font=f) > W * 0.86: size -= 8; f = ImageFont.truetype(POPPINS, size, layout_engine=ImageFont.Layout.RAQM)
    L = Layer(); L.circ(W / 2, H * 0.46, 300, outline=hx(pal[-1]) + (60,), width=3); L.circ(W / 2, H * 0.46, 380, outline=hx(pal[-1]) + (30,), width=3); base = L.done(base)
    for k, (dy, a) in enumerate([(-74, 40), (-38, 90), (38, 90), (74, 40)]):
        m = Image.new("L", (W, H), 0); ImageDraw.Draw(m).text((W / 2, H * 0.46 + dy), word, font=f, fill=a, anchor="mm")
        base = Image.composite(Image.new("RGBA", (W, H), hx(pal[-1]) + (255,)), base, m)
    m = Image.new("L", (W, H), 0); ImageDraw.Draw(m).text((W / 2, H * 0.46), word, font=f, fill=255, anchor="mm")
    grad = vgrad(["#ffffff", pal[-1]]); return Image.composite(grad, base, m)

# ---------- نصوص ----------
def fnt(path, size): return ImageFont.truetype(path, size, layout_engine=ImageFont.Layout.RAQM)
def caption(img, text, ar=False, y=0.80, size=44):
    size = int(size * 1.08) if ar else size; f = fnt(ARAB if ar else POPPINS, size); kw = AR if ar else {}
    d = ImageDraw.Draw(img); words = text.split(); lines = []; cur = ""
    for w in words:
        t = (cur + " " + w).strip()
        if d.textlength(t, font=f, **kw) <= W * 0.78: cur = t
        else: lines.append(cur); cur = w
    lines.append(cur); lh = int(size * 1.5); y0 = int(H * y - lh * len(lines) / 2)
    sh = Image.new("RGBA", img.size, (0, 0, 0, 0)); sd = ImageDraw.Draw(sh)
    for i, ln in enumerate(lines): sd.text((W / 2, y0 + i * lh + 4), ln, font=f, fill=(0, 0, 0, 190), anchor="ma", **kw)
    img = Image.alpha_composite(img, sh.filter(ImageFilter.GaussianBlur(7))); d = ImageDraw.Draw(img)
    for i, ln in enumerate(lines): d.text((W / 2, y0 + i * lh), ln, font=f, fill=(255, 255, 255, 255), anchor="ma", **kw)
    return img

SPECS = [
 (lambda: sunrise_sea(P["dawn"], 1), "Every sunrise is a fresh start.", False),
 (lambda: mountains(P["steel"], 2, True), "Climb. Even slowly.", False),
 (lambda: rocket(P["cosmic"], 3), "Fuel your focus.", False),
 (lambda: typo("RISE", P["sun"], 4), None, False),
 (lambda: rings(P["violet"], 5), "ركّز.. فالنجاح أقرب مما تظن", True),
 (lambda: starry_path(P["cosmic"], 6), "ابدأ الآن، وستشكر نفسك لاحقًا", True),
 (lambda: stairs(P["gold"], 7), "Small steps. Big finish.", False),
 (lambda: road(P["crimson"], 8), "Keep going. It counts.", False),
 (lambda: aurora(P["mint"], 9), "بالهدوء والتركيز تُبنى الأحلام", True),
 (lambda: skyline(P["dawn"], 10), "Build the life you can't scroll to.", False),
 (lambda: rays(P["sun"], 11), "أنت أقوى من أي تشتيت", True),
 (lambda: waves(P["ocean"], 12), "Quiet mind, loud results.", False),
 (lambda: embers(P["crimson"], 13), "تعب اليوم، راحة وفخر غدًا", True),
 (lambda: target(P["steel"], 14), "Aim. Focus. Repeat.", False),
 (lambda: geo(P["violet"], 15), "You are closer than you think.", False),
 (lambda: dots(P["lime"], 16), "خطوة اليوم تصنع إنجاز الغد", True),
 (lambda: lines(P["mint"], 17), "Less noise. More progress.", False),
 (lambda: typo("FOCUS", P["cosmic"], 18), None, False),
 (lambda: mountains(P["forest"], 19), "كل شروق بداية جديدة", True),
 (lambda: sunrise_sea(P["gold"], 20), "Today's effort is tomorrow's pride.", False),
 (lambda: rocket(P["violet"], 21), "اجعل وقتك يعمل لأجلك", True),
 (lambda: stairs(P["ocean"], 22), "كن نسخة أفضل من نفسك", True),
 (lambda: aurora(P["cosmic"], 23), "Energy flows where focus goes.", False),
 (lambda: road(P["sun"], 24), "الإصرار يصنع المستحيل", True),
 (lambda: typo("BEGIN", P["lime"], 25), None, False),
 (lambda: rings(P["gold"], 26), "One calm hour changes the whole day.", False),
 (lambda: skyline(P["steel"], 27), "حياتك أثمن من الشاشة", True),
 (lambda: embers(P["dawn"], 28), "Do it for the person you're becoming.", False),
 (lambda: waves(P["crimson"], 29), "Be the reason you're proud tonight.", False),
 (lambda: typo("NOW", P["crimson"], 30), None, False),
]

for i, (make, text, ar) in enumerate(SPECS, 1):
    img = make()
    if text: img = caption(img, text, ar, y=0.82)
    a = np.array(img.convert("RGB")).astype(float)
    a += np.random.default_rng(i).normal(0, 1.6, a.shape)
    Image.fromarray(np.clip(a, 0, 255).astype("uint8")).save(os.path.join(OUT, f"bg_{i}.jpg"), "JPEG", quality=84, optimize=True)
    print("ok", i)
