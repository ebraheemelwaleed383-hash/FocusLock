#!/usr/bin/env python3
"""Generates one extra original wallpaper: a person studying at a desk under a lit lamp.
Same procedural style as make_wallpapers.py (no third-party images). Outputs bg_31.jpg."""
import os, sys, numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

sys.path.insert(0, os.path.dirname(__file__))
from make_wallpapers import W, H, S, POPPINS, ARAB, hx, mix, vgrad, glow, OUT as DEFAULT_OUT

OUT = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_OUT
os.makedirs(OUT, exist_ok=True)

def text_block(img, lines, y, fonts, color=(255, 255, 255, 255), align="center", ls=1.12):
    d = ImageDraw.Draw(img)
    cy = y
    for s, f in zip(lines, fonts):
        bb = d.textbbox((0, 0), s, font=f)
        w = bb[2] - bb[0]
        x = (W * S - w) / 2 if align == "center" else 0
        d.text((x, cy), s, font=f, fill=color)
        cy += (bb[3] - bb[1]) * ls + 10 * S
    return cy

def glow_local(img, cx, cy, r, col, strength=1.0):
    w, h = img.size
    yy, xx = np.mgrid[0:h, 0:w]
    d = np.exp(-(((xx - cx) ** 2 + (yy - cy) ** 2) / (r * r))) * strength
    a = np.array(img.convert("RGB")).astype(float)
    c = np.array(hx(col) if isinstance(col, str) else col, float)
    a = a + (c - a) * np.clip(d, 0, 1)[..., None] * 0.9
    return Image.fromarray(np.clip(a, 0, 255).astype("uint8"), "RGB").convert("RGBA")

def build(idx, ar, en):
    base = vgrad(["#070314", "#140a33", "#241752", "#3a2166"])
    img = base.resize((W * S, H * S), Image.LANCZOS)

    # نافذة ونجوم خلفية
    d = ImageDraw.Draw(img, "RGBA")
    rng = np.random.default_rng(idx * 7 + 3)
    for _ in range(140):
        x = rng.integers(0, W * S); y = rng.integers(0, int(H * S * 0.42))
        r = rng.uniform(0.6, 1.8) * S
        a = int(rng.uniform(90, 220))
        d.ellipse([x - r, y - r, x + r, y + r], fill=(255, 255, 255, a))
    img = img.filter(ImageFilter.GaussianBlur(0))

    deskY = int(H * S * 0.78)
    lampX, lampY = int(W * S * 0.70), int(H * S * 0.42)

    # توهّج الأباجورة الدافئ
    img = glow_local(img, lampX, lampY + 60 * S, 340 * S, "#ffcf7a", 1.0)
    img = glow_local(img, lampX, lampY + 60 * S, 150 * S, "#fff1cf", 0.55)

    d = ImageDraw.Draw(img, "RGBA")
    ink = (8, 4, 20, 255)

    # المكتب
    d.rectangle([60 * S, deskY, W * S - 60 * S, deskY + 18 * S], fill=ink)
    d.polygon([(90 * S, deskY + 18 * S), (120 * S, H * S - 10 * S), (150 * S, H * S - 10 * S), (140 * S, deskY + 18 * S)], fill=ink)
    d.polygon([(W * S - 90 * S, deskY + 18 * S), (W * S - 120 * S, H * S - 10 * S), (W * S - 150 * S, H * S - 10 * S), (W * S - 140 * S, deskY + 18 * S)], fill=ink)

    # الأباجورة: قاعدة، عمود، شدة، لمبة مضيئة
    baseX = lampX
    d.ellipse([baseX - 26 * S, deskY - 10 * S, baseX + 26 * S, deskY + 8 * S], fill=ink)
    d.line([(baseX, deskY), (baseX - 10 * S, lampY + 40 * S)], fill=ink, width=10 * S)
    d.polygon([(baseX - 70 * S, lampY + 30 * S), (baseX + 50 * S, lampY + 30 * S),
               (baseX + 24 * S, lampY - 40 * S), (baseX - 44 * S, lampY - 40 * S)], fill=ink)
    d.ellipse([baseX - 22 * S, lampY + 10 * S, baseX + 22 * S, lampY + 54 * S], fill=(255, 226, 150, 255))

    # الشخص: جالس، رأس منحنٍ قليلًا على الكتاب، ذراع على المكتب
    px, py = int(W * S * 0.38), deskY
    d.ellipse([px - 46 * S, py + 30 * S, px + 46 * S, py + 160 * S], fill=ink)  # جسم/كرسي
    hx_, hy_ = px + 6 * S, py - 56 * S
    d.ellipse([hx_ - 34 * S, hy_ - 34 * S, hx_ + 34 * S, hy_ + 34 * S], fill=ink)  # رأس
    d.polygon([(px - 40 * S, py + 20 * S), (px + 70 * S, py + 10 * S), (px + 86 * S, py + 30 * S), (px - 20 * S, py + 46 * S)], fill=ink)  # كتف-ذراع للكتاب
    # كتاب مفتوح على المكتب
    bxx = px + 50 * S
    d.polygon([(bxx - 70 * S, deskY - 6 * S), (bxx, deskY - 26 * S), (bxx + 70 * S, deskY - 6 * S), (bxx, deskY + 10 * S)], fill=(255, 241, 214, 255))
    d.line([(bxx, deskY - 26 * S), (bxx, deskY + 10 * S)], fill=(200, 160, 90, 255), width=3 * S)
    # كوب بجانبه
    d.rectangle([px - 120 * S, deskY - 46 * S, px - 92 * S, deskY - 6 * S], fill=(255, 255, 255, 90), outline=ink, width=3 * S)

    img = img.resize((W, H), Image.LANCZOS)
    img = img.filter(ImageFilter.GaussianBlur(0.4))

    draw = ImageDraw.Draw(img, "RGBA")
    maxw = W - 56

    def fit(txt, path, start):
        size = start
        while size > 14:
            f = ImageFont.truetype(path, size)
            bb = draw.textbbox((0, 0), txt, font=f)
            if bb[2] - bb[0] <= maxw: return f, bb
            size -= 1
        return f, bb

    fEn, bbEn = fit(en, POPPINS, 30)
    fAr, bbAr = fit(ar, ARAB, 32)
    yy = int(H * 0.87)
    draw.text(((W - (bbEn[2] - bbEn[0])) / 2, yy), en, font=fEn, fill=(255, 255, 255, 255))
    draw.text(((W - (bbAr[2] - bbAr[0])) / 2, yy + (bbEn[3] - bbEn[1]) + 16), ar, font=fAr, fill=(255, 226, 150, 255))

    img.convert("RGB").save(os.path.join(OUT, "bg_31.jpg"), "JPEG", quality=90)
    print("ok 31")

build(31, "ركّز الليلة، يشكرك غدك", "Study tonight, thank yourself tomorrow.")
