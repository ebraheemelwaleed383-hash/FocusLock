# FocusLock Ultimate — Implementation Checklist

Source of truth for the 15 planned features. Documentation describes the *reported* state; source code is the authority.

## Status legend
- **Not Started** — no code found in the project
- **In Progress** — work begun, incomplete
- **Implemented — Unverified** — code written, NOT compiled, NOT tested
- **Verified** — compiled (CI) AND tested (unit/device) with evidence

> Nothing is **Verified** yet. No Gradle build, unit test run, or device test has been performed on any item.

Last code inspection: FocusLock.zip, version 2.7 (versionCode 18) + Hardening Stage + Features 01/02 (static review only; no compiler or Gradle was available).

## Foundation stages
| Stage | Content | Status | Evidence |
|---|---|---|---|
| 0 | Session Log (`SessionLog` in `FocusTasks.kt`) | Implemented — Unverified | Code present; not compiled; unit tests written, never run |
| H | Hardening Stage (review findings H1, M1–M5, L1) | Implemented — Unverified | Static review only; see "Hardening Stage" below |
| A | Shared analytics foundation (`Analytics.kt`) used by Features 01 and 02 | Implemented — Unverified | Pure Kotlin; 59 new unit tests written, never run |

## The 15 features (original order)
| # | Feature | Status | Notes |
|---|---|---|---|
| 01 | Focus Intelligence | Implemented — Unverified | Screen + `FocusIntel.kt`; see "Feature 01" below. Not compiled, tests not run |
| 02 | Focus DNA | Implemented — Unverified | Screen + `FocusDna.kt` + weekly history `dna_hist`; see "Feature 02" below. Not compiled, tests not run |
| 03 | Focus Tasks | Implemented — Unverified | Reported complete; hardened (see below) |
| 04 | Focus Journey | Not Started | Needs original illustrations |
| 05 | Emergency Focus | Not Started | |
| 06 | Smart Task Breakdown | Not Started | Local templates first; any AI provider needs user key + consent |
| 07 | Specialized Focus Modes | Not Started | Extend existing `Plans.kt`, do not duplicate |
| 08 | Team Challenges | Not Started | Needs a backend configured by the owner |
| 09 | Focus Shield | Not Started | Highest risk; extend `Engine.kt` / `Protect.kt`, do not replace |
| 10 | Focus Sound Studio | Not Started | Extend `Sfx.kt`; original or licensed audio only |
| 11 | Weekly Review | Not Started | Extend existing `WeeklyReport` (`Extras.kt`) |
| 12 | Meaningful Achievements | Not Started | Extend `Rewards.kt` |
| 13 | Focus Widgets | Not Started | Extend existing `FocusWidget` (`Extras.kt`) |
| 14 | Restart Without Guilt | Not Started | Build on planner's existing rolling logic |
| 15 | Focus Profiles | Not Started | Feature 03 "select focus profile" deferred here |

Verified by code search: no feature-specific code exists for 04–15 (only pre-existing `WeeklyReport` and `FocusWidget`, which are base systems to extend).

## Stage 0 — Session Log (Implemented — Unverified)
- Start/end, planned vs actual minutes, done/interrupted status, linked task, goal
- Hooked into `Prefs.begin / settle / cancel`, wrapped in try/catch
- SharedPreferences key `sl_log` (cap 600 sessions); included in backup/restore
- Not recorded: pauses, in-session breaks
- Hardening: duplicate settle events are skipped/merged and never replace an existing record (L1)

## Feature 03 — Focus Tasks (Implemented — Unverified)
- Home "Session focus" card (now also in single-screen mode); select/create task; project; goal; checklist
- Lock-screen checklist card; post-session review (Done / Partly / Continue later); optional reminders
- Task completes ONLY via explicit checkbox (unit test written, not run)

## Hardening Stage — review findings and fixes (all Implemented — Unverified)
| ID | Finding (from static review) | Fix | Main files |
|---|---|---|---|
| H1 | CI published a public release on any push with a new versionName; `Updater.kt` reads `/releases/latest`, so 2.7 would have reached all users | (Superseded by R1: the `v*` tag path was removed later.) Release step runs only on manual dispatch with `publish_release=true` or on a `v*` tag; also requires passing unit tests, tag == versionName, and no existing release. Normal pushes only upload an artifact | `build.yml` |
| M1 | Corrupt task JSON could crash `LockActivity.onCreate`; restore wrote `tasks` unvalidated | `Tasks.load` never throws (bad items skipped, original raw kept once in `tasks_corrupt`); `lockCard` wrapped in try/catch; restore validates `tasks` and `sl_log` first and keeps current data if the backup value is unusable; previous values saved to `rb_tasks` / `rb_sl_log` | `FocusSafe.kt`, `Look.kt`, `Prefs.kt`, `FocusTaskUi.kt`, `FocusLogic.kt` |
| M2 | Stale-list overwrites (load at dialog open, save later) | `Tasks.update` = synchronized load-modify-save on fresh data; all task writers converted (picker, review, Home, lock screen, Tasks page, Builder, Screens, afterSession). Picker/review merge field-by-field by id | `Look.kt` + all callers |
| M3 | Reminders lost on reboot, one at a time, no permission handling, no task validation | Reminders persisted in `ft_rems`, one per task, up to 20, rescheduled from `BootReceiver` (boot + app update) and app start; overdue ones delivered immediately; task validated when firing; own channel `ft_remind`; warning dialog with link to notification settings when blocked | `FocusReminders.kt`, `BootReceiver.kt`, `MainActivity.kt` |
| M4 | Review shown only when app opened, silently lost after 3 days or "Not now" until process restart | Review queue (`ft_revq`, up to 10), end-of-session notification (channel `ft_review`) opening the review, "Not now" = 10-min snooze, expiry after 7 days recorded as outcome `skip` instead of silent loss | `FocusTasks.kt`, `FocusTaskUi.kt`, `MainActivity.kt` |
| M5 | No task display/selection in single-screen mode | `FocusCard` added to `renderFocus` (separate instance, refreshed via `refreshCards()`) | `MainActivity.kt` |
| L1 | Duplicate settle could replace a linked record with an unlinked one | `SessionMath.addOrMerge` (existing record never replaced), `hasStart` guard, `uniqueId`; `afterSession` only runs for newly inserted records | `FocusLogic.kt`, `FocusTasks.kt` |

## Feature 01 — Focus Intelligence (Implemented — Unverified)
- Screen `IntelPage` (`FocusIntelUi.kt`), sub-tab "Insights" in the Stats tab (next to "Usage" and "DNA"). Logic in `FocusIntel.kt`, shared foundation in `Analytics.kt`, Android glue in `FocusData.kt`.
- Data: `SessionLog` (`sl_log`, capped at 600) for session-level figures; daily/weekly time = per-day max of the `fm_yyyyMMdd` counters and the log (see DECISIONS.md; corrected in the review-fix pass), task list (title/done/project/steps), and the existing lifetime counters (display only). No new tracking system, no new permission.
- Measured: completed time, completed sessions, early exits, completion rate (null when denominator is 0), average/median/IQR of completed length, planned vs actual (completed) and how far early-ended sessions got, 14-day and 8-week series, 7-day vs previous 7-day trend, 2-week completion/early-exit trend.
- Patterns (estimated, minimum data required, see DECISIONS.md): start-period shares, peak hour, weekday averages, completion by planned length, consistency (active days in 28, streaks, weekly steadiness).
- Tasks: focus time per task, planned vs actual, review outcomes, project totals, "carried over" (only from explicit "continue later" outcomes), split candidates. An interrupted session never marks a task as unsuccessful.
- Insights/recommendations are generated from codes + evidence numbers; recommendations are text only, nothing is applied automatically.

## Feature 02 — Focus DNA (Implemented — Unverified)
- Screen `DnaPage` (`FocusDnaUi.kt`), sub-tab "DNA". Logic in `FocusDna.kt`.
- Storage: new SharedPreferences key `dna_hist` (versioned JSON of weekly summaries, max 104 weeks, written by `DnaStore.update` after every logged session and when the screen opens). Derived data: the session log is never modified. Included in backup; restore VALIDATES it (`BackupGuard`) and MERGES it with the local history (never replaces). Safety copies: `rb_dna_hist`, `dna_hist_bad` (device-only).
- Profile: rolling window (last 3 full weeks + current week) vs baseline (the 4 full weeks before). Labels by documented rules with entry/exit thresholds (hysteresis). Evolution changes only when both windows have >= 8 attempts and >= 14 days. Shows sessions analyzed, period covered, confidence.
- Not used: legacy daily totals (they carry no start time/length/outcome).

## Features 01/02 — Remaining limitations
- Nothing compiled or run. Compile errors are possible (no Kotlin compiler available when writing).
- The app cannot tell "cancelled" from "interrupted": both are `stop` (early exit). Flowtime sessions (`Flow.kt`) are not logged at all, so they appear in neither feature.
- Pauses and in-session breaks are not recorded (existing limitation).
- Hours/weekdays use the device time zone at analysis time; sessions recorded in another time zone are shifted.
- DNA needs session details recorded by version 2.7+: users upgrading from 2.6 start with an empty profile (Intelligence still shows older daily totals).
- Weekly summaries cannot be re-derived once the log was trimmed; stored weeks are kept as-is (more complete copy wins). There is no "clear history" feature; if one is added it must call `DnaStore.clear`.
- "Types of tasks" = the task's project (the only classification stored). Tasks without a project are grouped as "No project".
- "Repeatedly postponed" is approximated by explicit "continue later" outcomes; there are no due dates to measure real postponement.
- Recommendations are suggestions; no "apply" button was added (would change settings; needs an explicit decision).
- `WhatsNew.kt` / `RELEASE_NOTES.txt` were NOT updated for these features (to be done at release preparation).
- UI strings are Arabic/English via `L(ar, en)`; RTL comes from the existing `applyDir`. Not visually checked on a device.
- A session that ends before midnight but is settled after midnight can be counted on both days in the daily series (fm_ uses the settle day, the log the end day). Rare; not corrected.
- When the log is at its cap, session-based figures (completed time, rates, patterns) cover only the retained sessions while daily/weekly hours use the counters; the Insights screen says so.
- Unit tests: 59 added (21 `AnalyticsTest`, 15 `DailyTotalsTest`, 23 `FocusDnaTest`), total 92, none run.

## Review-fix pass (after code review of Features 01/02) — all Implemented — Unverified
| ID | Finding | Fix | Main files |
|---|---|---|---|
| R1 | Workflow could still publish on a pushed `v*` tag and held `contents: write` everywhere | Tag trigger removed; separate `publish` job is the only one with write permission and needs manual dispatch + `publish_release` + `confirm=PUBLISH` + repo variable `ALLOW_PUBLIC_RELEASE=true` + passing tests; signing/build/test steps byte-identical to before; re-enable procedure in DECISIONS.md | `build.yml` (also copied into the zip) |
| R2 | Daily totals ignored `fm_` counters for any day after the first logged session, so days trimmed (fully or partly) from the 600-session log were undercounted; coverage assumed a complete log | Per-day `max(fm_, log by end day)`, coverage from earliest valid `fm_` key or the log's first complete day, truncation flag, corrupt/negative keys ignored, rate trends use the log's own completeness | `Analytics.kt`, `FocusIntel.kt`, `FocusData.kt`, `FocusIntelUi.kt` |
Regression tests: `DailyTotalsTest.kt` (overlap, counter lower than log, stopped sessions, partially and fully trimmed days, truncation flag and coverage, midnight attribution, malformed/negative/zero keys, last 14 days, last 8 weeks, weekly trend, consistency/streak/CV, session-rate trend not computed over the lost period, no trend before known data) and one updated test in `AnalyticsTest.kt`.

## Remaining limitations (known, not fixed)
- Nothing in this stage has been compiled or run. Compile errors are possible.
- Reminders use an inexact alarm (no extra permission): they can arrive minutes late in Doze. One reminder per task; cap 20.
- Review notification is skipped if notifications are disabled; the review then waits in the queue until the app is opened (7-day limit).
- Sessions started by `Plans.kt`, `Disc.kt`, `Extras.kt` are logged but never linked to a task (only the Home start is "armed").
- Task editing is still limited: no rename, no step-text edit, no step reorder in the picker. `later` stays set until the next review.
- `rb_tasks`, `rb_sl_log`, `tasks_corrupt`, `sl_log_corrupt` are safety copies with no in-app restore UI yet.
- Restore replaces `tasks` / `sl_log` (does not merge), as before.
- Synchronization is per process only (single app process; `:crash` process does not touch tasks).
- `Tasks.load` still writes ids on read when legacy tasks have none (existing behavior).
- Pause intentionally not added (would weaken strict lock) — needs explicit decision.
- "Select focus profile" deferred to Feature 15.
- Unit tests: 33 written (17 new in this stage), none run. CI runs them as informational for normal builds, but they must pass to publish.

## Verification required before any item becomes Verified
1. CI build of Lite and Full (`assembleLiteRelease`, `assembleFullRelease`)
2. `gradle testLiteDebugUnitTest`
3. Device test: session flow, lock screen checklist, backup/restore with existing `fl` data (including `dna_hist` merge), upgrade from 2.6 without data loss, Insights and DNA screens in Arabic (RTL) and English with empty, small and large histories
4. Device test of hardening: reminder after reboot, two reminders at once, notifications off, review notification, single-screen task card, restore of a corrupted backup

## Exact next task
1. Push the new `FocusLock.zip` together with `build.yml` (already hardened; a copy is also inside the zip), confirm the Actions run builds only (no release is created), and send the compile errors / `testLiteDebugUnitTest` result for fixing.
2. After the code review of Features 01/02 is accepted, begin Features 05 and 14 (Emergency Focus, Restart Without Guilt) or the next group the owner chooses.
