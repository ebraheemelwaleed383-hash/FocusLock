plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

fun env(k: String, d: String): String = System.getenv(k)?.takeIf { it.isNotEmpty() } ?: d

android {
    namespace = "com.focuslock"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.focuslock"
        minSdk = 27
        targetSdk = 34
        versionCode = 9
        versionName = "1.8"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file(env("FL_KEYSTORE", rootProject.file("focuslock.jks").path))
            storePassword = env("FL_STORE_PASS", "focuslock")
            keyAlias = env("FL_KEY_ALIAS", "focuslock")
            keyPassword = env("FL_KEY_PASS", "focuslock")
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
        getByName("release") {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("fixed")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core:1.12.0")
}
