package com.focuslock

import android.content.Context
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.SeekBar
import kotlin.math.abs

// إطار يلتقط السحب الأفقي للتنقل بين الصفحات، ويتجاهله فوق المنزلقات وعجلة الألوان والقوائم الأفقية
class SwipeFrame(c: Context, private val onSwipe: (Int) -> Unit) : FrameLayout(c) {
    private var x0 = 0f
    private var y0 = 0f
    private var armed = false
    private var taken = false
    private val slop = ViewConfiguration.get(c).scaledTouchSlop
    private val minDist = c.dp(80)

    private fun noSwipe(v: View, x: Float, y: Float): Boolean {
        if (x < 0f || y < 0f || x > v.width || y > v.height) return false
        if (v is SeekBar || v is HorizontalScrollView || v is ColorWheelView || v is EditText) return true
        if (v is ViewGroup) {
            for (i in v.childCount - 1 downTo 0) {
                val ch = v.getChildAt(i)
                if (ch.visibility != View.VISIBLE) continue
                if (noSwipe(ch, x + v.scrollX - ch.left, y + v.scrollY - ch.top)) return true
            }
        }
        return false
    }

    private fun track(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { x0 = e.x; y0 = e.y; taken = false; armed = !noSwipe(this, e.x, e.y) }
            MotionEvent.ACTION_MOVE -> if (armed && !taken) {
                val dx = e.x - x0
                val dy = e.y - y0
                if (abs(dx) > slop * 3 && abs(dx) > abs(dy) * 2f) taken = true
            }
            MotionEvent.ACTION_UP -> {
                if (taken && abs(e.x - x0) > minDist) onSwipe(if (e.x < x0) 1 else -1)
                taken = false
            }
            MotionEvent.ACTION_CANCEL -> taken = false
        }
        return taken
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean = track(e)

    override fun onTouchEvent(e: MotionEvent): Boolean { track(e); return true }
}
