package com.focuslock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent

class UpdateJob : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        val app = applicationContext
        Thread {
            try {
                if (Prefs.autoUpdate(app) && !Prefs.active(app)) {
                    val (ok, info) = Updater.checkNow(app)
                    if (ok && info != null && Prefs.notifiedTag(app) != info.tag) postUpdateNotice(app, info)
                }
            } catch (e: Exception) { }
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true

    private fun postUpdateNotice(c: Context, info: Updater.Info) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("upd", c.L("التحديثات", "Updates"), NotificationManager.IMPORTANCE_DEFAULT))
        val pi = PendingIntent.getActivity(
            c, 7,
            Intent(c, MainActivity::class.java).putExtra("update", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(c, "upd")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(c.L("نسخة جديدة من Stay focused", "New Stay focused version"))
            .setContentText(c.L("الإصدار ${info.tag} متاح. اضغط للتحديث، وتقدمك محفوظ.", "Version ${info.tag} is ready. Tap to update, your progress is kept."))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(42, n)
        Prefs.setNotifiedTag(c, info.tag)
    }

    companion object {
        private const val ID = 4201

        fun schedule(c: Context) {
            val js = c.getSystemService(JobScheduler::class.java)
            if (!Prefs.autoUpdate(c)) { js.cancel(ID); return }
            if (js.getPendingJob(ID) != null) return
            js.schedule(
                JobInfo.Builder(ID, ComponentName(c, UpdateJob::class.java))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPeriodic(6 * 3_600_000L)
                    .setPersisted(true)
                    .build()
            )
        }
    }
}
