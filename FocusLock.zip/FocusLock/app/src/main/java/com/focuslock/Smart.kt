package com.focuslock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

// المرشد الذكي (اختياري): يتعلم محليًا من مدة جلساتك في التطبيقات المشتتة ثم ينبّهك تدريجيًا
object Smart {
    private var sessPkg: String? = null
    private var sessMs = 0L
    private var lastSeen = 0L
    private var level = 0
    private var quietUntil = 0L
    private var lastNudge = 0L

    private fun distracting(c: Context, pkg: String) = pkg in Prefs.blocked(c) && pkg !in Prefs.essentials(c)

    fun onTick(c: Context, pkg: String, d: Long) {
        if (!Prefs.smart(c)) return
        val now = System.currentTimeMillis()
        if (!distracting(c, pkg)) {
            if (sessPkg != null && now - lastSeen > 90_000L) endSession(c)
            return
        }
        if (sessPkg != pkg) { endSession(c); sessPkg = pkg; sessMs = 0L; level = 0 }
        sessMs += d
        lastSeen = now
        if (Prefs.active(c) || now < quietUntil || now - lastNudge < 5 * 60_000L) return
        val avg = Prefs.avgSession(c, pkg)
        val t1 = ((if (avg > 0f) avg * 1.2f else 10f) * Prefs.smartFactor(c)).coerceIn(5f, 30f)
        val mins = sessMs / 60_000f
        when {
            mins >= t1 * 2.8f && level < 3 -> { level = 3; lastNudge = now; nudgeScreen(c, pkg, mins.toInt()) }
            mins >= t1 * 1.8f && level < 2 -> { level = 2; lastNudge = now; notifyTasks(c, pkg, mins.toInt()) }
            mins >= t1 && level < 1 -> { level = 1; lastNudge = now; notifyTime(c, pkg, mins.toInt()) }
        }
    }

    fun onSwitch(c: Context, pkg: String?) {
        if (sessPkg != null && System.currentTimeMillis() - lastSeen > 90_000L) endSession(c)
    }

    private fun endSession(c: Context) {
        val p = sessPkg ?: return
        val m = sessMs / 60_000f
        if (m >= 1f) {
            val old = Prefs.avgSession(c, p)
            Prefs.setAvgSession(c, p, if (old == 0f) m else old * 0.7f + m * 0.3f)
        }
        sessPkg = null; sessMs = 0L; level = 0
    }

    fun snooze(c: Context, mins: Int) { quietUntil = System.currentTimeMillis() + mins * 60_000L }

    // يتعلم من رد فعلك: لو التزمت يخفف التنبيه، ولو طلبت مهلة يبكّر في المرة الجاية
    fun learn(c: Context, cooperative: Boolean) {
        val f = Prefs.smartFactor(c)
        Prefs.setSmartFactor(c, if (cooperative) minOf(1.4f, f * 1.05f) else maxOf(0.6f, f * 0.9f))
    }

    private fun topTask(c: Context): String? = Tasks.load(c).filter { !it.d }.maxByOrNull { it.p }?.t

    private fun post(c: Context, id: Int, title: String, text: String, high: Boolean, withAction: Boolean) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val ch = if (high) "nudge2" else "nudge1"
        nm.createNotificationChannel(NotificationChannel(ch, c.L("تنبيهات المرشد", "Guide nudges"),
            if (high) NotificationManager.IMPORTANCE_DEFAULT else NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(c, 20 + id, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = Notification.Builder(c, ch).setSmallIcon(R.drawable.ic_stat).setContentTitle(title).setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text)).setContentIntent(open).setAutoCancel(true)
        if (withAction) {
            val quick = PendingIntent.getActivity(c, 30 + id, Intent(c, MainActivity::class.java).putExtra("quick", 15).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            b.addAction(Notification.Action.Builder(null, c.L("ابدأ 15 دقيقة تركيز", "Start 15 min focus"), quick).build())
        }
        nm.notify(40 + id, b.build())
    }

    private fun notifyTime(c: Context, pkg: String, m: Int) =
        post(c, 1, c.L("⏱ ${c.appLabel(pkg)} من $m دقيقة", "⏱ $m min in ${c.appLabel(pkg)}"),
            c.L("خدت وقت حلو هنا. تحتاج استراحة من الشاشة؟", "You've spent a good while here. Need a screen break?"), false, false)

    private fun notifyTasks(c: Context, pkg: String, m: Int) {
        val t = topTask(c)
        post(c, 2, c.L("لسه في ${c.appLabel(pkg)} من $m دقيقة", "Still in ${c.appLabel(pkg)} after $m min"),
            if (t != null) c.L("أهم مهمة مستنياك: $t. تبدأ بيها دلوقتي؟", "Your top task is waiting: $t. Start it now?")
            else c.L("افتكر هدفك النهارده. جلسة تركيز قصيرة؟", "Remember today's goal. A short focus session?"), true, true)
    }

    private fun nudgeScreen(c: Context, pkg: String, m: Int) {
        val day = (System.currentTimeMillis() / 86_400_000L).toString()
        var cnt = 0
        val saved = Prefs.str(c, "n3day", "")
        if (saved.startsWith("$day:")) cnt = saved.substringAfter(":").toIntOrNull() ?: 0
        if (cnt >= 3) return
        Prefs.putStr(c, "n3day", "$day:${cnt + 1}")
        c.startActivity(Intent(c, NudgeActivity::class.java).putExtra("pkg", pkg).putExtra("min", m)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    }
}
