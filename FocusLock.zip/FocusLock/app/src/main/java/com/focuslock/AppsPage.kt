package com.focuslock

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*

// صفحة التطبيقات: كل تطبيق في مستطيل بأيقونته، والمحظورة في الأعلى والمسموحة تحتها
class AppsPage(private val a: Activity, private val picked: HashSet<String>, private val onChange: () -> Unit) {
    private class Item(val pkg: String, val name: String, val icon: Drawable?)

    private val items = ArrayList<Item>()
    private var query = ""
    private lateinit var blockedGrid: GridLayout
    private lateinit var allowedGrid: GridLayout
    private lateinit var blockedTitle: TextView
    private lateinit var allowedTitle: TextView
    private lateinit var loading: TextView

    private val common = setOf(
        "com.instagram.android", "com.instagram.lite", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
        "com.google.android.youtube", "com.twitter.android", "com.snapchat.android", "com.facebook.katana",
        "com.facebook.lite", "com.reddit.frontpage", "com.netflix.mediaclient", "com.pinterest"
    )

    private fun toast(s: String) = Toast.makeText(a, s, Toast.LENGTH_LONG).show()

    fun build(): View {
        val col = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(18), a.dp(26), a.dp(18), a.dp(24))
        }
        col.put(a.tv(a.L("التطبيقات", "Apps"), 24f, C.TX, true), 0)
        col.put(a.tv(a.L("اضغط على تطبيق لإضافته للمحظورة، واضغط عليه تاني ليرجع للمسموحة. اضغط مطولًا لتحديده كتطبيق أساسي ⭐ لا يُحظر أبدًا (بنك، خرائط...).",
            "Tap an app to block it, tap again to allow it. Long-press to mark it as an essential app ⭐ that is never blocked (bank, maps...)."), 13f, C.MU)
            .apply { setLineSpacing(0f, 1.2f) }, 4)

        val search = EditText(a).apply {
            hint = a.L("ابحث عن تطبيق", "Search apps")
            inputType = InputType.TYPE_CLASS_TEXT
            setTextColor(C.TX); setHintTextColor(C.MU)
            background = a.rounded(C.SF, 12, C.LN)
            setPadding(a.dp(14), a.dp(12), a.dp(14), a.dp(12))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) { query = e?.toString().orEmpty().trim().lowercase(); render() }
                override fun beforeTextChanged(s: CharSequence?, x: Int, y: Int, z: Int) {}
                override fun onTextChanged(s: CharSequence?, x: Int, y: Int, z: Int) {}
            })
        }
        col.put(search, 12)
        col.put(a.btn(a.L("اختر التطبيقات المشتتة الشائعة", "Select common distracting apps")) {
            val ess = Prefs.essentials(a)
            items.filter { it.pkg in common && it.pkg !in ess }.forEach { picked.add(it.pkg) }
            Prefs.setBlocked(a, picked); onChange(); render()
        }, 10)

        blockedTitle = a.tv("", 15f, C.AC, true)
        col.put(blockedTitle, 16)
        blockedGrid = GridLayout(a).apply { columnCount = 3 }
        col.put(blockedGrid, 6)
        allowedTitle = a.tv("", 15f, C.MU, true)
        col.put(allowedTitle, 16)
        allowedGrid = GridLayout(a).apply { columnCount = 3 }
        col.put(allowedGrid, 6)
        loading = a.tv(a.L("جارٍ تحميل التطبيقات...", "Loading apps..."), 14f, C.MU)
        col.put(loading, 12)
        load()
        return ScrollView(a).apply { addView(col) }
    }

    private fun load() {
        Thread {
            val pm = a.packageManager
            val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { Item(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
                .filter { it.pkg != a.packageName }
                .distinctBy { it.pkg }
                .sortedBy { it.name.lowercase() }
            a.runOnUiThread { items.clear(); items.addAll(l); loading.visibility = View.GONE; render() }
        }.start()
    }

    private fun lp() = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNSPECIFIED), GridLayout.spec(GridLayout.UNSPECIFIED, 1f)).apply {
        width = 0
        setMargins(a.dp(4), a.dp(4), a.dp(4), a.dp(4))
    }

    private fun render() {
        blockedGrid.removeAllViews()
        allowedGrid.removeAllViews()
        val vis = items.filter { query.isEmpty() || it.name.lowercase().contains(query) }
        val bl = vis.filter { it.pkg in picked }
        val al = vis.filter { it.pkg !in picked }
        blockedTitle.text = if (picked.isEmpty()) a.L("المحظورة في وضع التركيز: لا شيء بعد", "Blocked during focus: nothing yet")
            else a.L("المحظورة في وضع التركيز (${picked.size})", "Blocked during focus (${picked.size})")
        allowedTitle.text = a.L("المسموحة (${al.size})", "Allowed (${al.size})")
        bl.forEach { blockedGrid.addView(tile(it, true), lp()) }
        al.forEach { allowedGrid.addView(tile(it, false), lp()) }
    }

    private fun tile(item: Item, blocked: Boolean): View {
        val ess = item.pkg in Prefs.essentials(a)
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = a.rounded(if (blocked) (C.AC and 0x00FFFFFF) or (0x2A shl 24) else C.SF, 14, if (blocked) C.AC else C.LN)
            setPadding(a.dp(4), a.dp(10), a.dp(4), a.dp(8))
        }
        box.addView(ImageView(a).apply { setImageDrawable(item.icon) }, LinearLayout.LayoutParams(a.dp(40), a.dp(40)))
        box.addView(a.tv((if (ess) "⭐ " else "") + item.name, 11f, C.TX).apply {
            gravity = Gravity.CENTER; maxLines = 2; ellipsize = TextUtils.TruncateAt.END
            setPadding(0, a.dp(4), 0, 0)
        })
        box.setOnClickListener { toggle(item) }
        box.setOnLongClickListener { essential(item); true }
        return box
    }

    private fun toggle(item: Item) {
        if (item.pkg in Prefs.essentials(a)) {
            toast(a.L("تطبيق أساسي ⭐ لا يُحظر. اضغط مطولًا لإلغاء ذلك.", "Essential app ⭐ is never blocked. Long-press to undo."))
            return
        }
        if (item.pkg in picked) picked.remove(item.pkg) else picked.add(item.pkg)
        Prefs.setBlocked(a, picked)
        onChange()
        render()
    }

    private fun essential(item: Item) {
        val l = Prefs.essentials(a)
        if (item.pkg in l) {
            l.remove(item.pkg)
            toast(a.L("لم يعد أساسيًا", "No longer essential"))
        } else {
            l.add(item.pkg)
            picked.remove(item.pkg)
            Prefs.setBlocked(a, picked)
            toast(a.L("⭐ تطبيق أساسي: لن يُحظر أبدًا", "⭐ Essential: it will never be blocked"))
        }
        Prefs.setEssentials(a, l)
        onChange()
        render()
    }
}
