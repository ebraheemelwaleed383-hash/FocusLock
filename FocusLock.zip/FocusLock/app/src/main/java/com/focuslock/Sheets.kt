package com.focuslock

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.util.Locale
import kotlin.math.abs

// نوافذ سفلية أنيقة بدل نوافذ النظام القديمة: اختيار تطبيق بأيقونات وبحث، وقوائم خيارات، ومنتقي وقت بالسحب
object Sheets {
    class Item(val id: String, val title: String, val sub: String = "", val pkg: String? = null)

    private class Shell(val dialog: Dialog, val root: LinearLayout) {
        fun close() {
            root.animate().translationY(root.height.toFloat().coerceAtLeast(1f)).alpha(0.4f).setDuration(190).withEndAction {
                try { dialog.dismiss() } catch (_: Exception) { }
            }.start()
        }
    }

    private fun shell(a: Activity, title: String): Shell {
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val top = a.dp(28).toFloat()
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(C.SF)
                cornerRadii = floatArrayOf(top, top, top, top, 0f, 0f, 0f, 0f)
                setStroke(a.dp(1), C.LN)
            }
            setPadding(a.dp(20), a.dp(10), a.dp(20), a.dp(20))
            applyDir()
        }
        // مقبض السحب
        root.addView(View(a).apply { background = a.rounded(C.LN, 3) },
            LinearLayout.LayoutParams(a.dp(42), a.dp(5)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = a.dp(14) })
        root.addView(a.tv(title, 19f, C.TX, true))
        d.setContentView(root)
        d.setCanceledOnTouchOutside(true)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
            setDimAmount(0.62f)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            navigationBarColor = C.SF
        }
        d.setOnShowListener {
            root.post {
                root.translationY = root.height.toFloat()
                root.animate().translationY(0f).setDuration(300).setInterpolator(DecelerateInterpolator(1.7f)).start()
            }
        }
        return Shell(d, root)
    }

    private fun rowBg(a: Activity): StateListDrawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), a.rounded(C.LN, 16))
        addState(intArrayOf(), a.rounded(Color.TRANSPARENT, 16))
    }

    // ---------- قائمة اختيار (تطبيقات بأيقونات أو خيارات نصية) مع بحث ----------
    fun pick(a: Activity, title: String, items: List<Item>, search: Boolean = items.size > 8, onPick: (Item) -> Unit) {
        val sh = shell(a, title)
        var shown: List<Item> = items
        val list = ListView(a).apply {
            divider = null; dividerHeight = 0
            selector = ColorDrawable(Color.TRANSPARENT)
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
        }
        val empty = a.tv(a.L("لا نتائج", "No results"), 15f, C.MU).apply { gravity = Gravity.CENTER; visibility = View.GONE }
        val adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(p: Int) = shown[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
                val item = shown[p]
                val row: LinearLayout = (cv as? LinearLayout) ?: LinearLayout(a).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    minimumHeight = a.dp(62)
                    setPadding(a.dp(10), a.dp(8), a.dp(10), a.dp(8))
                    background = rowBg(a)
                    val ic = ImageView(a).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
                    val ini = TextView(a).apply {
                        gravity = Gravity.CENTER; textSize = 18f; setTextColor(C.AC)
                        setTypeface(typeface, Typeface.BOLD)
                        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C.BG); setStroke(a.dp(1), C.LN) }
                    }
                    addView(ic, LinearLayout.LayoutParams(a.dp(42), a.dp(42)).apply { marginEnd = a.dp(14) })
                    addView(ini, LinearLayout.LayoutParams(a.dp(42), a.dp(42)).apply { marginEnd = a.dp(14) })
                    val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
                    col.addView(a.tv("", 16f, C.TX))
                    col.addView(a.tv("", 12f, C.MU))
                    addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
                }
                val ic = row.getChildAt(0) as ImageView
                val ini = row.getChildAt(1) as TextView
                val col = row.getChildAt(2) as LinearLayout
                (col.getChildAt(0) as TextView).text = item.title
                val sub = col.getChildAt(1) as TextView
                sub.text = item.sub
                sub.visibility = if (item.sub.isEmpty()) View.GONE else View.VISIBLE
                val drawable = item.pkg?.let { k -> a.appIcon(k) }
                if (drawable != null) {
                    ic.setImageDrawable(drawable); ic.visibility = View.VISIBLE; ini.visibility = View.GONE
                } else {
                    ic.visibility = View.GONE; ini.visibility = View.VISIBLE
                    ini.text = item.title.trim().take(1).uppercase()
                }
                return row
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val chosen = shown.getOrNull(pos) ?: return@setOnItemClickListener
            Sfx.click(a)
            sh.dialog.dismiss()
            onPick(chosen)
        }
        if (search) {
            val et = EditText(a).apply {
                hint = "🔍  " + a.L("ابحث…", "Search…")
                setTextColor(C.TX); setHintTextColor(C.MU)
                textSize = 15f
                isSingleLine = true
                background = a.rounded(C.BG, 16, C.LN)
                setPadding(a.dp(16), a.dp(12), a.dp(16), a.dp(12))
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, af: Int) {}
                    override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        val q = s?.toString()?.trim()?.lowercase().orEmpty()
                        shown = if (q.isEmpty()) items else items.filter { i -> i.title.lowercase().contains(q) || i.sub.lowercase().contains(q) }
                        adapter.notifyDataSetChanged()
                        empty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
                    }
                })
            }
            sh.root.put(et, 14)
        }
        val maxH = (a.resources.displayMetrics.heightPixels * 0.5f).toInt()
        val tall = items.size > 6 || search
        sh.root.put(list, 10)
        (list.layoutParams as LinearLayout.LayoutParams).height = if (tall) maxH else WRAP
        sh.root.put(empty, 18)
        sh.dialog.show()
    }

    // قائمة خيارات نصية بسيطة: تعيد رقم الخيار
    fun options(a: Activity, title: String, labels: List<String>, onPick: (Int) -> Unit) {
        pick(a, title, labels.mapIndexed { i, s -> Item(i.toString(), s) }, false) { onPick(it.id.toInt()) }
    }

    // اختيار تطبيق من قائمة حزم
    fun apps(a: Activity, title: String, pkgs: List<Pair<String, String>>, onPick: (String) -> Unit) {
        pick(a, title, pkgs.map { Item(it.first, it.second, "", it.first) }) { onPick(it.id) }
    }

    // ---------- منتقي الوقت: اسحب الأرقام لأعلى وأسفل أو اضغط على الأرقام المجاورة ----------
    private class Drum(val a: Activity, val size: Int, start: Int, val onChange: () -> Unit) : LinearLayout(a) {
        var value = start
        private val rows = Array(5) { i ->
            a.tv("", if (i == 2) 58f else 22f, if (i == 2) C.AC else C.MU, i == 2).apply {
                gravity = Gravity.CENTER
                alpha = when (i) { 2 -> 1f; 1, 3 -> 0.5f; else -> 0.22f }
            }
        }
        private var lastY = 0f
        private var acc = 0f
        private var moved = 0f

        init {
            orientation = LinearLayout.VERTICAL
            rows.forEachIndexed { i, t -> addView(t, LinearLayout.LayoutParams(a.dp(96), if (i == 2) a.dp(78) else a.dp(34))) }
            refresh()
        }

        private fun fmt(v: Int) = String.format(Locale.US, "%02d", ((v % size) + size) % size)

        fun refresh() { for (i in 0..4) rows[i].text = fmt(value + i - 2) }

        fun set(v: Int) { value = ((v % size) + size) % size; refresh() }

        private fun bump(d: Int) {
            value = ((value + d) % size + size) % size
            refresh()
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onChange()
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastY = e.y; acc = 0f; moved = 0f
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = e.y - lastY
                    lastY = e.y; acc += dy; moved += abs(dy)
                    val t = a.dp(30).toFloat()
                    while (acc >= t) { acc -= t; bump(-1) }
                    while (acc <= -t) { acc += t; bump(1) }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved < a.dp(8)) {
                        if (e.y < height * 0.38f) bump(-1) else if (e.y > height * 0.62f) bump(1)
                    }
                    return true
                }
            }
            return super.onTouchEvent(e)
        }
    }

    fun time(a: Activity, title: String, curMin: Int, done: (Int) -> Unit) {
        val sh = shell(a, title)
        val preview = a.tv("", 15f, C.MU).apply { gravity = Gravity.CENTER }
        val chipViews = ArrayList<Pair<TextView, Int>>()
        var hh = (curMin / 60).coerceIn(0, 23)
        var mm = (curMin % 60).coerceIn(0, 59)
        fun paint() {
            val h12 = (hh % 12).let { if (it == 0) 12 else it }
            preview.text = String.format(Locale.US, "%d:%02d ", h12, mm) + (if (hh < 12) a.L("صباحًا", "AM") else a.L("مساءً", "PM"))
            chipViews.forEach { (v, minute) ->
                val on = minute == hh * 60 + mm
                v.background = a.rounded(if (on) C.AC else C.BG, 14, if (on) 0 else C.LN)
                v.setTextColor(if (on) C.ON else C.TX)
            }
        }
        var hRef: Drum? = null
        var mRef: Drum? = null
        val hD = Drum(a, 24, hh) { hh = hRef!!.value; paint() }
        val mD = Drum(a, 60, mm) { mm = mRef!!.value; paint() }
        hRef = hD; mRef = mD

        val wheels = LinearLayout(a).apply {
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            background = a.rounded(C.BG, 22, C.LN)
            setPadding(a.dp(8), a.dp(6), a.dp(8), a.dp(6))
        }
        wheels.addView(hD)
        wheels.addView(a.tv(":", 52f, C.TX, true).apply { gravity = Gravity.CENTER; setPadding(a.dp(6), 0, a.dp(6), a.dp(6)) })
        wheels.addView(mD)
        sh.root.put(wheels, 16)
        sh.root.put(preview, 10)

        val chipsRow = LinearLayout(a)
        listOf(6 * 60, 8 * 60, 12 * 60, 16 * 60, 18 * 60, 20 * 60, 22 * 60).forEach { minute ->
            val tvc = a.tv(String.format(Locale.US, "%02d:%02d", minute / 60, minute % 60), 14f, C.TX).apply {
                setPadding(a.dp(14), a.dp(8), a.dp(14), a.dp(8))
                setOnClickListener {
                    Sfx.click(a)
                    hh = minute / 60; mm = minute % 60
                    hD.set(hh); mD.set(mm); paint()
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                }
                pressFx()
            }
            chipViews.add(tvc to minute)
            chipsRow.addView(tvc, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = a.dp(8) })
        }
        sh.root.put(HorizontalScrollView(a).apply {
            isHorizontalScrollBarEnabled = false
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            addView(chipsRow)
        }, 14)
        paint()

        val br = LinearLayout(a)
        br.addView(a.btn(a.L("إلغاء", "Cancel")) { sh.close() }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = a.dp(6) })
        br.addView(a.btn(a.L("تأكيد", "Confirm"), true) { sh.dialog.dismiss(); done(hh * 60 + mm) }, LinearLayout.LayoutParams(0, WRAP, 1.4f).apply { marginStart = a.dp(6) })
        sh.root.put(br, 16)
        sh.dialog.show()
    }
}
