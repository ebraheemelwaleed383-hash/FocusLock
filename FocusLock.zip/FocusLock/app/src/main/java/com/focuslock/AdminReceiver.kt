package com.focuslock

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        if (Prefs.active(context)) context.L("جلسة تركيز نشطة. إلغاء صلاحية المشرف الآن يتطلب كلمة المرور أو انتهاء الوقت.", "A focus session is active. Disabling admin now needs the password or the end of the session.")
        else context.L("سيصبح من السهل إلغاء تثبيت التطبيق.", "The app will become easy to uninstall.")
}
