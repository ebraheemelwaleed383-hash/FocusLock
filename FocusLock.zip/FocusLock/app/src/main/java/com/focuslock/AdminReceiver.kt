package com.focuslock

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        if (Prefs.active(context)) "جلسة تركيز نشطة. إلغاء صلاحية المشرف الآن يتطلب كلمة المرور أو انتهاء الوقت."
        else "سيصبح من السهل إلغاء تثبيت التطبيق."
}
