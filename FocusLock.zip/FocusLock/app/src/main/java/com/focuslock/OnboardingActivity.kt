package com.focuslock

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class OnboardingActivity : Activity() {
    private var i = 0
    private var replay = false
    private lateinit var holder: FrameLayout
    private lateinit var dots: LinearLayout
    private lateinit var next: Button
    private lateinit var back: Button
    private lateinit var steps: List<Triple<String, String, () -> View>>

    private fun tint() = ColorStateList.valueOf(C.AC)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applyTheme()
        replay = intent.getBooleanExtra("replay", false)
        steps = listOf(
            Triple(L("أهلًا بك في Stay focused", "Welcome to Stay focused"),
                L("تطبيق يحميك من هاتفك وقت تركيزك: تختار التطبيقات المشتتة والمدة، وهو يقفل عليك لحد ما الوقت يخلص. المرشد ده بياخد دقيقتين ويشرح كل جزء من التطبيق.",
                  "An app that protects you from your phone while you focus: pick the distracting apps and a duration, and it locks you in until time is up. This guide takes two minutes and covers every part."),
                { logoArt() }),
            Triple(L("الخطوة 1: الصلاحيات", "Step 1: Permissions"),
                L("من تبويب الإعدادات فعّل أربع صلاحيات.\n• إمكانية الوصول: تكتشف فتح التطبيق المحظور.\n• مشرف الجهاز: يصعّب حذف التطبيق أثناء الجلسة.\n• استثناء البطارية: حتى لا يوقفه النظام.\n• الإشعارات: لإشعار الجلسة.\nلو ظهرت رسالة Restricted setting: معلومات التطبيق، ثم ⋮، ثم Allow restricted settings.",
                  "In the Settings tab, enable four permissions.\n• Accessibility: detects a blocked app being opened.\n• Device admin: makes uninstalling hard during a session.\n• Battery: stops the system from killing the app.\n• Notifications: for the session notification.\nIf you see a Restricted setting message: App info, then ⋮, then Allow restricted settings."),
                { permsArt() }),
            Triple(L("الخطوة 2: كلمة مرور الخروج", "Step 2: Emergency password"),
                L("اختر كلمة مرور قوية (8 أحرف، حروف وأرقام). هي المخرج الوحيد قبل انتهاء الوقت. كل محاولة خاطئة تضيف انتظارًا يتضاعف. احتفظ بها في مكان آمن، لأنها لا تُسترجع.",
                  "Choose a strong password (8+ characters, letters and numbers). It is the only way out before time ends. Every wrong try adds a doubling wait. Keep it safe, it can't be recovered."),
                { passArt() }),
            Triple(L("الخطوة 3: اختر التطبيقات", "Step 3: Pick the apps"),
                L("من تبويب التطبيقات حدّد ما يشتتك. زر «اختر التطبيقات المشتتة الشائعة» يحدّد انستغرام وتيك توك ويوتيوب وغيرها. أو فعّل «قفل كامل» من الإعدادات ليمنع كل شيء عدا الاتصال.",
                  "In the Apps tab, tick what distracts you. The common-apps button selects Instagram, TikTok, YouTube and more. Or enable Full lock in Settings to block everything except calls."),
                { appsArt() }),
            Triple(L("الخطوة 4: حدّد المدة", "Step 4: Set the duration"),
                L("حرّك المنزلق أو اختر رقمًا جاهزًا. تحت المدة بيظهر الوقت اللي هيفتح فيه الهاتف. بعد ما تبدأ، تقدر تزوّد الوقت لكن مش تقلله.",
                  "Drag the slider or tap a preset. Under it you'll see the time your phone unlocks. After you start, you can add time but never reduce it."),
                { durArt() }),
            Triple(L("شاشة القفل", "The lock screen"),
                L("تشوف العداد وجملة تحفيزية ومهامك، وتقدر تنجز مهامك وتدوّن ملاحظات سريعة من هنا. أزرار +5 و+15 و+30 تزوّد الوقت. لو اضطريت للخروج، اضغط «أحتاج إلى الخروج» وأدخل كلمة المرور.",
                  "You'll see the timer, a motivational quote and your tasks, which you can tick off, and you can jot quick notes, here. The +5, +15 and +30 buttons add time. If you must leave, tap I need to leave and enter your password."),
                { lockArt() }),
            Triple(L("خصّصه على ذوقك", "Make it yours"),
                L("من تبويب المظهر: وضع داكن أو فاتح، ثيمات وألوان، 11 شكلًا للعداد، خلفيات من صورك، وجملك التحفيزية. من المهام تضيف مهامك مع أصوات اختيارية، ومن الإعدادات تبدّل اللغة.",
                  "In the Style tab: dark or light mode, themes and colors, 11 timer styles, backgrounds from your photos, and your own quotes. Add tasks with optional sounds, and switch language in Settings."),
                { styleArt() }),
            Triple(L("تبويب الإحصائيات", "The Stats tab"),
                L("يعرض وقت استخدامك اليوم وأمس وآخر 7 أيام: أكثر التطبيقات استخدامًا، وتوزيع يومك ساعة بساعة، مع رسوم بيانية. يحتاج إذن «بيانات الاستخدام» تمنحه بنفسك، وكل شيء يبقى على هاتفك.",
                  "Shows your usage today, yesterday and over 7 days: your top apps, your day hour by hour, with charts. It needs the Usage access permission, which you grant yourself, and everything stays on your phone."),
                { statsArt() }),
            Triple(L("صفحة التطبيقات الجديدة", "The new Apps page"),
                L("التطبيقات المحظورة تظهر فوق، والمسموحة تحتها. اضغط على أي تطبيق لتنقله بين القسمين، واضغط عليه تاني لو غلطت. التطبيقات الحيوية مثل الاتصال والخرائط والبنوك لا تُحظر أبدًا.",
                  "Blocked apps sit on top and allowed apps below. Tap an app to move it between the two, and tap again if you slip. Essential apps like calls, maps and banks are never blocked."),
                { appsNewArt() }),
            Triple(L("مؤقت لكل تطبيق", "A timer for each app"),
                L("اضغط مطولًا على أي تطبيق في صفحة التطبيقات وحدّد له وقتًا مسموحًا. لو انتهى الوقت يُقفل 12 ساعة ثم يفتح من جديد بنفس الوقت. في الطوارئ تدخل بكلمة المرور لمدة 10 دقائق.",
                  "Long-press any app on the Apps page and give it an allowed time. When it runs out the app is locked for 12 hours, then opens again with the same allowance. In an emergency enter your password for 10 minutes."),
                { limitArt() }),
            Triple(L("نظم الدراسة", "Study systems"),
                L("أكثر من 20 نظامًا (بومودورو، 90/20، تقسيم الوقت، فلو تايم وغيرها). تضغط ابدأ فيتولى التطبيق جولات التركيز والاستراحة. شرح كل نظام ورسم مراحله وهو شغال موجودان داخل صفحة النظم نفسها.",
                  "More than 20 systems (Pomodoro, 90/20, Time Blocking, Flowtime and more). Tap Start and the app runs the focus and break rounds. Each system's explanation and a live diagram of its phases are inside the Systems page itself."),
                { systemsArt() }),
            Triple(L("المهام والملاحظات", "Tasks and notes"),
                L("رتّب مهامك بالأولوية وحرّكها لفوق وتحت، وتابع نسبة إنجازك. الملاحظات تقدر تثبّتها. وغير المكتمل من المهام يظهر على شاشة القفل.",
                  "Rank tasks by priority and move them up or down, and watch your completion. Notes can be pinned. Unfinished tasks show up on the lock screen."),
                { tasksArt() }),
            Triple(L("المرشد الذكي (اختياري)", "The smart guide (optional)"),
                L("لو قعدت وقتًا طويلًا في تطبيق مشتّت، ينبّهك بلطف، ثم يذكّرك بأهم مهمة، ثم يقترح استراحة. يتعلم من ردك على هاتفك فقط. فعّله أو أوقفه من الإعدادات، ولا يتدخل في أي تطبيق آخر.",
                  "If you stay long in a distracting app it nudges you gently, reminds you of your top task, then suggests a break. It learns from your replies on this phone only. Turn it on or off in Settings. It never touches other apps."),
                { coachArt() }),
            Triple(L("جاهز!", "You're ready!"),
                L("التطبيق يحدّث نفسه عند صدور نسخة جديدة وتقدمك محفوظ، ولا يرسل أي بيانات شخصية. تقدر تعيد المرشد من الإعدادات في أي وقت. وللتنقل أسرع اسحب يمينًا أو يسارًا بين الصفحات.\nالقائم على التطبيق: Ibrahim Elwaleed",
                  "The app updates itself when a new version is out and your progress is kept. It sends no personal data. You can replay this guide from Settings anytime. Swipe left or right to move between pages faster.\nMaintained by Ibrahim Elwaleed"),
                { logoArt() })
        )

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }
        val skip = tv(L("تخطّي", "Skip"), 14f, C.MU).apply {
            setPadding(dp(20), dp(16), dp(20), dp(8))
            setOnClickListener { finishGuide() }
        }
        root.addView(skip, LinearLayout.LayoutParams(WRAP, WRAP).apply { gravity = Gravity.END })
        holder = FrameLayout(this)
        root.addView(holder, LinearLayout.LayoutParams(MATCH, 0, 1f))
        dots = LinearLayout(this).apply { gravity = Gravity.CENTER }
        repeat(steps.size) {
            dots.addView(View(this), LinearLayout.LayoutParams(dp(8), dp(8)).apply { marginStart = dp(4); marginEnd = dp(4) })
        }
        root.addView(dots, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        val nav = LinearLayout(this).apply { setPadding(dp(16), dp(12), dp(16), dp(16)) }
        back = btn(L("السابق", "Back")) { if (i > 0) show(i - 1) }
        next = btn("", true) { if (i == steps.size - 1) finishGuide() else show(i + 1) }
        nav.addView(back, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(6) })
        nav.addView(next, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(6) })
        root.addView(nav, LinearLayout.LayoutParams(MATCH, WRAP))
        root.applyDir()
        setContentView(root)
        show(0)
    }

    private fun finishGuide() {
        Prefs.setOnboarded(this, true)
        if (!replay) startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun show(n: Int) {
        i = n
        holder.removeAllViews()
        val (title, body, art) = steps[n]
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(16)) }
        col.put(art(), 0)
        col.put(tv(title, 22f, C.TX, true), 20)
        col.put(tv(body, 15f, C.MU).apply { setLineSpacing(0f, 1.3f) }, 8)
        holder.addView(ScrollView(this).apply { addView(col) })
        for (k in 0 until dots.childCount) {
            dots.getChildAt(k).background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (k == n) C.AC else C.LN)
            }
        }
        next.text = if (n == steps.size - 1) L("ابدأ الآن", "Get started") else L("التالي", "Next")
        back.visibility = if (n == 0) View.INVISIBLE else View.VISIBLE
    }

    // ---------- رسومات الميزات الجديدة ----------
    private fun rowBar(frac: Float, color: Int): View {
        val r = LinearLayout(this)
        r.addView(View(this).apply { background = rounded(color, 6) }, LinearLayout.LayoutParams(0, dp(10), frac.coerceIn(0.02f, 1f)))
        r.addView(View(this), LinearLayout.LayoutParams(0, dp(10), (1f - frac).coerceAtLeast(0.001f)))
        return r
    }

    private fun tile(emoji: String, name: String, on: Boolean): View {
        val t = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = rounded(C.SF, 14, if (on) C.AC else C.LN)
            setPadding(dp(6), dp(10), dp(6), dp(8))
        }
        t.addView(tv(emoji, 24f).apply { gravity = Gravity.CENTER })
        t.addView(tv(name, 11f, C.TX).apply { gravity = Gravity.CENTER })
        return t
    }

    private fun tileRow(vararg tiles: View): LinearLayout {
        val r = LinearLayout(this)
        tiles.forEach { r.addView(it, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(4); marginEnd = dp(4) }) }
        return r
    }

    private fun statsArt(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = card()
        top.addView(tv(L("اليوم", "Today"), 13f, C.MU))
        top.addView(tv(L("3 س 24 د", "3h 24m"), 30f, C.TX, true))
        col.addView(top)
        val bars = card()
        bars.addView(tv(L("آخر 7 أيام (ساعات)", "Last 7 days (hours)"), 13f, C.MU))
        val days = L("س,ح,ن,ث,ر,خ,ج", "M,T,W,T,F,S,S").split(",")
        bars.addView(BarChartView(this, listOf(2.5f, 3.4f, 1.8f, 4.1f, 3.0f, 2.2f, 3.4f), days),
            LinearLayout.LayoutParams(MATCH, dp(130)).apply { topMargin = dp(8) })
        col.put(bars, 10)
        val apps = card()
        listOf("Instagram" to 0.9f, "YouTube" to 0.62f, "TikTok" to 0.38f).forEachIndexed { k, (n, f) ->
            apps.put(tv(n, 13f, C.TX), if (k == 0) 0 else 8)
            apps.put(rowBar(f, C.AC), 4)
        }
        col.put(apps, 10)
        return col
    }

    private fun appsNewArt(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val a = card()
        a.addView(tv(L("المحظورة الآن (2)", "Blocked now (2)"), 14f, C.AC, true))
        a.put(tileRow(tile("📸", "Instagram", true), tile("🎵", "TikTok", true), View(this)), 8)
        col.addView(a)
        val b = card()
        b.addView(tv(L("التطبيقات المسموحة", "Allowed apps"), 14f, C.MU, true))
        b.put(tileRow(tile("▶️", "YouTube", false), tile("🧮", "Calculator", false), tile("🗺️", "Maps", false)), 8)
        col.put(b, 10)
        return col
    }

    private fun limitArt(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val c1 = card()
        c1.addView(tv("📸 Instagram   ⏱ 30 " + L("د", "m"), 15f, C.TX, true))
        c1.put(rowBar(0.4f, C.AC), 8)
        c1.put(tv(L("متبقي 12 دقيقة من 30", "12 of 30 minutes left"), 12f, C.MU), 6)
        col.addView(c1)
        val c2 = card()
        c2.addView(tv(L("انتهى الوقت المسموح لـ Instagram", "Time is up for Instagram"), 16f, C.TX, true).apply { gravity = Gravity.CENTER })
        c2.put(tv(L("يفتح الساعة ", "Opens again at ") + clock(System.currentTimeMillis() + 12 * 3_600_000L), 14f, C.AC).apply { gravity = Gravity.CENTER }, 6)
        c2.put(tv(L("دخول طارئ", "Emergency access"), 14f, C.TX).apply {
            gravity = Gravity.CENTER; background = rounded(C.BG, 12, C.LN); setPadding(0, dp(10), 0, dp(10))
        }, 10)
        col.put(c2, 10)
        return col
    }

    private fun systemsArt(): View {
        val s = Plans.find("pomo25")
        val c = card()
        c.addView(tv(if (s != null) L(s.ar, s.en) else "Pomodoro 25/5", 17f, C.TX, true))
        if (s != null) {
            c.put(PhaseBarView(this, s.segs), 10)
            (c.getChildAt(c.childCount - 1)).layoutParams = LinearLayout.LayoutParams(MATCH, dp(70)).apply { topMargin = dp(10) }
            c.put(tv(L(s.dAr, s.dEn), 13f, C.MU), 8)
        }
        c.put(tv(L("▌ تركيز    ▌ استراحة", "▌ Focus    ▌ Break"), 12f, C.AC), 6)
        c.put(tv(L("ابدأ النظام", "Start the plan"), 16f, C.ON, true).apply {
            gravity = Gravity.CENTER; background = rounded(C.AC, 14); setPadding(0, dp(12), 0, dp(12))
        }, 12)
        return c
    }

    private fun tasksArt(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = card()
        head.addView(tv(L("أنجزت 2 من 5", "2 of 5 done"), 15f, C.TX, true))
        head.put(rowBar(0.4f, C.OK), 8)
        col.addView(head)
        val list = card()
        listOf(Triple(L("مراجعة الدرس", "Review the lesson"), C.WR, false), Triple(L("حل التمرين", "Solve the exercise"), C.AC, false),
            Triple(L("ترتيب المكتب", "Tidy the desk"), C.OK, true)).forEachIndexed { k, (n, dot, done) ->
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            r.addView(View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(dot) } }, LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(10) })
            r.addView(tv(n, 14f, if (done) C.MU else C.TX), LinearLayout.LayoutParams(0, WRAP, 1f))
            r.addView(tv(if (done) "✓" else "⋮", 16f, if (done) C.OK else C.MU))
            list.put(r, if (k == 0) 0 else 14)
        }
        col.put(list, 10)
        return col
    }

    private fun coachArt(): View {
        val c = card()
        c.addView(tv("Stay focused", 11f, C.MU))
        c.put(tv(L("⏱ Instagram من 12 دقيقة", "⏱ 12 min in Instagram"), 16f, C.TX, true), 4)
        c.put(tv(L("أهم مهمة مستنياك: مراجعة الدرس. تبدأ بيها دلوقتي؟", "Your top task is waiting: Review the lesson. Start it now?"), 13f, C.MU), 4)
        c.put(tv(L("ابدأ 15 دقيقة تركيز", "Start 15 min focus"), 13f, C.AC, true), 10)
        return c
    }

    // ---------- رسومات توضيحية مبنية من نفس عناصر التطبيق ----------
    private fun logoArt(): View {
        val box = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF0F1B4D.toInt(), 0xFF4A5CFF.toInt()))
                .apply { cornerRadius = dp(36).toFloat() }
        }
        box.addView(ImageView(this).apply { setImageResource(R.drawable.ic_launcher_foreground) },
            FrameLayout.LayoutParams(dp(150), dp(150), Gravity.CENTER))
        val wrap = LinearLayout(this).apply { gravity = Gravity.CENTER }
        wrap.addView(box, LinearLayout.LayoutParams(dp(170), dp(170)))
        return wrap
    }

    private fun permsArt(): View {
        val c = card()
        listOf(L("إمكانية الوصول", "Accessibility") to true, L("مشرف الجهاز", "Device admin") to true,
            L("استثناء البطارية", "Battery") to false, L("الإشعارات", "Notifications") to true)
            .forEachIndexed { k, (n, ok) ->
                val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
                r.addView(tv(n, 15f, C.TX), LinearLayout.LayoutParams(0, WRAP, 1f))
                r.addView(
                    if (ok) tv(L("مفعّل ✓", "On ✓"), 13f, C.OK)
                    else tv(L("تفعيل", "Enable"), 13f, C.ON).apply { background = rounded(C.AC, 10); setPadding(dp(14), dp(6), dp(14), dp(6)) }
                )
                c.put(r, if (k == 0) 0 else 14)
            }
        return c
    }

    private fun passArt(): View {
        val c = card()
        c.addView(tv(L("كلمة مرور الخروج الطارئ", "Emergency password"), 16f, C.TX, true))
        c.put(tv("••••••••••", 18f, C.TX).apply { background = rounded(C.BG, 12, C.LN); setPadding(dp(14), dp(12), dp(14), dp(12)) }, 10)
        c.put(tv(L("تم ضبط كلمة المرور ✓", "Password is set ✓"), 13f, C.OK), 8)
        return c
    }

    private fun appsArt(): View {
        val c = card()
        listOf("Instagram" to true, "TikTok" to true, "Calculator" to false, "YouTube" to true).forEach { (n, on) ->
            c.addView(CheckBox(this).apply {
                text = n; setTextColor(C.TX); buttonTintList = tint()
                isChecked = on; isClickable = false
            })
        }
        c.put(tv(L("اختر التطبيقات المشتتة الشائعة", "Select common distracting apps"), 14f, C.TX).apply {
            gravity = Gravity.CENTER; background = rounded(C.BG, 14, C.LN); setPadding(dp(12), dp(12), dp(12), dp(12))
        }, 10)
        return c
    }

    private fun durArt(): View {
        val c = card()
        c.addView(tv(L("مدة الجلسة", "Session length"), 14f, C.MU))
        c.put(tv(L("45 دقيقة", "45 min"), 30f, C.TX, true), 4)
        c.put(tv(L("ينتهي القفل الساعة ", "Unlocks at ") + clock(System.currentTimeMillis() + 45 * 60_000L), 13f, C.AC), 2)
        val chips = LinearLayout(this)
        listOf(15, 25, 45, 60).forEach { m ->
            chips.addView(tv("$m", 14f, if (m == 45) C.ON else C.TX).apply {
                gravity = Gravity.CENTER
                background = rounded(if (m == 45) C.AC else C.BG, 12, C.LN)
                setPadding(0, dp(10), 0, dp(10))
            }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
        }
        c.put(chips, 12)
        c.put(tv(L("ابدأ الجلسة", "Start session"), 16f, C.ON, true).apply {
            gravity = Gravity.CENTER; background = rounded(C.AC, 14); setPadding(0, dp(14), 0, dp(14))
        }, 12)
        return c
    }

    private fun lockArt(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val m = Counters.make(this, "ring", C.LN, C.AC)
        if (m != null) {
            m.upd(0.62f)
            val box = FrameLayout(this)
            box.addView(m.view, FrameLayout.LayoutParams(dp(200), dp(200)))
            box.addView(tv("00:27:40", 30f, C.TX, true).apply { gravity = Gravity.CENTER }, FrameLayout.LayoutParams(dp(200), dp(200)))
            col.addView(box, LinearLayout.LayoutParams(dp(200), dp(200)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        }
        val q = card()
        q.addView(tv("\u201CYour future self will thank you. Stay focused!\u201D", 16f, C.TX).apply { gravity = Gravity.CENTER })
        col.put(q, 14)
        val t = card()
        t.addView(CheckBox(this).apply { text = L("مراجعة الدرس", "Review the lesson"); setTextColor(C.TX); buttonTintList = tint(); isClickable = false })
        col.put(t, 10)
        val ex = LinearLayout(this)
        listOf("+5", "+15", "+30").forEach { s ->
            ex.addView(tv(s, 14f, C.TX).apply { gravity = Gravity.CENTER; background = rounded(C.SF, 12, C.LN); setPadding(0, dp(10), 0, dp(10)) },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        }
        col.put(ex, 10)
        col.put(tv(L("أحتاج إلى الخروج", "I need to leave"), 14f, C.TX).apply {
            gravity = Gravity.CENTER; background = rounded(C.SF, 14, C.LN); setPadding(0, dp(12), 0, dp(12))
        }, 10)
        return col
    }

    private fun styleArt(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tr = LinearLayout(this)
        C.presets.forEachIndexed { k, p ->
            tr.addView(View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(p.ac)
                    if (k == Prefs.preset(this@OnboardingActivity)) setStroke(dp(3), C.TX)
                }
            }, LinearLayout.LayoutParams(0, dp(34), 1f).apply { marginStart = dp(6); marginEnd = dp(6) })
        }
        col.addView(tr)
        val m = Counters.make(this, "drops", C.LN, C.AC)
        if (m != null) {
            m.upd(0.5f)
            col.addView(m.view, LinearLayout.LayoutParams(dp(m.w), dp(m.h)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(14) })
        }
        col.put(tv(Counters.styles.joinToString("  ") { Counters.label(this, it) }, 13f, C.MU).apply { gravity = Gravity.CENTER }, 8)
        return col
    }
}
