package com.focuslock

import org.json.JSONArray
import org.json.JSONObject

// منطق خالص بلا اعتماد على أندرويد (قابل للاختبار على JVM): نموذج خطوات المهمة وسجل الجلسات وقواعد نتيجة الجلسة

class Step(var text: String, var done: Boolean = false)

object TaskCodec {
    fun newId(): String = java.util.UUID.randomUUID().toString().replace("-", "").take(10)

    // الحقول القديمة (t,d,p) تبقى كما هي؛ الحقول الجديدة تُكتب فقط عند وجود قيمة، فيبقى الشكل القديم سليمًا
    fun encode(t: Task): JSONObject {
        val o = JSONObject().put("t", t.t).put("d", t.d).put("p", t.p)
        if (t.id.isNotEmpty()) o.put("id", t.id)
        if (t.proj.isNotEmpty()) o.put("pj", t.proj)
        if (t.steps.isNotEmpty()) {
            val a = JSONArray()
            t.steps.forEach { a.put(JSONObject().put("x", it.text).put("d", it.done)) }
            o.put("st", a)
        }
        if (t.focusMins > 0) o.put("fm", t.focusMins)
        if (t.sessions > 0) o.put("sn", t.sessions)
        if (t.later) o.put("lt", true)
        if (t.notes.isNotEmpty()) o.put("nt", t.notes)
        return o
    }

    // قراءة متسامحة: ترجع null لو لا عنوان صالح، وكل حقل ناقص أو بنوع خاطئ يأخذ قيمة افتراضية بدل أن يرمي استثناءً
    fun decodeOrNull(o: JSONObject): Task? {
        val title = o.optString("t", "")
        if (title.isBlank()) return null
        val t = Task(title, o.optBoolean("d", false), o.optInt("p", 1).coerceIn(0, 2))
        t.id = o.optString("id", "")
        t.proj = o.optString("pj", "")
        val a = o.optJSONArray("st")
        if (a != null) for (i in 0 until a.length()) {
            val s = a.optJSONObject(i) ?: continue
            val x = s.optString("x", "")
            if (x.isNotEmpty()) t.steps.add(Step(x, s.optBoolean("d", false)))
        }
        t.focusMins = o.optInt("fm", 0).coerceAtLeast(0)
        t.sessions = o.optInt("sn", 0).coerceAtLeast(0)
        t.later = o.optBoolean("lt", false)
        t.notes = o.optString("nt", "")
        return t
    }

    fun decode(o: JSONObject): Task = decodeOrNull(o) ?: throw org.json.JSONException("invalid task")
}

// سجل جلسة تركيز واحدة (المرحلة 0): أساس التحليلات والملف الشخصي والمراجعة الأسبوعية لاحقًا
class SessionRec(val id: Long, var start: Long, var planned: Int) {
    var end = 0L
    var actual = 0
    var status = "open"      // open | done (انتهت كاملة) | stop (خروج مبكر)
    var taskId = ""
    var taskTitle = ""
    var goal = ""
    var outcome = ""         // "" | done | part | later (تصنيف المستخدم بعد الجلسة) | skip (لم تُراجَع وانتهت مهلتها)

    fun toJson(): JSONObject {
        val o = JSONObject().put("id", id).put("s", start).put("p", planned).put("e", end).put("a", actual).put("st", status)
        if (taskId.isNotEmpty()) o.put("tk", taskId)
        if (taskTitle.isNotEmpty()) o.put("tt", taskTitle)
        if (goal.isNotEmpty()) o.put("g", goal)
        if (outcome.isNotEmpty()) o.put("oc", outcome)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): SessionRec {
            val r = SessionRec(o.getLong("id"), o.optLong("s", o.getLong("id")), o.optInt("p", 0))
            r.end = o.optLong("e", 0L)
            r.actual = o.optInt("a", 0)
            r.status = o.optString("st", "done")
            r.taskId = o.optString("tk", "")
            r.taskTitle = o.optString("tt", "")
            r.goal = o.optString("g", "")
            r.outcome = o.optString("oc", "")
            return r
        }
    }
}

object SessionMath {
    const val LOG_CAP = 600

    fun actualMins(startMs: Long, endMs: Long): Int = ((endMs - startMs).coerceAtLeast(0L) / 60_000L).toInt()

    // يبقي أحدث السجلات فقط حتى لا يكبر ملف الإعدادات بلا حدود
    fun trim(l: MutableList<SessionRec>, cap: Int = LOG_CAP) {
        while (l.size > cap) l.removeAt(0)
    }

    class LogParse(val list: MutableList<SessionRec>, val skipped: Int, val broken: Boolean)

    // نافذة اعتبار سجلين نفس الجلسة (بداية متقاربة)
    const val DUP_WINDOW_MS = 5_000L

    // قراءة متسامحة: السجل التالف يُتجاوز ويُحصى، وتُدمج المعرّفات المكررة بدل أن يظهر سجلان للجلسة نفسها
    fun parse(raw: String): LogParse {
        val out = ArrayList<SessionRec>()
        val a = try { JSONArray(raw) } catch (_: Exception) { return LogParse(out, 0, raw.isNotBlank()) }
        var skipped = 0
        for (i in 0 until a.length()) {
            try { out.add(SessionRec.fromJson(a.getJSONObject(i))) } catch (_: Exception) { skipped++ }
        }
        return LogParse(dedupe(out), skipped, false)
    }

    fun parseLog(raw: String): MutableList<SessionRec> = parse(raw).list

    fun dedupe(src: List<SessionRec>): MutableList<SessionRec> {
        val out = ArrayList<SessionRec>()
        src.forEach { addOrMerge(out, it, applyCap = false, byStart = false) } // عند القراءة: المعرّف المكرر فقط يُدمج
        return out
    }

    // يضيف سجلًا أو يدمجه في سجل موجود لنفس الجلسة (نفس المعرّف أو بداية متقاربة). الموجود لا يُستبدل أبدًا:
    // نكمّل الحقول الفارغة فيه فقط. يرجع true لو أُضيف سجل جديد، و false لو كان مكررًا
    fun addOrMerge(l: MutableList<SessionRec>, r: SessionRec, applyCap: Boolean = true, byStart: Boolean = true): Boolean {
        val ex = l.firstOrNull { it.id == r.id || (byStart && r.start > 0L && kotlin.math.abs(it.start - r.start) <= DUP_WINDOW_MS) }
        if (ex == null) {
            l.add(r)
            if (applyCap) trim(l)
            return true
        }
        if (ex.taskId.isEmpty()) ex.taskId = r.taskId
        if (ex.taskTitle.isEmpty()) ex.taskTitle = r.taskTitle
        if (ex.goal.isEmpty()) ex.goal = r.goal
        if (ex.outcome.isEmpty()) ex.outcome = r.outcome
        if (ex.planned == 0) ex.planned = r.planned
        if (ex.status == "open") { ex.end = r.end; ex.actual = r.actual; ex.status = r.status }
        return false
    }

    fun hasStart(l: List<SessionRec>, startMs: Long): Boolean = l.any { kotlin.math.abs(it.start - startMs) <= DUP_WINDOW_MS }

    // معرّف غير مستخدم (الأصل: وقت البداية). يمنع أن يستبدل سجل جديد سجلًا قديمًا بنفس المعرّف
    fun uniqueId(l: List<SessionRec>, start: Long): Long {
        var id = start
        while (l.any { it.id == id }) id++
        return id
    }

    // للاستعادة من نسخة احتياطية: نص نظيف، أو null لو الملف ليس سجلًا صالحًا (فلا يطمس السجل الحالي)
    fun sanitizeForRestore(raw: String): String? {
        val len = try { JSONArray(raw).length() } catch (_: Exception) { return null }
        val p = parse(raw)
        if (len > 0 && p.list.isEmpty()) return null
        trim(p.list)
        return encodeLog(p.list)
    }

    fun encodeLog(l: List<SessionRec>): String {
        val a = JSONArray()
        l.forEach { a.put(it.toJson()) }
        return a.toString()
    }
}

object FocusLogic {
    const val DONE = "done"
    const val PART = "part"
    const val LATER = "later"

    fun progress(t: Task): Pair<Int, Int> = t.steps.count { it.done } to t.steps.size

    fun fraction(t: Task): Float {
        val (d, n) = progress(t)
        return if (n == 0) (if (t.d) 1f else 0f) else d.toFloat() / n
    }

    fun addFocus(t: Task, mins: Int) {
        if (mins < 1) return
        t.focusMins += mins
        t.sessions += 1
    }

    // نتيجة الجلسة. القاعدة الأساسية: لا تُعلَّم المهمة مكتملة إلا إذا أكّد المستخدم صراحةً (markDone) ولا يوجد أي استنتاج تلقائي
    fun applyOutcome(t: Task, outcome: String, markDone: Boolean, note: String, pri: Int?) {
        t.later = outcome == LATER
        if (markDone && !t.d) t.d = true
        val n = note.trim()
        if (n.isNotEmpty()) t.notes = (if (t.notes.isEmpty()) n else t.notes + "\n" + n).takeLast(2000)
        if (pri != null) t.p = pri.coerceIn(0, 2)
    }
}
