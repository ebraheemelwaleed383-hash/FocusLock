package com.focuslock

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import java.text.DateFormat
import java.util.Date

class KeepAliveService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var wasActive = false
    private var ticks = 0
    private val loop = object : Runnable {
        override fun run() { step(); h.postDelayed(this, 1000L) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (!Engine.serviceNeeded(this)) { stopSelf(); return START_NOT_STICKY }
        wasActive = Prefs.active(this)
        show()
        h.removeCallbacksAndMessages(null)
        h.post(loop)
        return START_STICKY
    }

    private fun show() {
        val nm = getSystemService(NotificationManager::class.java)
        val n: Notification
        if (Prefs.active(this)) {
            nm.createNotificationChannel(NotificationChannel("fl", "Focus session", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getActivity(
                this, 0,
                Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val until = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(Prefs.end(this)))
            n = Notification.Builder(this, "fl")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(L("جلسة تركيز نشطة", "Focus session active"))
                .setContentText(L("القفل ينتهي عند $until", "Unlocks at $until"))
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .build()
        } else {
            nm.createNotificationChannel(NotificationChannel("watch", L("الحراسة الهادئة", "Quiet guard"), NotificationManager.IMPORTANCE_LOW))
            val pi = PendingIntent.getActivity(
                this, 1, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            n = Notification.Builder(this, "watch")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(L("Stay focused يحرس حدودك", "Stay focused is guarding your limits"))
                .setContentText(L("لا توجد جلسة نشطة الآن", "No active session right now"))
                .setOngoing(true)
                .setContentIntent(pi)
                .build()
        }
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun step() {
        val active = Prefs.active(this)
        if (active != wasActive) {
            wasActive = active
            if (!active && Prefs.settle(this)) Plans.onFocusEnd(this)
            if (!Engine.serviceNeeded(this)) { stopSelf(); return }
            show()
        }
        if (!Engine.serviceNeeded(this)) { stopSelf(); return }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isInteractive) { Guard.screenOff(this); return }
        if (Engine.canPoll(this)) {
            FgDetector.current(this)?.let { Guard.onForeground(this, it, "") }
            ticks++
            if (ticks % 10 == 0) Guard.commit(this)
        }
        Guard.beat(this)
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }

    companion object {
        fun start(c: Context) {
            try { c.startForegroundService(Intent(c, KeepAliveService::class.java)) } catch (_: Exception) { }
        }

        fun refresh(c: Context) {
            if (Engine.serviceNeeded(c)) start(c) else c.stopService(Intent(c, KeepAliveService::class.java))
        }
    }
}
