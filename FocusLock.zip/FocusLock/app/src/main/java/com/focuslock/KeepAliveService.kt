package com.focuslock

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import java.text.DateFormat
import java.util.Date

class KeepAliveService : Service() {
    private val h = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (!Prefs.active(this)) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("fl", "Focus session", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val until = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(Prefs.end(this)))
        val n = Notification.Builder(this, "fl")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(L("جلسة تركيز نشطة", "Focus session active"))
            .setContentText(L("القفل ينتهي عند $until", "Unlocks at $until"))
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_ALARM)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        h.removeCallbacksAndMessages(null)
        schedule()
        return START_STICKY
    }

    private fun schedule() {
        h.postDelayed({ if (Prefs.active(this)) schedule() else stopSelf() },
            maxOf(Prefs.end(this) - System.currentTimeMillis(), 0L) + 500)
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }

    companion object {
        fun start(c: Context) = c.startForegroundService(Intent(c, KeepAliveService::class.java))
    }
}
