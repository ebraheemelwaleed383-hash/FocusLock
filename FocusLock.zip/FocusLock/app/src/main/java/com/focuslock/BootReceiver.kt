package com.focuslock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Prefs.active(c)) EndAlarm.schedule(c)
        Plans.sync(c)
        KeepAliveService.refresh(c)
    }
}
