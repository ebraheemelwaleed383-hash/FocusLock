package com.focuslock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Prefs.active(c)) EndAlarm.schedule(c)
        Plans.sync(c)
        Disc.autoEval(c)
        DiscAlarm.schedule(c)
        PlanAlarms.rescan(c)
        KeepAliveService.refresh(c)
        FloatingFab.sync(c)
        AutoSched.schedule(c)
        WeeklyReport.schedule(c)
        FocusWidget.refresh(c)
    }
}
