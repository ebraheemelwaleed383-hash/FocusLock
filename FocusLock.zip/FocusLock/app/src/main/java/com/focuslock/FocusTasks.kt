package com.focuslock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

// المرحلة 0: سجل الجلسات. يُستدعى من Prefs.begin/settle/cancel فقط (نقطة التقاء كل مسارات بدء الجلسة)،
// وكل استدعاء محاط بـ try/catch هناك حتى لا يؤثر أي خلل في السجل على المؤقت أو الحماية.
// ترتيب الأقفال: SessionLog ثم Tasks (لا يُستدعى SessionLog من داخل كتلة Tasks.update أبدًا) فلا خطر من تشابك الأقفال.
object SessionLog {
    private const val LOG = "sl_log"
    private const val OPEN = "sl_open"
    private const val LOG_BAD = "sl_log_corrupt"

    @Synchronized
    fun onBegin(c: Context, plannedMins: Int) {
        val now = System.currentTimeMillis()
        closeOpen(c, "stop", now) // جلسة كانت ما زالت مفتوحة وتم استبدالها
        val start = Prefs.start(c).takeIf { it > 0L } ?: now
        val rec = SessionRec(SessionMath.uniqueId(all(c), start), start, plannedMins)
        if (FocusTasks.consumeArm(c)) {
            FocusTasks.current(c)?.let { rec.taskId = it.id; rec.taskTitle = it.t }
            rec.goal = FocusTasks.goal(c)
            FocusTasks.setGoal(c, "")
        }
        Prefs.putStr(c, OPEN, rec.toJson().toString())
    }

    @Synchronized
    fun onSettled(c: Context, startMs: Long, endMs: Long) {
        var rec = readOpen(c)
        if (rec != null && kotlin.math.abs(rec.start - startMs) > SessionMath.DUP_WINDOW_MS) {
            closeOpen(c, "stop", startMs.coerceAtLeast(rec.start)) // سجل قديم لجلسة أخرى
            rec = null
        }
        // settle مكرر لجلسة سُجّلت فعلًا (لا سجل مفتوح لها وبدايتها موجودة في السجل): نتجاهله ولا نكتب شيئًا
        if (rec == null && SessionMath.hasStart(all(c), startMs)) return
        // جلسة بدأت قبل تحديث التطبيق ولا سجل مفتوح لها: نسجلها من بيانات المؤقت نفسه
        val r = rec ?: SessionRec(SessionMath.uniqueId(all(c), startMs), startMs, SessionMath.actualMins(startMs, endMs))
        r.end = endMs
        r.actual = SessionMath.actualMins(startMs, endMs)
        r.status = "done"
        Prefs.putStr(c, OPEN, "")
        if (append(c, r)) FocusTasks.afterSession(c, r)
    }

    @Synchronized
    fun onCancelled(c: Context) {
        val r = closeOpen(c, "stop", System.currentTimeMillis()) ?: return
        FocusTasks.afterSession(c, r)
    }

    // يغلق السجل المفتوح. يرجع السجل فقط لو أُضيف جديدًا (لا شيء لو لا سجل مفتوح أو كان مكررًا فدُمج)
    private fun closeOpen(c: Context, status: String, endMs: Long): SessionRec? {
        val r = readOpen(c) ?: return null
        r.end = endMs.coerceAtLeast(r.start)
        r.actual = SessionMath.actualMins(r.start, r.end)
        r.status = status
        Prefs.putStr(c, OPEN, "")
        return if (append(c, r)) r else null
    }

    fun openRec(c: Context): SessionRec? = readOpen(c)

    private fun readOpen(c: Context): SessionRec? {
        val s = Prefs.str(c, OPEN, "")
        if (s.isEmpty()) return null
        return try { SessionRec.fromJson(org.json.JSONObject(s)) } catch (_: Exception) { null }
    }

    // قراءة متسامحة. لو السجل الأصلي تالف نحتفظ بنسخة منه (أول مرة فقط) قبل أن تكتب أي إضافة فوقه
    fun all(c: Context): MutableList<SessionRec> {
        val raw = Prefs.str(c, LOG, "[]")
        val p = SessionMath.parse(raw)
        if ((p.broken || p.skipped > 0) && Prefs.str(c, LOG_BAD, "").isEmpty()) Prefs.putStr(c, LOG_BAD, raw)
        return p.list
    }

    fun find(c: Context, id: Long): SessionRec? = all(c).firstOrNull { it.id == id }

    // يرجع true لو أُضيف سجل جديد، و false لو كانت الجلسة مسجلة من قبل (فيُدمج ولا يُستبدل السجل الموجود)
    private fun append(c: Context, r: SessionRec): Boolean {
        val l = all(c)
        val added = SessionMath.addOrMerge(l, r)
        Prefs.putStr(c, LOG, SessionMath.encodeLog(l))
        // بصمة التركيز: نحفظ الملخصات الأسبوعية فور تسجيل الجلسة قبل أن يقتطع الحد (600) أقدم جلسات. أي خطأ هنا لا يمس السجل
        try { DnaStore.update(c) } catch (_: Exception) { }
        return added
    }

    @Synchronized
    fun setOutcome(c: Context, id: Long, outcome: String) {
        val l = all(c)
        l.firstOrNull { it.id == id }?.outcome = outcome
        Prefs.putStr(c, LOG, SessionMath.encodeLog(l))
    }

    // يضع النتيجة فقط لو لم تُصنَّف الجلسة بعد (يُستخدم لعلامة «لم تُراجَع»)
    @Synchronized
    fun setOutcomeIfEmpty(c: Context, id: Long, outcome: String) {
        val l = all(c)
        val r = l.firstOrNull { it.id == id } ?: return
        if (r.outcome.isNotEmpty()) return
        r.outcome = outcome
        Prefs.putStr(c, LOG, SessionMath.encodeLog(l))
    }
}

// الميزة 03: المهام المرتبطة بجلسات التركيز. تعيد استخدام نظام المهام الحالي (Tasks) ولا تنشئ مدير مهام موازيًا.
object FocusTasks {
    private const val REVIEW_MAX_AGE = 7 * 86_400_000L
    private const val SNOOZE_MS = 10 * 60_000L
    private const val Q_KEY = "ft_revq"
    private const val SNOOZE_KEY = "ft_rv_snooze"
    private const val REVIEW_CH = "ft_review"
    private const val REVIEW_NOTIF = 7400
    private val qLock = Any()

    fun selectedId(c: Context): String = Prefs.str(c, "ft_sel", "")
    fun select(c: Context, id: String) = Prefs.putStr(c, "ft_sel", id)
    fun goal(c: Context): String = Prefs.str(c, "ft_goal", "")
    fun setGoal(c: Context, g: String) = Prefs.putStr(c, "ft_goal", g)
    fun clearSelection(c: Context) { select(c, ""); setGoal(c, "") }

    // المهمة المختارة لو ما زالت موجودة وغير مكتملة
    fun current(c: Context): Task? {
        val id = selectedId(c)
        if (id.isEmpty()) return null
        return Tasks.load(c).firstOrNull { it.id == id && !it.d }
    }

    fun projects(c: Context): List<String> = Tasks.load(c).map { it.proj }.filter { it.isNotBlank() }.distinct()

    // «تسليح» الربط: لا تُربط الجلسة بالمهمة المختارة إلا لو بدأها المستخدم من الشاشة الرئيسية، لا الجلسات التلقائية
    fun arm(c: Context) = Prefs.putBool(c, "ft_arm", true)
    fun consumeArm(c: Context): Boolean {
        val a = Prefs.boolOf(c, "ft_arm", false)
        if (a) Prefs.putBool(c, "ft_arm", false)
        return a
    }

    // بعد انتهاء جلسة (كاملة أو خروج مبكر): نضيف دقائق التركيز للمهمة (على أحدث نسخة محفوظة)،
    // ونضع الجلسة في طابور المراجعة ونرسل إشعارًا. لا إكمال تلقائي أبدًا
    fun afterSession(c: Context, r: SessionRec) {
        if (r.taskId.isEmpty() && r.goal.isEmpty()) return
        if (r.taskId.isNotEmpty()) {
            Tasks.update(c) { l -> TaskOps.find(l, r.taskId)?.let { FocusLogic.addFocus(it, r.actual) } }
        }
        // خروج مبكر بعد أقل من دقيقة: لا شيء يستحق المراجعة
        if (r.status == "stop" && r.actual < 1) return
        enqueueReview(c, r.id)
        notifyReview(c, r)
    }

    // ---------- طابور المراجعة ----------
    private fun enqueueReview(c: Context, id: Long) {
        val dropped = synchronized(qLock) {
            val q = ReviewQueue.parse(Prefs.str(c, Q_KEY, "[]"))
            val d = ReviewQueue.add(q, id)
            Prefs.putStr(c, Q_KEY, ReviewQueue.encode(q))
            d
        }
        dropped.forEach { SessionLog.setOutcomeIfEmpty(c, it, "skip") }
    }

    private fun removeFromQueue(c: Context, ids: Collection<Long>) {
        if (ids.isEmpty()) return
        synchronized(qLock) {
            val q = ReviewQueue.parse(Prefs.str(c, Q_KEY, "[]"))
            q.removeAll(ids.toSet())
            Prefs.putStr(c, Q_KEY, ReviewQueue.encode(q))
        }
    }

    // ترحيل من خانة المراجعة الواحدة (ft_review) في نسخة 2.7 الأولى إلى الطابور
    private fun migrateLegacy(c: Context) {
        val old = Prefs.str(c, "ft_review", "").toLongOrNull()
        if (old != null) enqueueReview(c, old)
        if (Prefs.str(c, "ft_review", "").isNotEmpty()) Prefs.putStr(c, "ft_review", "")
    }

    // أقدم مراجعة معلّقة صالحة. لا شيء يُحذف بصمت: ما انتهت مهلته (7 أيام) يُسجَّل في السجل بنتيجة «skip»،
    // وما لم يعد له سجل يُسقط من الطابور. «ليس الآن» يؤجل العرض 10 دقائق فقط ولا يلغيه
    fun pendingReview(c: Context): SessionRec? {
        migrateLegacy(c)
        val now = System.currentTimeMillis()
        if (now < Prefs.longOf(c, SNOOZE_KEY)) return null
        val q = synchronized(qLock) { ReviewQueue.parse(Prefs.str(c, Q_KEY, "[]")) }
        if (q.isEmpty()) return null
        val log = SessionLog.all(c)
        var found: SessionRec? = null
        val remove = ArrayList<Long>()
        val expired = ArrayList<Long>()
        for (id in q) {
            val r = log.firstOrNull { it.id == id }
            if (r == null || r.outcome.isNotEmpty()) { remove.add(id); continue }
            if (r.status == "open") continue
            if (now - r.end > REVIEW_MAX_AGE) { remove.add(id); expired.add(id); continue }
            if (found == null) found = r
        }
        expired.forEach { SessionLog.setOutcomeIfEmpty(c, it, "skip") }
        removeFromQueue(c, remove)
        return found
    }

    fun snoozeReview(c: Context) = Prefs.putLong(c, SNOOZE_KEY, System.currentTimeMillis() + SNOOZE_MS)
    fun clearSnooze(c: Context) = Prefs.putLong(c, SNOOZE_KEY, 0L)

    // يطبّق اختيار المستخدم بعد الجلسة على أحدث نسخة محفوظة من المهمة (لا على قائمة قديمة).
    // steps: لقطة لحالة الخطوات من نافذة المراجعة، تُدمج بالنص ولا تمسّ أي حقل آخر
    fun review(c: Context, r: SessionRec, steps: List<Step>?, outcome: String, markDone: Boolean, note: String, pri: Int?, remindAt: Long) {
        var found = false
        var finished = false
        var title = ""
        if (r.taskId.isNotEmpty()) {
            Tasks.update(c) { l ->
                val t = TaskOps.find(l, r.taskId)
                if (t != null) {
                    if (steps != null) TaskOps.mergeSteps(t, steps)
                    FocusLogic.applyOutcome(t, outcome, markDone, note, pri)
                    found = true; finished = t.d; title = t.t
                }
            }
        }
        if (found) {
            if (finished) {
                if (selectedId(c) == r.taskId) clearSelection(c)
                FocusReminders.cancel(c, r.taskId)
            } else if (remindAt > System.currentTimeMillis()) {
                select(c, r.taskId)
                FocusReminders.schedule(c, r.taskId, title, remindAt, r.planned.coerceIn(5, 240))
            }
        }
        SessionLog.setOutcome(c, r.id, outcome)
        removeFromQueue(c, listOf(r.id))
        try { c.getSystemService(NotificationManager::class.java).cancel(REVIEW_NOTIF) } catch (_: Exception) { }
    }

    // إشعار نهاية الجلسة: يفتح نافذة المراجعة. لو الإشعارات مغلقة تبقى المراجعة في الطابور وتظهر عند فتح التطبيق
    private fun notifyReview(c: Context, r: SessionRec) {
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            if (!nm.areNotificationsEnabled()) return
            nm.createNotificationChannel(NotificationChannel(REVIEW_CH, c.L("مراجعة الجلسة", "Session review"), NotificationManager.IMPORTANCE_DEFAULT))
            val what = r.taskTitle.ifEmpty { r.goal }.ifEmpty { c.L("جلسة حرّة", "Free session") }
            val open = PendingIntent.getActivity(
                c, 7401, Intent(c, SplashActivity::class.java).putExtra("review", r.id)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            nm.notify(
                REVIEW_NOTIF,
                Notification.Builder(c, REVIEW_CH).setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle(c.L("انتهت الجلسة: $what", "Session finished: $what"))
                    .setContentText(c.L("اضغط لتسجّل كيف كانت.", "Tap to record how it went."))
                    .setContentIntent(open).setAutoCancel(true).build()
            )
        } catch (_: Exception) { }
    }

    fun tomorrowMorning(): Long {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, 1)
        cal.set(Calendar.HOUR_OF_DAY, 9); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }
}
