package com.focuslock

import org.json.JSONArray
import org.json.JSONObject

// مرحلة التقوية (2.7): منطق خالص بلا اعتماد على أندرويد (قابل للاختبار على JVM).
// القاعدة العامة: أي بيانات تالفة تُتجاوز ولا تُسقط التطبيق، وأي استعادة لا تستبدل بيانات سليمة بشيء غير صالح.

class ParsedTasks(val tasks: MutableList<Task>, val skipped: Int, val broken: Boolean)

object TaskSafe {
    // قراءة متسامحة: المهمة التالفة تُتجاوز وتُحصى، والنص غير القابل للقراءة كقائمة يُعلَّم broken (بلا استثناء أبدًا)
    fun parse(raw: String): ParsedTasks {
        val out = ArrayList<Task>()
        val a = try { JSONArray(raw) } catch (_: Exception) { return ParsedTasks(out, 0, raw.isNotBlank()) }
        var skipped = 0
        for (i in 0 until a.length()) {
            val t = try { a.optJSONObject(i)?.let { TaskCodec.decodeOrNull(it) } } catch (_: Exception) { null }
            if (t == null) skipped++ else out.add(t)
        }
        return ParsedTasks(out, skipped, false)
    }

    // يعطي معرّفًا جديدًا لكل مهمة بلا معرّف أو بمعرّف مكرر (المعرّفات هي أساس كل تعديل). يرجع true لو تغيّر شيء
    fun normalizeIds(l: List<Task>): Boolean {
        var changed = false
        val seen = HashSet<String>()
        for (t in l) {
            if (t.id.isEmpty() || !seen.add(t.id)) {
                var n = TaskCodec.newId()
                while (!seen.add(n)) n = TaskCodec.newId()
                t.id = n
                changed = true
            }
        }
        return changed
    }

    fun encode(l: List<Task>): String {
        val a = JSONArray()
        l.forEach { a.put(TaskCodec.encode(it)) }
        return a.toString()
    }

    // للاستعادة من نسخة احتياطية: يرجع نصًا نظيفًا، أو null لو الملف ليس قائمة مهام صالحة
    // (قائمة غير فارغة لا تُقرأ منها ولا مهمة واحدة تُرفض كلها فلا تطمس المهام الحالية)
    fun sanitizeForRestore(raw: String): String? {
        val len = try { JSONArray(raw).length() } catch (_: Exception) { return null }
        val p = parse(raw)
        if (len > 0 && p.tasks.isEmpty()) return null
        return encode(p.tasks)
    }
}

object TaskOps {
    fun find(l: List<Task>, id: String): Task? = if (id.isEmpty()) null else l.firstOrNull { it.id == id }

    // يطبّق حالة الخطوات من لقطة (snap) على المهمة المحفوظة الحالية بمطابقة النص، فلا يمسّ أي حقل آخر
    fun mergeSteps(t: Task, snap: List<Step>) {
        val used = HashSet<Int>()
        for (s in snap) {
            val i = t.steps.indices.firstOrNull { it !in used && t.steps[it].text == s.text } ?: continue
            used.add(i)
            t.steps[i].done = s.done
        }
    }

    // يعيد ترتيب القائمة حسب قائمة المعرّفات؛ ما لم يُذكر فيها يبقى بعدها بترتيبه الحالي (لا يضيع شيء أبدًا)
    fun reorder(l: MutableList<Task>, ids: List<String>) {
        val rank = HashMap<String, Int>()
        ids.forEachIndexed { i, id -> if (!rank.containsKey(id)) rank[id] = i }
        val sorted = l.withIndex()
            .sortedWith(compareBy({ rank[it.value.id] ?: Int.MAX_VALUE }, { it.index }))
            .map { it.value }
        l.clear()
        l.addAll(sorted)
    }

    // يحرّك مهمة خانة واحدة (delta = -1 أو +1). يرجع false لو لا يمكن
    fun move(l: MutableList<Task>, id: String, delta: Int): Boolean {
        val i = l.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= l.size) return false
        java.util.Collections.swap(l, i, j)
        return true
    }
}

// طابور مراجعات الجلسات: معرّفات الجلسات التي تنتظر تصنيف المستخدم (الأقدم أولًا) بدل خانة واحدة تُطمس
object ReviewQueue {
    const val CAP = 10

    fun parse(raw: String): MutableList<Long> {
        val out = ArrayList<Long>()
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val v = a.optLong(i, 0L)
                if (v > 0L && v !in out) out.add(v)
            }
        } catch (_: Exception) { }
        return out
    }

    fun encode(l: List<Long>): String {
        val a = JSONArray()
        l.forEach { a.put(it) }
        return a.toString()
    }

    // يضيف المعرّف لو لم يكن موجودًا. يرجع المعرّفات التي أُزيحت بسبب السقف (الأقدم)
    fun add(l: MutableList<Long>, id: Long): List<Long> {
        if (id <= 0L || id in l) return emptyList()
        l.add(id)
        val dropped = ArrayList<Long>()
        while (l.size > CAP) dropped.add(l.removeAt(0))
        return dropped
    }
}

// تذكير مهمة محفوظ: مفتاحه معرّف المهمة (تذكير واحد لكل مهمة، وعدة مهام معًا)، و rc رمز طلب المنبّه الثابت لهذه المهمة
class Rem(val taskId: String, var title: String, var mins: Int, var at: Long, val rc: Int)

object RemLogic {
    const val CAP = 20
    private const val RC_BASE = 7_200_000

    fun parse(raw: String): MutableList<Rem> {
        val out = ArrayList<Rem>()
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                try {
                    val o = a.getJSONObject(i)
                    val k = o.getString("k")
                    val at = o.getLong("at")
                    if (k.isEmpty() || at <= 0L || out.any { it.taskId == k }) continue
                    out.add(Rem(k, o.optString("t", ""), o.optInt("m", 25), at, o.getInt("rc")))
                } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
        return out
    }

    fun encode(l: List<Rem>): String {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("k", it.taskId).put("t", it.title).put("m", it.mins).put("at", it.at).put("rc", it.rc)) }
        return a.toString()
    }

    // يبني تذكيرًا جديدًا: نفس المهمة تحتفظ برمز طلبها (فيُستبدل منبّهها)، والمهمة الجديدة تأخذ رمزًا غير مستخدم
    fun make(l: List<Rem>, taskId: String, title: String, mins: Int, at: Long): Rem {
        val same = l.firstOrNull { it.taskId == taskId }
        var rc = same?.rc ?: (RC_BASE + (taskId.hashCode() and 0xFFFFF))
        if (same == null) while (l.any { it.rc == rc }) rc++
        return Rem(taskId, title, mins, at, rc)
    }

    // يضيف التذكير ويستبدل تذكير نفس المهمة. يرجع التذكيرات التي أُزيحت بسبب السقف (الأقدم) لإلغاء منبّهاتها
    fun upsert(l: MutableList<Rem>, r: Rem): List<Rem> {
        l.removeAll { it.taskId == r.taskId }
        l.add(r)
        val dropped = ArrayList<Rem>()
        while (l.size > CAP) dropped.add(l.removeAt(0))
        return dropped
    }
}

// حارس الاستعادة: المفاتيح التي نتحقق من صلاحيتها قبل أن تستبدل بيانات المستخدم الحالية
object BackupGuard {
    val GUARDED = setOf("tasks", "sl_log", "dna_hist")

    fun sanitize(key: String, raw: String): String? = when (key) {
        "tasks" -> TaskSafe.sanitizeForRestore(raw)
        "sl_log" -> SessionMath.sanitizeForRestore(raw)
        "dna_hist" -> DnaCodec.sanitizeForRestore(raw)
        else -> raw
    }
}
