package com.focuslock

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable

fun Context.fmtDur(ms: Long): String {
    val m = ms / 60_000L
    return if (m < 60) L("$m د", "${m}m") else "${m / 60}" + L(" س", "h") + (if (m % 60 > 0) " ${m % 60}" + L(" د", "m") else "")
}

fun Context.appLabel(pkg: String): String =
    try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }

fun Context.appIcon(pkg: String): Drawable? =
    try { packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null }

fun Context.homeIntent(): Intent =
    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

fun Context.hasUsageAccess(): Boolean {
    val ops = getSystemService(android.app.AppOpsManager::class.java)
    @Suppress("DEPRECATION")
    val mode = ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
    return mode == android.app.AppOpsManager.MODE_ALLOWED
}
