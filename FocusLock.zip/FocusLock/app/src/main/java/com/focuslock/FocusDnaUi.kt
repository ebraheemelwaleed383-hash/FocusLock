package com.focuslock

import android.app.Activity
import android.view.View
import android.widget.LinearLayout

// الميزة 02: شاشة بصمة التركيز. وصف طويل المدى لعاداتك مبني على تاريخ أسبوعي محفوظ على الجهاز.
class DnaPage(private val a: Activity) {
    private lateinit var content: LinearLayout

    fun build(): View {
        val p = a.pageColumn(
            a.L("بصمة التركيز", "Focus DNA"),
            a.L("وصف لعاداتك في التركيز عبر الأسابيع، وكيف تتغير. وصف لسلوكك فقط وليس تقييمًا لشخصيتك.", "A description of your focus habits over the weeks and how they change. It describes behavior only; it is not a personality assessment.")
        )
        content = p.second
        return p.first
    }

    fun refresh() {
        content.removeAllViews()
        val pr = try { DnaStore.profile(a) } catch (e: Exception) { null }
        if (pr == null) {
            val c = a.card()
            c.addView(a.note(a.L("تعذّر حساب البصمة الآن. بياناتك لم تُمس.", "Could not compute the profile right now. Your data was not touched.")))
            content.put(c, 0)
            return
        }
        try { render(pr) } catch (e: Exception) {
            content.put(a.note(a.L("تعذّر عرض جزء من البصمة.", "Part of the profile could not be shown.")), 12)
        }
        content.put(a.btn(a.L("كيف تُسند التسميات؟", "How are labels assigned?")) { showRules() }, 14)
    }

    private fun render(p: DnaProfile) {
        if (p.conf == Conf.NONE && p.analyzed == 0 && p.storedWeeks == 0) {
            val c = a.sectionCard(a.L("لا بصمة بعد", "No profile yet"), null)
            c.put(a.note(a.L(
                "تُبنى البصمة من تفاصيل الجلسات المسجلة (وقت البدء والمدة والنتيجة). أكمل بعض الجلسات لتبدأ بالظهور. الإجماليات اليومية القديمة لا تحمل هذه التفاصيل فلا تُستخدم هنا.",
                "The profile is built from recorded session details (start time, length, outcome). Complete a few sessions and it will start to appear. Older daily totals do not carry these details, so they are not used here."
            )), 8)
            content.put(c, 0)
            return
        }
        content.put(coverageCard(p), 0)
        content.put(labelsCard(p), 14)
        content.put(rhythmCard(p), 14)
        content.put(durationCard(p), 14)
        content.put(consistencyCard(p), 14)
        content.put(behaviorCard(p), 14)
        content.put(evolutionCard(p), 14)
    }

    private fun coverageCard(p: DnaProfile): View {
        val c = a.sectionCard(a.L("اكتمال البيانات", "Data coverage"), null)
        val f = p.periodFrom
        c.put(a.tv(
            if (f != null) a.L("${p.analyzed} جلسة محللة، من ${a.dateS(f)} إلى ${a.dateS(p.periodTo)} (${p.days} يومًا).", "${p.analyzed} sessions analyzed, from ${a.dateS(f)} to ${a.dateS(p.periodTo)} (${p.days} days).")
            else a.L("لا جلسات محللة.", "No sessions analyzed."), 14f, C.TX), 8)
        c.put(a.tv(a.confName(p.conf), 13f, if (p.conf == Conf.HIGH || p.conf == Conf.MEDIUM) C.OK else C.WR, true), 6)
        if (p.conf == Conf.NONE || p.conf == Conf.LOW) c.put(a.note(a.L(
            "بصمة أولية: البيانات قليلة، فاعتبر ما يلي تقديرًا مبكرًا قد يتغير مع الوقت.",
            "Early profile: there is little data, so treat what follows as an early estimate that may change."
        )), 6)
        c.put(a.note(a.L(
            "النافذة الحالية: آخر 3 أسابيع كاملة مع الأسبوع الجاري، وتتحدث مع كل جلسة جديدة. محفوظ لديك ملخص ${p.storedWeeks} أسبوعًا. كل الحساب على جهازك.",
            "Current window: the last 3 full weeks plus this week, updated with every new session. ${p.storedWeeks} weekly summaries are kept. Everything is computed on your device."
        )), 6)
        return c
    }

    private fun labelName(l: DL): String = when (l) {
        DL.MORNING_FOCUS -> a.L("تركيز صباحي", "Morning Focus")
        DL.AFTERNOON_FOCUS -> a.L("تركيز بعد الظهر", "Afternoon Focus")
        DL.EVENING_FOCUS -> a.L("تركيز مسائي", "Evening Focus")
        DL.NIGHT_FOCUS -> a.L("تركيز ليلي", "Night Focus")
        DL.VARIED_TIMING -> a.L("أوقات متنوعة", "Varied Timing")
        DL.SHORT_SESSIONS -> a.L("تفضيل الجلسات القصيرة", "Short Session Preference")
        DL.LONG_SESSIONS -> a.L("تفضيل الجلسات الطويلة", "Long Session Preference")
        DL.MIXED_LENGTHS -> a.L("أطوال جلسات متنوعة", "Mixed Session Lengths")
        DL.CONSISTENT_HABIT -> a.L("جلسات منتظمة", "Consistent Sessions")
        DL.REGULAR_HABIT -> a.L("عادة منتظمة نسبيًا", "Regular Habit")
        DL.OCCASIONAL_HABIT -> a.L("تركيز متقطع", "Occasional Focus")
        DL.FINISHES_SESSIONS -> a.L("غالبًا تُكمل جلساتك", "Usually Finishes Sessions")
        DL.ENDS_EARLY -> a.L("كثيرًا ما تنهي جلساتك مبكرًا", "Often Ends Sessions Early")
        DL.TASK_LINKED -> a.L("تركيز مرتبط بالمهام", "Task-linked Focus")
        DL.IMPROVING_CONSISTENCY -> a.L("انتظام يتحسن", "Improving Consistency")
    }

    private fun labelRule(l: DL): String = when (l) {
        DL.MORNING_FOCUS -> a.L("50٪ أو أكثر من دقائق الإكمال تبدأ بين 05:00 و11:59", "50% or more of completed minutes start 05:00–11:59")
        DL.AFTERNOON_FOCUS -> a.L("50٪ أو أكثر من دقائق الإكمال تبدأ بين 12:00 و16:59", "50% or more of completed minutes start 12:00–16:59")
        DL.EVENING_FOCUS -> a.L("50٪ أو أكثر من دقائق الإكمال تبدأ بين 17:00 و21:59", "50% or more of completed minutes start 17:00–21:59")
        DL.NIGHT_FOCUS -> a.L("50٪ أو أكثر من دقائق الإكمال تبدأ بين 22:00 و04:59", "50% or more of completed minutes start 22:00–04:59")
        DL.VARIED_TIMING -> a.L("لا فترة تبلغ 50٪ (بعد 10 جلسات مكتملة على الأقل)", "No period reaches 50% (after at least 10 completed sessions)")
        DL.SHORT_SESSIONS -> a.L("60٪ أو أكثر من الجلسات المكتملة مدتها 25 دقيقة أو أقل", "60% or more of completed sessions are 25 minutes or shorter")
        DL.LONG_SESSIONS -> a.L("50٪ أو أكثر من الجلسات المكتملة مدتها أكثر من 40 دقيقة", "50% or more of completed sessions are longer than 40 minutes")
        DL.MIXED_LENGTHS -> a.L("لا قصيرة ولا طويلة تغلب (6 جلسات مكتملة على الأقل)", "Neither short nor long sessions dominate (at least 6 completed sessions)")
        DL.CONSISTENT_HABIT -> a.L("4 أيام نشطة في الأسبوع أو أكثر في المتوسط", "4 or more active days per week on average")
        DL.REGULAR_HABIT -> a.L("من يومين إلى أقل من 4 أيام نشطة في الأسبوع", "2 to under 4 active days per week")
        DL.OCCASIONAL_HABIT -> a.L("أقل من يومين نشطين في الأسبوع", "Under 2 active days per week")
        DL.FINISHES_SESSIONS -> a.L("نسبة الإكمال 85٪ أو أكثر (10 محاولات على الأقل)", "Completion rate 85% or more (at least 10 attempts)")
        DL.ENDS_EARLY -> a.L("نسبة الإكمال أقل من 60٪ (10 محاولات على الأقل)", "Completion rate under 60% (at least 10 attempts)")
        DL.TASK_LINKED -> a.L("40٪ أو أكثر من المحاولات مرتبطة بمهمة", "40% or more of attempts are linked to a task")
        DL.IMPROVING_CONSISTENCY -> a.L("ارتفع متوسط الأيام النشطة 0.75 يوم في الأسبوع أو أكثر عن الأسابيع الأربعة التي قبلها", "Average active days per week rose by 0.75 or more vs the 4 weeks before")
    }

    private fun labelsCard(p: DnaProfile): View {
        val c = a.sectionCard(a.L("ملامح تركيزك", "Your focus traits"), a.L("كل ملمح يُسند بقاعدة ثابتة على بيانات النافذة الحالية، وتجدها تحت اسمه.", "Each trait is assigned by a fixed rule on the current window's data; the rule is shown under its name."))
        if (p.labels.isEmpty()) {
            c.put(a.note(a.L("لا ملامح بعد: كل ملمح يحتاج حدًا أدنى من الجلسات (6 إلى 10) أو من الأيام (14).", "No traits yet: each trait needs a minimum of sessions (6 to 10) or days (14).")), 8)
            return c
        }
        for (l in p.labels) {
            c.put(a.tv(labelName(l), 16f, C.AC, true), 12)
            c.put(a.note(labelRule(l)), 2)
        }
        return c
    }

    private fun rhythmCard(p: DnaProfile): View {
        val m = p.recent
        val c = a.sectionCard(a.L("إيقاع التركيز", "Focus rhythm"), a.L("متى تبدأ جلساتك المكتملة عادةً (حصة كل فترة من دقائق الإكمال).", "When your completed sessions usually start (each period's share of completed minutes)."))
        val sh = m.shares
        if (sh == null || m.done < DTh.MIN_DONE_LABEL) {
            c.put(a.note(a.L("يحتاج الإيقاع ${DTh.MIN_DONE_LABEL} جلسات مكتملة على الأقل (لديك ${m.done}).", "Rhythm needs at least ${DTh.MIN_DONE_LABEL} completed sessions (you have ${m.done}).")), 8)
            return c
        }
        for (i in 0 until Ax.PERIODS) c.put(a.rateRow(a.periodName(i), sh[i], a.pctS(sh[i])), 8)
        val ps = m.peakStart
        if (ps != null) c.put(a.note(a.L(
            "أقوى نافذة 3 ساعات: ${hh(ps)}–${hh((ps + 3) % 24)} (${a.pctS(m.peakShare)} من دقائق الإكمال).",
            "Strongest 3-hour window: ${hh(ps)}–${hh((ps + 3) % 24)} (${a.pctS(m.peakShare)} of completed minutes)."
        ), C.TX), 10)
        val pr = m.presence
        if (pr != null) {
            val days = (0 until 7).filter { pr[it] >= 0.66 }.sortedByDescending { pr[it] }.take(2)
            if (days.isNotEmpty()) c.put(a.note(a.L(
                "أكثر أيامك انتظامًا: ${days.joinToString("، ") { a.dowName(it) }} (أُنجز فيها شيء في أسبوعين على الأقل من آخر 3).",
                "Most consistent days: ${days.joinToString(", ") { a.dowName(it) }} (focus completed in at least 2 of the last 3 full weeks)."
            ), C.TX), 6)
        } else c.put(a.note(a.L("الأيام الأكثر انتظامًا تحتاج 3 أسابيع كاملة من السجل.", "Most consistent days need 3 full weeks of history.")), 6)
        return c
    }

    private fun durationCard(p: DnaProfile): View {
        val m = p.recent
        val c = a.sectionCard(a.L("مدة الجلسة", "Session length"), a.L("لا توجد مدة مثلى للجميع. هذا وصف لما يحدث معك.", "There is no single best length for everyone. This describes what happens for you."))
        val mean = m.meanDone
        if (mean == null || m.done < DTh.MIN_DONE_LABEL) {
            c.put(a.note(a.L("تحتاج المدة ${DTh.MIN_DONE_LABEL} جلسات مكتملة على الأقل (لديك ${m.done}).", "Length needs at least ${DTh.MIN_DONE_LABEL} completed sessions (you have ${m.done}).")), 8)
            return c
        }
        c.put(a.kv(a.L("متوسط الجلسة المكتملة", "Average completed session"), a.minD(mean)), 10)
        val ss = m.shortShare
        val ls = m.longShare
        if (ss != null && ls != null) {
            c.put(a.kv(a.L("جلسات 25 د أو أقل", "Sessions of 25 min or less"), a.pctS(ss)), 6)
            c.put(a.kv(a.L("جلسات أكثر من 40 د", "Sessions over 40 min"), a.pctS(ls)), 6)
        }
        c.put(a.tv(a.L("نسبة الإكمال حسب الطول المخطط", "Completion by planned length"), 13f, C.MU), 12)
        var any = false
        for (b in 0 until Ax.BUCKETS) {
            val r = m.bucketRates[b]
            val n = m.bucketN[b]
            if (r == null || n < Th.MIN_BUCKET) continue
            any = true
            c.put(a.rateRow(a.bucketName(b), r, a.pctS(r) + " (" + n + ")"), 6)
        }
        if (!any) c.put(a.note(a.L("لا فئة طول بها ${Th.MIN_BUCKET} محاولات بعد.", "No length range has ${Th.MIN_BUCKET} attempts yet.")), 4)
        val bb = m.bestBucket
        val br = m.bestBucketRate
        if (bb != null && br != null) c.put(a.note(a.L(
            "أعلى نسبة إكمال عندك مع جلسات ${a.bucketName(bb)} (${a.pctS(br)}). هذا ما لوحظ في بياناتك، وليس طولًا مثاليًا.",
            "Your highest completion rate is with ${a.bucketName(bb)} sessions (${a.pctS(br)}). This is what your data shows, not an ideal length."
        ), C.TX), 8)
        return c
    }

    private fun consistencyCard(p: DnaProfile): View {
        val m = p.recent
        val c = a.sectionCard(a.L("الانتظام", "Consistency"), null)
        val pw = m.perWeek
        if (pw == null || m.days < DTh.MIN_DAYS) {
            c.put(a.note(a.L("يحتاج الانتظام ${DTh.MIN_DAYS} يومًا على الأقل من السجل (لديك ${m.days}).", "Consistency needs at least ${DTh.MIN_DAYS} days of history (you have ${m.days}).")), 8)
            return c
        }
        c.put(a.kv(a.L("متوسط الأيام النشطة في الأسبوع", "Average active days per week"), String.format(java.util.Locale.US, "%.1f", pw)), 10)
        c.put(a.kv(a.L("أسابيع فيها نشاط", "Weeks with activity"), "${m.weeksWithData} / ${m.weeksTotal}"), 6)
        c.put(a.note(a.L("«يوم نشط» = يوم فيه جلسة مكتملة واحدة على الأقل.", "“Active day” = a day with at least one completed session.")), 6)
        return c
    }

    private fun behaviorCard(p: DnaProfile): View {
        val m = p.recent
        val c = a.sectionCard(a.L("السلوك", "Behavior"), null)
        val cr = m.completion
        if (cr == null || m.attempts < DTh.MIN_RATE_ATTEMPTS) {
            c.put(a.note(a.L("يحتاج السلوك ${DTh.MIN_RATE_ATTEMPTS} محاولات على الأقل (لديك ${m.attempts}).", "Behavior needs at least ${DTh.MIN_RATE_ATTEMPTS} attempts (you have ${m.attempts}).")), 8)
            return c
        }
        c.put(a.kv(a.L("نسبة الإكمال", "Completion rate"), a.pctS(cr)), 10)
        val lk = m.linkedShare
        if (lk != null) c.put(a.kv(a.L("محاولات مرتبطة بمهمة", "Attempts linked to a task"), a.pctS(lk)), 6)
        c.put(a.note(a.L("الخروج المبكر لا يميّز بين الإلغاء والمقاطعة.", "Early exits do not distinguish cancelling from interruption.")), 6)
        return c
    }

    private fun changeText(ch: Change): String = when (ch.code) {
        CH.CONSIST_UP -> a.L("الانتظام يتحسن: من ${fmt1(ch.from)} إلى ${fmt1(ch.to)} يوم نشط في الأسبوع.", "Consistency is improving: from ${fmt1(ch.from)} to ${fmt1(ch.to)} active days per week.")
        CH.CONSIST_DOWN -> a.L("الانتظام تراجع: من ${fmt1(ch.from)} إلى ${fmt1(ch.to)} يوم نشط في الأسبوع.", "Consistency dipped: from ${fmt1(ch.from)} to ${fmt1(ch.to)} active days per week.")
        CH.DURATION_UP -> a.L("الجلسات المكتملة صارت أطول: من ${a.minD(ch.from)} إلى ${a.minD(ch.to)} في المتوسط.", "Completed sessions got longer: from ${a.minD(ch.from)} to ${a.minD(ch.to)} on average.")
        CH.DURATION_DOWN -> a.L("الجلسات المكتملة صارت أقصر: من ${a.minD(ch.from)} إلى ${a.minD(ch.to)} في المتوسط.", "Completed sessions got shorter: from ${a.minD(ch.from)} to ${a.minD(ch.to)} on average.")
        CH.COMPLETION_UP -> a.L("نسبة الإكمال ارتفعت من ${a.pctS(ch.from)} إلى ${a.pctS(ch.to)}.", "Completion rate rose from ${a.pctS(ch.from)} to ${a.pctS(ch.to)}.")
        CH.COMPLETION_DOWN -> a.L("نسبة الإكمال انخفضت من ${a.pctS(ch.from)} إلى ${a.pctS(ch.to)}.", "Completion rate fell from ${a.pctS(ch.from)} to ${a.pctS(ch.to)}.")
        CH.RHYTHM_SHIFT -> a.L("انتقل تركيزك الرئيسي من ${a.periodPhrase(ch.from.toInt())} إلى ${a.periodPhrase(ch.to.toInt())}.", "Your main focus time moved from your ${a.periodPhrase(ch.from.toInt())} to your ${a.periodPhrase(ch.to.toInt())}.")
    }

    private fun fmt1(x: Double): String = String.format(java.util.Locale.US, "%.1f", x)

    private fun evolutionCard(p: DnaProfile): View {
        val c = a.sectionCard(a.L("التطور عبر الزمن", "Evolution over time"), a.L("مقارنة النافذة الحالية بالأسابيع الأربعة التي قبلها.", "The current window compared with the 4 weeks before it."))
        if (p.evolutionOk) {
            if (p.changes.isEmpty()) c.put(a.note(a.L("لا تغير ملحوظ بين الفترتين.", "No notable change between the two periods."), C.TX), 8)
            for (ch in p.changes) c.put(a.tv("• " + changeText(ch), 14f, C.TX).apply { setLineSpacing(0f, 1.2f) }, 8)
        } else c.put(a.note(a.L(
            "المقارنة تحتاج 14 يومًا و${DTh.MIN_ATTEMPTS} محاولات على الأقل في كل من النافذة الحالية والأسابيع الأربعة قبلها. سيظهر ذلك مع تراكم تاريخك.",
            "Comparison needs at least 14 days and ${DTh.MIN_ATTEMPTS} attempts in both the current window and the 4 weeks before it. It will appear as your history grows."
        )), 8)
        if (p.timeline.size >= 2) {
            c.put(a.tv(a.L("الوقت المكتمل الأسبوعي (ساعات)", "Weekly completed time (hours)"), 13f, C.MU), 14)
            c.putChart(a, a.chart(p.timeline.map { it.doneMins / 60f }, p.timeline.map { dm(it.ws) }), 4)
            c.put(a.note(a.L("كل عمود أسبوع يبدأ في اليوم المذكور (الاثنين).", "Each bar is a week starting on the day shown (Monday).")), 4)
        }
        return c
    }

    private fun showRules() {
        val sb = StringBuilder()
        for (l in DL.values()) sb.append("• ").append(labelName(l)).append(": ").append(labelRule(l)).append("\n")
        sb.append("\n").append(a.L(
            "لتجنّب القفز بسبب جلسة شاذة: تُحسب الملامح على آخر 3 أسابيع كاملة مع الأسبوع الجاري، والملمح الذي كان قائمًا في الأسابيع الأربعة السابقة يبقى حتى ينزل مؤشره قليلًا تحت عتبة دخوله (مثلًا 45٪ بدل 50٪). أما الملامح التي بلا بيانات كافية فلا تُسند.",
            "To avoid jumps from one unusual session: traits use the last 3 full weeks plus the current week, and a trait held in the previous 4 weeks stays until its value falls a little below its entry threshold (for example 45% instead of 50%). Traits without enough data are not assigned."
        ))
        a.dlg().setTitle(a.L("قواعد التسمية", "Labeling rules")).setMessage(sb.toString()).setPositiveButton(a.L("حسنًا", "OK"), null).show()
    }
}
