package com.focuslock

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class ColorWheelView(c: Context, private val onPick: (Int) -> Unit) : View(c) {
    private var hue = 0f
    private var sat = 0f
    var value = 1f
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var cx = 0f
    private var cy = 0f
    private var r = 0f

    val color: Int get() = Color.HSVToColor(floatArrayOf(hue, sat, value))

    fun setColor(c: Int) {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hue = hsv[0]; sat = hsv[1]; value = hsv[2]
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cx = w / 2f; cy = h / 2f; r = min(w, h) / 2f - 8f
    }

    override fun onDraw(canvas: Canvas) {
        val hues = IntArray(7) { Color.HSVToColor(floatArrayOf((it * 60f) % 360f, 1f, value)) }
        p.style = Paint.Style.FILL
        p.shader = SweepGradient(cx, cy, hues, null)
        canvas.drawCircle(cx, cy, r, p)
        val mid = Color.HSVToColor(floatArrayOf(0f, 0f, value))
        p.shader = RadialGradient(cx, cy, r, mid, mid and 0x00FFFFFF, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r, p)
        p.shader = null
        val a = hue * (Math.PI / 180.0)
        val x = cx + (sat * r * cos(a)).toFloat()
        val y = cy + (sat * r * sin(a)).toFloat()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 5f; p.color = Color.WHITE
        canvas.drawCircle(x, y, 14f, p)
        p.strokeWidth = 2f; p.color = Color.BLACK
        canvas.drawCircle(x, y, 17f, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE) {
            parent.requestDisallowInterceptTouchEvent(true)
            val dx = e.x - cx
            val dy = e.y - cy
            hue = (Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat() + 360f) % 360f
            sat = min(sqrt(dx * dx + dy * dy) / r, 1f)
            invalidate()
            onPick(color)
        }
        return true
    }
}
