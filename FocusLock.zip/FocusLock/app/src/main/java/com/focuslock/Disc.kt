package com.focuslock

import android.app.Activity
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import java.util.Calendar

// «المراقب»: نظام التزام يختار المستخدم مستواه بنفسه بعد أن يقرأ ما سيحدث ويوافق
object Disc {
    class Lv(
        val id: Int, val ar: String, val en: String,
        val cool: Int, val exits: Int, val phrase: Boolean, val penX: Float, val saverX: Int,
        val focus: Int, val tasks: Int, val forced: Boolean, val dAr: String, val dEn: String
    )

    val levels = listOf(
        Lv(1, "هادئ", "Gentle", 0, -1, false, 0f, 1, 0, 0, false,
            "• الخروج الطارئ بكلمة المرور فقط.\n• لا عقوبات ولا أهداف إجبارية.\n• المرشد الذكي ينبّهك بلطف.",
            "• Emergency exit with your password only.\n• No penalties and no mandatory targets.\n• The smart coach nudges you gently."),
        Lv(2, "جاد", "Serious", 120, 3, true, 0.5f, 2, 60, 2, false,
            "• الخروج الطارئ: انتظار دقيقتين، ثم كتابة جملة التزام وكلمة المرور، وبحد أقصى 3 مرات يوميًا.\n• كل خروج مبكر يضيف «دَينًا» يساوي نصف الوقت المتبقي، تسدده بجلسات تركيز.\n• هدفك اليومي: 60 دقيقة تركيز ومهمتان.\n• مساءً يسألك التطبيق: ماذا أنجزت اليوم؟ والتقصير يزيد الدَين.\n• وضع توفير الطاقة: كل دقيقة توقف تُحسب دقيقتين.\n• المرشد الذكي ينبّهك أسرع.",
            "• Emergency exit: a 2-minute wait, then a commitment phrase and your password, at most 3 times a day.\n• Every early exit adds a \"debt\" of half the remaining time, repaid with focus sessions.\n• Daily target: 60 focus minutes and 2 tasks.\n• Each evening the app asks what you achieved. Falling short adds debt.\n• Battery saver: each minute of downtime counts double.\n• The smart coach nudges you sooner."),
        Lv(3, "صارم", "Strict", 600, 1, true, 1f, 3, 120, 3, true,
            "• الخروج الطارئ: انتظار 10 دقائق + جملة التزام + كلمة المرور، ومرة واحدة فقط في اليوم.\n• الدَين يساوي الوقت المتبقي كاملًا.\n• يبدأ التطبيق جلسة تركيز إجبارية يوميًا لسداد الدَين.\n• هدفك اليومي: 120 دقيقة تركيز و3 مهام. والتقصير يُحاسَب عليه مساءً بتوبيخ ودَين.\n• وضع توفير الطاقة: كل دقيقة توقف تُحسب 3 دقائق، ولا يمكن بدء جلسة وهو مفعّل.\n• المرشد الذكي حازم.",
            "• Emergency exit: 10-minute wait + commitment phrase + password, once a day only.\n• The debt equals the full remaining time.\n• The app starts a mandatory focus session daily to repay the debt.\n• Daily target: 120 focus minutes and 3 tasks. Falling short is called out each evening with debt.\n• Battery saver: each minute of downtime counts triple, and you can't start a session while it is on.\n• The smart coach is firm."),
        Lv(4, "حديدي", "Iron", 1800, 1, true, 2f, 4, 180, 4, true,
            "• الخروج الطارئ: انتظار 30 دقيقة + جملة التزام + كلمة المرور، ومرة واحدة في اليوم.\n• الدَين ضعف الوقت المتبقي.\n• جلسات إجبارية يومية لسداد الدَين.\n• هدفك اليومي: 180 دقيقة تركيز و4 مهام.\n• وضع توفير الطاقة: كل دقيقة توقف تُحسب 4 دقائق، ولا تبدأ الجلسات وهو مفعّل.\n• توبيخ صريح عند التقصير.\n• هذا المستوى صعب عن قصد، لمن يريد التغيير بالقوة.",
            "• Emergency exit: 30-minute wait + commitment phrase + password, once a day.\n• The debt is double the remaining time.\n• Mandatory daily sessions to repay the debt.\n• Daily target: 180 focus minutes and 4 tasks.\n• Battery saver: each minute of downtime counts 4x, and sessions can't start while it is on.\n• Blunt reprimands when you fall short.\n• This level is hard on purpose, for people who want to change by force.")
    )

    const val PHRASE_AR = "أنا أختار التشتت على أهدافي"
    const val PHRASE_EN = "I choose distraction over my goals"

    fun cur(c: Context): Lv? = levels.firstOrNull { it.id == Prefs.intOf(c, "disc", 0) }

    fun level(c: Context): Lv? { applyPending(c); return cur(c) }

    private fun applyPending(c: Context) {
        val at = Prefs.longOf(c, "discPendAt")
        if (at > 0L && System.currentTimeMillis() >= at) {
            Prefs.putInt(c, "disc", Prefs.intOf(c, "discPend", 0))
            Prefs.putLong(c, "discPendAt", 0L)
            sync(c)
        }
    }

    // يرجع true إذا طُبّق التغيير فورًا. الخفض من مستوى جاد أو أعلى يتأخر 24 ساعة حتى لا يكون قرارًا لحظيًا
    fun request(c: Context, id: Int): Boolean {
        val old = Prefs.intOf(c, "disc", 0)
        if (id >= old || old <= 1) {
            if (old == 0 && id > 0) Prefs.putStr(c, "discSince", Prefs.dayKey())
            Prefs.putInt(c, "disc", id)
            Prefs.putLong(c, "discPendAt", 0L)
            sync(c)
            return true
        }
        Prefs.putInt(c, "discPend", id)
        Prefs.putLong(c, "discPendAt", System.currentTimeMillis() + 24 * 3_600_000L)
        return false
    }

    fun pendingText(c: Context): String? {
        val at = Prefs.longOf(c, "discPendAt")
        if (at <= 0L) return null
        val to = Prefs.intOf(c, "discPend", 0)
        val name = levels.firstOrNull { it.id == to }?.let { c.L(it.ar, it.en) } ?: c.L("إيقاف", "Off")
        return c.L("سيتحول المستوى إلى «$name» الساعة ${c.clock(at)} (بعد 24 ساعة من طلبك).", "The level will switch to \"$name\" at ${c.clock(at)} (24 hours after your request).")
    }

    private fun sync(c: Context) {
        val lv = cur(c)
        if (lv != null) {
            Prefs.setSmart(c, true)
            Prefs.setSmartFactor(c, when (lv.id) { 1 -> 1.0f; 2 -> 0.8f; 3 -> 0.6f; else -> 0.5f })
        }
        DiscAlarm.schedule(c)
    }

    // ---- الخروج الطارئ ----
    fun coolSeconds(c: Context): Int = level(c)?.cool ?: 0
    fun phraseNeeded(c: Context): Boolean = level(c)?.phrase == true
    fun phrase(c: Context): String = c.L(PHRASE_AR, PHRASE_EN)
    fun saverX(c: Context): Int = cur(c)?.saverX ?: 1

    fun exitsLeft(c: Context): Int {
        val lv = level(c) ?: return Int.MAX_VALUE
        if (lv.exits < 0) return Int.MAX_VALUE
        return (lv.exits - Prefs.todayOf(c, "ex").toInt()).coerceAtLeast(0)
    }

    fun registerExit(c: Context) {
        val lv = level(c) ?: return
        val remain = ((Prefs.end(c) - System.currentTimeMillis()) / 60_000L).coerceAtLeast(0L)
        Prefs.addDay(c, "ex", 1)
        if (lv.penX > 0f) addDebt(c, (remain * lv.penX).toInt().coerceAtMost(480))
        Prefs.putInt(c, "streak", 0)
    }

    // ---- الدَين ----
    fun debt(c: Context): Int = Prefs.intOf(c, "debt", 0)
    fun addDebt(c: Context, m: Int) = Prefs.putInt(c, "debt", (debt(c) + m).coerceAtMost(1440))
    fun repay(c: Context, m: Int) { if (debt(c) > 0) Prefs.putInt(c, "debt", (debt(c) - m).coerceAtLeast(0)) }

    // ---- الأهداف اليومية والحساب ----
    class Eval(val focus: Int, val focusT: Int, val tasks: Int, val tasksT: Int) {
        val met: Boolean get() = focus >= focusT && tasks >= tasksT
        val deficit: Int get() = (focusT - focus).coerceAtLeast(0)
    }

    fun focusTarget(c: Context): Int {
        val o = Prefs.intOf(c, "tFocus", -1)
        return if (o >= 0) o else (cur(c)?.focus ?: 0)
    }

    fun taskTarget(c: Context): Int {
        val o = Prefs.intOf(c, "tTasks", -1)
        return if (o >= 0) o else (cur(c)?.tasks ?: 0)
    }

    fun today(c: Context): Eval =
        Eval(Prefs.todayOf(c, "fm").toInt(), focusTarget(c), Prefs.todayOf(c, "td").toInt(), taskTarget(c))

    fun dayEval(c: Context, day: String): Eval =
        Eval(Prefs.dayVal(c, "fm", day).toInt(), focusTarget(c), Prefs.dayVal(c, "td", day).toInt(), taskTarget(c))

    fun penalize(c: Context, ev: Eval): Int {
        val lv = cur(c) ?: return 0
        if (Rewards.restToday(c)) return 0
        val missTasks = (ev.tasksT - ev.tasks).coerceAtLeast(0)
        val add = ((ev.deficit + missTasks * 15) * lv.penX).toInt()
        if (add > 0) addDebt(c, add)
        Prefs.putInt(c, "streak", 0)
        return add
    }

    fun reward(c: Context) {
        val s = Prefs.intOf(c, "streak", 0) + 1
        Prefs.putInt(c, "streak", s)
        Rewards.add(c, 60 + minOf(100, s * 10))
    }

    fun message(c: Context, ev: Eval, add: Int): String {
        if (Rewards.restToday(c)) return c.L("يوم إجازة مستحقة: لا عقوبة اليوم. استرح وارجع بنشاط.", "A well-earned rest day: no penalty today. Rest and come back strong.")
        val lv = cur(c)?.id ?: 1
        val rest = if (ev.focus >= 300) "\n\n" + c.L("تركيزك اليوم عالٍ جدًا. خذ راحة كافية حتى لا تُرهق نفسك.", "Your focus today was very high. Rest properly so you don't burn out.") else ""
        if (ev.met) return rest + when (lv) {
            1 -> c.L("يوم جيد. كمّل.", "Good day. Keep going.")
            2 -> c.L("أحسنت. وفّيت بهدفك اليوم: ${ev.focus} دقيقة و${ev.tasks} مهام.", "Well done. You met today's target: ${ev.focus} minutes and ${ev.tasks} tasks.")
            else -> c.L("وفّيت بوعدك اليوم: ${ev.focus} دقيقة و${ev.tasks} مهام. الاستمرار هو السر.", "You kept your word today: ${ev.focus} minutes and ${ev.tasks} tasks. Consistency is the secret.")
        }
        val base = c.L("المنجز: ${ev.focus} من ${ev.focusT} دقيقة تركيز، و${ev.tasks} من ${ev.tasksT} مهام.", "Done: ${ev.focus} of ${ev.focusT} focus minutes and ${ev.tasks} of ${ev.tasksT} tasks.")
        val tail = when (lv) {
            1 -> c.L("لا بأس. غدًا فرصة جديدة.", "No worries. Tomorrow is a fresh start.")
            2 -> c.L("قصّرت اليوم. أُضيف $add دقيقة دَينًا، وسدّدها بجلسة تركيز.", "You fell short today. $add minutes of debt were added. Repay it with a focus session.")
            3 -> c.L("هذا أقل مما وعدت به نفسك. أُضيف $add دقيقة دَينًا، وسيبدأ التطبيق جلسة إجبارية لسداده.", "That is less than you promised yourself. $add minutes of debt were added, and the app will start a mandatory session to repay it.")
            else -> c.L("لا. هذا لا يكفي، وأنت اخترت الصرامة لتتغيّر فعلًا. الدَين +$add دقيقة، وجلسة إجبارية بانتظارك. لا أعذار: ابدأ غدًا من أول اليوم.", "No. This isn't enough, and you chose strictness to really change. Debt +$add minutes, and a mandatory session awaits. No excuses: start tomorrow from the first hour.")
        }
        return base + "\n\n" + tail
    }

    fun autoEval(c: Context) {
        val lv = level(c) ?: return
        if (lv.id < 2) return
        val y = Prefs.dayKey(System.currentTimeMillis() - 86_400_000L)
        if (y < Prefs.str(c, "discSince", "99999999")) return
        if (Rewards.restOn(c, y)) return
        if (Prefs.str(c, "lastCheckin", "") >= y) return
        if (Prefs.str(c, "lastAuto", "") == y) return
        Prefs.putStr(c, "lastAuto", y)
        val ev = dayEval(c, y)
        if (!ev.met && ev.focusT + ev.tasksT > 0) penalize(c, ev)
    }

    // ---- اليوميات ----
    fun addJournal(c: Context, rating: Int, text: String) {
        val a = JSONArray(Prefs.raw(c, "journal"))
        a.put(Prefs.dayKey() + "|" + rating + "|" + text.replace("\n", " "))
        val keep = JSONArray()
        for (i in maxOf(0, a.length() - 60) until a.length()) keep.put(a.getString(i))
        Prefs.putRaw(c, "journal", keep.toString())
    }

    fun journal(c: Context): List<String> {
        val a = JSONArray(Prefs.raw(c, "journal"))
        return List(a.length()) { a.getString(it) }
    }

    // ---- جلسة إجبارية لسداد الدَين ----
    fun startForced(c: Context) {
        val lv = level(c) ?: return
        if (!lv.forced || debt(c) <= 0 || Prefs.active(c)) return
        if (Prefs.blocked(c).isEmpty() || !Engine.ready(c)) return
        val mins = minOf(debt(c), 90).coerceAtLeast(5)
        Prefs.clearFails(c)
        Prefs.begin(c, mins)
        try { EndAlarm.schedule(c); KeepAliveService.start(c) } catch (e: Exception) { }
        notify(c, "forced", 72, c.L("جلسة إجبارية", "Mandatory session"),
            c.L("بدأت جلسة $mins دقيقة لسداد الدَين.", "A $mins-minute session started to repay your debt."), LockActivity::class.java)
        try { c.startActivity(Intent(c, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
    }

    fun notify(c: Context, chan: String, id: Int, title: String, text: String, target: Class<*>?) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(chan, c.L("المراقب", "Overseer"), NotificationManager.IMPORTANCE_DEFAULT))
        val b = Notification.Builder(c, chan).setSmallIcon(R.drawable.ic_stat).setContentTitle(title).setContentText(text).setAutoCancel(true)
        if (target != null) {
            b.setContentIntent(
                PendingIntent.getActivity(
                    c, id, Intent(c, target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
        }
        nm.notify(id, b.build())
    }
}

object DiscAlarm {
    private fun pi(c: Context, code: Int, cls: Class<*>): PendingIntent =
        PendingIntent.getBroadcast(c, code, Intent(c, cls), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun at(minOfDay: Int): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, minOfDay / 60)
        cal.set(Calendar.MINUTE, minOfDay % 60)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis() + 1000L) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        val lv = Disc.cur(c)
        if (lv == null || lv.id < 2) {
            am.cancel(pi(c, 51, CheckinReceiver::class.java))
            am.cancel(pi(c, 52, ForcedReceiver::class.java))
            return
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at(Prefs.intOf(c, "ciMin", 21 * 60)), pi(c, 51, CheckinReceiver::class.java))
        if (lv.forced) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at(Prefs.intOf(c, "fcMin", 17 * 60)), pi(c, 52, ForcedReceiver::class.java))
        else am.cancel(pi(c, 52, ForcedReceiver::class.java))
    }
}

class CheckinReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Disc.notify(c, "checkin", 71, c.L("وقت الحساب", "Daily check-in"),
            c.L("ماذا أنجزت اليوم؟ اضغط لتسجّل يومك.", "What did you achieve today? Tap to log your day."), CheckinActivity::class.java)
        DiscAlarm.schedule(c)
    }
}

class ForcedReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Disc.startForced(c)
        DiscAlarm.schedule(c)
    }
}

class CheckinActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applyTheme()
        val ev = Disc.today(this)
        val need = (Disc.level(this)?.id ?: 1) >= 2
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(30), dp(20), dp(24)) }
        root.addView(tv(L("حساب اليوم", "Daily check-in"), 26f, C.TX, true))
        root.put(tv(L("ما تحقق فعلًا (يُحسب تلقائيًا)", "What actually happened (tracked automatically)"), 13f, C.MU), 4)
        val st = card()
        st.addView(tv(L("تركيز: ${ev.focus} / ${ev.focusT} دقيقة", "Focus: ${ev.focus} / ${ev.focusT} min"), 16f, if (ev.focus >= ev.focusT) C.OK else C.WR, true))
        st.put(tv(L("مهام: ${ev.tasks} / ${ev.tasksT}", "Tasks: ${ev.tasks} / ${ev.tasksT}"), 16f, if (ev.tasks >= ev.tasksT) C.OK else C.WR, true), 6)
        st.put(tv(L("الدَين الحالي: ${Disc.debt(this)} دقيقة. السلسلة: ${Prefs.intOf(this, "streak", 0)} يوم.", "Current debt: ${Disc.debt(this)} min. Streak: ${Prefs.intOf(this, "streak", 0)} days."), 13f, C.MU), 6)
        root.put(st, 14)
        root.put(tv(L("ماذا أنجزت اليوم؟ اكتب بصدق" + (if (need) " (10 أحرف على الأقل)" else ""), "What did you achieve today? Be honest" + (if (need) " (10+ characters)" else "")), 15f, C.TX), 18)
        val et = EditText(this).apply {
            minLines = 3; gravity = Gravity.TOP
            setTextColor(C.TX); setHintTextColor(C.MU)
            background = rounded(C.SF, 12, C.LN)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        root.put(et, 8)
        root.put(tv(L("كيف تقيّم يومك؟", "How do you rate your day?"), 14f, C.MU), 14)
        var rating = 3
        val chips = LinearLayout(this)
        val chipViews = ArrayList<TextView>()
        for (n in 1..5) {
            val chip = tv("$n", 16f, C.TX).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)) }
            chipViews.add(chip)
            chips.addView(chip, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
        }
        fun paint() {
            chipViews.forEachIndexed { k, v ->
                val on = k + 1 == rating
                v.background = rounded(if (on) C.AC else C.SF, 12, C.LN)
                v.setTextColor(if (on) C.ON else C.TX)
            }
        }
        chipViews.forEachIndexed { k, v -> v.setOnClickListener { rating = k + 1; paint() } }
        paint()
        root.put(chips, 6)
        root.put(btn(L("إرسال", "Submit"), true) {
            val t = et.text.toString().trim()
            if (need && t.length < 10) {
                Toast.makeText(this, L("اكتب 10 أحرف على الأقل", "Write at least 10 characters"), Toast.LENGTH_LONG).show()
            } else {
                Disc.addJournal(this, rating, t)
                Prefs.putStr(this, "lastCheckin", Prefs.dayKey())
                val ev2 = Disc.today(this)
                val msg: String
                if (ev2.met) { Disc.reward(this); msg = Disc.message(this, ev2, 0) }
                else { val add = Disc.penalize(this, ev2); msg = Disc.message(this, ev2, add) }
                dlg().setTitle(L("نتيجة اليوم", "Today's result")).setMessage(msg)
                    .setPositiveButton(L("حسنًا", "OK")) { _, _ -> finish() }.setCancelable(false).show()
            }
        }, 18)
        root.applyDir()
        setContentView(ScrollView(this).apply { setBackgroundColor(C.BG); isFillViewport = true; addView(root) })
    }
}

class DisciplinePage(private val a: Activity) {
    private lateinit var col: LinearLayout

    fun build(): View {
        col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(18), a.dp(26), a.dp(18), a.dp(24)) }
        render()
        return ScrollView(a).apply { addView(col) }
    }

    fun refresh() = render()

    private fun fmt(min: Int): String = String.format(java.util.Locale.US, "%02d:%02d", min / 60, min % 60)

    private fun render() {
        col.removeAllViews()
        col.put(a.tv(a.L("المراقب", "The Overseer"), 24f, C.TX, true), 0)
        col.put(a.tv(a.L("نظام التزام تختاره بنفسك. كل مستوى يشرح لك ما سيحدث قبل أن توافق.", "A commitment system you choose yourself. Each level explains what will happen before you agree."), 13f, C.MU), 4)

        val lv = Disc.level(a)
        val st = a.card()
        st.addView(a.tv(if (lv == null) a.L("المراقب متوقف", "Overseer is off") else a.L("المستوى الحالي: ${lv.ar}", "Current level: ${lv.en}"), 17f, C.AC, true))
        if (lv != null) {
            val ev = Disc.today(a)
            st.put(a.tv(a.L("اليوم: ${ev.focus}/${ev.focusT} دقيقة تركيز، ${ev.tasks}/${ev.tasksT} مهام", "Today: ${ev.focus}/${ev.focusT} focus min, ${ev.tasks}/${ev.tasksT} tasks"), 14f, C.TX), 8)
            st.put(a.tv(a.L("الدَين: ${Disc.debt(a)} دقيقة. السلسلة: ${Prefs.intOf(a, "streak", 0)} يوم", "Debt: ${Disc.debt(a)} min. Streak: ${Prefs.intOf(a, "streak", 0)} days"), 13f, C.MU), 4)
        }
        Disc.pendingText(a)?.let { st.put(a.tv(it, 12f, C.WR), 8) }
        col.put(st, 16)
        col.put(rewardsCard(), 12)

        col.put(a.tv(a.L("اختر مستوى الصرامة", "Choose your strictness"), 16f, C.TX, true), 20)
        Disc.levels.forEach { l ->
            val k = a.card()
            val on = lv?.id == l.id
            k.addView(a.tv(a.L(l.ar, l.en) + if (on) "  ✓" else "", 16f, if (on) C.AC else C.TX, true))
            k.put(a.tv(a.L(l.dAr, l.dEn).lines().first(), 12f, C.MU), 4)
            k.setOnClickListener { confirm(l) }
            col.put(k, 8)
        }
        col.put(a.btn(a.L("إيقاف المراقب", "Turn the overseer off")) { confirmOff() }, 10)

        if (lv != null) {
            col.put(a.tv(a.L("أهدافك اليومية", "Your daily targets"), 16f, C.TX, true), 22)
            val fl = a.tv("", 13f, C.MU)
            col.put(fl, 6)
            col.put(seek(0, 24, Disc.focusTarget(a) / 15) { v ->
                Prefs.putInt(a, "tFocus", v * 15)
                fl.text = a.L("تركيز يومي: ${v * 15} دقيقة", "Daily focus: ${v * 15} min")
            }.also { fl.text = a.L("تركيز يومي: ${Disc.focusTarget(a)} دقيقة", "Daily focus: ${Disc.focusTarget(a)} min") }, 2)
            val tl = a.tv("", 13f, C.MU)
            col.put(tl, 10)
            col.put(seek(0, 10, Disc.taskTarget(a)) { v ->
                Prefs.putInt(a, "tTasks", v)
                tl.text = a.L("مهام يومية: $v", "Daily tasks: $v")
            }.also { tl.text = a.L("مهام يومية: ${Disc.taskTarget(a)}", "Daily tasks: ${Disc.taskTarget(a)}") }, 2)

            if (lv.id >= 2) {
                col.put(a.btn(a.L("وقت الحساب المسائي: ", "Evening check-in time: ") + fmt(Prefs.intOf(a, "ciMin", 21 * 60))) {
                    pick(Prefs.intOf(a, "ciMin", 21 * 60)) { m -> Prefs.putInt(a, "ciMin", m); DiscAlarm.schedule(a); render() }
                }, 14)
            }
            if (lv.forced) {
                col.put(a.btn(a.L("وقت الجلسة الإجبارية: ", "Mandatory session time: ") + fmt(Prefs.intOf(a, "fcMin", 17 * 60))) {
                    pick(Prefs.intOf(a, "fcMin", 17 * 60)) { m -> Prefs.putInt(a, "fcMin", m); DiscAlarm.schedule(a); render() }
                }, 8)
            }
            col.put(a.btn(a.L("سجّل يومك الآن", "Log your day now")) { a.startActivity(Intent(a, CheckinActivity::class.java)) }, 8)
        }

        val j = Disc.journal(a).takeLast(5).reversed()
        if (j.isNotEmpty()) {
            col.put(a.tv(a.L("آخر ما سجّلته", "Your recent entries"), 16f, C.TX, true), 22)
            j.forEach { line ->
                val p = line.split("|", limit = 3)
                if (p.size == 3) col.put(a.tv("${p[0].takeLast(4).chunked(2).joinToString("/")}  ★${p[1]}  ${p[2]}", 13f, C.MU), 6)
            }
        }

        val safe = a.card()
        safe.addView(a.tv(a.L("لا يُحظر أبدًا", "Never blocked"), 14f, C.OK, true))
        safe.put(a.tv(a.L("المكالمات والطوارئ والرسائل والبنوك والمحافظ الرقمية والتطبيقات المالية، وأي تطبيق حددته بنجمة ⭐ في صفحة التطبيقات. في كل المستويات.", "Calls, emergency, messages, banks, digital wallets and finance apps, plus any app you starred ⭐ on the Apps page. At every level."), 12f, C.MU), 4)
        col.put(safe, 22)
    }

    private fun rewardsCard(): View {
        val k = a.card()
        k.addView(a.tv(a.L("المكافآت", "Rewards"), 16f, C.TX, true))
        k.put(a.tv(a.L("${Rewards.levelName(a)}: ${Rewards.points(a)} نقطة، ${Rewards.tokens(a)} رمز", "${Rewards.levelName(a)}: ${Rewards.points(a)} points, ${Rewards.tokens(a)} tokens"), 14f, C.AC, true), 6)
        k.put(a.tv(a.L("تكسب نقطة لكل دقيقة تركيز (حتى 120 للجلسة)، و15 لكل مهمة، و60 فأكثر عند بلوغ هدفك اليومي. كل 500 نقطة = رمز، وتشتري به راحة مشروطة حتى لا تُرهق نفسك.", "You earn a point per focus minute (up to 120 per session), 15 per task, and 60+ when you hit your daily target. Every 500 points = 1 token, which buys conditional rest so you don't burn out."), 12f, C.MU), 6)
        k.put(a.btn(a.L("سدّد 30 دقيقة دَين (رمز)", "Repay 30 min of debt (1 token)")) {
            val why = Rewards.payDebt(a)
            Toast.makeText(a, why ?: a.L("تم سداد 30 دقيقة.", "30 minutes repaid."), Toast.LENGTH_LONG).show()
            render()
        }, 10)
        k.put(a.btn(a.L("إجازة اليوم بلا عقوبة (رمزان)", "Penalty-free rest day (2 tokens)")) {
            val why = Rewards.whyNotRest(a)
            if (why != null) Toast.makeText(a, why, Toast.LENGTH_LONG).show()
            else a.dlg().setMessage(a.L("تفعيل إجازة اليوم؟ لن يُحاسبك التطبيق اليوم.", "Activate today's rest day? The app won't penalize you today."))
                .setPositiveButton(a.L("نعم", "Yes")) { _, _ -> Rewards.useRest(a); render() }
                .setNegativeButton(a.L("إلغاء", "Cancel"), null).show()
        }, 8)
        k.put(a.btn(a.L("استراحة بلا ذنب 15 دقيقة (رمز)", "Guilt-free 15-minute break (1 token)")) { pickBreakApp() }, 8)
        return k
    }

    private fun pickBreakApp() {
        val pkgs = Prefs.blocked(a).toList()
        if (pkgs.isEmpty()) { Toast.makeText(a, a.L("لا توجد تطبيقات محظورة لتحرّر أحدها.", "There are no blocked apps to free."), Toast.LENGTH_LONG).show(); return }
        val labels = pkgs.map { a.appLabel(it) }.toTypedArray()
        a.dlg().setTitle(a.L("أي تطبيق تفتحه 15 دقيقة؟", "Which app to unlock for 15 minutes?"))
            .setItems(labels) { _, i ->
                val why = Rewards.freePass(a, pkgs[i])
                Toast.makeText(a, why ?: a.L("استمتع بـ15 دقيقة. ستعود الحماية بعدها.", "Enjoy 15 minutes. Protection returns afterwards."), Toast.LENGTH_LONG).show()
                render()
            }
            .setNegativeButton(a.L("إلغاء", "Cancel"), null).show()
    }

    private fun seek(lo: Int, hi: Int, cur: Int, onChange: (Int) -> Unit): SeekBar = SeekBar(a).apply {
        max = hi - lo
        progress = (cur - lo).coerceIn(0, hi - lo)
        progressTintList = android.content.res.ColorStateList.valueOf(C.AC)
        thumbTintList = android.content.res.ColorStateList.valueOf(C.AC)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) onChange(p + lo) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun pick(cur: Int, done: (Int) -> Unit) {
        TimePickerDialog(a, { _, h, m -> done(h * 60 + m) }, cur / 60, cur % 60, true).show()
    }

    private fun confirm(l: Disc.Lv) {
        val msg = a.L(l.dAr, l.dEn) + "\n\n" + a.L("لا يُحظر أبدًا: المكالمات والطوارئ والبنوك والتطبيقات المالية.", "Never blocked: calls, emergency, banks and finance apps.") + "\n\n" + a.L("هل توافق على هذا المستوى؟", "Do you agree to this level?")
        a.dlg().setTitle(a.L("مستوى ${l.ar}", "${l.en} level")).setMessage(msg)
            .setPositiveButton(a.L("أوافق", "I agree")) { _, _ ->
                val now = Disc.request(a, l.id)
                Toast.makeText(a, if (now) a.L("تم تفعيل المستوى", "Level activated") else a.L("سيُطبّق بعد 24 ساعة", "Will apply in 24 hours"), Toast.LENGTH_LONG).show()
                render()
            }
            .setNegativeButton(a.L("إلغاء", "Cancel"), null).show()
    }

    private fun confirmOff() {
        a.dlg().setMessage(a.L("إيقاف المراقب؟ من مستوى «جاد» وأعلى يتأخر الإيقاف 24 ساعة.", "Turn the overseer off? From Serious and above, turning it off takes 24 hours."))
            .setPositiveButton(a.L("نعم", "Yes")) { _, _ ->
                val now = Disc.request(a, 0)
                Toast.makeText(a, if (now) a.L("تم الإيقاف", "Turned off") else a.L("سيتوقف بعد 24 ساعة", "Will stop in 24 hours"), Toast.LENGTH_LONG).show()
                render()
            }
            .setNegativeButton(a.L("إلغاء", "Cancel"), null).show()
    }
}
