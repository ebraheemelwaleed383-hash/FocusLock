package com.focuslock

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------- الجلسات التلقائية: قواعد (أيام + وقت + مدة) تبدأ الجلسة وحدها ----------
object AutoSched {
    // days: كل بت يمثل يومًا (0 = الأحد ... 6 = السبت)
    class Rule(val days: Int, val min: Int, val len: Int)

    fun rules(c: Context): MutableList<Rule> {
        val out = ArrayList<Rule>()
        try {
            val a = JSONArray(Prefs.str(c, "autoRules", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Rule(o.getInt("d"), o.getInt("m"), o.getInt("l")))
            }
        } catch (_: Exception) { }
        return out
    }

    fun save(c: Context, l: List<Rule>) {
        val a = JSONArray()
        for (r in l) a.put(JSONObject().put("d", r.days).put("m", r.min).put("l", r.len))
        Prefs.putStr(c, "autoRules", a.toString())
        schedule(c)
    }

    fun describe(c: Context, r: Rule): String {
        val names = arrayOf(c.L("الأحد", "Sun"), c.L("الإثنين", "Mon"), c.L("الثلاثاء", "Tue"), c.L("الأربعاء", "Wed"),
            c.L("الخميس", "Thu"), c.L("الجمعة", "Fri"), c.L("السبت", "Sat"))
        val days = ArrayList<String>()
        for (d in 0..6) if (((r.days shr d) and 1) == 1) days.add(names[d])
        val t = String.format(Locale.US, "%02d:%02d", r.min / 60, r.min % 60)
        return days.joinToString("، ") + " · " + t + " · " + r.len + c.L(" د", " min")
    }

    private fun pending(c: Context, extras: Intent?): PendingIntent {
        val i = extras ?: Intent(c, AutoStartReceiver::class.java)
        return PendingIntent.getBroadcast(c, 81, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    // يجدول أقرب موعد قادم بين كل القواعد
    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        val now = System.currentTimeMillis()
        var best = Long.MAX_VALUE
        var bestLen = 0
        for (r in rules(c)) {
            for (d in 0..7) {
                val cal = Calendar.getInstance()
                cal.add(Calendar.DAY_OF_YEAR, d)
                cal.set(Calendar.HOUR_OF_DAY, r.min / 60)
                cal.set(Calendar.MINUTE, r.min % 60)
                cal.set(Calendar.SECOND, 0)
                cal.set(Calendar.MILLISECOND, 0)
                val bit = cal.get(Calendar.DAY_OF_WEEK) - 1
                if (cal.timeInMillis > now + 1000L && ((r.days shr bit) and 1) == 1) {
                    if (cal.timeInMillis < best) {
                        best = cal.timeInMillis
                        bestLen = r.len
                    }
                    break
                }
            }
        }
        if (best == Long.MAX_VALUE) {
            am.cancel(pending(c, null))
            return
        }
        val withData = Intent(c, AutoStartReceiver::class.java).putExtra("len", bestLen).putExtra("at", best)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best, pending(c, withData))
    }

    fun start(c: Context, len: Int) {
        if (Prefs.active(c) || Plans.running(c)) return
        if (!Prefs.hasPassword(c) || !Engine.ready(c)) return
        if (Prefs.blocked(c).isEmpty() && !Prefs.strict(c)) return
        Prefs.clearFails(c)
        Prefs.begin(c, len)
        try { EndAlarm.schedule(c); KeepAliveService.start(c) } catch (_: Exception) { }
        Disc.notify(c, "auto", 73, c.L("جلسة تلقائية", "Scheduled session"),
            c.L("بدأت جلسة تركيز $len دقيقة حسب جدولك.", "A $len-minute focus session started as scheduled."), LockActivity::class.java)
        try { c.startActivity(Intent(c, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
    }
}

class AutoStartReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val len = i.getIntExtra("len", 0)
        val at = i.getLongExtra("at", 0L)
        // نجدول الموعد القادم أولًا حتى لو تخطينا هذا
        AutoSched.schedule(c)
        if (len <= 0 || System.currentTimeMillis() - at > 30 * 60_000L) return
        AutoSched.start(c, len)
    }
}

// ---------- التقرير الأسبوعي: إشعار كل جمعة 8 مساءً ----------
object WeeklyReport {
    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(c, 82, Intent(c, WeeklyReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        if (!Prefs.boolOf(c, "weekly", true)) {
            am.cancel(pi)
            return
        }
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 20)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        while (cal.get(Calendar.DAY_OF_WEEK) != Calendar.FRIDAY || cal.timeInMillis <= System.currentTimeMillis() + 1000L) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }

    // مجموع دقائق التركيز لسبعة أيام تنتهي قبل endDaysAgo يومًا من اليوم
    fun minutes(c: Context, endDaysAgo: Int): Long {
        var s = 0L
        for (d in endDaysAgo until endDaysAgo + 7) {
            s += Prefs.dayVal(c, "fm", Prefs.dayKey(System.currentTimeMillis() - d * 86_400_000L))
        }
        return s
    }
}

class WeeklyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        WeeklyReport.schedule(c)
        val cur = WeeklyReport.minutes(c, 0)
        val prev = WeeklyReport.minutes(c, 7)
        if (cur == 0L && prev == 0L) return
        val h = cur / 60
        val m = cur % 60
        var t = c.L("هذا الأسبوع: $h س $m د من التركيز", "This week: ${h}h ${m}m of focus")
        if (prev > 0L) {
            val pct = ((cur - prev) * 100 / prev).toInt()
            val sign = if (pct >= 0) "+" else ""
            t += c.L(" ($sign$pct% عن الأسبوع الماضي)", " ($sign$pct% vs last week)")
        }
        Disc.notify(c, "weekly", 74, c.L("تقريرك الأسبوعي", "Your weekly report"), t, MainActivity::class.java)
    }
}

// ---------- زر الإعدادات السريعة: يبدأ جلسة 25 دقيقة ----------
class FocusTile : TileService() {
    override fun onStartListening() {
        val t = qsTile ?: return
        t.state = if (Prefs.active(this)) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Vigil"
        t.updateTile()
    }

    override fun onClick() {
        val intent = Intent(this, SplashActivity::class.java)
            .putExtra("quick", 25)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(this, 9, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            startActivityAndCollapse(pi)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }
}

// ---------- ويدجت الشاشة الرئيسية: السلسلة وتركيز اليوم ----------
class FocusWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, build(c))
    }

    companion object {
        fun build(c: Context): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.widget_focus)
            val streak = Prefs.intOf(c, "streak", 0)
            val today = Prefs.todayOf(c, "fm")
            val title = if (Prefs.active(c)) {
                val until = SimpleDateFormat("HH:mm", Locale.US).format(Date(Prefs.end(c)))
                c.L("تركيز حتى $until", "Focus until $until")
            } else {
                c.L("ابدأ تركيزك", "Start focus")
            }
            rv.setTextViewText(R.id.w_title, title)
            rv.setTextViewText(R.id.w_sub, c.L("اليوم $today د · سلسلة $streak", "Today $today min · streak $streak"))
            val pi = PendingIntent.getActivity(
                c, 10, Intent(c, SplashActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.w_root, pi)
            return rv
        }

        fun refresh(c: Context) {
            try {
                val m = AppWidgetManager.getInstance(c)
                val ids = m.getAppWidgetIds(ComponentName(c, FocusWidget::class.java))
                for (id in ids) m.updateAppWidget(id, build(c))
            } catch (_: Exception) { }
        }
    }
}
