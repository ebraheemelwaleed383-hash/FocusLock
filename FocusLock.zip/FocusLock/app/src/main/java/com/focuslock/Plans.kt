package com.focuslock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

class Seg(val w: Float, val kind: Int, val label: String = "")

class Sys(
    val id: String, val ar: String, val en: String, val dAr: String, val dEn: String,
    val phases: List<Pair<Char, Int>>?, val segs: List<Seg>, val action: String = ""
)

// نظم الدراسة: كل نظام سلسلة مراحل F (تركيز مع قفل) و B (استراحة)
object Plans {
    private fun cyc(f: Int, b: Int, n: Int): List<Pair<Char, Int>> =
        (1..n).flatMap { i -> if (i == n) listOf('F' to f) else listOf('F' to f, 'B' to b) }

    private fun sys(id: String, ar: String, en: String, dAr: String, dEn: String,
                    ph: List<Pair<Char, Int>>?, segs: List<Seg>? = null, action: String = ""): Sys =
        Sys(id, ar, en, dAr, dEn, ph, segs ?: ph!!.map { Seg(it.second.toFloat(), if (it.first == 'F') 0 else 1) }, action)

    val all: List<Sys> = listOf(
        sys("pomo25", "بومودورو 25/5", "Pomodoro 25/5",
            "25 دقيقة تركيز ثم 5 راحة. بعد 4 جولات خذ استراحة طويلة 15 دقيقة. مناسب للبداية وللمهام المملة.",
            "25 minutes of focus, then 5 off. After 4 rounds take a long 15-minute break. Great for starting and for boring tasks.", cyc(25, 5, 4)),
        sys("pomo50", "بومودورو 50/10", "Pomodoro 50/10",
            "جولات أطول للمذاكرة والبرمجة: 50 دقيقة تركيز و10 راحة.",
            "Longer rounds for studying and coding: 50 minutes of focus and 10 off.", cyc(50, 10, 3)),
        sys("pomo52", "بومودورو 52/17", "Pomodoro 52/17",
            "نسبة اشتهرت في دراسة عن أكثر الموظفين إنتاجية: 52 دقيقة عمل و17 راحة.",
            "A ratio made famous by a study of highly productive workers: 52 minutes of work and 17 off.", cyc(52, 17, 3)),
        sys("ultra90", "الدورة الفائقة 90/20", "Ultradian 90/20",
            "مبنية على فكرة دورات الطاقة في الجسم: اعمل 90 دقيقة ثم ارتح 20.",
            "Based on the body's energy cycles: work for 90 minutes, then rest for 20.", cyc(90, 20, 2)),
        sys("s60", "60/10", "60/10", "ساعة تركيز كاملة ثم 10 دقائق راحة. بسيطة وسهلة الحفظ.", "A full hour of focus, then 10 minutes off. Simple and easy to remember.", cyc(60, 10, 3)),
        sys("s45", "45/15", "45/15", "تناسب حصص الدراسة: 45 دقيقة تركيز و15 راحة.", "Fits study sessions: 45 minutes of focus and 15 off.", cyc(45, 15, 3)),
        sys("n9091", "90-90-1", "90-90-1",
            "90 دقيقة أول اليوم على هدف واحد مهم، لمدة 90 يومًا. الثبات هو السر.",
            "90 minutes first thing in the day on ONE important goal, for 90 days. Consistency is the secret.", listOf('F' to 90)),
        sys("block", "تقسيم الوقت", "Time Blocking",
            "تقسّم يومك إلى كتل، وتخصّص لكل كتلة مهمة محددة. ابدأ بكتلة تركيز 60 دقيقة.",
            "Split your day into blocks and give each block one specific job. Start with a 60-minute focus block.", listOf('F' to 60),
            listOf(Seg(2f, 0, "A"), Seg(0.5f, 1), Seg(2f, 0, "B"), Seg(1f, 2, "☕"), Seg(2f, 0, "C"))),
        sys("box", "تحديد صندوق زمني", "Timeboxing",
            "تحدد وقتًا ثابتًا للمهمة وتتوقف عنده حتى لو لم تكتمل. اختر المدة وابدأ.",
            "Give a task a fixed time box and stop when it ends, finished or not. Pick the length and go.", null,
            listOf(Seg(4f, 0, "⏳")), "box"),
        sys("flow", "فلو تايم", "Flowtime",
            "اعمل بدون مؤقت حتى يضعف تركيزك، ثم ارتح بقدر خُمس وقت عملك. لا قفل هنا.",
            "Work with no timer until your focus fades, then rest for one fifth of your work time. No lock here.", null,
            listOf(Seg(4f, 0, "Flow"), Seg(1f, 1)), "flow"),
        sys("n888", "8+8+8", "8+8+8",
            "8 ساعات عمل، 8 نوم، 8 لنفسك وأسرتك. ابدأ جلسة عمل 90 دقيقة.",
            "8 hours work, 8 sleep, 8 for yourself and family. Start a 90-minute work session.", listOf('F' to 90),
            listOf(Seg(8f, 0, "8"), Seg(8f, 2, "8"), Seg(8f, 1, "8"))),
        sys("deep4", "4 ساعات عمل عميق", "4 Hours Deep Work",
            "أربع ساعات عمل عميق: ثلاث كتل 80 دقيقة بينها راحة 10.",
            "Four hours of deep work: three 80-minute blocks with 10-minute breaks.", listOf('F' to 80, 'B' to 10, 'F' to 80, 'B' to 10, 'F' to 80)),
        sys("ivy", "آيفي لي (6 مهام)", "Ivy Lee (6 tasks)",
            "آخر اليوم اكتب 6 مهام لبكرة ورتّبها بالأهمية. ابدأ بالأولى ولا تنتقل قبل إنهائها.",
            "At day's end write 6 tasks for tomorrow, ranked by importance. Do #1 first and don't move on until it's done.", null,
            (1..6).map { Seg(1f, 0, "$it") }, "tasks"),
        sys("two", "قاعدة الدقيقتين", "2-Minute Rule",
            "لو المهمة تأخذ دقيقتين أو أقل، نفّذها فورًا. ابدأ دقيقتين الآن.",
            "If it takes two minutes or less, do it now. Start two minutes right away.", listOf('F' to 2)),
        sys("frog", "ابتلع الضفدع", "Eat the Frog",
            "ابدأ بأصعب مهمة في يومك وطاقتك في أعلاها: 60 دقيقة بدون تشتيت.",
            "Start with your hardest task while your energy is highest: 60 distraction-free minutes.", listOf('F' to 60)),
        sys("micro", "سبرنتات صغيرة 15/3", "Micro-Sprints 15/3",
            "للأيام الثقيلة: 15 دقيقة تركيز و3 راحة، ست مرات. سهل البداية.",
            "For heavy days: 15 minutes of focus and 3 off, six times. Easy to start.", cyc(15, 3, 6)),
        sys("dive", "غوص عميق 120/20", "Deep Dive 120/20",
            "ساعتان متواصلتان، راحة 20 دقيقة، ثم ساعتان. للمشاريع الكبيرة.",
            "Two uninterrupted hours, a 20-minute rest, then two more. For big projects.", cyc(120, 20, 2)),
        sys("recall", "استرجاع نشط 30/5", "Active Recall 30/5",
            "30 دقيقة مذاكرة، وآخر 5 منها تسترجع فيها المعلومات من ذاكرتك دون النظر للكتاب، ثم راحة 5.",
            "30 minutes of study; use the last 5 to recall everything from memory without looking, then rest for 5.", cyc(30, 5, 3)),
        sys("rule3", "قاعدة الثلاثة", "Rule of 3",
            "اختر 3 مهام فقط لليوم، لكل مهمة جلسة 40 دقيقة بينها راحة 10.",
            "Pick only 3 tasks for the day; one 40-minute session each with 10-minute breaks.", cyc(40, 10, 3)),
        sys("exam", "سباق الامتحان 90/30", "Exam Sprint 90/30",
            "قبل الامتحان: 90 دقيقة مذاكرة وراحة حقيقية 30 دقيقة، ثلاث جولات.",
            "Before exams: 90 minutes of study and a real 30-minute rest, three rounds.", cyc(90, 30, 3))
    )

    fun find(id: String): Sys? = all.firstOrNull { it.id == id }

    fun state(c: Context): Pair<Sys, Int>? {
        val s = Prefs.str(c, "plan", "")
        if (s.isEmpty()) return null
        val sys = find(s.substringBefore("|")) ?: return null
        val idx = s.substringAfter("|").toIntOrNull() ?: return null
        return if (sys.phases != null) sys to idx else null
    }

    fun running(c: Context): Boolean = state(c) != null

    private fun save(c: Context, id: String, idx: Int) = Prefs.putStr(c, "plan", "$id|$idx")

    fun stop(c: Context) { Prefs.putStr(c, "plan", ""); Prefs.putLong(c, "breakEnd", 0L) }

    fun start(c: Context, sys: Sys) { save(c, sys.id, -1); advance(c) }

    private fun advance(c: Context): Boolean {
        val st = state(c) ?: return false
        val ph = st.first.phases!!
        val next = st.second + 1
        if (next >= ph.size) { stop(c); return false }
        save(c, st.first.id, next)
        val (kind, mins) = ph[next]
        if (kind == 'F') {
            Prefs.clearFails(c); Prefs.begin(c, mins); EndAlarm.schedule(c); KeepAliveService.start(c)
            c.startActivity(Intent(c, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else {
            Prefs.putLong(c, "breakEnd", System.currentTimeMillis() + mins * 60_000L)
            c.startActivity(Intent(c, BreakActivity::class.java).putExtra("mode", "plan").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        return true
    }

    fun onFocusEnd(c: Context): Boolean = if (running(c)) advance(c) else false
    fun onBreakEnd(c: Context): Boolean = if (running(c)) advance(c) else false

    fun label(c: Context): String? {
        val st = state(c) ?: return null
        val ph = st.first.phases!!
        val total = ph.count { it.first == 'F' }
        val cur = ph.take(st.second + 1).count { it.first == 'F' }
        return c.L(st.first.ar, st.first.en) + ": " + c.L("الجولة", "Round") + " $cur/$total"
    }

    // لو انتهت جولة التركيز ولم يلتقطها أحد (التطبيق مغلق) نرسل إشعارًا لمتابعة النظام
    fun notifyNext(c: Context) {
        val st = state(c) ?: return
        if (st.first.phases!![st.second].first != 'F') return
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("plan", c.L("نظم الدراسة", "Study systems"), NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(c, 60, Intent(c, BreakActivity::class.java).putExtra("mode", "plan").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        nm.notify(61, Notification.Builder(c, "plan").setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(c.L("أحسنت! انتهت الجولة", "Well done! Round finished"))
            .setContentText(c.L("اضغط للمتابعة إلى الخطوة التالية", "Tap to continue to the next step"))
            .setContentIntent(pi).setAutoCancel(true).build())
    }
}
