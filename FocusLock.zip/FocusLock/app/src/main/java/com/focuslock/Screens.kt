package com.focuslock

import android.app.Activity
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

object BreakAlarm {
    private fun pi(c: Context): PendingIntent = PendingIntent.getBroadcast(
        c, 43, Intent(c, BreakEndReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
    fun schedule(c: Context) {
        val t = Prefs.longOf(c, "breakEnd")
        if (t > System.currentTimeMillis()) c.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi(c))
    }
    fun cancel(c: Context) { c.getSystemService(AlarmManager::class.java).cancel(pi(c)) }
}

class BreakEndReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!Plans.running(c)) return
        if (Prefs.planAuto(c)) { Plans.onBreakEnd(c); return }
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("plan", c.L("نظم الدراسة", "Study systems"), NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(c, 62, Intent(c, BreakActivity::class.java).putExtra("mode", "plan").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        nm.notify(63, Notification.Builder(c, "plan").setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(c.L("انتهت الاستراحة", "Break is over"))
            .setContentText(c.L("اضغط لبدء الجولة التالية", "Tap to start the next round"))
            .setContentIntent(pi).setAutoCancel(true).build())
    }
}

// شاشة الاستراحة بين جولات نظام الدراسة (أو بعد فلو تايم)
class BreakActivity : Activity() {
    private lateinit var timer: TextView
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { update(); h.postDelayed(this, 1000) } }
    private var mode = "plan"
    private var finished = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applyTheme()
        mode = intent.getStringExtra("mode") ?: "plan"
        if (mode == "plan") {
            Plans.sync(this)
            val st = Plans.state(this)
            if (st == null) { finish(); return }
            if (st.first.phases!![st.second].first == 'F') {
                startActivity(Intent(this, LockActivity::class.java)); finish(); return
            }
            BreakAlarm.schedule(this)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(C.BG); setPadding(dp(24), dp(40), dp(24), dp(24))
        }
        root.addView(tv("☕", 54f).apply { gravity = Gravity.CENTER })
        root.addView(tv(L("وقت الاستراحة", "Break time"), 26f, C.TX, true).apply { gravity = Gravity.CENTER })
        Plans.label(this)?.let { root.addView(tv(it, 13f, C.MU).apply { gravity = Gravity.CENTER }) }
        Plans.finishedTask(this)?.let { t ->
            val cd = card()
            cd.addView(tv(L("هل أنهيت «$t»؟", "Did you finish \u201C$t\u201D?"), 15f, C.TX).apply { gravity = Gravity.CENTER })
            val row = LinearLayout(this)
            row.addView(btn(L("أنهيتها ✔", "Done ✔"), true) {
                val l = Tasks.load(this)
                l.firstOrNull { it.t == t && !it.d }?.d = true
                Tasks.save(this, l)
                Sfx.task(this, Sfx.DONE)
                cd.visibility = View.GONE
            }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(4) })
            row.addView(btn(L("ليس بعد", "Not yet")) { cd.visibility = View.GONE },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(4) })
            cd.put(row, 10)
            root.put(cd, 14)
        }
        timer = tv("", 52f, C.AC, true).apply { gravity = Gravity.CENTER }
        root.put(timer, 20)
        val tip = card()
        tip.addView(tv(L("قم وتحرك، اشرب ماء، وبعّد عينك عن الشاشة.", "Stand up, drink some water and rest your eyes."), 16f, C.TX).apply { gravity = Gravity.CENTER })
        root.put(tip, 20)
        val q = card()
        q.addView(tv("\u201C" + Quotes.random(this) + "\u201D", 15f, C.MU).apply { gravity = Gravity.CENTER })
        root.put(q, 12)
        if (mode == "plan") {
            root.put(btn(L("ابدأ الجولة التالية الآن", "Start the next round now"), true) { done() }, 20)
            root.put(btn(L("إيقاف النظام", "Stop the plan")) { Plans.stop(this); BreakAlarm.cancel(this); finish() }, 8)
        } else root.put(btn(L("تمام", "OK"), true) { finish() }, 20)
        root.applyDir()
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
        update()
    }

    private fun done() {
        if (finished) return
        finished = true
        BreakAlarm.cancel(this)
        if (mode == "plan") {
            val had = Plans.running(this)
            Plans.onBreakEnd(this)
            if (had && !Plans.running(this)) Toast.makeText(this, L("اكتمل النظام 🎉", "Plan complete 🎉"), Toast.LENGTH_LONG).show()
        }
        finish()
    }

    private fun update() {
        val left = (Prefs.longOf(this, "breakEnd") - System.currentTimeMillis()) / 1000
        if (left <= 0) {
            if (mode == "plan") {
                if (Plans.paused(this)) { timer.text = "00:00"; return }
                done()
            } else finish()
            return
        }
        timer.text = String.format(Locale.US, "%02d:%02d", left / 60, left % 60)
    }

    override fun onResume() { super.onResume(); if (!finished) h.post(tick) }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }
}

// تنبيه المرشد الذكي: هادئ ويعطيك الاختيار
class NudgeActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applyTheme()
        val pkg = intent.getStringExtra("pkg") ?: ""
        val m = intent.getIntExtra("min", 0)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(C.BG); setPadding(dp(24), dp(32), dp(24), dp(24))
        }
        appIcon(pkg)?.let { root.addView(ImageView(this).apply { setImageDrawable(it) }, LinearLayout.LayoutParams(dp(72), dp(72))) }
        root.put(tv(L("بقالك $m دقيقة في ${appLabel(pkg)}", "$m minutes in ${appLabel(pkg)}"), 22f, C.TX, true).apply { gravity = Gravity.CENTER }, 16)
        root.put(tv(L("خد نفس. تحب تعمل إيه دلوقتي؟", "Take a breath. What would you like to do?"), 15f, C.MU).apply { gravity = Gravity.CENTER }, 6)
        Tasks.load(this).filter { !it.d }.maxByOrNull { it.p }?.let {
            val c = card()
            c.addView(tv(L("أهم مهمة مستنياك: ", "Your top task: ") + it.t, 15f, C.TX).apply { gravity = Gravity.CENTER })
            root.put(c, 16)
        }
        root.put(btn(L("ابدأ 15 دقيقة تركيز", "Start 15 min focus"), true) {
            Smart.learn(this, true)
            startActivity(Intent(this, MainActivity::class.java).putExtra("quick", 15))
            finish()
        }, 20)
        root.put(btn(L("اقفل التطبيق", "Close the app")) {
            Smart.learn(this, true); startActivity(homeIntent()); finish()
        }, 8)
        root.put(btn(L("5 دقائق كمان", "5 more minutes")) {
            Smart.learn(this, false); Smart.snooze(this, 10); finish()
        }, 8)
        root.applyDir()
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { finish() }
}

// شاشة انتهاء الوقت المسموح لتطبيق: يُقفل 12 ساعة، ومعه دخول طارئ بكلمة المرور
class LimitActivity : Activity() {
    private lateinit var msg: TextView
    private lateinit var exitBox: LinearLayout
    private lateinit var pw: EditText
    private lateinit var unlockBtn: Button
    private var pkg = ""
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { upd(); h.postDelayed(this, 1000) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applyTheme()
        pkg = intent.getStringExtra("pkg") ?: ""
        val until = Limits.find(this, pkg)?.blockedUntil ?: 0L
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(C.BG); setPadding(dp(24), dp(32), dp(24), dp(24))
        }
        appIcon(pkg)?.let { root.addView(ImageView(this).apply { setImageDrawable(it) }, LinearLayout.LayoutParams(dp(72), dp(72))) }
        root.put(tv(L("انتهى الوقت المسموح لـ ${appLabel(pkg)}", "Time is up for ${appLabel(pkg)}"), 22f, C.TX, true).apply { gravity = Gravity.CENTER }, 16)
        if (until > 0L) root.put(tv(L("يفتح الساعة ", "Opens again at ") + clock(until), 15f, C.AC).apply { gravity = Gravity.CENTER }, 6)
        val q = card()
        q.addView(tv("\u201C" + Quotes.random(this) + "\u201D", 16f, C.TX).apply { gravity = Gravity.CENTER })
        root.put(q, 20)
        msg = tv("", 14f, C.WR).apply { gravity = Gravity.CENTER }
        root.put(msg, 10)
        root.put(btn(L("الصفحة الرئيسية", "Go home"), true) { startActivity(homeIntent()); finish() }, 16)
        root.put(btn(L("دخول طارئ", "Emergency access")) { exitBox.visibility = View.VISIBLE }, 8)
        exitBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        pw = EditText(this).apply {
            hint = L("كلمة مرور الخروج الطارئ", "Emergency password")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(C.TX); setHintTextColor(C.MU); gravity = Gravity.CENTER
            background = rounded(C.SF, 12, C.LN); setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        unlockBtn = btn(L("افتح 10 دقائق", "Open for 10 minutes")) { tryUnlock() }
        exitBox.put(pw, 0)
        exitBox.put(unlockBtn, 8)
        root.put(exitBox, 10)
        root.applyDir()
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
    }

    private fun tryUnlock() {
        if (Prefs.check(this, pw.text.toString())) {
            Prefs.clearFails(this)
            Limits.grace(this, pkg)
            finish()
        } else {
            Prefs.registerFail(this)
            pw.text.clear()
            msg.text = L("كلمة المرور خاطئة. تمت إضافة عقوبة زمنية.", "Wrong password. A time penalty was added.")
            upd()
        }
    }

    private fun upd() {
        val wait = (Prefs.lockUntil(this) - System.currentTimeMillis()) / 1000
        unlockBtn.isEnabled = wait <= 0
        unlockBtn.text = if (wait > 0) L("انتظر $wait ثانية", "Wait $wait s") else L("افتح 10 دقائق", "Open for 10 minutes")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { startActivity(homeIntent()); finish() }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }
}
