package com.focuslock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView

// الزر العائم فوق كل التطبيقات (اختياري): يفتح وضع الصفحة الواحدة، ويمكن سحبه لأي مكان
object FloatingFab {
    // يكون true والتطبيق مفتوح أمام المستخدم، فيختفي الزر العائم لأن داخل التطبيق زر مماثل
    @Volatile var appVisible = false

    fun wanted(c: Context): Boolean = Prefs.boolOf(c, "fabAll", false) && Settings.canDrawOverlays(c)

    // يشغّل الخدمة أو يوقفها حسب الإعداد والصلاحية
    fun sync(c: Context) {
        val app = c.applicationContext
        if (wanted(app)) {
            try { app.startForegroundService(Intent(app, FabService::class.java)) } catch (_: Exception) { }
        } else {
            app.stopService(Intent(app, FabService::class.java))
        }
    }

    // يعيد موضع الزر العائم إلى مكانه الأصلي
    fun resetPosition(c: Context) {
        Prefs.putFloat(c, "fabX", -1f)
        Prefs.putFloat(c, "fabY", -1f)
        Prefs.putFloat(c, "fabOvX", 1f)
        Prefs.putFloat(c, "fabOvY", 0.7f)
        val app = c.applicationContext
        app.stopService(Intent(app, FabService::class.java))
        sync(app)
    }
}

class FabService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var btn: TextView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var shown = false
    private var sz = 0

    private val loop = object : Runnable {
        override fun run() {
            tick()
            h.postDelayed(this, if (Eco.on(this@FabService)) 3000L else 1200L)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        // startForeground أولًا دائمًا حتى لا ينهار التطبيق بعد startForegroundService
        startFg()
        if (!FloatingFab.wanted(this)) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        C.load(this)
        build()
        h.removeCallbacks(loop)
        h.post(loop)
        return START_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("fab", L("الزر العائم", "Floating button"), NotificationManager.IMPORTANCE_MIN))
        val pi = PendingIntent.getActivity(
            this, 8, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "fab")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(L("الزر العائم شغّال", "Floating button is on"))
            .setContentText(L("تقدر توقفه من الإعدادات", "You can turn it off in Settings"))
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(3, n)
    }

    private fun build() {
        if (btn != null) return
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        sz = dp(52)
        val size = sz
        val v = TextView(this)
        v.text = "◎"
        v.textSize = 22f
        v.setTextColor(C.ON)
        v.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(C.AC)
        v.background = bg
        v.elevation = dp(6).toFloat()

        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.LEFT
        val dm = resources.displayMetrics
        val fx = Prefs.floatOf(this, "fabOvX", 1f).coerceIn(0f, 1f)
        val fy = Prefs.floatOf(this, "fabOvY", 0.7f).coerceIn(0f, 1f)
        params.x = (fx * maxOf(0, dm.widthPixels - size)).toInt()
        params.y = (fy * maxOf(0, dm.heightPixels - size)).toInt()

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) moved = true
                    if (moved) {
                        val m = resources.displayMetrics
                        params.x = (startX + dx).toInt().coerceIn(0, maxOf(0, m.widthPixels - size))
                        params.y = (startY + dy).toInt().coerceIn(0, maxOf(0, m.heightPixels - size))
                        try { manager.updateViewLayout(v, params) } catch (_: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        val m = resources.displayMetrics
                        Prefs.putFloat(this, "fabOvX", params.x.toFloat() / maxOf(1, m.widthPixels - size))
                        Prefs.putFloat(this, "fabOvY", params.y.toFloat() / maxOf(1, m.heightPixels - size))
                    } else {
                        openFocus()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
        btn = v
        lp = params
    }

    private fun openFocus() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .putExtra("focusMode", true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        } catch (_: Exception) { }
    }

    private fun attach() {
        val v = btn ?: return
        val p = lp ?: return
        try {
            wm?.addView(v, p)
            shown = true
        } catch (_: Exception) { }
    }

    private fun detach() {
        val v = btn ?: return
        try { wm?.removeView(v) } catch (_: Exception) { }
        shown = false
    }

    private fun tick() {
        if (!FloatingFab.wanted(this)) {
            detach()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        val pm = getSystemService(PowerManager::class.java)
        // نخفيه أثناء الجلسة (القفل قائم) وعندما يكون التطبيق نفسه مفتوحًا أو الشاشة مطفأة
        val hide = Prefs.active(this) || FloatingFab.appVisible || !pm.isInteractive
        if (hide && shown) detach()
        else if (!hide && !shown) attach()
        if (shown) {
            // بعد تدوير الشاشة نتأكد أن الزر لا يخرج عن حدودها
            val p = lp ?: return
            val v = btn ?: return
            val m = resources.displayMetrics
            val nx = p.x.coerceIn(0, maxOf(0, m.widthPixels - sz))
            val ny = p.y.coerceIn(0, maxOf(0, m.heightPixels - sz))
            if (nx != p.x || ny != p.y) {
                p.x = nx
                p.y = ny
                try { wm?.updateViewLayout(v, p) } catch (_: Exception) { }
            }
        }
    }

    override fun onDestroy() {
        h.removeCallbacks(loop)
        detach()
        btn = null
        super.onDestroy()
    }
}
