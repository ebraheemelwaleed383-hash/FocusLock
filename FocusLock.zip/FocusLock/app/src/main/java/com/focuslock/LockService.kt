package com.focuslock

import android.accessibilityservice.AccessibilityService
import android.content.*
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent

class LockService : AccessibilityService() {
    private var last = 0L

    // صفحات الإعدادات والمثبّت: ممنوعة أثناء الجلسة لحماية التطبيق من الحذف أو تعطيل الخدمة
    private val protectedPkgs = setOf(
        "com.android.settings",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.samsung.android.packageinstaller",
        "com.android.vending"
    )

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { if (Prefs.active(c)) showLock(null) }
    }

    override fun onServiceConnected() {
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenRx, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(screenRx, f)
        if (Prefs.active(this)) {
            try { KeepAliveService.start(this) } catch (_: Exception) {}
            showLock(null)
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (!Prefs.active(this)) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (shouldBlock(pkg)) showLock(pkg)
    }

    private fun shouldBlock(pkg: String): Boolean {
        if (pkg in Prefs.blocked(this) || pkg in protectedPkgs) return true
        if (!Prefs.strict(this)) return false
        val ime = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)?.substringBefore('/')
        val allowed = pkg == "com.android.systemui" || pkg == ime ||
            listOf("dialer", "telecom", "incallui", "emergency").any { pkg.contains(it) }
        return !allowed
    }

    private fun showLock(pkg: String?) {
        val now = SystemClock.elapsedRealtime()
        if (now - last < 800) return
        last = now
        startActivity(
            Intent(this, LockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("why", pkg)
        )
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        try { unregisterReceiver(screenRx) } catch (_: Exception) {}
        super.onDestroy()
    }
}
