package com.focuslock

import android.accessibilityservice.AccessibilityService
import android.content.*
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent

class LockService : AccessibilityService() {
    private var last = 0L
    private var lastLimit = 0L
    private var fgPkg: String? = null
    private var fgSince = 0L
    private val h = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { commit(); h.postDelayed(this, 10_000L) }
    }

    // صفحات الإعدادات والمثبّت: ممنوعة أثناء الجلسة لحماية التطبيق من الحذف أو تعطيل الخدمة
    private val protectedPkgs = setOf(
        "com.android.settings",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.samsung.android.packageinstaller",
        "com.android.vending",
        "com.miui.packageinstaller",
        "com.miui.securitycenter",
        "com.coloros.safecenter",
        "com.oplus.safecenter",
        "com.oplus.appdetail"
    )

    // تطبيقات حيوية لا تُحجب حتى في القفل الكامل
    private val alwaysOk = setOf("com.google.android.apps.maps", "com.waze")

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF) { commit(); fgPkg = null; return }
            if (Prefs.active(c)) showLock(null)
        }
    }

    override fun onServiceConnected() {
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenRx, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(screenRx, f)
        h.removeCallbacks(ticker)
        h.postDelayed(ticker, 10_000L)
        if (Prefs.active(this)) {
            try { KeepAliveService.start(this) } catch (_: Exception) {}
            EndAlarm.schedule(this)
            showLock(null)
        }
    }

    private fun ime(): String? =
        Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)?.substringBefore('/')

    // نضيف وقت التطبيق المفتوح لعدّاد الحدود وللمرشد الذكي
    private fun commit() {
        val p = fgPkg ?: return
        val now = System.currentTimeMillis()
        val d = (now - fgSince).coerceIn(0L, 60_000L)
        fgSince = now
        if (d <= 0L) return
        if (Limits.find(this, p) != null && Limits.addUsage(this, p, d)) showLimit(p)
        Smart.onTick(this, p, d)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val type = e.eventType
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && type != AccessibilityEvent.TYPE_VIEW_SCROLLED) return
        val pkg = e.packageName?.toString() ?: return
        val now = System.currentTimeMillis()

        if (type == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            if (fgPkg == null && pkg != packageName && pkg != "com.android.systemui" && pkg != "android" && pkg != ime()) {
                fgPkg = pkg; fgSince = now
            }
            return
        }

        if (pkg == packageName) { commit(); fgPkg = null }
        else if (pkg != "com.android.systemui" && pkg != "android" && pkg != ime() && pkg != fgPkg) {
            commit()
            fgPkg = pkg; fgSince = now
            Smart.onSwitch(this, pkg)
        }

        if (pkg != packageName && Limits.blockedNow(this, pkg)) showLimit(pkg)

        if (!Prefs.active(this)) return
        if (pkg == packageName) return
        val cls = e.className?.toString()?.lowercase() ?: ""
        if (shouldBlock(pkg) || cls.contains("uninstall") || cls.contains("deviceadmin")) showLock(pkg)
    }

    private fun shouldBlock(pkg: String): Boolean {
        if (pkg in Prefs.essentials(this)) return false
        if (pkg in Prefs.blocked(this) || pkg in protectedPkgs) return true
        if (!Prefs.strict(this)) return false
        val allowed = pkg == "com.android.systemui" || pkg == ime() || pkg in alwaysOk ||
            listOf("dialer", "telecom", "incallui", "emergency").any { pkg.contains(it) }
        return !allowed
    }

    private fun showLock(pkg: String?) {
        val now = SystemClock.elapsedRealtime()
        if (now - last < 800) return
        last = now
        startActivity(
            Intent(this, LockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("why", pkg)
        )
    }

    private fun showLimit(pkg: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastLimit < 1500) return
        lastLimit = now
        startActivity(
            Intent(this, LimitActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("pkg", pkg)
        )
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        h.removeCallbacks(ticker)
        try { unregisterReceiver(screenRx) } catch (_: Exception) {}
        super.onDestroy()
    }
}
