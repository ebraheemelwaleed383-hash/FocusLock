package com.focuslock

// الميزة 01: تحليل التركيز. منطق خالص (بلا أندرويد). يقرأ فقط ولا يكتب شيئًا.
// كل ادعاء يخرج من هنا مرتبط برقم محسوب وبحجم العينة، وأي نمط لا يظهر إلا لو تجاوزت بياناته الحد الأدنى في Th.
// الإخراج رموز + أرقام (Insight/Rec) والواجهة هي التي تحوّلها لنص عربي/إنجليزي.

object Th {
    const val WINDOW_DAYS = 90        // نافذة التحليل
    const val MIN_ATTEMPTS = 10       // أقل عدد محاولات لأي حكم على نسبة الإكمال
    const val MIN_BUCKET = 5          // أقل عدد محاولات في فئة (فترة يوم / طول جلسة) للمقارنة
    const val MIN_DONE_PATTERN = 10   // أقل عدد جلسات مكتملة لأنماط الساعات
    const val MIN_DAYS_DOW = 21       // أقل مدة لأنماط أيام الأسبوع
    const val PEAK_SHARE = 0.45       // حصة الفترة من دقائق الإكمال لتُسمّى الأنشط
    const val GAP = 0.20              // فرق نسبة الإكمال (20 نقطة) لاعتبار فرق الطول/الفترة ذا معنى
    const val DOW_LEAD = 1.30         // أفضل يوم لازم يتفوق على متوسط الأيام بـ 30٪
    const val TREND_PCT = 20.0        // أقل تغير أسبوعي في وقت التركيز يُذكر
    const val RATE_DELTA = 0.15       // أقل تغير في نسبة الخروج المبكر يُذكر
    const val STOP_HIGH = 0.50        // نسبة خروج مبكر عالية لفترة
}

object IK { const val STRENGTH = 0; const val IMPROVE = 1; const val PATTERN = 2; const val TASK = 3 }

enum class IC {
    PEAK_PERIOD, BEST_DAY, COMPLETION_HIGH, COMPLETION_LOW, STOPS_BY_PERIOD, LENGTH_GAP, EXTENDED, STOP_REACH,
    TREND_UP, TREND_DOWN, STOPS_UP, STOPS_DOWN, STREAK, CONSIST_HIGH, CONSIST_LOW, TASK_TOP, TASK_CARRIED
}

enum class RC { SHORTER, LONGER, TIME_OF_DAY, SPLIT_TASK, CONSISTENCY, REDUCE_STOPS }

// n: أرقام الدليل بترتيب ثابت لكل رمز (موثق قرب إنشاء كل واحد)، s: نصوص (مثل عنوان مهمة)
class Insight(val code: IC, val kind: Int, val n: List<Double> = emptyList(), val s: List<String> = emptyList())
class Rec(val code: RC, val n: List<Double> = emptyList(), val s: List<String> = emptyList())

class TaskInfo(val id: String, val title: String, val done: Boolean, val proj: String, val steps: Int, val stepsDone: Int)

class Perf(
    val attempted: Int, val doneCount: Int, val stopCount: Int,
    val completedMins: Int, val partialMins: Int,
    val avgDone: Double?, val medianDone: Double?, val p25: Double?, val p75: Double?,
    val completionRate: Double?,
    val plannedSum: Int, val actualSum: Int, val extended: Int,
    val stopReach: Double?
)

// cur/prev: الفترة الحالية والسابقة. valid=false لو السابقة تبدأ قبل أول بيانات (لا نقارن بفراغ)
class Trend(val cur: Int, val prev: Int, val valid: Boolean) {
    fun pct(): Double? = if (valid && prev > 0) (cur - prev) * 100.0 / prev else null
}

class RateTrend(val cur: Double?, val prev: Double?, val curN: Int, val prevN: Int, val valid: Boolean)

class PeriodStat(val period: Int, val attempts: Int, val done: Int, val doneMins: Int) {
    val stops: Int get() = attempts - done
    fun doneRate(): Double? = Stats.rate(done, attempts)
    fun stopRate(): Double = if (attempts == 0) 0.0 else stops.toDouble() / attempts
}

class DowStat(val dow: Int, val mins: Int, val occurrences: Int, val activeDays: Int) {
    fun avg(): Double? = if (occurrences < 1) null else mins.toDouble() / occurrences
}

class BucketStat(val bucket: Int, val attempts: Int, val done: Int) {
    fun doneRate(): Double? = Stats.rate(done, attempts)
}

class Consistency(
    val spanDays: Int, val activeDays: Int, val activeRate: Double?,
    val currentStreak: Int, val longestStreak: Int, val weeklyCv: Double?
)

class TaskPerf(
    val id: String, val title: String, val proj: String,
    val sessions: Int, val doneSessions: Int, val mins: Int, val days: Int,
    val plannedSum: Int, val effSumPlanned: Int,
    val oDone: Int, val oPart: Int, val oLater: Int, val oSkip: Int,
    val taskDone: Boolean?,   // null = المهمة لم تعد موجودة
    val carried: Boolean, val split: Boolean
)

class TaskReport(
    val perTask: List<TaskPerf>, val byProject: List<Pair<String, Int>>,
    val linkedSessions: Int, val unlinkedSessions: Int, val goalOnly: Int
)

class IntelReport(
    val conf: Conf, val analyzed: Int, val firstDay: Long?, val lastDay: Long?, val spanDays: Int, val activeDays: Int,
    val excluded: Int, val openIgnored: Int,
    val perf: Perf,
    val daily14: List<Int>, val weekly8: List<Int>,
    val weekTrend: Trend, val completionTrend: RateTrend, val stopTrend: RateTrend,
    val periods: List<PeriodStat>, val dows: List<DowStat>, val buckets: List<BucketStat>,
    val peakHour: Int?,
    val consistency: Consistency,
    val tasks: TaskReport,
    val insights: List<Insight>, val recs: List<Rec>,
    val logTruncated: Boolean = false
)

object FocusIntel {

    fun build(cl: Cleaned, totals: DailyTotals, tasks: List<TaskInfo>, today: Long): IntelReport {
        val from = today - (Th.WINDOW_DAYS - 1)
        val ss = cl.sessions.filter { it.day >= from }
        val cov = totals.coverageStart
        val perf = perfOf(ss)

        var first: Long? = null
        var last: Long? = null
        for (s in ss) {
            if (first == null || s.day < first) first = s.day
            if (last == null || s.day > last) last = s.day
        }
        val span = if (first == null) 0 else (today - first + 1).toInt()
        val activeDays = ss.filter { it.done }.map { it.day }.distinct().size
        val conf = confidenceOf(perf.attempted, span)

        // ---- السلاسل والاتجاهات (حقائق مقاسة) ----
        val daily14 = (13 downTo 0).map { totals.mins(today - it) }
        val weekly8 = (7 downTo 0).map { k -> totals.sum(today - 7 * k - 6, today - 7 * k) }
        val weekTrend = Trend(totals.sum(today - 6, today), totals.sum(today - 13, today - 7), cov != null && cov <= today - 13)

        // اتجاه النسب يعتمد على السجل نفسه: لا نقارن بفترة تسبق اكتمال السجل (قد يكون اقتُطع)
        val logFrom = cl.logCompleteFrom
        val curW = cl.sessions.filter { it.day in (today - 13)..today }
        val prevW = cl.sessions.filter { it.day in (today - 27)..(today - 14) }
        val rateOk = logFrom != null && logFrom <= today - 27 && curW.size >= Th.MIN_BUCKET && prevW.size >= Th.MIN_BUCKET
        val completionTrend = RateTrend(
            if (rateOk) Stats.rate(curW.count { it.done }, curW.size) else null,
            if (rateOk) Stats.rate(prevW.count { it.done }, prevW.size) else null, curW.size, prevW.size, rateOk
        )
        val stopTrend = RateTrend(
            if (rateOk) Stats.rate(curW.count { !it.done }, curW.size) else null,
            if (rateOk) Stats.rate(prevW.count { !it.done }, prevW.size) else null, curW.size, prevW.size, rateOk
        )

        // ---- الأنماط (تقديرات تتطلب حدًا أدنى من البيانات) ----
        val periods = (0 until Ax.PERIODS).map { p ->
            val l = ss.filter { Ax.periodOf(it.hour) == p }
            PeriodStat(p, l.size, l.count { it.done }, l.filter { it.done }.sumOf { it.actual })
        }
        val buckets = (0 until Ax.BUCKETS).map { b ->
            val l = ss.filter { Ax.bucketOf(if (it.planned > 0) it.planned else it.actual) == b }
            BucketStat(b, l.size, l.count { it.done })
        }
        val dows = dowStats(totals, today, maxOf(from, cov ?: today))
        var peakHour: Int? = null
        if (perf.doneCount >= Th.MIN_DONE_PATTERN) {
            val hm = IntArray(24)
            for (s in ss) if (s.done) hm[s.hour] += s.actual
            var bh = 0
            for (h in 1 until 24) if (hm[h] > hm[bh]) bh = h
            if (hm[bh] > 0) peakHour = bh
        }
        val consistency = consistencyOf(totals, today)
        val taskReport = taskReportOf(ss, tasks)

        val ins = ArrayList<Insight>()
        val recs = ArrayList<Rec>()
        insights(perf, periods, dows, buckets, weekTrend, stopTrend, consistency, taskReport, span, ss, ins, recs)

        return IntelReport(
            conf, ss.size, first, last, span, activeDays, cl.excluded, cl.openIgnored,
            perf, daily14, weekly8, weekTrend, completionTrend, stopTrend, periods, dows, buckets, peakHour,
            consistency, taskReport, ins, recs, cl.logTruncated
        )
    }

    // انتظام الدقائق الأسبوعية من معامل الاختلاف: 0 منتظم (حتى 0.35)، 1 متوسط (حتى 0.75)، 2 متفاوت. null لو لا بيانات كافية
    fun steadiness(cv: Double?): Int? = if (cv == null) null else if (cv <= 0.35) 0 else if (cv <= 0.75) 1 else 2

    fun perfOf(ss: List<Sess>): Perf {
        val d = ss.filter { it.done }
        val s = ss.filter { !it.done }
        val dm = d.map { it.actual }
        val withPlan = d.filter { it.planned > 0 }
        val stopsPlan = s.filter { it.planned > 0 }
        val reach = if (stopsPlan.isEmpty()) null else stopsPlan.sumOf { it.eff }.toDouble() / stopsPlan.sumOf { it.planned }
        return Perf(
            ss.size, d.size, s.size,
            d.sumOf { it.actual }, s.sumOf { it.eff },
            if (d.isEmpty()) null else dm.sum().toDouble() / d.size,
            if (d.size >= 3) Stats.median(dm) else null,
            if (d.size >= 8) Stats.percentile(dm, 0.25) else null,
            if (d.size >= 8) Stats.percentile(dm, 0.75) else null,
            Stats.rate(d.size, ss.size),
            withPlan.sumOf { it.planned }, withPlan.sumOf { it.actual },
            d.count { it.planned > 0 && it.actual > it.planned + 1 },
            reach
        )
    }

    // متوسط دقائق التركيز لكل يوم أسبوع على أيام النافذة، مع عدد مرات تكرار اليوم في المدة (حتى لا يُظلم يوم تكرر أقل)
    private fun dowStats(totals: DailyTotals, today: Long, start: Long): List<DowStat> {
        val mins = IntArray(7)
        val occ = IntArray(7)
        val act = IntArray(7)
        var d = start
        while (d <= today) {
            val k = Ax.dowOf(d)
            occ[k]++
            val m = totals.mins(d)
            mins[k] += m
            if (m > 0) act[k]++
            d++
        }
        return (0 until 7).map { DowStat(it, mins[it], occ[it], act[it]) }
    }

    private fun consistencyOf(totals: DailyTotals, today: Long): Consistency {
        val cov = totals.coverageStart
        val from = maxOf(today - 27, cov ?: today)
        val span = if (cov == null) 0 else (today - from + 1).toInt()
        var active = 0
        var d = from
        while (cov != null && d <= today) { if (totals.mins(d) > 0) active++; d++ }
        var cur = 0
        var x = if (totals.mins(today) > 0) today else today - 1 // اليوم الذي لم تبدأ فيه جلسة بعد لا يقطع السلسلة
        while (totals.mins(x) > 0) { cur++; x-- }
        val days = totals.byDay.filter { it.value > 0 }.keys.sorted()
        var longest = 0
        var run = 0
        var prev = Long.MIN_VALUE
        for (v in days) {
            run = if (prev != Long.MIN_VALUE && v == prev + 1) run + 1 else 1
            if (run > longest) longest = run
            prev = v
        }
        var cv: Double? = null
        if (cov != null && cov <= today - 27) {
            cv = Stats.cv((3 downTo 0).map { k -> totals.sum(today - 7 * k - 6, today - 7 * k) })
        }
        return Consistency(span, active, if (span >= 7) active.toDouble() / span else null, cur, longest, cv)
    }

    fun taskReportOf(ss: List<Sess>, tasks: List<TaskInfo>): TaskReport {
        val info = HashMap<String, TaskInfo>()
        for (t in tasks) info[t.id] = t
        val linked = ss.filter { it.taskId.isNotEmpty() }
        val out = ArrayList<TaskPerf>()
        for ((id, l) in linked.groupBy { it.taskId }) {
            val ti = info[id]
            val withPlan = l.filter { it.planned > 0 }
            val oLater = l.count { it.outcome == "later" }
            val oPart = l.count { it.outcome == "part" }
            val days = l.map { it.day }.distinct().size
            // «تُرحَّل مرارًا» تعتمد فقط على اختيار المستخدم الصريح «أكمل لاحقًا» (لا نستنتج من الخروج المبكر، ولا توجد مواعيد استحقاق)
            val open = ti != null && !ti.done
            out.add(
                TaskPerf(
                    id, ti?.title ?: l[l.size - 1].taskTitle, ti?.proj ?: "",
                    l.size, l.count { it.done }, l.sumOf { it.eff }, days,
                    withPlan.sumOf { it.planned }, withPlan.sumOf { it.eff },
                    l.count { it.outcome == "done" }, oPart, oLater, l.count { it.outcome == "skip" },
                    ti?.done,
                    open && oLater >= 3 && days >= 3,
                    open && (oPart + oLater) >= 3 && (ti?.steps ?: 0) < 2
                )
            )
        }
        out.sortByDescending { it.mins }
        val byProj = HashMap<String, Int>()
        for (t in out) byProj[t.proj] = (byProj[t.proj] ?: 0) + t.mins
        val proj = byProj.entries.sortedByDescending { it.value }.map { Pair(it.key, it.value) }
        return TaskReport(out, proj, linked.size, ss.size - linked.size, ss.count { it.taskId.isEmpty() && it.goal.isNotEmpty() })
    }

    // ---- توليد الرؤى والتوصيات: كل واحدة لها شرط بيانات صريح ----
    private fun insights(
        perf: Perf, periods: List<PeriodStat>, dows: List<DowStat>, buckets: List<BucketStat>,
        weekTrend: Trend, stopTrend: RateTrend, cons: Consistency, tr: TaskReport, span: Int, ss: List<Sess>,
        ins: MutableList<Insight>, recs: MutableList<Rec>
    ) {
        // PEAK_PERIOD n = [الفترة, الحصة 0..1, عدد الجلسات المكتملة فيها]
        if (perf.doneCount >= Th.MIN_DONE_PATTERN) {
            val total = periods.sumOf { it.doneMins }
            val top = periods.maxByOrNull { it.doneMins }
            if (top != null && total > 0) {
                val share = top.doneMins.toDouble() / total
                if (share >= Th.PEAK_SHARE && top.done >= 4) {
                    ins.add(Insight(IC.PEAK_PERIOD, IK.PATTERN, listOf(top.period.toDouble(), share, top.done.toDouble())))
                }
            }
        }
        // BEST_DAY n = [اليوم 0..6, متوسط الدقائق لذلك اليوم, متوسط كل الأيام]
        val usable = dows.filter { it.occurrences >= 2 }
        if (perf.doneCount >= Th.MIN_DONE_PATTERN && span >= Th.MIN_DAYS_DOW && usable.size == 7) {
            val avgs = usable.map { it.avg() ?: 0.0 }
            val mean = avgs.sum() / avgs.size
            val best = usable.maxByOrNull { it.avg() ?: 0.0 }
            if (best != null && mean > 0.0 && (best.avg() ?: 0.0) >= mean * Th.DOW_LEAD && best.activeDays >= 2) {
                ins.add(Insight(IC.BEST_DAY, IK.PATTERN, listOf(best.dow.toDouble(), best.avg() ?: 0.0, mean)))
            }
        }
        // COMPLETION_HIGH/LOW n = [النسبة 0..1, عدد المحاولات]
        val rate = perf.completionRate
        if (rate != null && perf.attempted >= Th.MIN_ATTEMPTS) {
            if (rate >= 0.85) ins.add(Insight(IC.COMPLETION_HIGH, IK.STRENGTH, listOf(rate, perf.attempted.toDouble())))
            else if (rate < 0.60) ins.add(Insight(IC.COMPLETION_LOW, IK.IMPROVE, listOf(rate, perf.attempted.toDouble())))
        }
        // STOPS_BY_PERIOD n = [الفترة, نسبة الخروج المبكر, محاولات الفترة]
        var worst: PeriodStat? = null
        if (perf.attempted >= Th.MIN_ATTEMPTS) {
            val overallStop = perf.stopCount.toDouble() / perf.attempted
            for (p in periods) {
                if (p.attempts < Th.MIN_BUCKET) continue
                val sr = p.stopRate()
                if (sr >= Th.STOP_HIGH && sr >= overallStop + Th.GAP && (worst == null || sr > worst.stopRate())) worst = p
            }
        }
        if (worst != null) {
            ins.add(Insight(IC.STOPS_BY_PERIOD, IK.IMPROVE, listOf(worst.period.toDouble(), worst.stopRate(), worst.attempts.toDouble())))
            recs.add(Rec(RC.REDUCE_STOPS, listOf(worst.period.toDouble(), worst.stopRate(), worst.attempts.toDouble())))
        }
        // LENGTH_GAP n = [فئة الأقصر, نسبة إكمالها, فئة الأطول, نسبة إكمالها, محاولات الأولى, محاولات الثانية]
        var gap = 0.0
        var ga = -1
        var gb = -1
        for (a in 0 until Ax.BUCKETS) for (b in (a + 1) until Ax.BUCKETS) {
            val ra = buckets[a].doneRate()
            val rb = buckets[b].doneRate()
            if (ra != null && rb != null && buckets[a].attempts >= Th.MIN_BUCKET && buckets[b].attempts >= Th.MIN_BUCKET &&
                ra - rb >= Th.GAP && ra - rb > gap
            ) { gap = ra - rb; ga = a; gb = b }
        }
        if (ga >= 0) {
            val ra = buckets[ga].doneRate() ?: 0.0
            val rb = buckets[gb].doneRate() ?: 0.0
            ins.add(Insight(IC.LENGTH_GAP, IK.IMPROVE, listOf(ga.toDouble(), ra, gb.toDouble(), rb, buckets[ga].attempts.toDouble(), buckets[gb].attempts.toDouble())))
            recs.add(Rec(RC.SHORTER, listOf(Ax.BUCKET_MAX[ga].toDouble(), ra, rb)))
        }
        // EXTENDED n = [عدد الممدّدة, عدد المكتملة, الوسيط المقترح بالدقائق]
        if (perf.doneCount >= 8 && perf.extended >= 3 && perf.extended.toDouble() / perf.doneCount >= 0.20) {
            val ext = ss.filter { it.done && it.planned > 0 && it.actual > it.planned + 1 }.map { it.actual }
            val med = Stats.median(ext)
            if (med != null) {
                val sug = Stats.roundTo5(med)
                ins.add(Insight(IC.EXTENDED, IK.PATTERN, listOf(perf.extended.toDouble(), perf.doneCount.toDouble(), sug.toDouble())))
                recs.add(Rec(RC.LONGER, listOf(sug.toDouble(), perf.extended.toDouble(), perf.doneCount.toDouble())))
            }
        }
        // STOP_REACH n = [متوسط ما بلغته من الخطة 0..1, عدد الجلسات المبكرة]
        val reach = perf.stopReach
        if (reach != null && perf.stopCount >= 5) ins.add(Insight(IC.STOP_REACH, IK.PATTERN, listOf(reach, perf.stopCount.toDouble())))
        // TREND_UP/DOWN n = [النسبة٪, دقائق الأسبوع الحالي, دقائق السابق]
        val pct = weekTrend.pct()
        if (pct != null && weekTrend.cur + weekTrend.prev >= 60) {
            if (pct >= Th.TREND_PCT) ins.add(Insight(IC.TREND_UP, IK.STRENGTH, listOf(pct, weekTrend.cur.toDouble(), weekTrend.prev.toDouble())))
            else if (pct <= -Th.TREND_PCT) ins.add(Insight(IC.TREND_DOWN, IK.IMPROVE, listOf(pct, weekTrend.cur.toDouble(), weekTrend.prev.toDouble())))
        }
        // STOPS_UP/DOWN n = [النسبة الحالية, السابقة, محاولات حالية, محاولات سابقة]
        val sc = stopTrend.cur
        val sp = stopTrend.prev
        if (stopTrend.valid && sc != null && sp != null) {
            val ev = listOf(sc, sp, stopTrend.curN.toDouble(), stopTrend.prevN.toDouble())
            if (sc - sp >= Th.RATE_DELTA) {
                ins.add(Insight(IC.STOPS_UP, IK.IMPROVE, ev))
                if (worst == null) recs.add(Rec(RC.REDUCE_STOPS, listOf(-1.0, sc, stopTrend.curN.toDouble())))
            } else if (sp - sc >= Th.RATE_DELTA) ins.add(Insight(IC.STOPS_DOWN, IK.STRENGTH, ev))
        }
        // STREAK n = [الحالية, الأطول]
        if (cons.currentStreak >= 3) ins.add(Insight(IC.STREAK, IK.STRENGTH, listOf(cons.currentStreak.toDouble(), cons.longestStreak.toDouble())))
        // CONSIST_HIGH/LOW n = [أيام نشطة, المدة]
        val ar = cons.activeRate
        if (ar != null) {
            val ev = listOf(cons.activeDays.toDouble(), cons.spanDays.toDouble())
            if (ar >= 0.70) ins.add(Insight(IC.CONSIST_HIGH, IK.STRENGTH, ev))
            else if (ar <= 0.30 && cons.spanDays >= 14) {
                ins.add(Insight(IC.CONSIST_LOW, IK.IMPROVE, ev))
                val bestDow = ins.firstOrNull { it.code == IC.BEST_DAY }?.n?.get(0) ?: -1.0
                recs.add(Rec(RC.CONSISTENCY, listOf(cons.activeDays.toDouble(), cons.spanDays.toDouble(), bestDow)))
            }
        }
        // TIME_OF_DAY n = [أفضل فترة، نسبة إكمالها، أضعف فترة، نسبة إكمالها]
        val rated = periods.filter { it.attempts >= Th.MIN_BUCKET && it.doneRate() != null }
        if (rated.size >= 2) {
            val b = rated.maxByOrNull { it.doneRate() ?: 0.0 }
            val w = rated.minByOrNull { it.doneRate() ?: 0.0 }
            if (b != null && w != null && b.period != w.period && (b.doneRate() ?: 0.0) - (w.doneRate() ?: 0.0) >= Th.GAP) {
                recs.add(Rec(RC.TIME_OF_DAY, listOf(b.period.toDouble(), b.doneRate() ?: 0.0, w.period.toDouble(), w.doneRate() ?: 0.0)))
            }
        }
        // TASK_TOP n = [دقائق المهمة, حصتها من دقائق الجلسات المرتبطة, عدد جلساتها]، s = [العنوان]
        if (tr.linkedSessions >= 3 && tr.perTask.isNotEmpty()) {
            val top = tr.perTask[0]
            val totalMins = tr.perTask.sumOf { it.mins }
            if (top.sessions >= 3 && totalMins > 0) {
                ins.add(Insight(IC.TASK_TOP, IK.TASK, listOf(top.mins.toDouble(), top.mins.toDouble() / totalMins, top.sessions.toDouble()), listOf(top.title)))
            }
        }
        for (t in tr.perTask) {
            if (t.carried) ins.add(Insight(IC.TASK_CARRIED, IK.TASK, listOf(t.oLater.toDouble(), t.days.toDouble()), listOf(t.title)))
            if (t.split) recs.add(Rec(RC.SPLIT_TASK, listOf((t.oPart + t.oLater).toDouble(), t.sessions.toDouble()), listOf(t.title)))
        }
    }
}
