package com.focuslock

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import java.util.Locale

class BarChartView(c: Context, private val values: List<Float>, private val labels: List<String>) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        val n = values.size
        if (n == 0) return
        val w = width.toFloat(); val h = height.toFloat()
        val labelH = context.dp(18).toFloat(); val topPad = context.dp(18).toFloat()
        val max = (values.maxOrNull() ?: 1f).coerceAtLeast(0.01f)
        val slot = w / n; val bw = slot * 0.56f
        p.textAlign = Paint.Align.CENTER; p.textSize = context.dp(10).toFloat()
        for (i in 0 until n) {
            val cx = slot * (i + 0.5f)
            val bh = (h - labelH - topPad) * values[i] / max
            val top = h - labelH - bh
            val last = i == n - 1
            p.style = Paint.Style.FILL
            p.color = if (last) C.AC else (C.AC and 0x00FFFFFF) or (0x55 shl 24)
            canvas.drawRoundRect(RectF(cx - bw / 2, top, cx + bw / 2, h - labelH), 10f, 10f, p)
            p.color = C.MU
            canvas.drawText(labels[i], cx, h - 4f, p)
            if (values[i] > 0f) {
                p.color = if (last) C.TX else C.MU
                canvas.drawText(String.format(Locale.US, "%.1f", values[i]), cx, top - 6f, p)
            }
        }
    }
}

class DonutView(c: Context, private val values: List<Float>, private val colors: List<Int>) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        val total = values.sum()
        if (total <= 0f) return
        val sw = context.dp(22).toFloat()
        val r = RectF(sw, sw, width - sw, height - sw)
        p.style = Paint.Style.STROKE; p.strokeWidth = sw
        var a = -90f
        values.forEachIndexed { i, v ->
            val sweep = 360f * v / total
            p.color = colors[i % colors.size]
            canvas.drawArc(r, a + 1.5f, maxOf(sweep - 3f, 0.5f), false, p)
            a += sweep
        }
    }
}

// شريط يوضح تسلسل نظام الدراسة وهو "شغال": تعبئة تتحرك عبر المراحل
class PhaseBarView(c: Context, private val segs: List<Seg>) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val total = segs.sumOf { it.w.toDouble() }.toFloat()
        if (total <= 0f) return
        val gap = 6f
        val barH = h * 0.56f
        val top = (h - barH) / 2f
        val pos = (t * 0.1f) % 1f
        val usable = w - gap * (segs.size - 1)
        var x = 0f
        var acc = 0f
        var markX = -1f
        p.textAlign = Paint.Align.CENTER
        p.textSize = context.dp(12).toFloat()
        for (s in segs) {
            val sw = usable * s.w / total
            val base = when (s.kind) { 0 -> C.AC; 1 -> C.OK; else -> C.MU }
            val segStart = acc / total
            val segEnd = (acc + s.w) / total
            val rect = RectF(x, top, x + sw, top + barH)
            p.style = Paint.Style.FILL
            p.color = (base and 0x00FFFFFF) or (0x44 shl 24)
            cv.drawRoundRect(rect, 14f, 14f, p)
            val ff = ((pos - segStart) / (segEnd - segStart)).coerceIn(0f, 1f)
            if (ff > 0f) {
                p.color = base
                cv.save()
                cv.clipRect(x, top, x + sw * ff, top + barH)
                cv.drawRoundRect(rect, 14f, 14f, p)
                cv.restore()
            }
            if (pos in segStart..segEnd) markX = x + sw * ff
            if (s.label.isNotEmpty() && sw > 30f) {
                p.color = if (ff > 0.5f) C.ON else C.TX
                cv.drawText(s.label, x + sw / 2f, top + barH / 2f + p.textSize / 3f, p)
            }
            x += sw + gap
            acc += s.w
        }
        if (markX >= 0f) {
            p.style = Paint.Style.FILL; p.color = C.TX
            cv.drawCircle(markX, top + barH + 8f, 5f, p)
        }
    }
}
