package com.focuslock

import android.app.Activity
import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.PrintWriter
import java.io.StringWriter

// يلتقط أي كراش ويعرض سببه في شاشة مستقلة (في عملية منفصلة) يمكن نسخها وإرسالها للمطوّر
class FlApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 28 && Application.getProcessName().endsWith(":crash")) return
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                var info = "Vigil " + BuildConfig.VERSION_NAME + " " + BuildConfig.FLAVOR +
                    "\nAndroid " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ") " +
                    Build.MANUFACTURER + " " + Build.MODEL + "\n\n" + sw.toString()
                if (info.length > 20000) info = info.substring(0, 20000)
                startActivity(
                    Intent(this, CrashActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        .putExtra("trace", info)
                )
            } catch (_: Throwable) { }
            old?.uncaughtException(t, e)
        }
    }
}

class CrashActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val trace = intent.getStringExtra("trace") ?: ""
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)
        col.setBackgroundColor(0xFFFFFFFF.toInt())
        val title = TextView(this)
        title.text = "Vigil توقف بسبب خطأ. اضغط «نسخ» وأرسل النص للمطوّر.\nVigil crashed. Tap Copy and send the text to the developer."
        title.textSize = 16f
        title.setTextColor(0xFF000000.toInt())
        col.addView(title)
        val body = TextView(this)
        body.text = trace
        body.textSize = 11f
        body.setTextColor(0xFF222222.toInt())
        body.setTextIsSelectable(true)
        col.addView(body)
        val copy = Button(this)
        copy.text = "نسخ / Copy"
        copy.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("crash", trace))
        }
        col.addView(copy)
        val share = Button(this)
        share.text = "مشاركة / Share"
        share.setOnClickListener {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, trace), "Share"))
        }
        col.addView(share)
        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
    }
}
