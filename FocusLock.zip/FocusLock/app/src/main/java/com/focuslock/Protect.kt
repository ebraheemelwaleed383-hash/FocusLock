package com.focuslock

import android.content.Context

// تطبيقات لا تُحظر أبدًا في أي مستوى: المكالمات والطوارئ والرسائل والبنوك والمحافظ الرقمية
object Protect {
    private val exact = setOf(
        "com.android.dialer", "com.google.android.dialer", "com.samsung.android.dialer", "com.android.phone",
        "com.android.server.telecom", "com.android.incallui", "com.android.mms", "com.google.android.apps.messaging",
        "com.samsung.android.messaging", "com.android.emergency", "com.google.android.apps.nbu.paisa.user",
        "com.paypal.android.p2pmobile", "com.google.android.apps.walletnfcrel"
    )
    private val words = listOf(
        "dialer", "telecom", "incallui", "emergency", "bank", "banque", "wallet", "visa", "mastercard",
        "fawry", "instapay", "paypal", "fintech", "payment", "vodafonecash", "etisalatcash", "orangecash", "paymob", "telda"
    )

    fun isProtected(c: Context, pkg: String): Boolean {
        if (pkg in exact) return true
        val p = pkg.lowercase()
        return words.any { p.contains(it) }
    }
}
