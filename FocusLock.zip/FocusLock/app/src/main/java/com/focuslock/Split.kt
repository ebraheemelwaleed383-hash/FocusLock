package com.focuslock

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.WindowManager

// حماية تقسيم الشاشة والنوافذ العائمة: شاشة القفل لازم تاخد الشاشة كلها دايمًا
object Split {
    private var lastEscape = 0L
    private val h = Handler(Looper.getMainLooper())

    // true لو نافذة النشاط ليست بملء الشاشة (تقسيم، نافذة عائمة، صورة داخل صورة)
    fun notFull(a: Activity): Boolean {
        try {
            if (Build.VERSION.SDK_INT >= 24 && a.isInMultiWindowMode) return true
            if (Build.VERSION.SDK_INT >= 26 && a.isInPictureInPictureMode) return true
            if (Build.VERSION.SDK_INT >= 30) {
                val wm = a.getSystemService(WindowManager::class.java)
                val cur = wm.currentWindowMetrics.bounds
                val max = wm.maximumWindowMetrics.bounds
                val curArea = cur.width().toLong() * cur.height()
                val maxArea = max.width().toLong() * max.height()
                if (maxArea > 0 && curArea < maxArea * 0.88) return true
            }
        } catch (_: Exception) { }
        return false
    }

    // نخرج من التقسيم بالرجوع للرئيسية ثم نعيد شاشة القفل بملء الشاشة
    fun escape(c: Context) {
        val el = SystemClock.elapsedRealtime()
        if (el - lastEscape < 1500L) return
        lastEscape = el
        val go = Engine.homeAction
        try {
            if (go != null) go() else c.startActivity(c.homeIntent())
        } catch (_: Exception) { }
        h.postDelayed({ Guard.showLock(c, null, true) }, 420L)
        h.postDelayed({ Guard.showLock(c, null, true) }, 1100L)
    }
}
