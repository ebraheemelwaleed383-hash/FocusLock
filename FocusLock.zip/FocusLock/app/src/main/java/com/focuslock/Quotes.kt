package com.focuslock

import android.content.Context

object Quotes {
    private val enBase = listOf(
        "Your future self will thank you. Stay focused!",
        "Discipline is choosing between what you want now and what you want most.",
        "The pain of discipline is far less than the pain of regret.",
        "You didn't come this far to only come this far.",
        "Every minute you hold the line is a vote for the person you want to become.",
        "Motivation gets you started. Discipline keeps you going.",
        "The phone will still be there later. Your goals won't wait.",
        "Small steps every day lead to big results. Keep going.",
        "Don't trade what you want most for what you want right now.",
        "Focus on the goal, not the distraction.",
        "You don't need more time, you need more focus.",
        "One focused hour beats a distracted day.",
        "Be proud of the minutes you protect.",
        "Distraction is a thief. Don't open the door.",
        "Do it now. Your future self is watching.",
        "Quiet effort today builds loud results tomorrow.",
        "You are one focused session away from progress.",
        "Make this minute count.",
        "The scroll can wait. Your dreams can't.",
        "Strong people say no to the easy thing.",
        "Finish what you started.",
        "Be stronger than your excuses.",
        "Progress, not perfection.",
        "Today's discipline is tomorrow's freedom.",
        "Stay with it. It's getting easier.",
        "You're building a habit, one session at a time.",
        "Nothing changes if nothing changes. Stay focused.",
        "Win the next minute.",
        "Your attention is your most valuable asset.",
        "Believe in yourself and keep going.",
        "Only you can change your future.",
        "Don't stop when you're tired. Stop when you're done."
    )
    private val arBase = listOf(
        "قيمتك في ما تنجزه، لا فيما تتصفحه.",
        "دقيقة تركيز اليوم تغنيك عن ساعة ندم بكرة.",
        "لا تستبدل ما تريده أكثر بما تريده الآن.",
        "الانضباط أن تفعل ما يجب حتى لو لم تكن في المزاج.",
        "كل جلسة تكملها خطوة نحو نسختك الأفضل.",
        "الهاتف سينتظرك، وأهدافك لن تنتظر.",
        "ركّز اليوم لترتاح غدًا.",
        "الخطوة الصغيرة المنتظمة أقوى من القفزة المتقطعة.",
        "أنت أقوى من إغراء الشاشة.",
        "ما تبدأه الآن يصنع ما ستكونه غدًا.",
        "التركيز مهارة، وكل جلسة تدريب عليها.",
        "اربح الدقيقة القادمة.",
        "لا تقل غدًا، قل الآن.",
        "اصنع عادة، لا مزاجًا.",
        "انتباهك أثمن ما تملك، فلا تهدره.",
        "أنجز أولًا، ثم استمتع دون شعور بالذنب.",
        "كن أقوى من أعذارك.",
        "استمر. الأمر يصبح أسهل.",
        "كل دقيقة تحميها هي صوت لمن تريد أن تصبح.",
        "التقدم أهم من الكمال.",
        "النجاح يبدأ بقرار صغير: أغلق الشاشة.",
        "عقلك يستحق أن يرتاح من الضجيج.",
        "اللي يصبر على التركيز يحصد بعدين.",
        "ثبات صغير كل يوم يغيّر كل شيء.",
        "اتعب دلوقتي، وارتاح لما تحقق اللي عاوزه."
    )
    private val en: List<String> by lazy { (enBase + EN_MORE).distinct() }
    private val ar: List<String> by lazy { (arBase + AR_MORE).distinct() }
    private var last = ""

    fun random(c: Context): String {
        val mine = Prefs.myQuotes(c)
        val base = when (Prefs.quoteLang(c)) { "ar" -> ar; "en" -> en; else -> en + ar }
        val pool = if (mine.isNotEmpty() && Prefs.onlyMine(c)) mine else base + mine
        var q: String
        do { q = pool.random() } while (q == last && pool.size > 1)
        last = q
        return q
    }
}
