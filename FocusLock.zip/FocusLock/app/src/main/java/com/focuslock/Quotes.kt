package com.focuslock

import android.content.Context

object Quotes {
    private val list = listOf(
        "Your future self will thank you. Stay focused!",
        "Discipline is choosing between what you want now and what you want most.",
        "The pain of discipline is far less than the pain of regret.",
        "You didn't come this far to only come this far.",
        "Every minute you hold the line is a vote for the person you want to become.",
        "Motivation gets you started. Discipline keeps you going.",
        "The phone will still be there later. Your goals won't wait.",
        "Small steps every day lead to big results. Keep going.",
        "Don't trade what you want most for what you want right now.",
        "Focus on the goal, not the distraction.",
        "You don't need more time, you need more focus.",
        "One focused hour beats a distracted day.",
        "Be proud of the minutes you protect.",
        "Distraction is a thief. Don't open the door.",
        "Do it now. Your future self is watching.",
        "Quiet effort today builds loud results tomorrow.",
        "You are one focused session away from progress.",
        "Make this minute count.",
        "The scroll can wait. Your dreams can't.",
        "Strong people say no to the easy thing.",
        "Finish what you started.",
        "Be stronger than your excuses.",
        "Progress, not perfection.",
        "Today's discipline is tomorrow's freedom.",
        "Stay with it. It's getting easier.",
        "You're building a habit, one session at a time.",
        "Nothing changes if nothing changes. Stay focused.",
        "Win the next minute.",
        "Your attention is your most valuable asset.",
        "Believe in yourself and keep going.",
        "Only you can change your future.",
        "Don't stop when you're tired. Stop when you're done."
    )
    private var last = ""

    fun random(c: Context): String {
        val mine = Prefs.myQuotes(c)
        val pool = if (mine.isNotEmpty() && Prefs.onlyMine(c)) mine else list + mine
        var q: String
        do { q = pool.random() } while (q == last && pool.size > 1)
        last = q
        return q
    }
}
