package com.focuslock

object Quotes {
    private val list = listOf(
        "Your future self will thank you. Stay focused!",
        "Discipline is choosing between what you want now and what you want most.",
        "The pain of discipline is far less than the pain of regret.",
        "You didn't come this far to only come this far.",
        "Every minute you hold the line is a vote for the person you want to become.",
        "Motivation gets you started. Discipline keeps you going.",
        "The phone will still be there later. Your goals won't wait.",
        "Small steps every day lead to big results. Keep going.",
        "Don't trade what you want most for what you want right now.",
        "Focus on the goal, not the distraction."
    )
    private var last = -1
    fun random(): String {
        var i: Int
        do { i = list.indices.random() } while (i == last && list.size > 1)
        last = i
        return list[i]
    }
}
