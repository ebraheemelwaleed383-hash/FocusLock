package com.focuslock

import android.content.Context
import java.time.LocalDate
import java.time.ZoneId

// طبقة أندرويد الرقيقة فوق المنطق الخالص: قراءة فقط من السجلات الحالية (لا نظام تتبع جديد).
object FocusData {
    fun cleaned(c: Context): Cleaned =
        SessionAnalytics.clean(SessionLog.all(c), ZoneId.systemDefault(), System.currentTimeMillis())

    fun today(): Long = LocalDate.now(ZoneId.systemDefault()).toEpochDay()

    fun totals(c: Context, cl: Cleaned): DailyTotals =
        DailyTotals.build(cl, LegacyDaily.parse(Prefs.dayTotals(c, "fm")))

    fun taskInfos(c: Context): List<TaskInfo> = Tasks.load(c).map { t ->
        TaskInfo(t.id, t.t, t.d, t.proj, t.steps.size, t.steps.count { it.done })
    }

    fun intel(c: Context): IntelReport {
        val cl = cleaned(c)
        return FocusIntel.build(cl, totals(c, cl), taskInfos(c), today())
    }
}

// تاريخ ملخصات أسبوعية مشتق (مفتاح dna_hist). يُدمج ولا يُنقص: لا يضيع أسبوع قديم لأن السجل اقتطع جلساته.
// لو أضيفت يومًا ميزة «مسح السجل» فعليها استدعاء clear() صراحةً (لا يوجد حاليًا أي مسح للسجل).
object DnaStore {
    private const val KEY = "dna_hist"
    private const val BAD = "dna_hist_bad"

    @Synchronized
    fun update(c: Context): List<WeekAgg> {
        val raw = Prefs.str(c, KEY, "")
        val p = DnaCodec.parse(raw)
        // محتوى تالف أو بإصدار غير معروف: نحتفظ بنسخة منه مرة واحدة قبل أن نكتب فوقه
        if (p.broken && raw.isNotBlank() && Prefs.str(c, BAD, "").isEmpty()) Prefs.putStr(c, BAD, raw)
        val fresh = WeekAgg.fromSessions(FocusData.cleaned(c).sessions)
        val merged = DnaCodec.merge(p.weeks, fresh)
        val enc = DnaCodec.encode(merged)
        if (enc != raw) Prefs.putStr(c, KEY, enc)
        return merged
    }

    @Synchronized
    fun clear(c: Context) {
        Prefs.putStr(c, KEY, "")
    }

    fun profile(c: Context): DnaProfile = FocusDna.build(update(c), FocusData.today())
}
