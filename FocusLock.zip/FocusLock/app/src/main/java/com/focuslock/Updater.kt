package com.focuslock

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object Updater {
    private const val API = "https://api.github.com/repos/ebraheemelwaleed383-hash/FocusLock/releases/latest"

    class Info(val tag: String, val url: String)

    private fun newer(a: String, b: String): Boolean {
        val x = a.split(".").map { it.toIntOrNull() ?: 0 }
        val y = b.split(".").map { it.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(x.size, y.size)) {
            val p = x.getOrElse(i) { 0 }
            val q = y.getOrElse(i) { 0 }
            if (p != q) return p > q
        }
        return false
    }

    // يُستدعى من خيط خلفي. الأول: هل نجح الاتصال؟ والثاني: معلومات النسخة الجديدة إن وُجدت
    fun checkNow(c: Context): Pair<Boolean, Info?> {
        val app = c.applicationContext
        var ok = false
        var info: Info? = null
        try {
            val conn = URL(API).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val tag = j.getString("tag_name")
            val assets = j.getJSONArray("assets")
            var url = ""
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.getString("name").endsWith(".apk", true)) { url = a.getString("browser_download_url"); break }
            }
            val cur = app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "0"
            ok = true
            if (url.isNotEmpty() && newer(tag.removePrefix("v"), cur)) info = Info(tag, url)
        } catch (e: Exception) { }
        return Pair(ok, info)
    }

    fun check(c: Context, cb: (Boolean, Info?) -> Unit) {
        Thread {
            val r = checkNow(c)
            Handler(Looper.getMainLooper()).post { cb(r.first, r.second) }
        }.start()
    }

    fun download(c: Context, info: Info) {
        val app = c.applicationContext
        File(app.getExternalFilesDir(null), "update.apk").delete()
        val dm = app.getSystemService(DownloadManager::class.java)
        val id = dm.enqueue(
            DownloadManager.Request(Uri.parse(info.url))
                .setTitle("Stay focused " + info.tag)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(app, null, "update.apk")
        )
        val rx = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, i: Intent) {
                if (i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) == id) {
                    try { app.unregisterReceiver(this) } catch (_: Exception) {}
                    install(app)
                }
            }
        }
        val f = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(rx, f, Context.RECEIVER_EXPORTED) else app.registerReceiver(rx, f)
    }

    fun install(c: Context) {
        if (!c.packageManager.canRequestPackageInstalls()) {
            c.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + c.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        val f = File(c.getExternalFilesDir(null), "update.apk")
        if (!f.exists()) return
        val uri = FileProvider.getUriForFile(c, c.packageName + ".fileprovider", f)
        c.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
