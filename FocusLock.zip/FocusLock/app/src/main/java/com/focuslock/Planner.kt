package com.focuslock

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class Prof(var wake: Int = 420, var sleep: Int = 1380, var peak: Int = 0, var maxH: Float = 4f, var blk: Int = 50, var brk: Int = 10, var rest: Int = 5)
class Fixed(var label: String, var days: Int, var start: Int, var end: Int)
class PTask(var title: String, var hours: Float, var dl: Int, var pri: Int, var endMs: Long = 0L)
class Goal(var title: String, var endMs: Long, var total: Float, var done: Float, var startMs: Long = System.currentTimeMillis())
class WeekLoad(val start: Long, val planned: Int, val capacity: Int)
class Block(var day: Long, var start: Int, var end: Int, var title: String, var kind: Int)
class Plan(val blocks: List<Block>, val unplaced: List<Pair<String, Int>>, val finish: Map<String, Long>)

object Planner {
    private fun arr(c: Context, k: String) = JSONArray(Prefs.raw(c, k))

    fun profile(c: Context): Prof {
        val s = Prefs.str(c, "pl_prof", "")
        if (s.isEmpty()) return Prof()
        val o = JSONObject(s)
        return Prof(o.optInt("wake", 420), o.optInt("sleep", 1380), o.optInt("peak", 0), o.optDouble("maxH", 4.0).toFloat(), o.optInt("blk", 50), o.optInt("brk", 10), o.optInt("rest", 5))
    }

    fun saveProfile(c: Context, p: Prof) {
        Prefs.putStr(c, "pl_prof", JSONObject().put("wake", p.wake).put("sleep", p.sleep).put("peak", p.peak).put("maxH", p.maxH.toDouble()).put("blk", p.blk).put("brk", p.brk).put("rest", p.rest).toString())
    }

    fun fixed(c: Context): MutableList<Fixed> {
        val a = arr(c, "pl_fixed")
        return MutableList(a.length()) { i -> val o = a.getJSONObject(i); Fixed(o.getString("l"), o.getInt("d"), o.getInt("s"), o.getInt("e")) }
    }

    fun saveFixed(c: Context, l: List<Fixed>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("l", it.label).put("d", it.days).put("s", it.start).put("e", it.end)) }
        Prefs.putRaw(c, "pl_fixed", a.toString())
    }

    fun tasks(c: Context): MutableList<PTask> {
        val a = arr(c, "pl_tasks")
        return MutableList(a.length()) { i -> val o = a.getJSONObject(i); PTask(o.getString("t"), o.getDouble("h").toFloat(), o.getInt("dl"), o.getInt("p"), o.optLong("ed", 0L)) }
    }

    fun saveTasks(c: Context, l: List<PTask>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("t", it.title).put("h", it.hours.toDouble()).put("dl", it.dl).put("p", it.pri).put("ed", it.endMs)) }
        Prefs.putRaw(c, "pl_tasks", a.toString())
    }

    fun goals(c: Context): MutableList<Goal> {
        val a = arr(c, "pl_goals")
        return MutableList(a.length()) { i -> val o = a.getJSONObject(i); Goal(o.getString("t"), o.getLong("end"), o.getDouble("tot").toFloat(), o.getDouble("done").toFloat(), o.optLong("st", System.currentTimeMillis())) }
    }

    fun saveGoals(c: Context, l: List<Goal>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("t", it.title).put("end", it.endMs).put("tot", it.total.toDouble()).put("done", it.done.toDouble()).put("st", it.startMs)) }
        Prefs.putRaw(c, "pl_goals", a.toString())
    }

    fun dayStart(ms: Long): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = ms
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    private fun addDays(ms: Long, d: Int): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = ms
        cal.add(Calendar.DAY_OF_YEAR, d)
        return cal.timeInMillis
    }

    fun dow(ms: Long): Int {
        val cal = Calendar.getInstance()
        cal.timeInMillis = ms
        return cal.get(Calendar.DAY_OF_WEEK) - 1
    }

    fun dayName(c: Context, d: Int): String {
        val ar = listOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
        val en = listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        return c.L(ar[d.coerceIn(0, 6)], en[d.coerceIn(0, 6)])
    }

    private class Dem(val title: String, var left: Int, val dlIdx: Int, val pri: Int, val kind: Int)

    private fun free(start: Int, end: Int, busy: List<Pair<Int, Int>>): MutableList<IntArray> {
        val out = ArrayList<IntArray>()
        var cur = start
        for ((bs, be) in busy.sortedBy { it.first }) {
            if (be <= cur) continue
            if (bs > cur) out.add(intArrayOf(cur, min(bs, end)))
            cur = max(cur, be)
            if (cur >= end) break
        }
        if (cur < end) out.add(intArrayOf(cur, end))
        return out.filter { it[1] - it[0] >= 15 }.toMutableList()
    }

    fun build(c: Context, capFactor: Float = 1f): Plan {
        val prof = profile(c)
        val fixed = fixed(c)
        val now = System.currentTimeMillis()
        val today = dayStart(now)
        val dems = ArrayList<Dem>()
        for (t in tasks(c)) {
            val left = (t.hours * 60).toInt() - doneMin(c, t.title)
            if (left <= 0) continue
            if (t.endMs > 0L) {
                val daysLeft = max(1, ((t.endMs - now) / 86_400_000L).toInt())
                if (daysLeft > 7) dems.add(Dem(t.title, Math.ceil((left / (daysLeft / 7f)).toDouble()).toInt(), 7, t.pri, 0))
                else dems.add(Dem(t.title, left, min(6, daysLeft), t.pri, 0))
                continue
            }
            var idx = 99
            if (t.dl in 1..7) { idx = ((t.dl - 1) - dow(today) + 7) % 7 }
            dems.add(Dem(t.title, left, idx, t.pri, 0))
        }
        for (g in goals(c)) {
            val days = max(1, ((g.endMs - now) / 86_400_000L).toInt())
            val weeks = max(1f, days / 7f)
            val perWeek = ((g.total - g.done) * 60f / weeks).toInt().coerceAtLeast(0)
            if (perWeek > 0) dems.add(Dem(g.title, perWeek, 7, 1, 1))
        }
        dems.sortWith(compareBy({ it.dlIdx }, { it.pri }))
        val blocks = ArrayList<Block>()
        val finish = HashMap<String, Long>()
        val sleepEff = min(if (prof.sleep <= prof.wake) prof.sleep + 1440 else prof.sleep, 1439)
        val peakR = when (prof.peak) { 0 -> 360 to 720; 1 -> 720 to 1020; 2 -> 1020 to 1320; else -> 1260 to 1439 }
        val cal = Calendar.getInstance()
        for (d in 0..6) {
            val dayMs = addDays(today, d)
            val dw = dow(dayMs)
            val busy = fixed.filter { ((it.days shr dw) and 1) == 1 }.map { it.start to it.end }
            var from = prof.wake
            if (d == 0) {
                val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
                from = max(from, ((nowMin + 10) / 5) * 5 + 5)
            }
            val slots = free(from, sleepEff, busy)
            slots.sortByDescending { max(0, min(it[1], peakR.second) - max(it[0], peakR.first)) }
            var capF = prof.maxH * 60f * capFactor * 0.85f * adapt(c)
            if (d == 0) capF *= energyFactor(energy(c))
            if (dw == prof.rest) capF *= 0.4f
            val cap = capF.toInt()
            var used = 0
            for (dem in dems) {
                if (dem.left <= 0 || dem.dlIdx < d) continue
                for (s in slots) {
                    while (dem.left > 0 && used < cap && s[1] - s[0] >= 15) {
                        val len = minOf(prof.blk, dem.left, s[1] - s[0], cap - used)
                        if (len < 15) break
                        blocks.add(Block(dayMs, s[0], s[0] + len, dem.title, dem.kind))
                        finish[dem.title] = dayMs
                        s[0] = s[0] + len + prof.brk
                        used += len
                        dem.left -= len
                    }
                    if (dem.left <= 0 || used >= cap) break
                }
            }
        }
        blocks.sortWith(compareBy({ it.day }, { it.start }))
        val unplaced = dems.filter { it.left > 0 }.map { it.title to it.left }
        return Plan(blocks, unplaced, finish)
    }

    fun savePlan(c: Context, p: Plan) {
        val a = JSONArray()
        p.blocks.forEach { a.put(JSONObject().put("d", it.day).put("s", it.start).put("e", it.end).put("t", it.title).put("k", it.kind)) }
        val u = JSONArray()
        p.unplaced.forEach { u.put(JSONObject().put("t", it.first).put("m", it.second)) }
        val f = JSONObject()
        p.finish.forEach { (k, v) -> f.put(k, v) }
        val todayMs = dayStart(System.currentTimeMillis())
        Prefs.putLong(c, "plp_" + Prefs.dayKey(), p.blocks.filter { it.day == todayMs }.sumOf { (it.end - it.start).toLong() })
        Prefs.putStr(c, "pl_sched", JSONObject().put("gen", System.currentTimeMillis()).put("b", a).put("u", u).put("f", f).toString())
    }

    fun loadPlan(c: Context): Plan? {
        val s = Prefs.str(c, "pl_sched", "")
        if (s.isEmpty()) return null
        val o = JSONObject(s)
        val a = o.getJSONArray("b")
        val blocks = List(a.length()) { i -> val b = a.getJSONObject(i); Block(b.getLong("d"), b.getInt("s"), b.getInt("e"), b.getString("t"), b.getInt("k")) }
        val u = o.getJSONArray("u")
        val un = List(u.length()) { i -> val b = u.getJSONObject(i); b.getString("t") to b.getInt("m") }
        val f = o.getJSONObject("f")
        val fin = HashMap<String, Long>()
        f.keys().forEach { k -> fin[k] = f.getLong(k) }
        return Plan(blocks, un, fin)
    }

    // ---- التقدم الفعلي والتكيّف والطاقة ----
    fun doneMin(c: Context, title: String): Int = Prefs.intOf(c, "pldt_" + title, 0)
    fun resetDone(c: Context, title: String) = Prefs.putInt(c, "pldt_" + title, 0)

    fun onSessionDone(c: Context, mins: Int) {
        val t = Prefs.str(c, "activeBlock", "")
        if (t.isEmpty()) return
        Prefs.putStr(c, "activeBlock", "")
        Prefs.putInt(c, "pldt_" + t, doneMin(c, t) + mins)
        Prefs.addDay(c, "pld", mins.toLong())
        val gl = goals(c)
        var changed = false
        for (g in gl) if (g.title == t) { g.done += mins / 60f; changed = true }
        if (changed) saveGoals(c, gl)
    }

    fun adapt(c: Context): Float {
        var planned = 0L
        var done = 0L
        for (k in 1..7) {
            val day = Prefs.dayKey(System.currentTimeMillis() - k * 86_400_000L)
            planned += Prefs.dayVal(c, "plp", day)
            done += Prefs.dayVal(c, "pld", day)
        }
        if (planned < 120L) return 1f
        val r = done.toFloat() / planned
        return when { r < 0.4f -> 0.7f; r < 0.6f -> 0.85f; r > 0.9f -> 1.08f; else -> 1f }
    }

    fun energy(c: Context): Int { val v = Prefs.dayVal(c, "energy", Prefs.dayKey()).toInt(); return if (v in 1..5) v else 0 }
    fun setEnergy(c: Context, v: Int) = Prefs.putLong(c, "energy_" + Prefs.dayKey(), v.toLong())
    private fun energyFactor(v: Int): Float = when (v) { 1 -> 0.4f; 2 -> 0.65f; 4 -> 1.05f; 5 -> 1.1f; else -> 1f }

    fun genDay(c: Context): Long {
        val s = Prefs.str(c, "pl_sched", "")
        return if (s.isEmpty()) 0L else dayStart(JSONObject(s).optLong("gen", 0L))
    }

    // تجديد الخطة يوميًا: ما فات يُترك بلا ذنب، والمتبقي يُعاد ترتيبه
    fun maybeRoll(c: Context) {
        if (loadPlan(c) == null) return
        if (genDay(c) != dayStart(System.currentTimeMillis())) { savePlan(c, build(c)); PlanAlarms.rescan(c) }
    }

    fun replan(c: Context) { savePlan(c, build(c)); PlanAlarms.rescan(c) }

    private fun weeklyDemandMin(c: Context): Int {
        val now = System.currentTimeMillis()
        var sum = 0
        for (g in goals(c)) {
            val weeks = max(1f, max(1, ((g.endMs - now) / 86_400_000L).toInt()) / 7f)
            sum += ((g.total - g.done) * 60f / weeks).toInt().coerceAtLeast(0)
        }
        for (t in tasks(c)) {
            if (t.endMs <= 0L) continue
            val days = max(1, ((t.endMs - now) / 86_400_000L).toInt())
            val left = (t.hours * 60).toInt() - doneMin(c, t.title)
            if (days > 7 && left > 0) sum += (left / (days / 7f)).toInt()
        }
        return sum
    }

    fun weekLoads(c: Context): List<WeekLoad> {
        val prof = profile(c)
        val today = dayStart(System.currentTimeMillis())
        val cap = (prof.maxH * 60f * 6.4f * 0.85f * adapt(c)).toInt()
        val plan = loadPlan(c)
        val demand = weeklyDemandMin(c)
        return List(5) { w ->
            val start = addDays(today, 7 * w)
            val planned = if (w == 0 && plan != null) plan.blocks.sumOf { it.end - it.start } else demand
            WeekLoad(start, planned, cap)
        }
    }

    fun goalLine(c: Context, g: Goal): String {
        val now = System.currentTimeMillis()
        val daysLeft = ((g.endMs - now) / 86_400_000L).toInt()
        val remaining = max(0f, g.total - g.done)
        val weeks = max(1f, max(1, daysLeft) / 7f)
        val perWeek = remaining / weeks
        val span = max(1L, g.endMs - g.startMs)
        val expected = g.total * ((now - g.startMs).toFloat() / span).coerceIn(0f, 1f)
        val diff = g.done - expected
        val horizon = when {
            daysLeft > 365 -> c.L("طويل المدى (أكثر من سنة)", "Long term (over a year)")
            daysLeft > 60 -> c.L("متوسط المدى", "Mid term")
            else -> c.L("قصير المدى", "Short term")
        }
        fun f1(x: Float) = String.format(Locale.US, "%.1f", x)
        val status = if (diff >= -g.total * 0.05f) c.L("على المسار ✓", "On track ✓")
        else c.L("متأخر ${f1(-diff)} ساعة. هذا عادي: حدّث الخطة وكمّل بلا جلد للذات.", "Behind by ${f1(-diff)} h. That's normal: refresh the plan and carry on without guilt.")
        val step = if (daysLeft > 365) c.L(" كل ربع سنة ≈ ${f1(perWeek * 13f)} ساعة.", " Each quarter ≈ ${f1(perWeek * 13f)} h.")
        else if (daysLeft > 60) c.L(" هدف الشهر القادم: +${f1(perWeek * 4.3f)} ساعة.", " Next month's goal: +${f1(perWeek * 4.3f)} h.") else ""
        return horizon + "\n" + c.L("المطلوب: ${f1(perWeek)} ساعة أسبوعيًا (≈ ${f1(perWeek / 7f * 60f)} دقيقة يوميًا).$step $status", "Needed: ${f1(perWeek)} h per week (≈ ${f1(perWeek / 7f * 60f)} min a day).$step $status")
    }

    fun clearPlan(c: Context) { Prefs.putStr(c, "pl_sched", ""); PlanAlarms.rescan(c) }

    fun fmt(min: Int): String = String.format(Locale.US, "%02d:%02d", min / 60, min % 60)

    fun explain(c: Context): String {
        val p = loadPlan(c) ?: return ""
        val totalMin = p.blocks.sumOf { it.end - it.start }
        val perDay = p.blocks.groupBy { it.day }.mapValues { e -> e.value.sumOf { it.end - it.start } }
        val busiest = perDay.maxByOrNull { it.value }
        val sb = StringBuilder()
        sb.append(c.L("خطتك: ${String.format(Locale.US, "%.1f", totalMin / 60f)} ساعة تركيز موزعة على ${perDay.size} أيام.", "Your plan: ${String.format(Locale.US, "%.1f", totalMin / 60f)} focus hours over ${perDay.size} days."))
        if (busiest != null) sb.append(c.L(" أكثر يوم ازدحامًا: ${dayName(c, dow(busiest.key))} (${String.format(Locale.US, "%.1f", busiest.value / 60f)} ساعة).", " Busiest day: ${dayName(c, dow(busiest.key))} (${String.format(Locale.US, "%.1f", busiest.value / 60f)} h)."))
        val ad = adapt(c)
        if (ad < 1f) sb.append("\n").append(c.L("خففت الحمل لأن التزامك الأسبوع الماضي كان أقل من المخطط. هذا طبيعي، المهم أن تستمر.", "I lightened the load because last week's completion was below plan. That's normal, what matters is continuing."))
        else if (ad > 1f) sb.append("\n").append(c.L("رفعت الحمل قليلًا لأنك ملتزم. أحسنت.", "I raised the load slightly because you're consistent. Well done."))
        if (energy(c) in 1..2) sb.append("\n").append(c.L("طاقتك اليوم منخفضة، فخطة اليوم أخف عمدًا.", "Your energy is low today, so today's plan is deliberately lighter."))
        sb.append("\n\n").append(c.L("لو التزمت بالجدول:", "If you follow the schedule:"))
        for (t in tasks(c)) {
            val fd = p.finish[t.title]
            if (fd != null) sb.append("\n• ").append(c.L("«${t.title}» تنتهي يوم ${dayName(c, dow(fd))}.", "\"${t.title}\" is done by ${dayName(c, dow(fd))}."))
        }
        for (g in goals(c)) {
            val mins = p.blocks.filter { it.kind == 1 && it.title == g.title }.sumOf { it.end - it.start }
            if (mins > 0) sb.append("\n• ").append(c.L("هدف «${g.title}»: +${String.format(Locale.US, "%.1f", mins / 60f)} ساعة هذا الأسبوع.", "Goal \"${g.title}\": +${String.format(Locale.US, "%.1f", mins / 60f)} h this week."))
        }
        if (p.unplaced.isNotEmpty()) {
            val need = p.unplaced.sumOf { it.second } / 60f
            sb.append("\n\n").append(c.L("لم يتّسع الوقت لـ: ", "There was no room for: ")).append(p.unplaced.joinToString("، ") { it.first })
            sb.append(c.L(". تحتاج حوالي ${String.format(Locale.US, "%.1f", need)} ساعة إضافية. الحل: زوّد ساعات التركيز اليومية، أو خفّف المهام، أو مدّ المواعيد.", ". You need about ${String.format(Locale.US, "%.1f", need)} more hours. Fix it by adding daily focus hours, trimming tasks, or moving deadlines."))
        }
        val at80 = build(c, 0.8f).unplaced.map { it.first }.toSet() - p.unplaced.map { it.first }.toSet()
        sb.append("\n\n")
        if (at80.isEmpty()) sb.append(c.L("حتى لو التزمت بـ80% فقط عندك هامش أمان جيد.", "Even at 80% compliance you still have a healthy buffer."))
        else sb.append(c.L("لو التزمت بـ80% فقط فقد تتأخر في: ", "At only 80% compliance you may be late on: ")).append(at80.joinToString("، "))
        sb.append("\n\n").append(c.L("لو لم تمشِ على الجدول: كل ساعة تفوتك تتراكم على الأيام التالية، فتزداد الضغوط قرب المواعيد وتقل جودة الشغل ويزيد خطر فوات المواعيد.", "If you don't follow it: every missed hour piles onto later days, pressure rises near deadlines, quality drops, and the risk of missing deadlines grows."))
        return sb.toString()
    }
}

object PlanAlarms {
    private fun pi(c: Context, code: Int, title: String, mins: Int): PendingIntent {
        val i = Intent(c, BlockReceiver::class.java).putExtra("t", title).putExtra("m", mins)
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun rescan(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        val n = Prefs.intOf(c, "pl_an", 0)
        for (k in 0 until n) am.cancel(pi(c, 6000 + k, "", 0))
        Prefs.putInt(c, "pl_an", 0)
        if (!Prefs.boolOf(c, "pl_remind", true)) return
        val plan = Planner.loadPlan(c) ?: return
        val now = System.currentTimeMillis()
        var k = 0
        for (b in plan.blocks) {
            val t = b.day + b.start * 60_000L
            if (t > now && t < now + 36 * 3_600_000L && k < 40) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi(c, 6000 + k, b.title, b.end - b.start))
                k++
            }
        }
        Prefs.putInt(c, "pl_an", k)
    }
}

class BlockReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val t = i.getStringExtra("t") ?: return
        val m = i.getIntExtra("m", 25)
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("plan", c.L("جدول المهام", "Task schedule"), NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(
            c, 77, Intent(c, SplashActivity::class.java).putExtra("quick", m).putExtra("qt", t).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        nm.notify(
            78,
            Notification.Builder(c, "plan").setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(c.L("ابدأ الآن: $t", "Start now: $t"))
                .setContentText(c.L("جلسة تركيز $m دقيقة. اضغط للبدء.", "A $m-minute focus session. Tap to begin."))
                .setContentIntent(open).setAutoCancel(true).build()
        )
        PlanAlarms.rescan(c)
    }
}
