package com.focuslock

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// شبكة أمان ثانية: منبّه على مستوى النظام ينظّف الجلسة عند انتهاء الوقت حتى لو مات التطبيق
object EndAlarm {
    private fun pi(c: Context): PendingIntent = PendingIntent.getBroadcast(
        c, 41, Intent(c, EndReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun schedule(c: Context) {
        val end = Prefs.end(c)
        if (end <= System.currentTimeMillis()) return
        c.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end + 1000L, pi(c))
    }

    fun cancel(c: Context) {
        c.getSystemService(AlarmManager::class.java).cancel(pi(c))
    }
}

class EndReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Prefs.active(c)) { EndAlarm.schedule(c); return }
        if (Prefs.settle(c)) Plans.onFocusEnd(c)
        KeepAliveService.refresh(c)
        c.getSystemService(NotificationManager::class.java).cancel(1)
    }
}
