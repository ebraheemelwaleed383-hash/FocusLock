package com.focuslock

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.*
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.util.Locale

class LockActivity : Activity() {
    private lateinit var quote: TextView
    private lateinit var timer: TextView
    private lateinit var msg: TextView
    private lateinit var endTv: TextView
    private lateinit var pw: EditText
    private lateinit var unlockBtn: Button
    private lateinit var exitBox: LinearLayout
    private lateinit var tasksBox: LinearLayout
    private lateinit var notesCard: LinearLayout
    private lateinit var notesList: LinearLayout
    private var meter: Meter? = null
    private var txc = 0
    private var muc = 0
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { update(); h.postDelayed(this, 1000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applyTheme()
        if (!Prefs.active(this)) { finish(); return }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Sfx.warm(this)

        val bgd = Look.background(this)
        val hasBg = bgd != null
        val dark = hasBg && (!C.light || Prefs.bgOpacity(this) >= 70)
        txc = if (dark) 0xFFFFFFFF.toInt() else C.TX
        muc = if (dark) 0xFFD5DBE8.toInt() else C.MU
        val track = if (dark) 0x55FFFFFF else C.LN

        val frame = FrameLayout(this)
        frame.setBackgroundColor(C.BG)
        if (bgd != null) {
            frame.addView(ImageView(this).apply {
                setImageDrawable(bgd); scaleType = ImageView.ScaleType.CENTER_CROP
                alpha = Prefs.bgOpacity(this@LockActivity) / 100f
            }, FrameLayout.LayoutParams(MATCH, MATCH))
            frame.addView(View(this).apply {
                setBackgroundColor(Color.argb((Prefs.bgDim(this@LockActivity) * 2.55f).toInt(), 0, 0, 0))
            }, FrameLayout.LayoutParams(MATCH, MATCH))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(36), dp(22), dp(24))
        }
        root.addView(tv(L("جلسة تركيز نشطة", "Focus session active"), 15f, muc).apply { gravity = Gravity.CENTER })

        timer = tv("", 44f, txc, true).apply { gravity = Gravity.CENTER }
        val m = Counters.make(this, Prefs.counter(this), track, C.AC)
        meter = m
        if (m == null) {
            timer.textSize = 64f
            root.put(timer, 28)
        } else if (m.overlay) {
            val box = FrameLayout(this)
            box.addView(m.view, FrameLayout.LayoutParams(dp(m.w), dp(m.h)))
            box.addView(timer, FrameLayout.LayoutParams(dp(m.w), dp(m.h)))
            root.addView(box, LinearLayout.LayoutParams(dp(m.w), dp(m.h)).apply {
                gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(24)
            })
        } else {
            root.put(timer, 24)
            val lp = if (m.w == 0) LinearLayout.LayoutParams(MATCH, dp(m.h)) else LinearLayout.LayoutParams(dp(m.w), dp(m.h))
            lp.gravity = Gravity.CENTER_HORIZONTAL
            lp.topMargin = dp(12)
            root.addView(m.view, lp)
        }

        endTv = tv("", 13f, muc).apply { gravity = Gravity.CENTER }
        root.put(endTv, 8)

        val ex = LinearLayout(this)
        listOf(5, 15, 30).forEach { mm ->
            ex.addView(btn("+$mm " + L("د", "m")) { extend(mm) }.apply { textSize = 13f },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        }
        root.put(tv(L("زوّد الوقت (لا يمكن تقليله)", "Add time (it can't be reduced)"), 12f, muc).apply { gravity = Gravity.CENTER }, 14)
        root.put(ex, 6)

        val qc = card()
        if (dark) qc.background = rounded(0x77000000.toInt(), 16, 0x33FFFFFF)
        quote = tv("", 19f, txc).apply { gravity = Gravity.CENTER }
        qc.addView(quote)
        root.put(qc, 20)

        tasksBox = card()
        if (dark) tasksBox.background = rounded(0x77000000.toInt(), 16, 0x33FFFFFF)
        root.put(tasksBox, 12)
        renderTasks()

        notesCard = card()
        if (dark) notesCard.background = rounded(0x77000000.toInt(), 16, 0x33FFFFFF)
        notesCard.addView(tv(L("ملاحظة سريعة", "Quick note"), 13f, muc))
        val nf = EditText(this).apply {
            hint = L("اكتب الفكرة اللي جت في بالك وارجع للتركيز", "Jot the thought down, then get back to focus")
            setTextColor(txc); setHintTextColor(muc)
            background = rounded(0x33000000, 12, 0x33FFFFFF)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        notesCard.put(nf, 8)
        notesCard.put(btn(L("حفظ الملاحظة", "Save note")) {
            val t = nf.text.toString().trim()
            if (t.isNotEmpty()) {
                val l = Prefs.notes(this); l.add(0, t); Prefs.setNotes(this, l)
                nf.text.clear(); Sfx.task(this, Sfx.ADD); renderNotes()
            }
        }, 8)
        notesList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        notesCard.put(notesList, 8)
        root.put(notesCard, 12)
        renderNotes()

        msg = tv("", 14f, C.WR).apply { gravity = Gravity.CENTER }
        root.put(msg, 10)
        root.put(btn(L("أحتاج إلى الخروج", "I need to leave")) { exitBox.visibility = View.VISIBLE }, 16)

        exitBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        pw = EditText(this).apply {
            hint = L("كلمة مرور الخروج الطارئ", "Emergency password")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(C.TX); setHintTextColor(C.MU)
            gravity = Gravity.CENTER
            background = rounded(C.SF, 12, C.LN)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        unlockBtn = btn(L("خروج طارئ", "Emergency exit")) { tryUnlock() }
        val hintTxt = Prefs.hint(this)
        if (hintTxt.isNotBlank()) exitBox.put(tv(L("تلميح: ", "Hint: ") + hintTxt, 13f, C.MU).apply { gravity = Gravity.CENTER }, 0)
        exitBox.put(pw, 6)
        exitBox.put(unlockBtn, 8)
        root.put(exitBox, 10)

        frame.addView(ScrollView(this).apply { isFillViewport = true; addView(root) }, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.applyDir()
        setContentView(frame)
        show(intent)
    }

    private fun extend(mins: Int) {
        if (Prefs.extend(this, mins)) {
            KeepAliveService.start(this)
            msg.text = L("تمت زيادة $mins دقيقة", "Added $mins min")
        } else {
            msg.text = L("وصلت للحد الأقصى: 12 ساعة", "You reached the 12-hour cap")
        }
        update()
    }

    private fun renderNotes() {
        notesList.removeAllViews()
        Prefs.notes(this).take(3).forEach { n -> notesList.put(tv("• $n", 13f, txc), 4) }
    }

    private fun renderTasks() {
        tasksBox.removeAllViews()
        val all = Tasks.load(this)
        val pending = all.filter { !it.d }.take(5)
        tasksBox.visibility = if (pending.isEmpty()) View.GONE else View.VISIBLE
        if (pending.isEmpty()) return
        tasksBox.addView(tv(L("مهامك", "Your tasks"), 13f, muc))
        pending.forEach { t ->
            tasksBox.addView(CheckBox(this).apply {
                text = t.t
                setTextColor(txc)
                buttonTintList = ColorStateList.valueOf(C.AC)
                setOnCheckedChangeListener { _, on ->
                    if (on) {
                        t.d = true
                        Tasks.save(this@LockActivity, all)
                        Sfx.task(this@LockActivity, Sfx.DONE)
                        renderTasks()
                    }
                }
            })
        }
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); show(i) }

    private fun show(i: Intent?) {
        quote.text = "\u201C" + Quotes.random(this) + "\u201D"
        val why = i?.getStringExtra("why")
        msg.text = if (why == null) "" else {
            val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(why, 0)).toString() } catch (_: Exception) { why }
            L("تم منع فتح: $label", "Blocked: $label")
        }
        update()
    }

    private fun update() {
        if (!Prefs.active(this)) { Prefs.settle(this); finish(); return }
        val now = System.currentTimeMillis()
        val end = Prefs.end(this)
        val left = (end - now) / 1000
        val total = (end - Prefs.start(this)).coerceAtLeast(1L)
        meter?.upd?.invoke((end - now).toFloat() / total)
        endTv.text = L("ينتهي القفل الساعة ", "Unlocks at ") + clock(end)
        timer.text = String.format(Locale.US, "%02d:%02d:%02d", left / 3600, left % 3600 / 60, left % 60)
        val wait = (Prefs.lockUntil(this) - now) / 1000
        unlockBtn.isEnabled = wait <= 0
        unlockBtn.text = if (wait > 0) L("انتظر $wait ثانية", "Wait $wait s") else L("خروج طارئ", "Emergency exit")
    }

    private fun tryUnlock() {
        if (Prefs.check(this, pw.text.toString())) {
            Prefs.clearFails(this)
            Prefs.cancel(this)
            stopService(Intent(this, KeepAliveService::class.java))
            finish()
        } else {
            Prefs.registerFail(this)
            pw.text.clear()
            msg.text = L("كلمة المرور خاطئة. تمت إضافة عقوبة زمنية.", "Wrong password. A time penalty was added.")
            update()
        }
    }

    @Deprecated("Back is disabled during a session")
    override fun onBackPressed() {}

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }
}
