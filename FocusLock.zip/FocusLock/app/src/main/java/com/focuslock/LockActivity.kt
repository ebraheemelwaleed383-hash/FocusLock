package com.focuslock

import android.app.Activity
import android.content.Intent
import android.os.*
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.widget.*

class LockActivity : Activity() {
    private lateinit var quote: TextView
    private lateinit var timer: TextView
    private lateinit var msg: TextView
    private lateinit var pw: EditText
    private lateinit var btn: Button
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { update(); h.postDelayed(this, 1000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!Prefs.active(this)) { finish(); return }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF0C1019.toInt())
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        fun tv(size: Float, color: Int) = TextView(this).apply {
            textSize = size; setTextColor(color); gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
        }
        quote = tv(24f, 0xFFE9EDF6.toInt())
        timer = tv(48f, 0xFF8FB4FF.toInt())
        msg = tv(14f, 0xFFFF8A6B.toInt())
        pw = EditText(this).apply {
            hint = "كلمة المرور للخروج الطارئ"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(0xFFE9EDF6.toInt()); setHintTextColor(0xFF8B95AD.toInt())
            gravity = Gravity.CENTER
        }
        btn = Button(this).apply { setOnClickListener { tryUnlock() } }
        listOf(quote, timer, msg, pw, btn).forEach { root.addView(it) }
        setContentView(root)
        show(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); show(i) }

    private fun show(i: Intent?) {
        quote.text = "\u201C" + Quotes.random() + "\u201D"
        val why = i?.getStringExtra("why")
        msg.text = if (why == null) "" else {
            val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(why, 0)).toString() } catch (_: Exception) { why }
            "تم منع فتح: $label"
        }
        update()
    }

    private fun update() {
        if (!Prefs.active(this)) { Prefs.settle(this); finish(); return }
        val left = (Prefs.end(this) - System.currentTimeMillis()) / 1000
        timer.text = "%02d:%02d:%02d".format(left / 3600, left % 3600 / 60, left % 60)
        val wait = (Prefs.lockUntil(this) - System.currentTimeMillis()) / 1000
        btn.isEnabled = wait <= 0
        btn.text = if (wait > 0) "انتظر $wait ثانية" else "خروج طارئ بكلمة المرور"
    }

    private fun tryUnlock() {
        if (Prefs.check(this, pw.text.toString())) {
            Prefs.clearFails(this)
            Prefs.cancel(this)
            stopService(Intent(this, KeepAliveService::class.java))
            finish()
        } else {
            Prefs.registerFail(this)
            pw.text.clear()
            msg.text = "كلمة المرور خاطئة. تمت إضافة عقوبة زمنية."
            update()
        }
    }

    @Deprecated("Back is disabled during a session")
    override fun onBackPressed() {}

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }
}
