package com.focuslock

import android.app.Activity
import android.content.Intent
import android.os.*
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.util.Locale

class LockActivity : Activity() {
    private lateinit var quote: TextView
    private lateinit var timer: TextView
    private lateinit var msg: TextView
    private lateinit var pw: EditText
    private lateinit var unlockBtn: Button
    private lateinit var ring: RingView
    private lateinit var exitBox: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { update(); h.postDelayed(this, 1000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!Prefs.active(this)) { finish(); return }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(C.BG)
            setPadding(dp(22), dp(36), dp(22), dp(24))
        }
        root.addView(tv("جلسة تركيز نشطة", 15f, C.MU).apply { gravity = Gravity.CENTER })

        ring = RingView(this)
        timer = tv("", 44f, C.TX, true).apply { gravity = Gravity.CENTER }
        val box = FrameLayout(this)
        box.addView(ring, FrameLayout.LayoutParams(dp(250), dp(250)))
        box.addView(timer, FrameLayout.LayoutParams(dp(250), dp(250)))
        root.addView(box, LinearLayout.LayoutParams(dp(250), dp(250)).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(24)
        })

        val qc = card()
        quote = tv("", 19f, C.TX).apply { gravity = Gravity.CENTER }
        qc.addView(quote)
        root.put(qc, 28)

        msg = tv("", 14f, C.WR).apply { gravity = Gravity.CENTER }
        root.put(msg, 10)

        root.put(btn("أحتاج إلى الخروج") { exitBox.visibility = View.VISIBLE }, 16)

        exitBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        pw = EditText(this).apply {
            hint = "كلمة مرور الخروج الطارئ"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(C.TX); setHintTextColor(C.MU)
            gravity = Gravity.CENTER
            background = rounded(C.SF, 12, C.LN)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        unlockBtn = btn("خروج طارئ") { tryUnlock() }
        exitBox.put(pw, 0)
        exitBox.put(unlockBtn, 8)
        root.put(exitBox, 10)

        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
        show(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); show(i) }

    private fun show(i: Intent?) {
        quote.text = "\u201C" + Quotes.random() + "\u201D"
        val why = i?.getStringExtra("why")
        msg.text = if (why == null) "" else {
            val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(why, 0)).toString() } catch (_: Exception) { why }
            "تم منع فتح: $label"
        }
        update()
    }

    private fun update() {
        if (!Prefs.active(this)) { Prefs.settle(this); finish(); return }
        val now = System.currentTimeMillis()
        val end = Prefs.end(this)
        val left = (end - now) / 1000
        val total = (end - Prefs.start(this)).coerceAtLeast(1L)
        ring.fraction = (end - now).toFloat() / total
        timer.text = String.format(Locale.US, "%02d:%02d:%02d", left / 3600, left % 3600 / 60, left % 60)
        val wait = (Prefs.lockUntil(this) - now) / 1000
        unlockBtn.isEnabled = wait <= 0
        unlockBtn.text = if (wait > 0) "انتظر $wait ثانية" else "خروج طارئ"
    }

    private fun tryUnlock() {
        if (Prefs.check(this, pw.text.toString())) {
            Prefs.clearFails(this)
            Prefs.cancel(this)
            stopService(Intent(this, KeepAliveService::class.java))
            finish()
        } else {
            Prefs.registerFail(this)
            pw.text.clear()
            msg.text = "كلمة المرور خاطئة. تمت إضافة عقوبة زمنية."
            update()
        }
    }

    @Deprecated("Back is disabled during a session")
    override fun onBackPressed() {}

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }
}
