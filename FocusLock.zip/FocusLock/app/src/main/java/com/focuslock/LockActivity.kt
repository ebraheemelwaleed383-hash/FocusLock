package com.focuslock

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.os.*
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.util.Locale

class LockActivity : Activity() {
    private lateinit var quote: TextView
    private lateinit var timer: TextView
    private lateinit var msg: TextView
    private lateinit var pw: EditText
    private lateinit var unlockBtn: Button
    private lateinit var exitBox: LinearLayout
    private lateinit var tasksBox: LinearLayout
    private var ring: RingView? = null
    private var bar: BarView? = null
    private var txc = 0
    private var muc = 0
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { update(); h.postDelayed(this, 1000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applyTheme()
        if (!Prefs.active(this)) { finish(); return }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val bgd = Look.background(this)
        val hasBg = bgd != null
        txc = if (hasBg) 0xFFFFFFFF.toInt() else C.TX
        muc = if (hasBg) 0xFFD5DBE8.toInt() else C.MU
        val track = if (hasBg) 0x55FFFFFF else C.LN

        val frame = FrameLayout(this)
        if (bgd != null) {
            frame.addView(ImageView(this).apply {
                setImageDrawable(bgd); scaleType = ImageView.ScaleType.CENTER_CROP
            }, FrameLayout.LayoutParams(MATCH, MATCH))
            frame.addView(View(this).apply { setBackgroundColor(0x99000000.toInt()) }, FrameLayout.LayoutParams(MATCH, MATCH))
        } else frame.setBackgroundColor(C.BG)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(36), dp(22), dp(24))
        }
        root.addView(tv(L("جلسة تركيز نشطة", "Focus session active"), 15f, muc).apply { gravity = Gravity.CENTER })

        timer = tv("", 44f, txc, true).apply { gravity = Gravity.CENTER }
        when (Prefs.counter(this)) {
            "bar" -> {
                bar = BarView(this, track, C.AC)
                root.put(timer, 28)
                root.addView(bar, LinearLayout.LayoutParams(MATCH, dp(10)).apply { topMargin = dp(12) })
            }
            "digital" -> {
                timer.textSize = 64f
                root.put(timer, 28)
            }
            else -> {
                ring = RingView(this, track, C.AC)
                val box = FrameLayout(this)
                box.addView(ring, FrameLayout.LayoutParams(dp(250), dp(250)))
                box.addView(timer, FrameLayout.LayoutParams(dp(250), dp(250)))
                root.addView(box, LinearLayout.LayoutParams(dp(250), dp(250)).apply {
                    gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(24)
                })
            }
        }
        root.put(tv(L("ينتهي القفل الساعة ", "Unlocks at ") + clock(Prefs.end(this)), 13f, muc).apply { gravity = Gravity.CENTER }, 6)

        val qc = card()
        if (hasBg) qc.background = rounded(0x77000000.toInt(), 16, 0x33FFFFFF)
        quote = tv("", 19f, txc).apply { gravity = Gravity.CENTER }
        qc.addView(quote)
        root.put(qc, 24)

        tasksBox = card()
        if (hasBg) tasksBox.background = rounded(0x77000000.toInt(), 16, 0x33FFFFFF)
        root.put(tasksBox, 12)
        renderTasks()

        msg = tv("", 14f, C.WR).apply { gravity = Gravity.CENTER }
        root.put(msg, 10)
        root.put(btn(L("أحتاج إلى الخروج", "I need to leave")) { exitBox.visibility = View.VISIBLE }, 16)

        exitBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        pw = EditText(this).apply {
            hint = L("كلمة مرور الخروج الطارئ", "Emergency password")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(C.TX); setHintTextColor(C.MU)
            gravity = Gravity.CENTER
            background = rounded(C.SF, 12, C.LN)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        unlockBtn = btn(L("خروج طارئ", "Emergency exit")) { tryUnlock() }
        exitBox.put(pw, 0)
        exitBox.put(unlockBtn, 8)
        root.put(exitBox, 10)

        frame.addView(ScrollView(this).apply { isFillViewport = true; addView(root) }, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.applyDir()
        setContentView(frame)
        show(intent)
    }

    private fun renderTasks() {
        tasksBox.removeAllViews()
        val all = Tasks.load(this)
        val pending = all.filter { !it.d }.take(5)
        tasksBox.visibility = if (pending.isEmpty()) View.GONE else View.VISIBLE
        if (pending.isEmpty()) return
        tasksBox.addView(tv(L("مهامك", "Your tasks"), 13f, muc))
        pending.forEach { t ->
            tasksBox.addView(CheckBox(this).apply {
                text = t.t
                setTextColor(txc)
                buttonTintList = ColorStateList.valueOf(C.AC)
                setOnCheckedChangeListener { _, on ->
                    if (on) { t.d = true; Tasks.save(this@LockActivity, all); renderTasks() }
                }
            })
        }
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); show(i) }

    private fun show(i: Intent?) {
        quote.text = "\u201C" + Quotes.random(this) + "\u201D"
        val why = i?.getStringExtra("why")
        msg.text = if (why == null) "" else {
            val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(why, 0)).toString() } catch (_: Exception) { why }
            L("تم منع فتح: $label", "Blocked: $label")
        }
        update()
    }

    private fun update() {
        if (!Prefs.active(this)) { Prefs.settle(this); finish(); return }
        val now = System.currentTimeMillis()
        val end = Prefs.end(this)
        val left = (end - now) / 1000
        val total = (end - Prefs.start(this)).coerceAtLeast(1L)
        val f = (end - now).toFloat() / total
        ring?.fraction = f
        bar?.fraction = f
        timer.text = String.format(Locale.US, "%02d:%02d:%02d", left / 3600, left % 3600 / 60, left % 60)
        val wait = (Prefs.lockUntil(this) - now) / 1000
        unlockBtn.isEnabled = wait <= 0
        unlockBtn.text = if (wait > 0) L("انتظر $wait ثانية", "Wait $wait s") else L("خروج طارئ", "Emergency exit")
    }

    private fun tryUnlock() {
        if (Prefs.check(this, pw.text.toString())) {
            Prefs.clearFails(this)
            Prefs.cancel(this)
            stopService(Intent(this, KeepAliveService::class.java))
            finish()
        } else {
            Prefs.registerFail(this)
            pw.text.clear()
            msg.text = L("كلمة المرور خاطئة. تمت إضافة عقوبة زمنية.", "Wrong password. A time penalty was added.")
            update()
        }
    }

    @Deprecated("Back is disabled during a session")
    override fun onBackPressed() {}

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }
}
