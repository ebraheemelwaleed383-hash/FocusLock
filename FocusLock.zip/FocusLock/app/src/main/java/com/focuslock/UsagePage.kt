package com.focuslock

import android.app.Activity
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// إحصائيات الاستخدام (تحتاج إذن "بيانات الاستخدام") + حدود يومية لكل تطبيق
class UsagePage(private val a: Activity) {
    private lateinit var content: LinearLayout
    private val day = 86_400_000L
    private var sel = 6
    private var selApp = -1
    private var showAll = false
    private var cache: List<Map<String, Long>> = emptyList()

    private fun palette() = listOf(C.AC, C.OK, C.WR, 0xFFB69CFF.toInt(), 0xFFFFD166.toInt(), C.MU)
    private fun toast(s: String) = Toast.makeText(a, s, Toast.LENGTH_LONG).show()
    private fun launchable(pkg: String) = pkg != a.packageName && a.packageManager.getLaunchIntentForPackage(pkg) != null

    fun build(): View {
        val col = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(18), a.dp(26), a.dp(18), a.dp(24))
        }
        col.put(a.tv(a.L("الإحصائيات", "Statistics"), 24f, C.TX, true), 0)
        col.put(a.tv(a.L("وقتك على الهاتف، وحد يومي لكل تطبيق.", "Your phone time, and a daily limit for each app."), 13f, C.MU), 4)
        content = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        col.put(content, 12)
        return ScrollView(a).apply { addView(col) }
    }

    private fun dayStart(back: Int): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.DAY_OF_YEAR, -back)
        return c.timeInMillis
    }

    private fun totals(from: Long, to: Long): Map<String, Long> {
        val m = HashMap<String, Long>()
        val usm = a.getSystemService(UsageStatsManager::class.java)
        usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, from, to)?.forEach {
            val t = it.totalTimeInForeground
            if (t > 0L && t <= day && launchable(it.packageName)) m[it.packageName] = (m[it.packageName] ?: 0L) + t
        }
        return m
    }

    fun refresh() {
        content.removeAllViews()
        if (!a.hasUsageAccess()) {
            val c = a.card()
            c.addView(a.tv(a.L("لعرض إحصائياتك فعّل «الوصول إلى بيانات الاستخدام» للتطبيق. البيانات تبقى على هاتفك.",
                "To see your stats, allow Usage access for the app. The data stays on your phone."), 14f, C.TX).apply { setLineSpacing(0f, 1.2f) })
            c.put(a.btn(a.L("افتح الإعداد", "Open the setting"), true) {
                a.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }, 10)
            content.put(c, 0)
            content.put(limitsCard(), 14)
            return
        }
        content.put(a.tv(a.L("جارٍ التحميل...", "Loading..."), 14f, C.MU), 0)
        Thread {
            val days = (6 downTo 0).map { d -> totals(dayStart(d), dayStart(d) + day) }
            a.runOnUiThread { if (!a.isFinishing) render(days) }
        }.start()
    }

    private fun dayLabel(back: Int): String = when (back) {
        0 -> a.L("اليوم", "Today")
        1 -> a.L("أمس", "Yesterday")
        else -> SimpleDateFormat("EEEE d MMM", Locale(if (Prefs.lang(a) == "en") "en" else "ar")).format(Date(dayStart(back)))
    }

    private fun render(days: List<Map<String, Long>>) {
        cache = days
        content.removeAllViews()
        val s = sel.coerceIn(0, days.size - 1)
        val sums = days.map { it.values.sum() }
        val tMs = sums[s]
        val prev = if (s > 0) sums[s - 1] else 0L

        val c1 = a.card()
        c1.addView(a.tv(dayLabel(6 - s), 13f, C.MU))
        c1.addView(a.tv(a.fmtDur(tMs), 34f, C.TX, true))
        val diff = if (prev > 0L) ((tMs - prev) * 100f / prev).toInt() else 0
        val cmp = when {
            prev == 0L -> a.L("لا بيانات لليوم السابق", "No data for the previous day")
            diff > 0 -> a.L("أكثر من اليوم السابق بـ $diff٪", "$diff% more than the previous day")
            else -> a.L("أقل من اليوم السابق بـ ${-diff}٪", "${-diff}% less than the previous day")
        }
        c1.addView(a.tv(cmp, 13f, if (diff > 0 && prev > 0L) C.WR else C.OK))
        c1.put(a.tv(a.L("متوسط 7 أيام: ", "7-day average: ") + a.fmtDur(sums.sum() / sums.size), 12f, C.MU), 4)
        content.put(c1, 0)

        val fmt = SimpleDateFormat("EEE", Locale(if (Prefs.lang(a) == "en") "en" else "ar"))
        val labels = (6 downTo 0).map { d -> fmt.format(Date(dayStart(d))) }
        val c2 = a.card()
        c2.addView(a.tv(a.L("آخر 7 أيام بالساعات (اضغط على أي يوم)", "Last 7 days in hours (tap a day)"), 14f, C.TX, true))
        c2.addView(BarChartView(a, sums.map { it / 3_600_000f }, labels, s) { i -> sel = i; selApp = -1; render(cache) },
            LinearLayout.LayoutParams(MATCH, a.dp(180)).apply { topMargin = a.dp(10) })
        content.put(c2, 14)

        val all = days[s].entries.sortedByDescending { it.value }
        val top = all.take(if (showAll) 30 else 8)
        val c3 = a.card()
        c3.addView(a.tv(a.L("تطبيقات ", "Apps: ") + dayLabel(6 - s), 14f, C.TX, true))
        if (top.isEmpty()) {
            c3.put(a.tv(a.L("لا توجد بيانات لهذا اليوم.", "No data for this day."), 13f, C.MU), 8)
        } else {
            val pal = palette()
            val shown = top.take(5)
            val rest = (tMs - shown.sumOf { it.value }).coerceAtLeast(0L)
            val vals = shown.map { it.value.toFloat() } + listOf(rest.toFloat())
            val sa = if (selApp in shown.indices) selApp else -1
            val donut = DonutView(
                a, vals, pal, sa,
                if (sa >= 0) a.appLabel(shown[sa].key) else a.L("الكل", "All"),
                if (sa >= 0) a.fmtDur(shown[sa].value) else a.fmtDur(tMs)
            ) { i -> selApp = if (i >= shown.size || i == selApp) -1 else i; render(cache) }
            c3.addView(donut, LinearLayout.LayoutParams(a.dp(190), a.dp(190)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = a.dp(10) })
            val maxMs = top.first().value.coerceAtLeast(1L)
            top.forEachIndexed { i, e ->
                val row = appRow(e.key, e.value, maxMs, pal[minOf(i, pal.size - 1)], i == selApp, i)
                c3.put(row, 0)
            }
            if (all.size > top.size || showAll) c3.put(a.btn(if (showAll) a.L("عرض أقل", "Show less") else a.L("عرض كل التطبيقات", "Show all apps")) {
                showAll = !showAll; render(cache)
            }, 8)
        }
        content.put(c3, 14)
        content.put(limitsCard(), 14)
    }

    private fun appRow(pkg: String, ms: Long, maxMs: Long, color: Int, picked: Boolean, index: Int): View {
        val r = LinearLayout(a).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(a.dp(6), a.dp(8), a.dp(6), a.dp(8))
            if (picked) background = a.rounded(C.BG, 10, color)
        }
        r.addView(ImageView(a).apply { setImageDrawable(a.appIcon(pkg)) }, LinearLayout.LayoutParams(a.dp(34), a.dp(34)))
        val mid = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(10), 0, a.dp(10), 0) }
        mid.addView(a.tv(a.appLabel(pkg), 14f, C.TX))
        val w = maxOf(a.dp(6), (a.dp(150) * ms / maxMs).toInt())
        mid.addView(View(a).apply { background = a.rounded(color, 4) }, LinearLayout.LayoutParams(w, a.dp(6)).apply { topMargin = a.dp(4) })
        r.addView(mid, LinearLayout.LayoutParams(0, WRAP, 1f))
        r.addView(a.tv(a.fmtDur(ms), 13f, C.MU))
        r.addView(a.tv(if (Limits.find(a, pkg) != null) "⏱" else "⏲", 18f, if (Limits.find(a, pkg) != null) C.AC else C.MU).apply {
            setPadding(a.dp(12), a.dp(6), a.dp(4), a.dp(6))
            setOnClickListener { limitDialog(pkg) }
        })
        r.setOnClickListener { selApp = if (selApp == index) -1 else index; render(cache) }
        return r
    }

    private fun limitsCard(): View {
        val c = a.card()
        c.addView(a.tv(a.L("حدود التطبيقات ⏱", "App limits ⏱"), 16f, C.TX, true))
        c.put(a.tv(a.L("حدد وقتًا يوميًا لتطبيق. لو استهلكته يُقفل التطبيق 12 ساعة ثم يُفتح من جديد بنفس الوقت. ولو احتجته في طارئ، افتحه بكلمة مرور الخروج الطارئ.",
            "Give an app a daily time. When it's used up the app locks for 12 hours, then opens again with the same time. In an emergency, open it with your emergency password."),
            12f, C.MU).apply { setLineSpacing(0f, 1.2f) }, 4)
        val ls = Limits.all(a)
        if (ls.isEmpty()) c.put(a.tv(a.L("لا توجد حدود بعد.", "No limits yet."), 13f, C.MU), 10)
        val now = System.currentTimeMillis()
        ls.forEach { l ->
            val st = if (l.blockedUntil > now) a.L("مقفول حتى ", "Locked until ") + a.clock(l.blockedUntil)
                     else a.L("المتبقي ", "Left ") + a.fmtDur(Limits.remainingMs(l)) + a.L(" من ", " of ") + a.fmtDur(l.allowMin * 60_000L)
            val r = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, a.dp(8), 0, a.dp(8)) }
            r.addView(ImageView(a).apply { setImageDrawable(a.appIcon(l.pkg)) }, LinearLayout.LayoutParams(a.dp(30), a.dp(30)))
            val mid = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(10), 0, a.dp(10), 0) }
            mid.addView(a.tv(a.appLabel(l.pkg), 14f, C.TX))
            mid.addView(a.tv(st, 12f, if (l.blockedUntil > now) C.WR else C.MU))
            r.addView(mid, LinearLayout.LayoutParams(0, WRAP, 1f))
            r.setOnClickListener { limitDialog(l.pkg) }
            c.put(r, 6)
        }
        c.put(a.btn(a.L("إضافة حد لتطبيق", "Add an app limit")) { pickApp() }, 10)
        return c
    }

    private fun pickApp() {
        val pm = a.packageManager
        val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != a.packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        a.dlg().setTitle(a.L("اختر تطبيقًا", "Pick an app"))
            .setItems(l.map { it.second }.toTypedArray()) { _, i -> limitDialog(l[i].first) }
            .show()
    }

    private fun limitDialog(pkg: String) {
        val opts = listOf(15, 30, 45, 60, 90, 120, 180)
        val labels = opts.map { a.fmtDur(it * 60_000L) }.toMutableList()
        if (Limits.find(a, pkg) != null) labels.add(a.L("إزالة الحد", "Remove limit"))
        a.dlg().setTitle(a.appLabel(pkg) + ": " + a.L("حد يومي", "daily limit"))
            .setItems(labels.toTypedArray()) { _, i ->
                if (i < opts.size) {
                    Limits.set(a, pkg, opts[i])
                    toast(a.L("تم. لو انتهى الوقت يُقفل التطبيق 12 ساعة.", "Done. When time is up the app locks for 12 hours."))
                } else Limits.remove(a, pkg)
                refresh()
            }
            .show()
    }
}
