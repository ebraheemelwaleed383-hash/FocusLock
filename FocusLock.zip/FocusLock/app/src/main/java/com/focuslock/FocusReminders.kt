package com.focuslock

import android.app.Activity
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

// تذكيرات الجلسة التالية على مهمة. الحالة محفوظة في الإعدادات (ft_rems) فتُستعاد بعد إعادة التشغيل وتحديث التطبيق.
// تذكير واحد لكل مهمة (الجديد يستبدل القديم لنفس المهمة)، وعدة مهام معًا (حتى 20). المنبّه غير دقيق عمدًا
// (setAndAllowWhileIdle) فلا يحتاج صلاحية منبّه دقيق، وقد يتأخر دقائق في وضع توفير الطاقة.
object FocusReminders {
    private const val KEY = "ft_rems"
    private const val CH = "ft_remind"
    private val lock = Any()

    private fun load(c: Context): MutableList<Rem> = RemLogic.parse(Prefs.str(c, KEY, "[]"))
    private fun store(c: Context, l: List<Rem>) = Prefs.putStr(c, KEY, RemLogic.encode(l))

    fun pending(c: Context): List<Rem> = synchronized(lock) { load(c) }

    private fun pi(c: Context, rc: Int, taskId: String): PendingIntent =
        PendingIntent.getBroadcast(
            c, rc, Intent(c, FocusReminderReceiver::class.java).putExtra("ft", taskId),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun setAlarm(c: Context, r: Rem) {
        try {
            c.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pi(c, r.rc, r.taskId))
        } catch (_: Exception) { }
    }

    private fun cancelAlarm(c: Context, r: Rem) {
        try {
            c.getSystemService(AlarmManager::class.java).cancel(pi(c, r.rc, r.taskId))
            c.getSystemService(NotificationManager::class.java).cancel(r.rc)
        } catch (_: Exception) { }
    }

    fun schedule(c: Context, taskId: String, title: String, atMs: Long, mins: Int) {
        if (taskId.isEmpty()) return
        val (rem, dropped) = synchronized(lock) {
            val l = load(c)
            val r = RemLogic.make(l, taskId, title, mins, atMs)
            val d = RemLogic.upsert(l, r)
            store(c, l)
            Pair(r, d)
        }
        dropped.forEach { cancelAlarm(c, it) }
        setAlarm(c, rem)
    }

    // يلغي تذكير مهمة (مثلًا حين تكتمل)
    fun cancel(c: Context, taskId: String) {
        val gone = synchronized(lock) {
            val l = load(c)
            val r = l.firstOrNull { it.taskId == taskId }
            if (r != null) { l.remove(r); store(c, l) }
            r
        } ?: return
        cancelAlarm(c, gone)
    }

    // بعد إعادة التشغيل أو تحديث التطبيق أو فتحه: المنبّهات تُمسح من النظام، فنعيد جدولتها من الحالة المحفوظة.
    // تذكير فات وقته (الهاتف كان مغلقًا) يُسلَّم فورًا بدل أن يضيع. العملية آمنة للتكرار
    fun rescheduleAll(c: Context) {
        val list = pending(c)
        if (list.isEmpty()) return
        val now = System.currentTimeMillis()
        for (r in list) {
            if (r.at <= now) fire(c, r.taskId) else setAlarm(c, r)
        }
    }

    // عند حلول التذكير: نأخذ السجل (فلا يتكرر)، ونتحقق من المهمة، ولا نُظهر إشعارًا لمهمة حُذفت أو اكتملت
    fun fire(c: Context, taskId: String) {
        val rem = synchronized(lock) {
            val l = load(c)
            val r = l.firstOrNull { it.taskId == taskId }
            if (r != null) { l.remove(r); store(c, l) }
            r
        } ?: return
        val t = TaskOps.find(Tasks.load(c), taskId)
        if (t == null || t.d) return
        post(c, rem, t)
    }

    private fun post(c: Context, r: Rem, t: Task) {
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            if (!nm.areNotificationsEnabled()) return
            nm.createNotificationChannel(NotificationChannel(CH, c.L("تذكيرات المهام", "Task reminders"), NotificationManager.IMPORTANCE_HIGH))
            val open = PendingIntent.getActivity(
                c, r.rc, Intent(c, SplashActivity::class.java).putExtra("quick", r.mins).putExtra("ft", t.id)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            nm.notify(
                r.rc,
                Notification.Builder(c, CH).setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle(c.L("جلسة جديدة على: ${t.t}", "Next session on: ${t.t}"))
                    .setContentText(c.L("${r.mins} دقيقة. اضغط لتراجع الإعدادات وتبدأ.", "${r.mins} min. Tap to review and begin."))
                    .setContentIntent(open).setAutoCancel(true).build()
            )
        } catch (_: Exception) { }
    }

    // الإشعارات مغلقة للتطبيق كله أو لقناة التذكيرات
    fun notificationsBlocked(c: Context): Boolean {
        val nm = c.getSystemService(NotificationManager::class.java)
        if (!nm.areNotificationsEnabled()) return true
        val ch = nm.getNotificationChannel(CH)
        return ch != null && ch.importance == NotificationManager.IMPORTANCE_NONE
    }

    // عند اختيار تذكير والإشعارات مغلقة: نشرح بدل أن يضيع التذكير بصمت، ونفتح إعدادات إشعارات التطبيق
    fun warnIfBlocked(a: Activity) {
        try {
            if (!notificationsBlocked(a)) return
            a.dlg().setTitle(a.L("الإشعارات مغلقة", "Notifications are off"))
                .setMessage(a.L("حفظنا التذكير، لكنه لن يظهر لأن إشعارات Vigil مغلقة. فعّلها من الإعدادات ليعمل.", "The reminder is saved, but it won't show because notifications are off for Vigil. Turn them on in Settings."))
                .setPositiveButton(a.L("فتح الإعدادات", "Open settings")) { _, _ ->
                    try {
                        a.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, a.packageName))
                    } catch (_: Exception) { }
                }
                .setNegativeButton(a.L("لاحقًا", "Later"), null)
                .show()
        } catch (_: Exception) { }
    }
}

class FocusReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getStringExtra("ft") ?: return
        try { FocusReminders.fire(c, id) } catch (_: Exception) { }
    }
}
