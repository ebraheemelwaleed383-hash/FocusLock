package com.focuslock

import android.app.Activity
import android.content.ClipData
import android.view.DragEvent
import android.content.res.ColorStateList
import android.graphics.Paint
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

// المهام والملاحظات: تبويبان منفصلان، مع أولويات وترتيب وتحفيز
class TasksNotesPage(private val a: Activity) {
    private var tab = 0
    private var pri = 1
    private var draft = ""
    private lateinit var content: LinearLayout
    private lateinit var scroller: ScrollView

    private fun tint() = ColorStateList.valueOf(C.AC)
    private fun lp1() = LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = a.dp(3); marginEnd = a.dp(3) }

    private fun field(h: String) = EditText(a).apply {
        hint = h
        setTextColor(C.TX); setHintTextColor(C.MU)
        background = a.rounded(C.BG, 12, C.LN)
        setPadding(a.dp(14), a.dp(12), a.dp(14), a.dp(12))
    }

    fun build(): View {
        val col = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(18), a.dp(26), a.dp(18), a.dp(24))
        }
        col.put(a.tv(a.L("مهامي", "My plan"), 24f, C.TX, true), 0)
        content = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val seg = LinearLayout(a)
        col.put(seg, 12)
        build2(seg)
        col.put(content, 12)
        render()
        scroller = ScrollView(a).apply { addView(col) }
        return scroller
    }

    // يعيد رسم زرّي التبديل بين المهام والملاحظات
    private fun build2(seg: LinearLayout) {
        seg.removeAllViews()
        seg.addView(a.btn(a.L("✅ المهام", "✅ Tasks"), tab == 0) { tab = 0; draft = ""; render(); build2(seg) }, lp1())
        seg.addView(a.btn(a.L("📝 الملاحظات", "📝 Notes"), tab == 1) { tab = 1; draft = ""; render(); build2(seg) }, lp1())
    }

    private fun render() {
        content.removeAllViews()
        if (tab == 0) renderTasks() else renderNotes()
    }

    private fun motivation(total: Int, done: Int): String = when {
        total == 0 -> a.L("ابدأ بأهم مهمة النهارده. خطوة صغيرة كفاية.", "Start with today's most important task. One small step is enough.")
        done == total -> a.L("🎉 خلصت كل مهامك! خد استراحة تستحقها.", "🎉 All done! Take the break you earned.")
        done * 2 >= total -> a.L("قربت! كمّل، الباقي أقل من اللي عدّى.", "Almost there! What's left is less than what's behind you.")
        done > 0 -> a.L("بداية ممتازة. مهمة كمان وتاخد زخم.", "Great start. One more task and you'll build momentum.")
        else -> a.L("اختر مهمة واحدة وابدأ بيها دلوقتي.", "Pick one task and start it now.")
    }

    private fun dot(p: Int) = when (p) { 2 -> "🔴"; 1 -> "🟡"; else -> "🟢" }

    private fun renderTasks() {
        val l = Tasks.load(a)
        val total = l.size
        val done = l.count { it.d }

        val hc = a.card()
        hc.addView(a.tv(a.L("تقدمك", "Your progress"), 13f, C.MU))
        hc.put(a.tv(if (total == 0) "—" else "$done / $total", 30f, C.AC, true), 2)
        val bar = BarView(a, C.LN, C.AC).apply { fraction = if (total == 0) 0f else done.toFloat() / total }
        hc.addView(bar, LinearLayout.LayoutParams(MATCH, a.dp(10)).apply { topMargin = a.dp(10) })
        hc.put(a.tv(motivation(total, done), 14f, C.TX), 10)
        content.put(hc, 0)

        val ac = a.card()
        val inp = field(a.L("مهمة جديدة...", "New task...")).apply { setText(draft) }
        ac.addView(inp)
        val pr = LinearLayout(a)
        listOf(2 to a.L("🔴 عالية", "🔴 High"), 1 to a.L("🟡 متوسطة", "🟡 Medium"), 0 to a.L("🟢 عادية", "🟢 Low")).forEach { (v, n) ->
            pr.addView(a.btn(n, pri == v) { draft = inp.text.toString(); pri = v; render() }
                .apply { textSize = 12f; setPadding(a.dp(2), a.dp(10), a.dp(2), a.dp(10)) }, lp1())
        }
        ac.put(pr, 8)
        ac.put(a.btn(a.L("إضافة المهمة", "Add task"), true) {
            val t = inp.text.toString().trim()
            if (t.isNotEmpty()) {
                val list = Tasks.load(a); list.add(Task(t, false, pri)); Tasks.save(a, list)
                draft = ""; Sfx.task(a, Sfx.ADD); render()
            }
        }, 8)
        content.put(ac, 12)

        val manual = Prefs.str(a, "tsort", "pri") == "manual"
        val sr = LinearLayout(a)
        sr.addView(a.btn(a.L("ترتيب بالأهمية", "By priority"), !manual) { Prefs.putStr(a, "tsort", "pri"); render() }
            .apply { textSize = 13f }, lp1())
        sr.addView(a.btn(a.L("ترتيب يدوي", "Manual order"), manual) { Prefs.putStr(a, "tsort", "manual"); render() }
            .apply { textSize = 13f }, lp1())
        content.put(sr, 12)

        if (l.isNotEmpty()) content.put(a.tv(a.L("اضغط مطولًا على ☰ واسحب لإعادة الترتيب.", "Long-press ☰ and drag to reorder."), 12f, C.MU), 4)
        if (l.isEmpty()) content.put(a.tv(a.L("لا توجد مهام بعد. أضف أول مهمة وابدأ بالأهم.", "No tasks yet. Add your first one and start with the most important."), 14f, C.MU), 14)

        val order = if (manual) l.indices.toList() else l.indices.sortedWith(compareBy({ l[it].d }, { -l[it].p }))
        order.forEachIndexed { pos, i ->
            val t = l[i]
            val row = LinearLayout(a).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = a.rounded(C.SF, 12, C.LN)
                setPadding(a.dp(8), a.dp(2), a.dp(2), a.dp(2))
            }
            val handle = a.tv("☰", 18f, C.MU).apply {
                setPadding(a.dp(8), a.dp(10), a.dp(6), a.dp(10))
                setOnLongClickListener { v ->
                    v.startDragAndDrop(ClipData.newPlainText("t", "$pos"), View.DragShadowBuilder(row), pos, 0)
                    true
                }
            }
            row.addView(handle)
            row.setOnDragListener { v, ev ->
                when (ev.action) {
                    DragEvent.ACTION_DRAG_LOCATION -> {
                        val y = v.top - scroller.scrollY + ev.y
                        if (y < a.dp(110)) scroller.scrollBy(0, -28) else if (y > scroller.height - a.dp(110)) scroller.scrollBy(0, 28)
                    }
                    DragEvent.ACTION_DRAG_ENTERED -> v.alpha = 0.55f
                    DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> v.alpha = 1f
                    DragEvent.ACTION_DROP -> {
                        v.alpha = 1f
                        val from = (ev.localState as? Int) ?: -1
                        if (from >= 0 && from != pos) {
                            val ordered = order.map { l[it] }.toMutableList()
                            val moved = ordered.removeAt(from)
                            ordered.add(pos, moved)
                            Tasks.save(a, ordered)
                            Prefs.putStr(a, "tsort", "manual")
                            Sfx.task(a, Sfx.ADD)
                            render()
                        }
                    }
                }
                true
            }
            row.addView(a.tv(dot(t.p), 18f).apply {
                setPadding(a.dp(6), a.dp(10), a.dp(6), a.dp(10))
                setOnClickListener { t.p = (t.p + 1) % 3; Tasks.save(a, l); render() }
            })
            row.addView(CheckBox(a).apply {
                text = t.t
                setTextColor(if (t.d) C.MU else C.TX)
                if (t.d) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                buttonTintList = tint()
                isChecked = t.d
                setOnCheckedChangeListener { _, on ->
                    t.d = on; Tasks.save(a, l)
                    if (on) Sfx.task(a, Sfx.DONE)
                    render()
                }
            }, LinearLayout.LayoutParams(0, WRAP, 1f))
            if (manual) {
                row.addView(a.tv("▲", 15f, if (pos > 0) C.AC else C.LN).apply {
                    setPadding(a.dp(10), a.dp(10), a.dp(10), a.dp(10))
                    setOnClickListener { if (i > 0) { java.util.Collections.swap(l, i, i - 1); Tasks.save(a, l); render() } }
                })
                row.addView(a.tv("▼", 15f, if (pos < l.size - 1) C.AC else C.LN).apply {
                    setPadding(a.dp(10), a.dp(10), a.dp(10), a.dp(10))
                    setOnClickListener { if (i < l.size - 1) { java.util.Collections.swap(l, i, i + 1); Tasks.save(a, l); render() } }
                })
            }
            row.addView(a.tv("✕", 16f, C.MU).apply {
                setPadding(a.dp(12), a.dp(10), a.dp(12), a.dp(10))
                setOnClickListener { Sfx.task(a, Sfx.DEL); l.removeAt(i); Tasks.save(a, l); render() }
            })
            content.put(row, 8)
        }
        if (done > 0) content.put(a.btn(a.L("حذف المكتمل", "Clear completed")) {
            Tasks.save(a, Tasks.load(a).filter { !it.d }); render()
        }, 14)
    }

    private fun renderNotes() {
        val l = Prefs.notes(a)
        val hc = a.card()
        hc.addView(a.tv(a.L("ملاحظاتك", "Your notes"), 13f, C.MU))
        hc.put(a.tv("${l.size}", 30f, C.AC, true), 2)
        hc.put(a.tv(a.L("أفكارك أهم من إنها تضيع. دوّنها وارجع لتركيزك، وتقدر تضيف من شاشة القفل كمان.",
            "Your thoughts matter too much to lose. Note them and get back to focus. You can add notes from the lock screen too."), 14f, C.TX), 8)
        content.put(hc, 0)

        val ac = a.card()
        val inp = field(a.L("اكتب ملاحظة...", "Write a note...")).apply { setText(draft); minLines = 2; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
        ac.addView(inp)
        ac.put(a.btn(a.L("إضافة الملاحظة", "Add note"), true) {
            val t = inp.text.toString().trim()
            if (t.isNotEmpty()) {
                val list = Prefs.notes(a); list.add(0, t); Prefs.setNotes(a, list)
                draft = ""; Sfx.task(a, Sfx.ADD); render()
            }
        }, 8)
        content.put(ac, 12)

        if (l.isEmpty()) content.put(a.tv(a.L("لا توجد ملاحظات بعد.", "No notes yet."), 14f, C.MU), 14)
        val order = l.indices.sortedBy { if (l[it].startsWith("📌 ")) 0 else 1 }
        order.forEach { i ->
            val n = l[i]
            val pinned = n.startsWith("📌 ")
            val row = LinearLayout(a).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = a.rounded(C.SF, 12, if (pinned) C.AC else C.LN)
                setPadding(a.dp(14), a.dp(6), a.dp(2), a.dp(6))
            }
            row.addView(a.tv(n.removePrefix("📌 "), 14f, C.TX).apply { setPadding(0, a.dp(8), 0, a.dp(8)) }, LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(a.tv(if (pinned) "📌" else "📍", 16f, if (pinned) C.AC else C.MU).apply {
                setPadding(a.dp(10), a.dp(10), a.dp(10), a.dp(10))
                setOnClickListener {
                    l[i] = if (pinned) n.removePrefix("📌 ") else "📌 $n"
                    Prefs.setNotes(a, l); render()
                }
            })
            row.addView(a.tv("✕", 16f, C.MU).apply {
                setPadding(a.dp(12), a.dp(10), a.dp(12), a.dp(10))
                setOnClickListener { Sfx.task(a, Sfx.DEL); l.removeAt(i); Prefs.setNotes(a, l); render() }
            })
            content.put(row, 8)
        }
    }
}
