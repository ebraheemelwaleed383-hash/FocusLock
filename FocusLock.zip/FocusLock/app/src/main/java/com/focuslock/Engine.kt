package com.focuslock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings

object Edition {
    val FULL: Boolean get() = BuildConfig.FLAVOR == "full"
}

// محرك الحماية: النسخة الكاملة تستخدم إمكانية الوصول، والخفيفة تستخدم بيانات الاستخدام والعرض فوق التطبيقات
object Engine {
    @Volatile var a11yAlive = false

    fun a11yOn(c: Context): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(c.packageName + "/")
    }
    fun usageOn(c: Context): Boolean = c.hasUsageAccess()
    fun overlayOn(c: Context): Boolean = Settings.canDrawOverlays(c)
    fun pollReady(c: Context): Boolean = usageOn(c) && overlayOn(c)
    fun ready(c: Context): Boolean = (Edition.FULL && a11yOn(c)) || pollReady(c)
    fun extras(c: Context): Boolean = Limits.all(c).isNotEmpty() || Prefs.smart(c)
    fun serviceNeeded(c: Context): Boolean = Prefs.active(c) || (extras(c) && usageOn(c))
    fun canPoll(c: Context): Boolean = usageOn(c) && !(Edition.FULL && a11yAlive)
}

// يعرف التطبيق المفتوح الآن من سجل الأحداث بدون أي صلاحية حساسة
object FgDetector {
    private var fg: String? = null
    private var lastQ = 0L

    fun reset() { fg = null; lastQ = 0L }

    fun current(c: Context): String? {
        try {
            val um = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val from = if (lastQ == 0L) now - 3_600_000L else lastQ - 1000L
            val ev = um.queryEvents(from, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) fg = e.packageName
                else if (e.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND && e.packageName == fg) fg = null
            }
            lastQ = now
        } catch (_: Exception) { }
        return fg
    }
}

// منطق الحجب والحدود والمرشد: يغذّيه محرك إمكانية الوصول أو محرك الاستطلاع حسب النسخة
object Guard {
    private var last = 0L
    private var lastLimit = 0L
    private var fgPkg: String? = null
    private var fgSince = 0L
    private var lastBeatEl = 0L

    // صفحات الإعدادات والمثبّت: ممنوعة أثناء الجلسة لحماية التطبيق من الحذف أو تعطيل الحماية
    private val protectedPkgs = setOf(
        "com.android.settings", "com.google.android.packageinstaller", "com.android.packageinstaller",
        "com.samsung.android.packageinstaller", "com.android.vending", "com.miui.packageinstaller",
        "com.miui.securitycenter", "com.coloros.safecenter", "com.oplus.safecenter", "com.oplus.appdetail"
    )
    private val alwaysOk = setOf("com.google.android.apps.maps", "com.waze")

    private fun ime(c: Context): String? =
        Settings.Secure.getString(c.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)?.substringBefore('/')

    fun commit(c: Context) {
        val p = fgPkg ?: return
        val now = System.currentTimeMillis()
        val d = (now - fgSince).coerceIn(0L, 60_000L)
        fgSince = now
        if (d <= 0L) return
        if (Limits.find(c, p) != null && Limits.addUsage(c, p, d)) showLimit(c, p)
        Smart.onTick(c, p, d)
    }

    fun screenOff(c: Context) {
        commit(c)
        fgPkg = null
        FgDetector.reset()
        Prefs.putLong(c, "scrOffAt", System.currentTimeMillis())
    }

    fun scroll(c: Context, pkg: String) {
        if (fgPkg == null && pkg != c.packageName && pkg != "com.android.systemui" && pkg != "android" && pkg != ime(c)) {
            fgPkg = pkg; fgSince = System.currentTimeMillis()
        }
    }

    fun onForeground(c: Context, pkg: String, cls: String) {
        val now = System.currentTimeMillis()
        if (pkg == c.packageName) { commit(c); fgPkg = null }
        else if (pkg != "com.android.systemui" && pkg != "android" && pkg != ime(c) && pkg != fgPkg) {
            commit(c)
            fgPkg = pkg; fgSince = now
            Smart.onSwitch(c, pkg)
        }
        if (pkg != c.packageName && Limits.blockedNow(c, pkg)) showLimit(c, pkg)
        if (!Prefs.active(c) || pkg == c.packageName) return
        val k = cls.lowercase()
        if (shouldBlock(c, pkg) || k.contains("uninstall") || k.contains("deviceadmin")) showLock(c, pkg)
    }

    private fun shouldBlock(c: Context, pkg: String): Boolean {
        if (pkg in Prefs.essentials(c)) return false
        if (pkg in Prefs.blocked(c) || pkg in protectedPkgs) return true
        if (!Prefs.strict(c)) return false
        val allowed = pkg == "com.android.systemui" || pkg == ime(c) || pkg in alwaysOk ||
            listOf("dialer", "telecom", "incallui", "emergency").any { pkg.contains(it) }
        return !allowed
    }

    fun showLock(c: Context, pkg: String?) {
        val now = SystemClock.elapsedRealtime()
        if (now - last < 800) return
        last = now
        try {
            c.startActivity(
                Intent(c, LockActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra("why", pkg)
            )
        } catch (_: Exception) { }
    }

    private fun showLimit(c: Context, pkg: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastLimit < 1500) return
        lastLimit = now
        try {
            c.startActivity(
                Intent(c, LimitActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra("pkg", pkg)
            )
        } catch (_: Exception) { }
    }

    // نبضة حماية: لو توقفت الحماية والشاشة مضاءة (مثل وضع توفير الطاقة الفائق) نضيف وقت التوقف لنهاية الجلسة
    fun beat(c: Context) {
        val el = SystemClock.elapsedRealtime()
        if (el - lastBeatEl < 9_000L) return
        lastBeatEl = el
        val now = System.currentTimeMillis()
        val prevW = Prefs.longOf(c, "beatW")
        val prevE = Prefs.longOf(c, "beatE")
        Prefs.putLong(c, "beatW", now)
        Prefs.putLong(c, "beatE", el)
        // وضع توفير الطاقة: كل دقيقة فيه تُضاف لمدة الجلسة حتى لا يفيد التحايل به
        if (Prefs.active(c) && Prefs.saverPenalty(c) && prevW != 0L && el >= prevE &&
            c.getSystemService(PowerManager::class.java).isPowerSaveMode) {
            val acc = Prefs.longOf(c, "saverMs") + (now - prevW).coerceIn(0L, 30_000L)
            if (acc >= 60_000L) {
                Prefs.putLong(c, "saverMs", acc % 60_000L)
                if (Prefs.extend(c, (acc / 60_000L).toInt())) { EndAlarm.schedule(c); notifyGap(c, (acc / 60_000L).toInt()) }
            } else Prefs.putLong(c, "saverMs", acc)
        }
        if (!Prefs.active(c) || prevW == 0L || el < prevE) return
        val gap = now - prevW
        if (gap > 90_000L && Prefs.longOf(c, "scrOffAt") < prevW) {
            val extra = ((gap - 10_000L) / 60_000L).toInt() + 1
            if (Prefs.extend(c, extra)) {
                EndAlarm.schedule(c)
                notifyGap(c, extra)
            }
        }
    }

    private fun notifyGap(c: Context, mins: Int) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("gap", c.L("تنبيه الحماية", "Protection alert"), NotificationManager.IMPORTANCE_DEFAULT))
        nm.notify(70, Notification.Builder(c, "gap").setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(c.L("توقفت الحماية لحظات", "Protection was paused for a while"))
            .setContentText(c.L("أضفنا $mins دقيقة للجلسة تعويضًا (هل فعّلت توفير الطاقة؟).", "Added $mins min to your session to compensate (power saver?)."))
            .setAutoCancel(true).build())
    }
}
