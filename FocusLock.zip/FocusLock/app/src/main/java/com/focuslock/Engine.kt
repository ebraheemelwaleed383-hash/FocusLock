package com.focuslock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings

object Edition {
    val FULL: Boolean get() = BuildConfig.FLAVOR == "full"
}

// محرك الحماية: النسخة الكاملة تستخدم إمكانية الوصول، والخفيفة تستخدم بيانات الاستخدام والعرض فوق التطبيقات
object Engine {
    @Volatile var a11yAlive = false
    // أوامر يوفرها محرك إمكانية الوصول (النسخة الكاملة): الرجوع للرئيسية وإطفاء الشاشة
    @Volatile var homeAction: (() -> Unit)? = null
    @Volatile var lockScreenAction: (() -> Unit)? = null

    fun a11yOn(c: Context): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(c.packageName + "/")
    }
    fun usageOn(c: Context): Boolean = c.hasUsageAccess()
    fun overlayOn(c: Context): Boolean = Settings.canDrawOverlays(c)
    fun pollReady(c: Context): Boolean = usageOn(c) && overlayOn(c)
    fun ready(c: Context): Boolean = (Edition.FULL && a11yOn(c)) || pollReady(c)
    fun extras(c: Context): Boolean = Limits.all(c).isNotEmpty() || Prefs.smart(c)
    fun serviceNeeded(c: Context): Boolean = Prefs.active(c) || (extras(c) && usageOn(c))
    fun canPoll(c: Context): Boolean = usageOn(c) && !(Edition.FULL && a11yAlive)
}

// يعرف التطبيق المفتوح الآن من سجل الأحداث بدون أي صلاحية حساسة
object FgDetector {
    private var fg: String? = null
    private var lastQ = 0L

    fun reset() { fg = null; lastQ = 0L }

    // آخر وقت انطفأت فيه الشاشة بين from وto من سجل النظام (0 لو لا يوجد أو غير متاح)
    fun lastScreenOff(c: Context, from: Long, to: Long): Long {
        if (android.os.Build.VERSION.SDK_INT < 28) return 0L
        var last = 0L
        try {
            val um = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val ev = um.queryEvents(from, to)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == 16) last = e.timeStamp // SCREEN_NON_INTERACTIVE
            }
        } catch (_: Exception) { }
        return last
    }

    fun current(c: Context): String? {
        try {
            val um = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val from = if (lastQ == 0L) now - 3_600_000L else lastQ - 1000L
            val ev = um.queryEvents(from, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) fg = e.packageName
                else if (e.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND && e.packageName == fg) fg = null
            }
            lastQ = now
        } catch (_: Exception) { }
        return fg
    }
}

// منطق الحجب والحدود والمرشد: يغذّيه محرك إمكانية الوصول أو محرك الاستطلاع حسب النسخة
object Guard {
    private var last = 0L
    private var lastLimit = 0L
    private var fgPkg: String? = null
    private var fgSince = 0L
    private var lastBeatEl = 0L

    // صفحات الإعدادات والمثبّت: ممنوعة أثناء الجلسة لحماية التطبيق من الحذف أو تعطيل الحماية
    private val protectedPkgs = setOf(
        "com.android.settings", "com.google.android.packageinstaller", "com.android.packageinstaller",
        "com.samsung.android.packageinstaller", "com.android.vending", "com.miui.packageinstaller",
        "com.miui.securitycenter", "com.coloros.safecenter", "com.oplus.safecenter", "com.oplus.appdetail",
        // بدائل الإعدادات وصفحات الطاقة والذاكرة عند الشركات المصنّعة (كانت ثغرة لإيقاف التطبيق)
        "com.android.settings.intelligence", "com.google.android.settings.intelligence",
        "com.samsung.android.lool", "com.samsung.android.sm", "com.samsung.android.sm.devicesecurity",
        "com.miui.powerkeeper", "com.miui.cleanmaster", "com.xiaomi.misettings",
        "com.huawei.systemmanager", "com.hihonor.systemmanager",
        "com.vivo.permissionmanager", "com.iqoo.secure", "com.vivo.abe",
        "com.coloros.phonemanager", "com.oplus.battery", "com.coloros.oppoguardelf", "com.oneplus.security",
        "com.transsion.phonemaster", "com.asus.mobilemanager", "com.lenovo.security", "com.realme.securitycheck"
    )
    // أسماء شاشات خطرة تُحجب حتى لو كانت داخل تطبيق نظام مسموح (إلغاء التثبيت، إيقاف الإجبار، تعطيل الحماية)
    private val badScreens = listOf("forcestop", "installedappdetails", "accessibilitysettings", "managepermissions")
    private val systemish = listOf("com.android.", "com.google.android.", "com.samsung.", "com.miui.", "com.coloros.", "com.oplus.", "com.huawei.", "com.vivo.")
    private val alwaysOk = setOf("com.google.android.apps.maps", "com.waze")

    private fun ime(c: Context): String? =
        Settings.Secure.getString(c.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)?.substringBefore('/')

    fun commit(c: Context) {
        val p = fgPkg ?: return
        val now = System.currentTimeMillis()
        val d = (now - fgSince).coerceIn(0L, 60_000L)
        fgSince = now
        if (d <= 0L) return
        if (Limits.find(c, p) != null && Limits.addUsage(c, p, d)) showLimit(c, p)
        Smart.onTick(c, p, d)
    }

    fun screenOff(c: Context) {
        commit(c)
        fgPkg = null
        FgDetector.reset()
        Prefs.putLong(c, "scrOffAt", System.currentTimeMillis())
    }

    fun scroll(c: Context, pkg: String) {
        if (fgPkg == null && pkg != c.packageName && pkg != "com.android.systemui" && pkg != "android" && pkg != ime(c)) {
            fgPkg = pkg; fgSince = System.currentTimeMillis()
        }
    }

    fun onForeground(c: Context, pkg: String, cls: String) {
        val now = System.currentTimeMillis()
        if (pkg == c.packageName) { commit(c); fgPkg = null }
        else if (pkg != "com.android.systemui" && pkg != "android" && pkg != ime(c) && pkg != fgPkg) {
            commit(c)
            fgPkg = pkg; fgSince = now
            Smart.onSwitch(c, pkg)
        }
        if (pkg != c.packageName && !Protect.isProtected(c, pkg) && !Rewards.passActive(c, pkg) && pkg !in Prefs.essentials(c) && Limits.blockedNow(c, pkg)) showLimit(c, pkg)
        if (!Prefs.active(c) || pkg == c.packageName) return
        val k = cls.lowercase()
        val bad = k.contains("uninstall") || k.contains("deviceadmin") ||
            (systemish.any { pkg.startsWith(it) } && badScreens.any { k.contains(it) })
        if (shouldBlock(c, pkg) || bad) blockHit(c, pkg, explicit(c, pkg) || bad)
    }

    // تفاعل (لمس/تمرير) داخل نافذة تطبيق محظور: يكشف التطبيق المحظور في النصف الآخر من الشاشة المقسومة
    fun onInteract(c: Context, pkg: String) {
        if (!Prefs.active(c) || pkg == c.packageName) return
        if (shouldBlock(c, pkg)) blockHit(c, pkg, explicit(c, pkg))
    }

    // محظور صراحةً (قائمة المستخدم أو صفحات الحماية)، وليس مجرد "غير مسموح" في الوضع الصارم
    private fun explicit(c: Context, pkg: String) = pkg in Prefs.blocked(c) || pkg in protectedPkgs

    private var hitPkg: String? = null
    private var hitAt = 0L
    private var hits = 0
    private var lastHardLock = 0L

    // سلّم التصعيد: قفل عادي، ثم خروج من التقسيم/النوافذ العائمة، ثم إطفاء الشاشة لو أصرّ المستخدم
    private fun blockHit(c: Context, pkg: String, escalate: Boolean) {
        val now = SystemClock.elapsedRealtime()
        hits = if (pkg == hitPkg && now - hitAt < 6_000L) hits + 1 else 1
        hitPkg = pkg; hitAt = now
        if (!escalate || hits < 2) { showLock(c, pkg); return }
        Split.escape(c)
        if (hits >= 4 && now - lastHardLock > 30_000L) {
            val lockIt = Engine.lockScreenAction
            if (lockIt != null) { lastHardLock = now; hits = 0; try { lockIt() } catch (_: Exception) { } }
        }
    }

    private fun shouldBlock(c: Context, pkg: String): Boolean {
        if (pkg in Prefs.essentials(c)) return false
        if (Protect.isProtected(c, pkg)) return false
        if (Rewards.passActive(c, pkg)) return false
        if (pkg in Prefs.blocked(c) || pkg in protectedPkgs) return true
        if (!Prefs.strict(c)) return false
        val allowed = pkg == "com.android.systemui" || pkg == ime(c) || pkg in alwaysOk ||
            listOf("dialer", "telecom", "incallui", "emergency").any { pkg.contains(it) }
        return !allowed
    }

    fun showLock(c: Context, pkg: String?, force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (!force && now - last < 800) return
        last = now
        try {
            c.startActivity(
                Intent(c, LockActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                    .putExtra("why", pkg)
            )
        } catch (_: Exception) { }
    }

    private fun showLimit(c: Context, pkg: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastLimit < 1500) return
        lastLimit = now
        try {
            c.startActivity(
                Intent(c, LimitActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra("pkg", pkg)
            )
        } catch (_: Exception) { }
    }

    // نبضة حماية: لو توقفت الحماية والشاشة مضاءة (مثل وضع توفير الطاقة الفائق) نضيف وقت التوقف لنهاية الجلسة
    fun beat(c: Context) {
        val el = SystemClock.elapsedRealtime()
        if (el - lastBeatEl < 9_000L) return
        lastBeatEl = el
        val now = System.currentTimeMillis()
        val prevW = Prefs.longOf(c, "beatW")
        val prevE = Prefs.longOf(c, "beatE")
        Prefs.putLong(c, "beatW", now)
        Prefs.putLong(c, "beatE", el)
        // وضع توفير الطاقة: كل دقيقة فيه تُضاف لمدة الجلسة حتى لا يفيد التحايل به
        if (Prefs.active(c) && Prefs.saverPenalty(c) && prevW != 0L && el >= prevE &&
            c.getSystemService(PowerManager::class.java).isPowerSaveMode) {
            val acc = Prefs.longOf(c, "saverMs") + (now - prevW).coerceIn(0L, 30_000L)
            if (acc >= 60_000L) {
                Prefs.putLong(c, "saverMs", acc % 60_000L)
                if (Prefs.extend(c, (acc / 60_000L).toInt() * Disc.saverX(c))) { EndAlarm.schedule(c); notifyGap(c, (acc / 60_000L).toInt() * Disc.saverX(c)) }
            } else Prefs.putLong(c, "saverMs", acc)
        }
        if (!Prefs.active(c) || prevW == 0L || el < prevE) return
        val gap = now - prevW
        // لو انطفأت الشاشة أثناء الفجوة (حسب سجل النظام) فالفجوة طبيعية ولا تُحسب توقفًا للحماية
        if (gap > 90_000L && Prefs.longOf(c, "scrOffAt") < prevW && FgDetector.lastScreenOff(c, prevW, now) < prevW) {
            val extra = ((gap - 10_000L) / 60_000L).toInt() + 1
            if (Prefs.extend(c, extra * Disc.saverX(c))) {
                EndAlarm.schedule(c)
                notifyGap(c, extra)
            }
        }
    }

    private fun notifyGap(c: Context, mins: Int) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("gap", c.L("تنبيه الحماية", "Protection alert"), NotificationManager.IMPORTANCE_DEFAULT))
        nm.notify(70, Notification.Builder(c, "gap").setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(c.L("توقفت الحماية لحظات", "Protection was paused for a while"))
            .setContentText(c.L("أضفنا $mins دقيقة للجلسة تعويضًا (هل فعّلت توفير الطاقة؟).", "Added $mins min to your session to compensate (power saver?)."))
            .setAutoCancel(true).build())
    }
}
