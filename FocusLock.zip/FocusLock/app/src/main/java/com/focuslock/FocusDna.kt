package com.focuslock

import org.json.JSONArray
import org.json.JSONObject

// الميزة 02: بصمة التركيز. منطق خالص (بلا أندرويد).
// تعتمد على «ملخصات أسبوعية» تُشتق من سجل الجلسات وتُحفظ (dna_hist) فلا تضيع حين يقتطع السجل (600 جلسة) أقدم جلساته.
// الملف الشخصي يُحسب على نافذة متدحرجة (آخر 3 أسابيع كاملة + الأسبوع الجاري) ويُقارن بالأربعة أسابيع التي قبلها،
// والتسميات تُسند بقواعد ثابتة بعتبات دخول وخروج مختلفة (hysteresis) حتى لا تقفز بسبب جلسة شاذة.

enum class DL {
    MORNING_FOCUS, AFTERNOON_FOCUS, EVENING_FOCUS, NIGHT_FOCUS, VARIED_TIMING,
    SHORT_SESSIONS, LONG_SESSIONS, MIXED_LENGTHS,
    CONSISTENT_HABIT, REGULAR_HABIT, OCCASIONAL_HABIT,
    FINISHES_SESSIONS, ENDS_EARLY, TASK_LINKED,
    IMPROVING_CONSISTENCY
}

enum class CH { CONSIST_UP, CONSIST_DOWN, DURATION_UP, DURATION_DOWN, COMPLETION_UP, COMPLETION_DOWN, RHYTHM_SHIFT }

object DTh {
    const val MIN_ATTEMPTS = 8        // أقل عدد محاولات لتحسب نافذة صالحة للمقارنة
    const val MIN_DONE_LABEL = 6      // أقل عدد جلسات مكتملة لتسمية الإيقاع والطول
    const val MIN_DONE_VARIED = 10
    const val MIN_DAYS = 14           // أقل مدة مغطاة لتسمية الانتظام
    const val MIN_RATE_ATTEMPTS = 10  // أقل محاولات لتسمية السلوك
    const val RECENT_FULL_WEEKS = 3
    const val BASE_WEEKS = 4
    const val CAP_WEEKS = 104         // سنتان من الملخصات الأسبوعية
    const val PEAK_WINDOW_SHARE = 0.40
}

// ملخص أسبوع واحد (الأسبوع يبدأ الاثنين). صغير الحجم عمدًا: بلا نصوص ولا عناوين مهام
class WeekAgg(val ws: Long) {
    var done = 0
    var stop = 0
    var doneMins = 0
    var stopMins = 0
    var activeDays = 0       // أيام فيها جلسة مكتملة
    var firstDay = 0L        // أقدم يوم فيه جلسة (لمعرفة بداية التغطية)
    var linked = 0           // محاولات مرتبطة بمهمة
    val hm = IntArray(24)    // دقائق الإكمال حسب ساعة البداية
    val wd = IntArray(7)     // دقائق الإكمال حسب يوم الأسبوع (0 = الاثنين)
    val ab = IntArray(Ax.BUCKETS)  // الجلسات المكتملة حسب فئة طولها الفعلي
    val pa = IntArray(Ax.BUCKETS)  // المحاولات حسب فئة الطول المخطط
    val pd = IntArray(Ax.BUCKETS)  // المكتملة حسب فئة الطول المخطط

    val attempts: Int get() = done + stop

    fun toJson(): JSONObject {
        val o = JSONObject().put("w", ws).put("d", done).put("s", stop).put("dm", doneMins).put("sm", stopMins)
            .put("ad", activeDays).put("fd", firstDay).put("lk", linked)
        o.put("hm", arr(hm)).put("wd", arr(wd)).put("ab", arr(ab)).put("pa", arr(pa)).put("pd", arr(pd))
        return o
    }

    companion object {
        private fun arr(a: IntArray): JSONArray {
            val j = JSONArray()
            for (x in a) j.put(x)
            return j
        }

        private fun fill(a: IntArray, j: JSONArray?) {
            if (j == null) return
            for (i in a.indices) a[i] = j.optInt(i, 0).coerceAtLeast(0)
        }

        // قراءة متسامحة: null لو لا مفتاح أسبوع صالح
        fun fromJson(o: JSONObject): WeekAgg? {
            if (!o.has("w")) return null
            val w = WeekAgg(o.optLong("w", Long.MIN_VALUE))
            if (w.ws == Long.MIN_VALUE) return null
            w.done = o.optInt("d", 0).coerceAtLeast(0)
            w.stop = o.optInt("s", 0).coerceAtLeast(0)
            w.doneMins = o.optInt("dm", 0).coerceAtLeast(0)
            w.stopMins = o.optInt("sm", 0).coerceAtLeast(0)
            w.activeDays = o.optInt("ad", 0).coerceIn(0, 7)
            w.firstDay = o.optLong("fd", 0L).coerceAtLeast(0L)
            w.linked = o.optInt("lk", 0).coerceAtLeast(0)
            fill(w.hm, o.optJSONArray("hm")); fill(w.wd, o.optJSONArray("wd")); fill(w.ab, o.optJSONArray("ab"))
            fill(w.pa, o.optJSONArray("pa")); fill(w.pd, o.optJSONArray("pd"))
            return w
        }

        // ملخصات أسبوعية من جلسات نظيفة (انظر SessionAnalytics.clean)
        fun fromSessions(ss: List<Sess>): List<WeekAgg> {
            val out = ArrayList<WeekAgg>()
            for ((ws, l) in ss.groupBy { Ax.weekStart(it.day) }) {
                val w = WeekAgg(ws)
                w.firstDay = l.minOf { it.day }
                w.activeDays = l.filter { it.done }.map { it.day }.distinct().size
                for (s in l) {
                    val b = Ax.bucketOf(if (s.planned > 0) s.planned else s.actual)
                    w.pa[b]++
                    if (s.taskId.isNotEmpty()) w.linked++
                    if (s.done) {
                        w.done++
                        w.doneMins += s.actual
                        w.hm[s.hour] += s.actual
                        w.wd[s.dow] += s.actual
                        w.ab[Ax.bucketOf(s.actual)]++
                        w.pd[b]++
                    } else {
                        w.stop++
                        w.stopMins += s.eff
                    }
                }
                out.add(w)
            }
            out.sortBy { it.ws }
            return out
        }
    }
}

object DnaCodec {
    const val VERSION = 1

    class Parsed(val weeks: List<WeekAgg>, val skipped: Int, val broken: Boolean)

    fun encode(weeks: List<WeekAgg>): String {
        val a = JSONArray()
        for (w in weeks) a.put(w.toJson())
        return JSONObject().put("v", VERSION).put("w", a).toString()
    }

    // نص فارغ = لا تاريخ بعد (ليس تالفًا). نص غير مفهوم أو بإصدار غير معروف = broken (لا نكتب فوقه قبل حفظ نسخة منه)
    fun parse(raw: String): Parsed {
        if (raw.isBlank()) return Parsed(emptyList(), 0, false)
        try {
            val o = JSONObject(raw)
            if (o.optInt("v", -1) != VERSION) return Parsed(emptyList(), 0, true)
            val a = o.optJSONArray("w") ?: return Parsed(emptyList(), 0, true)
            val out = ArrayList<WeekAgg>()
            var skipped = 0
            for (i in 0 until a.length()) {
                val w = try { a.optJSONObject(i)?.let { WeekAgg.fromJson(it) } } catch (_: Exception) { null }
                if (w == null) skipped++ else out.add(w)
            }
            return Parsed(merge(out, emptyList()), skipped, false)
        } catch (_: Exception) {
            return Parsed(emptyList(), 0, true)
        }
    }

    // الدمج لا يُنقص المعلومات أبدًا: لكل أسبوع نُبقي النسخة الأكثر محاولات (التعادل لصالح الأحدث)،
    // فلا يضيع أسبوع قديم اقتُطعت جلساته من السجل، ولا تُستبدل نسخة مكتملة بأخرى أنقص
    fun merge(stored: List<WeekAgg>, fresh: List<WeekAgg>, cap: Int = DTh.CAP_WEEKS): List<WeekAgg> {
        val m = HashMap<Long, WeekAgg>()
        for (w in stored) {
            val ex = m[w.ws]
            if (ex == null || w.attempts > ex.attempts) m[w.ws] = w
        }
        for (w in fresh) {
            val ex = m[w.ws]
            if (ex == null || w.attempts >= ex.attempts) m[w.ws] = w
        }
        val out = m.values.sortedBy { it.ws }.toMutableList()
        while (out.size > cap) out.removeAt(0)
        return out
    }

    // للاستعادة من نسخة احتياطية: نص نظيف أو null لو غير صالح (فيُبقى ما عندك). لا يُدمج هنا (الدمج في mergeRaw)
    fun sanitizeForRestore(raw: String): String? {
        val p = parse(raw)
        if (p.broken) return null
        val len = try { JSONObject(raw).optJSONArray("w")?.length() ?: 0 } catch (_: Exception) { 0 }
        if (len > 0 && p.weeks.isEmpty()) return null
        return encode(p.weeks)
    }

    // عند الاستعادة: التاريخ الحالي على الجهاز + تاريخ النسخة الاحتياطية، بالدمج لا بالاستبدال
    fun mergeRaw(current: String?, backup: String): String {
        val cur = if (current == null) emptyList<WeekAgg>() else parse(current).weeks
        return encode(merge(cur, parse(backup).weeks))
    }
}

class Metrics(
    val attempts: Int, val done: Int, val days: Int,
    val shares: DoubleArray?,       // حصة كل فترة يوم من دقائق الإكمال
    val topPeriod: Int,
    val peakStart: Int?,            // بداية أقوى نافذة 3 ساعات
    val peakShare: Double,
    val presence: DoubleArray?,     // نسبة الأسابيع الكاملة التي أُنجز فيها شيء في كل يوم أسبوع
    val meanDone: Double?,
    val shortShare: Double?, val longShare: Double?,
    val bucketRates: List<Double?>, val bucketN: List<Int>,
    val bestBucket: Int?, val bestBucketRate: Double?,
    val perWeek: Double?,           // متوسط الأيام النشطة في الأسبوع
    val weeksWithData: Int, val weeksTotal: Int,
    val completion: Double?, val linkedShare: Double?
) {
    companion object {
        fun empty(): Metrics = Metrics(
            0, 0, 0, null, -1, null, 0.0, null, null, null, null,
            List(Ax.BUCKETS) { null }, List(Ax.BUCKETS) { 0 }, null, null, null, 0, 0, null, null
        )
    }
}

class Change(val code: CH, val from: Double, val to: Double)
class WeekPoint(val ws: Long, val doneMins: Int, val activeDays: Int, val attempts: Int, val completion: Double?)

class DnaProfile(
    val conf: Conf, val analyzed: Int, val periodFrom: Long?, val periodTo: Long, val days: Int,
    val recent: Metrics, val baseline: Metrics?, val evolutionOk: Boolean,
    val labels: List<DL>, val changes: List<Change>, val timeline: List<WeekPoint>, val storedWeeks: Int
)

object FocusDna {

    fun metrics(ws: List<WeekAgg>, days: Int, completeWs: List<Long>): Metrics {
        var done = 0; var stop = 0; var linked = 0; var activeDays = 0; var doneMins = 0
        val hm = IntArray(24)
        val ab = IntArray(Ax.BUCKETS)
        val pa = IntArray(Ax.BUCKETS)
        val pd = IntArray(Ax.BUCKETS)
        var withData = 0
        for (w in ws) {
            done += w.done; stop += w.stop; linked += w.linked; activeDays += w.activeDays; doneMins += w.doneMins
            for (i in 0 until 24) hm[i] += w.hm[i]
            for (i in 0 until Ax.BUCKETS) { ab[i] += w.ab[i]; pa[i] += w.pa[i]; pd[i] += w.pd[i] }
            if (w.attempts > 0) withData++
        }
        val attempts = done + stop
        val hmTotal = hm.sum()
        var shares: DoubleArray? = null
        var top = -1
        var peakStart: Int? = null
        var peakShare = 0.0
        if (hmTotal > 0) {
            val sh = DoubleArray(Ax.PERIODS)
            for (h in 0 until 24) sh[Ax.periodOf(h)] += hm[h].toDouble() / hmTotal
            shares = sh
            top = 0
            for (p in 1 until Ax.PERIODS) if (sh[p] > sh[top]) top = p
            var best = -1
            var bestSum = 0
            for (h in 0 until 24) {
                val s3 = hm[h] + hm[(h + 1) % 24] + hm[(h + 2) % 24]
                if (s3 > bestSum) { bestSum = s3; best = h }
            }
            if (best >= 0 && done >= DTh.MIN_DONE_LABEL) {
                peakShare = bestSum.toDouble() / hmTotal
                if (peakShare >= DTh.PEAK_WINDOW_SHARE) peakStart = best
            }
        }
        var presence: DoubleArray? = null
        if (completeWs.size >= DTh.RECENT_FULL_WEEKS) {
            val pr = DoubleArray(7)
            for (w in ws) if (w.ws in completeWs) for (k in 0 until 7) if (w.wd[k] > 0) pr[k] += 1.0
            for (k in 0 until 7) pr[k] /= completeWs.size
            presence = pr
        }
        val rates = ArrayList<Double?>()
        val ns = ArrayList<Int>()
        for (b in 0 until Ax.BUCKETS) { rates.add(Stats.rate(pd[b], pa[b])); ns.add(pa[b]) }
        var bestB: Int? = null
        var bestR: Double? = null
        var worstR: Double? = null
        var qualified = 0
        for (b in 0 until Ax.BUCKETS) {
            val r = rates[b]
            if (r == null || pa[b] < Th.MIN_BUCKET) continue
            qualified++
            if (bestR == null || r > bestR) { bestR = r; bestB = b }
            if (worstR == null || r < worstR) worstR = r
        }
        if (qualified < 2 || bestR == null || worstR == null || bestR - worstR < 0.10) { bestB = null; bestR = null }
        val doneN = ab.sum()
        return Metrics(
            attempts, done, days, shares, top, peakStart, peakShare, presence,
            if (done > 0) doneMins.toDouble() / done else null,
            if (doneN > 0) (ab[0] + ab[1]).toDouble() / doneN else null,
            if (doneN > 0) (ab[3] + ab[4]).toDouble() / doneN else null,
            rates, ns, bestB, bestR,
            if (days > 0) activeDays / (days / 7.0) else null,
            withData, ws.size,
            Stats.rate(done, attempts),
            Stats.rate(linked, attempts)
        )
    }

    private fun thr(l: DL, enter: Double, exit: Double, prev: Set<DL>?): Double = if (prev != null && l in prev) exit else enter

    private val PERIOD_LABEL = listOf(DL.MORNING_FOCUS, DL.AFTERNOON_FOCUS, DL.EVENING_FOCUS, DL.NIGHT_FOCUS)

    // قواعد التسمية. prev = تسميات النافذة الأقدم: التسمية التي كانت قائمة تبقى حتى لو نزل المؤشر قليلًا تحت عتبة الدخول (عتبة الخروج أوطأ)
    fun labelsFor(m: Metrics, prev: Set<DL>?): List<DL> {
        val out = ArrayList<DL>()
        val sh = m.shares
        if (sh != null && m.done >= DTh.MIN_DONE_LABEL) {
            var best = -1
            for (p in 0 until Ax.PERIODS) {
                if (sh[p] >= thr(PERIOD_LABEL[p], 0.50, 0.45, prev) && (best < 0 || sh[p] > sh[best])) best = p
            }
            if (best >= 0) out.add(PERIOD_LABEL[best])
            else if (m.done >= DTh.MIN_DONE_VARIED) out.add(DL.VARIED_TIMING)
        }
        val ss = m.shortShare
        val ls = m.longShare
        if (ss != null && ls != null && m.done >= DTh.MIN_DONE_LABEL) {
            if (ss >= thr(DL.SHORT_SESSIONS, 0.60, 0.55, prev)) out.add(DL.SHORT_SESSIONS)
            else if (ls >= thr(DL.LONG_SESSIONS, 0.50, 0.45, prev)) out.add(DL.LONG_SESSIONS)
            else out.add(DL.MIXED_LENGTHS)
        }
        val pw = m.perWeek
        if (pw != null && m.days >= DTh.MIN_DAYS) {
            if (pw >= thr(DL.CONSISTENT_HABIT, 4.0, 3.5, prev)) out.add(DL.CONSISTENT_HABIT)
            else if (pw >= thr(DL.REGULAR_HABIT, 2.0, 1.75, prev)) out.add(DL.REGULAR_HABIT)
            else out.add(DL.OCCASIONAL_HABIT)
        }
        val cr = m.completion
        if (cr != null && m.attempts >= DTh.MIN_RATE_ATTEMPTS) {
            if (cr >= thr(DL.FINISHES_SESSIONS, 0.85, 0.80, prev)) out.add(DL.FINISHES_SESSIONS)
            else if (cr < (if (prev != null && DL.ENDS_EARLY in prev) 0.65 else 0.60)) out.add(DL.ENDS_EARLY)
        }
        val lk = m.linkedShare
        if (lk != null && m.attempts >= DTh.MIN_RATE_ATTEMPTS && lk >= thr(DL.TASK_LINKED, 0.40, 0.35, prev)) out.add(DL.TASK_LINKED)
        return out
    }

    fun changes(r: Metrics, b: Metrics): List<Change> {
        val out = ArrayList<Change>()
        val rp = r.perWeek
        val bp = b.perWeek
        if (rp != null && bp != null) {
            if (rp - bp >= 0.75) out.add(Change(CH.CONSIST_UP, bp, rp))
            else if (bp - rp >= 0.75) out.add(Change(CH.CONSIST_DOWN, bp, rp))
        }
        val rm = r.meanDone
        val bm = b.meanDone
        if (rm != null && bm != null && bm > 0.0 && Math.abs(rm - bm) >= 5.0 && Math.abs(rm - bm) / bm >= 0.20) {
            out.add(Change(if (rm > bm) CH.DURATION_UP else CH.DURATION_DOWN, bm, rm))
        }
        val rc = r.completion
        val bc = b.completion
        if (rc != null && bc != null && r.attempts >= DTh.MIN_RATE_ATTEMPTS && b.attempts >= DTh.MIN_RATE_ATTEMPTS) {
            if (rc - bc >= 0.10) out.add(Change(CH.COMPLETION_UP, bc, rc))
            else if (bc - rc >= 0.10) out.add(Change(CH.COMPLETION_DOWN, bc, rc))
        }
        val rs = r.shares
        val bs = b.shares
        if (rs != null && bs != null && r.topPeriod >= 0 && b.topPeriod >= 0 && r.topPeriod != b.topPeriod &&
            rs[r.topPeriod] >= 0.45 && bs[b.topPeriod] >= 0.45
        ) out.add(Change(CH.RHYTHM_SHIFT, b.topPeriod.toDouble(), r.topPeriod.toDouble()))
        return out
    }

    fun build(weeks: List<WeekAgg>, today: Long): DnaProfile {
        val curWs = Ax.weekStart(today)
        var cov: Long? = null
        for (w in weeks) {
            val f = if (w.firstDay > 0L) w.firstDay else w.ws
            if (cov == null || f < cov) cov = f
        }
        val c0: Long = cov ?: return DnaProfile(Conf.NONE, 0, null, today, 0, Metrics.empty(), null, false, emptyList(), emptyList(), emptyList(), 0)
        // النافذة الحديثة: آخر 3 أسابيع كاملة + الأسبوع الجاري (تتحدث مع كل جلسة جديدة)، مقصوصة عند أول بيانات
        val rStart = maxOf(curWs - 7L * DTh.RECENT_FULL_WEEKS, c0)
        val rDays = (today - rStart + 1).toInt()
        val rWeeks = weeks.filter { it.ws >= curWs - 7L * DTh.RECENT_FULL_WEEKS && it.ws <= curWs }
        val rComplete = (1..DTh.RECENT_FULL_WEEKS).map { curWs - 7L * it }.filter { it >= c0 }
        val recent = metrics(rWeeks, rDays, rComplete)

        // النافذة المرجعية: 4 أسابيع كاملة قبل الحديثة
        val bFrom = curWs - 7L * (DTh.RECENT_FULL_WEEKS + DTh.BASE_WEEKS)
        val bEnd = curWs - 7L * DTh.RECENT_FULL_WEEKS - 1
        val bStart = maxOf(bFrom, c0)
        val baseline: Metrics? = if (bEnd >= bStart) {
            val bWeeks = weeks.filter { it.ws >= bFrom && it.ws <= bEnd }
            val bComplete = (0 until DTh.BASE_WEEKS).map { bFrom + 7L * it }.filter { it >= c0 }
            metrics(bWeeks, (bEnd - bStart + 1).toInt(), bComplete)
        } else null
        val evOk = baseline != null && recent.attempts >= DTh.MIN_ATTEMPTS && recent.days >= DTh.MIN_DAYS &&
            baseline.attempts >= DTh.MIN_ATTEMPTS && baseline.days >= DTh.MIN_DAYS

        val prevLabels: Set<DL>? = if (baseline != null && baseline.attempts >= DTh.MIN_ATTEMPTS) labelsFor(baseline, null).toSet() else null
        val labels = ArrayList<DL>(labelsFor(recent, prevLabels))
        val ch = if (evOk && baseline != null) changes(recent, baseline) else emptyList<Change>()
        if (ch.any { it.code == CH.CONSIST_UP }) labels.add(DL.IMPROVING_CONSISTENCY)

        val byWs = HashMap<Long, WeekAgg>()
        for (w in weeks) byWs[w.ws] = w
        val tl = ArrayList<WeekPoint>()
        var ws = maxOf(curWs - 7L * 7, Ax.weekStart(c0))
        while (ws <= curWs) {
            val w = byWs[ws]
            tl.add(WeekPoint(ws, w?.doneMins ?: 0, w?.activeDays ?: 0, w?.attempts ?: 0, if (w == null) null else Stats.rate(w.done, w.attempts)))
            ws += 7L
        }
        val analyzed = recent.attempts
        return DnaProfile(confidenceOf(analyzed, rDays), analyzed, rStart, today, rDays, recent, baseline, evOk, labels, ch, tl, weeks.size)
    }
}
