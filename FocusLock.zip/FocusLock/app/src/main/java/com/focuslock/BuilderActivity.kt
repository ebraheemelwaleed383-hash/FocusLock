package com.focuslock

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray

// منشئ آيفي لي (6 مهام) وتقسيم الوقت: اختيار المهام وترتيبها ثم تشغيلها جولة بعد جولة
class BuilderActivity : Activity() {
    private var mode = "ivy"
    private var cap = 6
    private var focus = 45
    private var brk = 10
    private val chosen = ArrayList<String>()
    private lateinit var listBox: LinearLayout
    private lateinit var poolBox: LinearLayout
    private lateinit var chipsBox: LinearLayout
    private lateinit var countTv: TextView

    private fun key() = "bld_" + mode
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun loadChosen() {
        chosen.clear()
        val a = JSONArray(Prefs.raw(this, key()))
        for (i in 0 until a.length()) chosen.add(a.getString(i))
        while (chosen.size > cap) chosen.removeAt(chosen.size - 1)
    }

    private fun changed() {
        Prefs.putRaw(this, key(), JSONArray(chosen).toString())
        render()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applyTheme()
        mode = intent.getStringExtra("mode") ?: "ivy"
        cap = if (mode == "ivy") 6 else 8
        focus = if (mode == "ivy") 45 else 60
        loadChosen()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
        }
        col.put(tv(L("‹ رجوع", "‹ Back"), 15f, C.AC).apply {
            setPadding(0, dp(6), 0, dp(10)); setOnClickListener { finish() }
        }, 0)
        col.put(tv(
            if (mode == "ivy") L("آيفي لي: مهامك الست", "Ivy Lee: your six tasks")
            else L("تقسيم الوقت: كتل يومك", "Time Blocking: your day's blocks"), 24f, C.TX, true), 4)
        col.put(tv(
            if (mode == "ivy") L("اختر 6 مهام كحد أقصى ورتّبها بالأهمية. نشغّلها واحدة بعد الأخرى، لكل مهمة جلسة تركيز، ولا تنتقل للتالية قبل نهاية الجولة.",
                "Pick up to 6 tasks and rank them by importance. We run them one after another, one focus session per task, and you don't move on before the round ends.")
            else L("حدّد كتل اليوم (حتى 8) ورتّبها. كل كتلة لها مهمة واحدة وتشتغل وراء بعض مع راحة بينها.",
                "Choose today's blocks (up to 8) and order them. Each block has one job and they run back to back with breaks between.")
            , 13f, C.MU), 6)

        val listCard = card()
        countTv = tv("", 15f, C.TX, true)
        listCard.addView(countTv)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listCard.put(listBox, 8)
        col.put(listCard, 14)

        val addCard = card()
        addCard.addView(tv(L("أضف مهمة", "Add a task"), 15f, C.TX, true))
        val inp = EditText(this).apply {
            hint = L("اكتب مهمة جديدة", "Write a new task")
            setTextColor(C.TX); setHintTextColor(C.MU)
            background = rounded(C.BG, 12, C.LN)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        addCard.put(inp, 8)
        addCard.put(btn(L("إضافة", "Add")) {
            val t = inp.text.toString().trim()
            if (t.isNotEmpty()) { newTask(t); inp.text.clear() }
        }, 8)
        addCard.put(tv(L("أو اختر من مهامك:", "Or pick from your tasks:"), 13f, C.MU), 12)
        poolBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        addCard.put(poolBox, 4)
        col.put(addCard, 14)

        val setCard = card()
        setCard.addView(tv(L("مدة الجولة والراحة", "Round length and break"), 15f, C.TX, true))
        chipsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setCard.put(chipsBox, 8)
        col.put(setCard, 14)

        col.put(btn(L("ابدأ التشغيل", "Start"), true) { start() }.apply { textSize = 17f }, 16)

        val sv = ScrollView(this).apply { setBackgroundColor(C.BG); addView(col) }
        sv.applyDir()
        setContentView(sv)
        render()
    }

    private fun act(s: String, f: () -> Unit): TextView = tv(s, 16f, C.MU).apply {
        setPadding(dp(11), dp(8), dp(11), dp(8)); setOnClickListener { f() }
    }

    private fun chipRow(vals: List<Int>, cur: Int, pick: (Int) -> Unit): LinearLayout {
        val r = LinearLayout(this)
        vals.forEach { v ->
            r.addView(tv("$v", 14f, if (v == cur) C.ON else C.TX).apply {
                gravity = Gravity.CENTER
                background = rounded(if (v == cur) C.AC else C.BG, 12, C.LN)
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { pick(v) }
            }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(3); marginEnd = dp(3); topMargin = dp(6) })
        }
        return r
    }

    private fun render() {
        countTv.text = L("قائمتك (${chosen.size}/$cap)", "Your list (${chosen.size}/$cap)")
        listBox.removeAllViews()
        if (chosen.isEmpty()) listBox.addView(tv(L("لم تختر مهامًا بعد.", "No tasks yet."), 13f, C.MU))
        chosen.forEachIndexed { i, t ->
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(C.BG, 12, C.LN)
                setPadding(dp(10), dp(6), dp(4), dp(6))
            }
            row.addView(tv("${i + 1}", 14f, C.ON, true).apply {
                gravity = Gravity.CENTER; background = rounded(C.AC, 14); setPadding(dp(9), dp(3), dp(9), dp(3))
            })
            row.addView(tv(t, 14f, C.TX).apply { setPadding(dp(10), 0, dp(6), 0) }, LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(act("▲") { if (i > 0) { chosen.add(i - 1, chosen.removeAt(i)); changed() } })
            row.addView(act("▼") { if (i < chosen.size - 1) { chosen.add(i + 1, chosen.removeAt(i)); changed() } })
            row.addView(act("✕") { Sfx.task(this, Sfx.DEL); chosen.removeAt(i); changed() })
            listBox.put(row, 6)
        }
        poolBox.removeAllViews()
        val pool = Tasks.load(this).filter { !it.d && it.t !in chosen }
        if (pool.isEmpty()) poolBox.addView(tv(L("لا توجد مهام أخرى.", "No other tasks."), 13f, C.MU))
        pool.forEach { t ->
            poolBox.put(tv("＋  " + t.t, 14f, C.TX).apply {
                background = rounded(C.BG, 12, C.LN)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setOnClickListener { addChosen(t.t) }
            }, 6)
        }
        chipsBox.removeAllViews()
        chipsBox.addView(tv(L("مدة التركيز (دقيقة)", "Focus (min)"), 12f, C.MU))
        chipsBox.addView(chipRow(listOf(25, 45, 60, 90), focus) { focus = it; render() })
        if (chosen.size > 1) {
            chipsBox.put(tv(L("الراحة بين الجولات (دقيقة)", "Break between rounds (min)"), 12f, C.MU), 10)
            chipsBox.addView(chipRow(listOf(5, 10, 15, 20), brk) { brk = it; render() })
        }
    }

    private fun addChosen(t: String) {
        if (chosen.size >= cap) { toast(L("وصلت للحد الأقصى ($cap)", "You reached the limit ($cap)")); return }
        chosen.add(t)
        Sfx.task(this, Sfx.ADD)
        changed()
    }

    private fun newTask(t: String) {
        val l = Tasks.load(this)
        l.add(Task(t, false, 0))
        Tasks.save(this, l)
        addChosen(t)
    }

    private fun start() {
        if (chosen.isEmpty()) { toast(L("اختر مهمة واحدة على الأقل", "Pick at least one task")); return }
        if (!Prefs.hasPassword(this)) { toast(L("اضبط كلمة مرور الخروج الطارئ أولًا من الإعدادات", "Set an emergency password in Settings first")); return }
        if (!Engine.ready(this)) { toast(L("فعّل صلاحيات الحماية أولًا من الإعدادات", "Enable the protection permissions in Settings first")); return }
        if (Prefs.blocked(this).isEmpty() && !Prefs.strict(this)) { toast(L("اختر تطبيقًا واحدًا على الأقل لحظره أولًا", "Pick at least one app to block first")); return }
        val total = chosen.size * focus + (chosen.size - 1) * brk
        dlg().setTitle(L("بدء التشغيل", "Start"))
            .setMessage(L("ستعمل ${chosen.size} جولات (حوالي ${fmtDur(total * 60_000L)}). يبدأ القفل فورًا وتقدر تنهيه بكلمة مرور الطوارئ. جاهز؟",
                "You'll run ${chosen.size} rounds (about ${fmtDur(total * 60_000L)}). The lock starts now and you can end it with your emergency password. Ready?"))
            .setPositiveButton(L("ابدأ", "Start")) { _, _ -> launch() }
            .setNegativeButton(L("إلغاء", "Cancel"), null)
            .show()
    }

    private fun launch() {
        val ph = ArrayList<Pair<Char, Int>>()
        for (i in chosen.indices) {
            ph.add('F' to focus)
            if (i < chosen.size - 1) ph.add('B' to brk)
        }
        Plans.startCustom(this, if (mode == "ivy") "ivy" else "block", ph, ArrayList(chosen))
        finish()
    }
}
