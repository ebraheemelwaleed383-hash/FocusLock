package com.focuslock

import android.content.Context
import android.os.BatteryManager

// وضع توفير البطارية للجلسات: يخفّض وتيرة الفحص والحركة ولا يُبقي الشاشة مضاءة
object Eco {
    private var cachedAt = 0L
    private var cached = false

    fun on(c: Context): Boolean {
        if (Prefs.boolOf(c, "eco", false)) return true
        if (!Prefs.boolOf(c, "ecoAuto", true)) return false
        val now = System.currentTimeMillis()
        if (now - cachedAt < 30_000L) return cached
        cachedAt = now
        cached = try {
            val bm = c.getSystemService(BatteryManager::class.java)
            val lvl = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            lvl in 1..20 && !bm.isCharging
        } catch (e: Exception) { false }
        return cached
    }
}
