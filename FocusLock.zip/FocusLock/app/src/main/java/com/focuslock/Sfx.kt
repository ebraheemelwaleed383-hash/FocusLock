package com.focuslock

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool

object Sfx {
    private var pool: SoundPool? = null
    private val ids = HashMap<Int, Int>()

    private fun get(c: Context): SoundPool {
        pool?.let { return it }
        val p = SoundPool.Builder()
            .setMaxStreams(3)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            ).build()
        listOf(R.raw.sfx_click, R.raw.sfx_add, R.raw.sfx_done, R.raw.sfx_delete)
            .forEach { ids[it] = p.load(c.applicationContext, it, 1) }
        pool = p
        return p
    }

    fun warm(c: Context) { get(c) }

    private fun play(c: Context, res: Int) {
        val p = get(c)
        val id = ids[res] ?: return
        p.play(id, 1f, 1f, 1, 0, 1f)
    }

    fun task(c: Context, res: Int) { if (Prefs.taskSounds(c)) play(c, res) }
    fun click(c: Context) { if (Prefs.clickSounds(c)) play(c, R.raw.sfx_click) }
}
