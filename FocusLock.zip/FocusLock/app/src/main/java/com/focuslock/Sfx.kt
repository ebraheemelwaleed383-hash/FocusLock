package com.focuslock

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool

object Sfx {
    const val CLICK = 0
    const val ADD = 1
    const val DONE = 2
    const val DEL = 3

    private val packs = arrayOf(
        intArrayOf(R.raw.sfx_click, R.raw.sfx_add, R.raw.sfx_done, R.raw.sfx_delete),
        intArrayOf(R.raw.s2_click, R.raw.s2_add, R.raw.s2_done, R.raw.s2_delete),
        intArrayOf(R.raw.s3_click, R.raw.s3_add, R.raw.s3_done, R.raw.s3_delete),
        intArrayOf(R.raw.s4_click, R.raw.s4_add, R.raw.s4_done, R.raw.s4_delete)
    )
    private var pool: SoundPool? = null
    private val ids = HashMap<Int, Int>()

    private fun get(c: Context): SoundPool {
        pool?.let { return it }
        val p = SoundPool.Builder()
            .setMaxStreams(3)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            ).build()
        packs.forEach { pk -> pk.forEach { ids[it] = p.load(c.applicationContext, it, 1) } }
        pool = p
        return p
    }

    fun warm(c: Context) { get(c) }

    fun playKind(c: Context, kind: Int) {
        val p = get(c)
        val id = ids[packs[Prefs.soundPack(c).coerceIn(0, packs.size - 1)][kind]] ?: return
        p.play(id, 1f, 1f, 1, 0, 1f)
    }

    fun task(c: Context, kind: Int) { if (Prefs.taskSounds(c)) playKind(c, kind) }
    fun click(c: Context) { if (Prefs.clickSounds(c)) playKind(c, CLICK) }
}
