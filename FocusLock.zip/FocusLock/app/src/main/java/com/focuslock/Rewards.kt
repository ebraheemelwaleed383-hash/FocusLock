package com.focuslock

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Locale

// حوافز متوازنة: نقاط ورموز تشتري راحة مشروطة، حتى لا يتحول الانضباط إلى إرهاق
object Rewards {
    private val titles = listOf(
        0 to ("مبتدئ" to "Rookie"), 200 to ("منضبط" to "Disciplined"), 600 to ("محارب" to "Warrior"),
        1500 to ("حارس" to "Guardian"), 3000 to ("أسطورة" to "Legend")
    )

    fun points(c: Context): Int = Prefs.intOf(c, "pts", 0)
    fun tokens(c: Context): Int = Prefs.intOf(c, "tok", 0)

    fun levelName(c: Context): String {
        val p = points(c)
        val t = titles.last { p >= it.first }
        return c.L(t.second.first, t.second.second)
    }

    fun add(c: Context, n: Int) {
        if (n <= 0) return
        val before = points(c)
        val after = before + n
        Prefs.putInt(c, "pts", after)
        val gained = after / 500 - before / 500
        if (gained > 0) Prefs.putInt(c, "tok", tokens(c) + gained)
    }

    private fun restDays(c: Context): List<String> = Prefs.str(c, "restDays", "").split(",").filter { it.isNotEmpty() }
    fun restOn(c: Context, day: String): Boolean = day in restDays(c)
    fun restToday(c: Context): Boolean = restOn(c, Prefs.dayKey())

    private fun daysBetween(a: String, b: String): Int {
        val f = SimpleDateFormat("yyyyMMdd", Locale.US)
        return try { ((f.parse(b)!!.time - f.parse(a)!!.time) / 86_400_000L).toInt() } catch (e: Exception) { 99 }
    }

    // يرجع سبب الرفض أو null إذا كانت الإجازة مسموحة
    fun whyNotRest(c: Context): String? {
        if (tokens(c) < 2) return c.L("تحتاج رمزين.", "You need 2 tokens.")
        if (restToday(c)) return c.L("اليوم إجازة بالفعل.", "Today is already a rest day.")
        val last = Prefs.str(c, "restLast", "")
        if (last.isNotEmpty() && daysBetween(last, Prefs.dayKey()) < 3) return c.L("الإجازة مرة كل 3 أيام كحد أقصى.", "A rest day is allowed once every 3 days at most.")
        val target = Disc.focusTarget(c)
        if (target > 0 && Disc.today(c).focus < target * 0.4f) return c.L("أنجز 40% من هدف اليوم أولًا، فالإجازة مكافأة وليست هروبًا.", "Do 40% of today's target first: a rest day is a reward, not an escape.")
        return null
    }

    fun useRest(c: Context) {
        Prefs.putInt(c, "tok", tokens(c) - 2)
        val l = restDays(c).takeLast(13) + Prefs.dayKey()
        Prefs.putStr(c, "restDays", l.joinToString(","))
        Prefs.putStr(c, "restLast", Prefs.dayKey())
    }

    fun payDebt(c: Context): String? {
        if (tokens(c) < 1) return c.L("تحتاج رمزًا واحدًا.", "You need 1 token.")
        if (Disc.debt(c) <= 0) return c.L("لا يوجد دَين تسدده.", "You have no debt to repay.")
        Prefs.putInt(c, "tok", tokens(c) - 1)
        Disc.repay(c, 30)
        return null
    }

    fun freePass(c: Context, pkg: String): String? {
        if (tokens(c) < 1) return c.L("تحتاج رمزًا واحدًا.", "You need 1 token.")
        if (Prefs.active(c)) return c.L("لا تُستخدم الاستراحة أثناء جلسة نشطة.", "A break can't be used during an active session.")
        Prefs.putInt(c, "tok", tokens(c) - 1)
        Prefs.putStr(c, "passPkg", pkg)
        Prefs.putLong(c, "passUntil", System.currentTimeMillis() + 15 * 60_000L)
        return null
    }

    fun passActive(c: Context, pkg: String): Boolean =
        pkg == Prefs.str(c, "passPkg", "") && Prefs.longOf(c, "passUntil") > System.currentTimeMillis()
}
