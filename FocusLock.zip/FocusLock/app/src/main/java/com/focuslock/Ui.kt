package com.focuslock

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.DateFormat
import java.util.Date

object C {
    var BG = 0; var SF = 0; var LN = 0; var TX = 0; var MU = 0
    var AC = 0; var WR = 0; var OK = 0; var ON = 0
    var light = false

    class P(val ar: String, val en: String, val ac: Int, val bg: Int, val sf: Int, val ln: Int)

    val presets = listOf(
        P("المحيط", "Ocean", 0xFF8FB4FF.toInt(), 0xFF0C1019.toInt(), 0xFF151B2A.toInt(), 0xFF232C40.toInt()),
        P("الغابة", "Forest", 0xFF6FE3B0.toInt(), 0xFF0B130F.toInt(), 0xFF141F18.toInt(), 0xFF22332A.toInt()),
        P("الغروب", "Sunset", 0xFFFFA45C.toInt(), 0xFF140E0B.toInt(), 0xFF1F1612.toInt(), 0xFF332620.toInt()),
        P("الوردي", "Rose", 0xFFFF8FB1.toInt(), 0xFF150C11.toInt(), 0xFF21141B.toInt(), 0xFF36222C.toInt()),
        P("البنفسجي", "Violet", 0xFFB69CFF.toInt(), 0xFF100C19.toInt(), 0xFF1A1428.toInt(), 0xFF2B2340.toInt()),
        P("الرمادي", "Mono", 0xFFE9EDF6.toInt(), 0xFF000000.toInt(), 0xFF111111.toInt(), 0xFF262626.toInt()),
        P("الفيروزي", "Teal", 0xFF4DD0E1.toInt(), 0xFF081315.toInt(), 0xFF10201F.toInt(), 0xFF1E3534.toInt()),
        P("الذهبي", "Gold", 0xFFFFD54F.toInt(), 0xFF14110A.toInt(), 0xFF1F1A0F.toInt(), 0xFF332B18.toInt()),
        P("الأحمر", "Crimson", 0xFFFF5C6C.toInt(), 0xFF150A0C.toInt(), 0xFF211214.toInt(), 0xFF361C20.toInt()),
        P("السماوي", "Sky", 0xFF5CC8FF.toInt(), 0xFF08121C.toInt(), 0xFF101D2B.toInt(), 0xFF1C3248.toInt()),
        P("الليموني", "Lime", 0xFFC6FF4D.toInt(), 0xFF0E130A.toInt(), 0xFF182012.toInt(), 0xFF2A3820.toInt()),
        P("العنابي", "Plum", 0xFFE070C0.toInt(), 0xFF14081A.toInt(), 0xFF200F28.toInt(), 0xFF361C44.toInt())
    )

    private fun shade(c: Int, f: Float): Int =
        Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

    private fun lum(c: Int): Double = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255

    fun load(c: Context) {
        val p = presets[Prefs.preset(c).coerceIn(0, presets.size - 1)]
        val custom = Prefs.customAccent(c)
        light = Prefs.light(c)
        if (light) {
            BG = 0xFFF4F6FB.toInt(); SF = 0xFFFFFFFF.toInt(); LN = 0xFFD9DEEA.toInt()
            TX = 0xFF141A28.toInt(); MU = 0xFF5B6478.toInt(); WR = 0xFFD9532C.toInt(); OK = 0xFF1E9E6A.toInt()
            AC = if (custom != 0) custom else shade(p.ac, 0.62f)
        } else {
            BG = p.bg; SF = p.sf; LN = p.ln
            TX = 0xFFE9EDF6.toInt(); MU = 0xFF8B95AD.toInt(); WR = 0xFFFF8A6B.toInt(); OK = 0xFF6FE3B0.toInt()
            AC = if (custom != 0) custom else p.ac
        }
        ON = if (lum(AC) > 0.6) 0xFF0C1019.toInt() else 0xFFFFFFFF.toInt()
    }
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.L(ar: String, en: String): String = if (Prefs.lang(this) == "en") en else ar
fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
fun Context.clock(ms: Long): String = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(ms))

fun Context.dlg(): AlertDialog.Builder = AlertDialog.Builder(
    this,
    if (C.light) android.R.style.Theme_DeviceDefault_Light_Dialog_Alert else android.R.style.Theme_DeviceDefault_Dialog_Alert
)

fun Activity.applyTheme() {
    C.load(this)
    window.statusBarColor = C.BG
    window.navigationBarColor = C.SF
    window.setBackgroundDrawable(ColorDrawable(C.BG))
    val lightBar = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    val f = window.decorView.systemUiVisibility
    window.decorView.systemUiVisibility = if (C.light) f or lightBar else f and lightBar.inv()
}

fun View.applyDir() {
    layoutDirection = if (Prefs.lang(context) == "en") View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
}

fun Context.rounded(color: Int, radius: Int = 14, stroke: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

fun Context.tv(t: String, size: Float = 15f, color: Int = C.TX, bold: Boolean = false): TextView =
    TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

fun Context.btn(t: String, primary: Boolean = false, onClick: () -> Unit): Button {
    val ctx = this
    return Button(this).apply {
        text = t
        setAllCaps(false)
        textSize = 15f
        setTextColor(if (primary) C.ON else C.TX)
        background = rounded(if (primary) C.AC else C.SF, 14, if (primary) 0 else C.LN)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        stateListAnimator = null
        setOnClickListener { Sfx.click(ctx); onClick() }
    }
}

fun Context.card(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = rounded(C.SF, 16, C.LN)
    setPadding(dp(16), dp(14), dp(16), dp(14))
}

fun LinearLayout.put(v: View, top: Int = 12) {
    val px = (top * context.resources.displayMetrics.density).toInt()
    addView(v, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = px })
}

class RingView(c: Context, track: Int = C.LN, arc: Int = C.AC) : View(c) {
    var fraction = 1f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    private val sw = c.dp(9).toFloat()
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = track; strokeWidth = sw; strokeCap = Paint.Cap.ROUND
    }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = arc; strokeWidth = sw; strokeCap = Paint.Cap.ROUND
    }
    override fun onDraw(canvas: Canvas) {
        val r = RectF(sw, sw, width - sw, height - sw)
        canvas.drawArc(r, 0f, 360f, false, trackPaint)
        canvas.drawArc(r, -90f, 360f * fraction, false, arcPaint)
    }
}

class BarView(c: Context, private val track: Int = C.LN, private val fill: Int = C.AC) : View(c) {
    var fraction = 1f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        val h = height.toFloat()
        val r = h / 2
        p.color = track
        canvas.drawRoundRect(0f, 0f, width.toFloat(), h, r, r, p)
        p.color = fill
        canvas.drawRoundRect(0f, 0f, width * fraction, h, r, r, p)
    }
}
