package com.focuslock

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

object C {
    val BG = 0xFF0C1019.toInt()
    val SF = 0xFF151B2A.toInt()
    val LN = 0xFF232C40.toInt()
    val TX = 0xFFE9EDF6.toInt()
    val MU = 0xFF8B95AD.toInt()
    val AC = 0xFF8FB4FF.toInt()
    val WR = 0xFFFF8A6B.toInt()
    val OK = 0xFF6FE3B0.toInt()
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.rounded(color: Int, radius: Int = 14, stroke: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

fun Context.tv(t: String, size: Float = 15f, color: Int = C.TX, bold: Boolean = false): TextView =
    TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

fun Context.btn(t: String, primary: Boolean = false, onClick: () -> Unit): Button =
    Button(this).apply {
        text = t
        setAllCaps(false)
        textSize = 15f
        setTextColor(if (primary) C.BG else C.TX)
        background = rounded(if (primary) C.AC else C.SF, 14, if (primary) 0 else C.LN)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        stateListAnimator = null
        setOnClickListener { onClick() }
    }

fun Context.card(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = rounded(C.SF, 16, C.LN)
    setPadding(dp(16), dp(14), dp(16), dp(14))
}

fun LinearLayout.put(v: View, top: Int = 12) {
    val px = (top * context.resources.displayMetrics.density).toInt()
    addView(v, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = px })
}

class RingView(c: Context) : View(c) {
    var fraction = 1f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    private val sw = c.dp(9).toFloat()
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = C.LN; strokeWidth = sw; strokeCap = Paint.Cap.ROUND
    }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = C.AC; strokeWidth = sw; strokeCap = Paint.Cap.ROUND
    }
    override fun onDraw(canvas: Canvas) {
        val r = RectF(sw, sw, width - sw, height - sw)
        canvas.drawArc(r, 0f, 360f, false, trackPaint)
        canvas.drawArc(r, -90f, 360f * fraction, false, arcPaint)
    }
}
