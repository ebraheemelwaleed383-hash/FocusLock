package com.focuslock

import android.app.Activity

// رسالة «ما الجديد» تظهر مرة واحدة بعد كل تحديث
object WhatsNew {
    private fun version(a: Activity): String =
        try { a.packageManager.getPackageInfo(a.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

    fun notes(a: Activity): String = a.L(
        "• «المراقب»: مستويات صرامة تختارها بنفسك (هادئ، جاد، صارم، حديدي) بعد أن تقرأ ما سيحدث وتوافق.\n" +
        "• خروج طارئ أصعب: انتظار، وجملة التزام، وعدد مرات محدود يوميًا، و«دَين» تسدده بجلسات تركيز.\n" +
        "• حساب مسائي: ماذا أنجزت اليوم؟ مع أهداف يومية وسلسلة أيام.\n" +
        "• وضع توفير الطاقة: مدة توقف الحماية تُضاف إلى جلستك (بمضاعف حسب المستوى).\n" +
        "• جدولة المهام: مساعد يسألك ثم يبني جدولًا أسبوعيًا ويشرح نتائجه ويذكّرك بكل مهمة.\n" +
        "• الأهداف والروتين الثابت.\n" +
        "• المكالمات والبنوك والتطبيقات المالية والطوارئ لا تُحظر أبدًا.\n" +
        "• تنقل جديد أسلس: خمسة أقسام سفلية وتبويبات داخلها.",
        "• The Overseer: strictness levels you choose yourself (Gentle, Serious, Strict, Iron) after reading what will happen and agreeing.\n" +
        "• A tougher emergency exit: a wait, a commitment phrase, limited uses per day, and a \"debt\" repaid with focus sessions.\n" +
        "• An evening check-in: what did you achieve today? With daily targets and a streak.\n" +
        "• Battery saver: time the guard was down is added to your session (with a level multiplier).\n" +
        "• Task scheduling: an assistant asks, then builds a weekly schedule, explains its results and reminds you before each task.\n" +
        "• Goals and a fixed routine.\n" +
        "• Calls, banks, finance apps and emergency are never blocked.\n" +
        "• Smoother navigation: five bottom sections with tabs inside."
    )

    fun check(a: Activity) {
        val cur = version(a)
        val last = Prefs.str(a, "seenVer", "")
        if (cur.isEmpty() || last == cur) return
        Prefs.putStr(a, "seenVer", cur)
        if (!Prefs.onboarded(a) || last.isEmpty()) return
        a.dlg().setTitle(a.L("جديد في $cur", "What's new in $cur")).setMessage(notes(a))
            .setPositiveButton(a.L("حسنًا", "OK"), null).show()
    }
}
