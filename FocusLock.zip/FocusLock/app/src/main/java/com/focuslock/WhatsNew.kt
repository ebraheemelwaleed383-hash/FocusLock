package com.focuslock

import android.app.Activity

// رسالة «ما الجديد» تظهر مرة واحدة بعد كل تحديث
object WhatsNew {
    private fun version(a: Activity): String =
        try { a.packageManager.getPackageInfo(a.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

    fun notes(a: Activity): String = a.L(
        "• الزر ◎ بقى عائم: اسحبه وحطّه في أي مكان، ومكانه يتحفظ.\n" +
        "• خيار جديد في الإعدادات: إبقاء الزر عائمًا فوق كل التطبيقات طوال الوقت.\n" +
        "• إصلاح: نظم الدراسة كانت لا تبدأ.\n" +
        "• إصلاح: تغيير ساعة الهاتف أثناء الجلسة لم يعد ينهيها، والعقوبة الزمنية لا تتأثر بالساعة.\n" +
        "• إصلاح: جلسات النسخة Lite لم تعد تتمدد بالغلط.\n" +
        "• إصلاح انهيارين محتملين، وإغلاق ثغرتين في بدء الجلسة.",
        "• The ◎ button is now floating: drag it anywhere, its place is remembered.\n" +
        "• New setting: keep the button floating over all apps at all times.\n" +
        "• Fixed: study systems never started.\n" +
        "• Fixed: changing the phone clock mid-session no longer ends it, and the password penalty ignores the clock.\n" +
        "• Fixed: Lite sessions no longer stretch by mistake.\n" +
        "• Fixed two possible crashes and closed two loopholes in starting a session."
    )

    fun check(a: Activity) {
        val cur = version(a)
        val last = Prefs.str(a, "seenVer", "")
        if (cur.isEmpty() || last == cur) return
        Prefs.putStr(a, "seenVer", cur)
        if (!Prefs.onboarded(a) || last.isEmpty()) return
        a.dlg().setTitle(a.L("جديد في $cur", "What's new in $cur")).setMessage(notes(a))
            .setPositiveButton(a.L("حسنًا", "OK"), null).show()
    }
}
