package com.focuslock

import android.app.Activity

// رسالة «ما الجديد» تظهر مرة واحدة بعد كل تحديث
object WhatsNew {
    private fun version(a: Activity): String =
        try { a.packageManager.getPackageInfo(a.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

    fun notes(a: Activity): String = a.L(
        "• اسم وهوية جديدان: Vigil.\n" +
        "• وضع التركيز: زر ◎ يحوّل التطبيق إلى صفحة واحدة فيها الأساسيات فقط، وزر ✕ يعيده كاملًا.\n" +
        "• مكافآت: نقاط ورموز تشتري راحة مشروطة (سداد دَين، إجازة بلا عقوبة، استراحة 15 دقيقة).\n" +
        "• جدولة مرنة: اليوم والأسبوع والشهر، مع طاقتك اليومية وتجديد الخطة كل يوم بلا ذنب، وأهداف بعيدة المدى.\n" +
        "• رفع عدة صور دفعة واحدة، وإدارة أيها يظهر.\n" +
        "• وضع توفير البطارية للجلسات.\n" +
        "• حركات أنعم في كل الشاشات.\n" +
        "• إصلاح عرض كل المهام والملاحظات على شاشة القفل.",
        "• A new name and identity: Vigil.\n" +
        "• Focus mode: the ◎ button turns the app into one page with only the essentials, and ✕ brings it all back.\n" +
        "• Rewards: points and tokens that buy conditional rest (debt repayment, a penalty-free day, a 15-minute break).\n" +
        "• Flexible planning: day, week and month views, daily energy, a plan that renews each day without guilt, and long-term goals.\n" +
        "• Upload several images at once and manage which ones appear.\n" +
        "• A battery-saving mode for sessions.\n" +
        "• Smoother animations everywhere.\n" +
        "• Fixed: all tasks and notes now show on the lock screen."
    )

    fun check(a: Activity) {
        val cur = version(a)
        val last = Prefs.str(a, "seenVer", "")
        if (cur.isEmpty() || last == cur) return
        Prefs.putStr(a, "seenVer", cur)
        if (!Prefs.onboarded(a) || last.isEmpty()) return
        a.dlg().setTitle(a.L("جديد في $cur", "What's new in $cur")).setMessage(notes(a))
            .setPositiveButton(a.L("حسنًا", "OK"), null).show()
    }
}
