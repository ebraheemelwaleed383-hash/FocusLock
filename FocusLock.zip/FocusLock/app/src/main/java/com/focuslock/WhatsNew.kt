package com.focuslock

import android.app.Activity

// رسالة «ما الجديد» تظهر مرة واحدة بعد كل تحديث
object WhatsNew {
    private fun version(a: Activity): String =
        try { a.packageManager.getPackageInfo(a.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

    fun notes(a: Activity): String = a.L(
        "• إصلاح كبير: تقسيم الشاشة والنوافذ العائمة لم يعودا يسمحان بتطبيق محظور في النصف الآخر. شاشة القفل تأخذ الشاشة كلها دائمًا.\n" +
        "• لو أصرّ أحد على تطبيق محظور، يرجع بك التطبيق للرئيسية ثم للقفل، وفي النسخة الكاملة تُطفأ الشاشة بعد محاولات متكررة.\n" +
        "• إغلاق ثغرات: صفحات إدارة الطاقة والأمان عند شركات الهواتف (سامسونج وشاومي وأوبو وفيفو وهواوي وغيرها)، وشاشات إيقاف التطبيق وإلغاء التثبيت.\n" +
        "• نوافذ جديدة بالكامل: اختيار التطبيق بأيقونات وبحث، ومنتقي وقت تسحب أرقامه بإصبعك، وقوائم خيارات سفلية ناعمة.\n" +
        "• كل نوافذ التأكيد بقت بزوايا مدورة وألوان الثيم وحركة دخول ناعمة.",
        "• Big fix: split-screen and floating windows can no longer show a blocked app next to the lock screen. The lock always takes the whole screen.\n" +
        "• If someone keeps pushing a blocked app, the app sends you Home and back to the lock, and the Full edition turns the screen off after repeated tries.\n" +
        "• Closed loopholes: phone makers' power and security pages (Samsung, Xiaomi, Oppo, Vivo, Huawei and more), force-stop and uninstall screens.\n" +
        "• Brand-new pickers: app picker with icons and search, a time picker you drag with your finger, and smooth bottom sheets.\n" +
        "• Every confirmation dialog now has rounded corners, theme colors and a soft entrance."
    )

    fun check(a: Activity) {
        val cur = version(a)
        val last = Prefs.str(a, "seenVer", "")
        if (cur.isEmpty() || last == cur) return
        Prefs.putStr(a, "seenVer", cur)
        if (!Prefs.onboarded(a) || last.isEmpty()) return
        a.dlg().setTitle(a.L("جديد في $cur", "What's new in $cur")).setMessage(notes(a))
            .setPositiveButton(a.L("حسنًا", "OK"), null).show()
    }
}
