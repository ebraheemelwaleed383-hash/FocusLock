package com.focuslock

import android.app.Activity

// رسالة «ما الجديد» تظهر مرة واحدة بعد كل تحديث
object WhatsNew {
    private fun version(a: Activity): String =
        try { a.packageManager.getPackageInfo(a.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

    fun notes(a: Activity): String = a.L(
        "• مهام مرتبطة بالجلسة: اختر مهمة (أو أنشئ واحدة) مع مشروع وهدف وقائمة خطوات قبل البدء، وتظهر في شاشة القفل.\n" +
        "• بعد الجلسة تصنّف النتيجة: أنجزت، جزئيًا، أو أكمل لاحقًا، وتحدّث الخطوات وتضيف ملاحظة وتضبط تذكيرًا بجلسة أخرى.\n" +
        "• لا تُعلَّم أي مهمة كاملة تلقائيًا عند انتهاء المؤقت. أنت من يؤكد.\n" +
        "• سجل جلسات داخلي (بياناتك على جهازك فقط) يمهّد لميزات التحليل القادمة.",
        "• Tasks linked to sessions: pick (or create) a task with a project, goal and checklist before you start. They show on the lock screen.\n" +
        "• After a session you classify it: done, partly, or continue later, update steps, add a note and set a reminder for another session.\n" +
        "• No task is ever marked complete automatically when the timer ends. You confirm.\n" +
        "• An on-device session log (your data stays on your phone) prepares the ground for upcoming analytics."
    )

    fun check(a: Activity) {
        val cur = version(a)
        val last = Prefs.str(a, "seenVer", "")
        if (cur.isEmpty() || last == cur) return
        Prefs.putStr(a, "seenVer", cur)
        if (!Prefs.onboarded(a) || last.isEmpty()) return
        a.dlg().setTitle(a.L("جديد في $cur", "What's new in $cur")).setMessage(notes(a))
            .setPositiveButton(a.L("حسنًا", "OK"), null).show()
    }
}
