package com.focuslock

import android.content.Context
import android.os.SystemClock
import java.security.MessageDigest
import java.security.SecureRandom
import kotlin.math.abs

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("fl", Context.MODE_PRIVATE)

    fun blocked(c: Context): Set<String> = sp(c).getStringSet("blocked", emptySet()) ?: emptySet()
    fun setBlocked(c: Context, s: Set<String>) = sp(c).edit().putStringSet("blocked", HashSet(s)).apply()

    fun end(c: Context): Long = sp(c).getLong("end", 0L)
    fun start(c: Context): Long = sp(c).getLong("start", 0L)

    fun begin(c: Context, mins: Int) {
        val now = System.currentTimeMillis()
        sp(c).edit().putLong("end", now + mins * 60_000L).putLong("start", now)
            .putLong("bw", now).putLong("be", SystemClock.elapsedRealtime()).apply()
    }

    fun cancel(c: Context) = sp(c).edit().putLong("end", 0L).apply()

    // حماية من العبث بالساعة: لو تغيّر وقت الهاتف يدويًا أثناء الجلسة يُزاح موعد الانتهاء بنفس الفرق
    fun active(c: Context): Boolean {
        val s = sp(c)
        val end = s.getLong("end", 0L)
        if (end == 0L) return false
        val now = System.currentTimeMillis()
        val el = SystemClock.elapsedRealtime()
        val bw = s.getLong("bw", 0L)
        val be = s.getLong("be", 0L)
        if (bw == 0L || el < be) {
            s.edit().putLong("bw", now).putLong("be", el).apply()
        } else {
            val drift = now - (bw + (el - be))
            if (abs(drift) > 60_000L) {
                s.edit().putLong("end", end + drift).putLong("bw", now).putLong("be", el).apply()
                return end + drift > now
            }
        }
        return end > now
    }

    // تسجيل الجلسة المكتملة في الإحصائيات
    fun settle(c: Context) {
        val s = sp(c)
        val e = s.getLong("end", 0L)
        if (e > 0L && e <= System.currentTimeMillis()) {
            val mins = (e - s.getLong("start", e)) / 60_000L
            s.edit().putInt("done", s.getInt("done", 0) + 1)
                .putLong("mins", s.getLong("mins", 0L) + mins).putLong("end", 0L).apply()
        }
    }
    fun doneCount(c: Context): Int = sp(c).getInt("done", 0)
    fun doneMins(c: Context): Long = sp(c).getLong("mins", 0L)

    fun strict(c: Context): Boolean = sp(c).getBoolean("strict", false)
    fun setStrict(c: Context, b: Boolean) = sp(c).edit().putBoolean("strict", b).apply()

    private fun hash(salt: String, pw: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pw).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun hasPassword(c: Context): Boolean = sp(c).contains("hash")

    fun setPassword(c: Context, pw: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            .joinToString("") { "%02x".format(it) }
        sp(c).edit().putString("salt", salt).putString("hash", hash(salt, pw)).apply()
    }

    fun check(c: Context, pw: String): Boolean {
        val s = sp(c)
        return hash(s.getString("salt", "") ?: "", pw) == s.getString("hash", "")
    }

    // عقوبة زمنية تتضاعف مع كل محاولة خاطئة (30 ثانية، 60، 120 ... حتى ساعة)
    fun lockUntil(c: Context): Long = sp(c).getLong("lockUntil", 0L)

    fun registerFail(c: Context) {
        val n = sp(c).getInt("fails", 0) + 1
        val wait = minOf(30_000L * (1L shl minOf(n - 1, 7)), 3_600_000L)
        sp(c).edit().putInt("fails", n).putLong("lockUntil", System.currentTimeMillis() + wait).apply()
    }

    fun clearFails(c: Context) = sp(c).edit().putInt("fails", 0).putLong("lockUntil", 0L).apply()
}
