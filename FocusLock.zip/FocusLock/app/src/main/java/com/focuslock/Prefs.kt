package com.focuslock

import android.content.Context
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.security.MessageDigest
import java.security.SecureRandom
import kotlin.math.abs

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("fl", Context.MODE_PRIVATE)

    fun blocked(c: Context): Set<String> = sp(c).getStringSet("blocked", emptySet()) ?: emptySet()
    fun setBlocked(c: Context, s: Set<String>) = sp(c).edit().putStringSet("blocked", HashSet(s)).apply()

    fun end(c: Context): Long = sp(c).getLong("end", 0L)
    fun start(c: Context): Long = sp(c).getLong("start", 0L)

    fun begin(c: Context, mins: Int) {
        val now = System.currentTimeMillis()
        val el = SystemClock.elapsedRealtime()
        // نصفّر نبضة الحماية مع بداية كل جلسة، حتى لا يُحسب وقت ما قبل الجلسة كأنه توقف للحماية
        sp(c).edit().putLong("end", now + mins * 60_000L).putLong("start", now)
            .putLong("bw", now).putLong("be", el)
            .putLong("beatW", now).putLong("beatE", el).putLong("saverMs", 0L).apply()
        try { SessionLog.onBegin(c, mins) } catch (_: Exception) { }
        Sfx.event(c, Sfx.START)
        FocusWidget.refresh(c)
    }

    fun cancel(c: Context) {
        try { SessionLog.onCancelled(c) } catch (_: Exception) { }
        sp(c).edit().putLong("end", 0L).apply()
        FocusWidget.refresh(c)
    }

    // حماية من العبث بالساعة: لو تغيّر وقت الهاتف يدويًا أثناء الجلسة يُزاح موعد الانتهاء بنفس الفرق
    fun active(c: Context): Boolean {
        val s = sp(c)
        val end = s.getLong("end", 0L)
        if (end == 0L) return false
        val now = System.currentTimeMillis()
        val el = SystemClock.elapsedRealtime()
        val bw = s.getLong("bw", 0L)
        val be = s.getLong("be", 0L)
        if (bw == 0L || el < be) {
            s.edit().putLong("bw", now).putLong("be", el).apply()
        } else {
            val drift = now - (bw + (el - be))
            if (abs(drift) > 60_000L) {
                s.edit().putLong("end", end + drift).putLong("bw", now).putLong("be", el).apply()
                return end + drift > now
            }
        }
        return end > now
    }

    // تسجيل الجلسة المكتملة في الإحصائيات
    fun settle(c: Context): Boolean {
        // active() يطبّق حماية الساعة أولًا: لو غُيّرت الساعة للأمام لا تُعتبر الجلسة منتهية
        if (active(c)) return false
        val s = sp(c)
        val e = s.getLong("end", 0L)
        if (e > 0L && e <= System.currentTimeMillis()) {
            val mins = (e - s.getLong("start", e)) / 60_000L
            s.edit().putInt("done", s.getInt("done", 0) + 1)
                .putLong("mins", s.getLong("mins", 0L) + mins).putLong("end", 0L).apply()
            addDay(c, "fm", mins)
            try { SessionLog.onSettled(c, s.getLong("start", e), e) } catch (_: Exception) { }
            Disc.repay(c, mins.toInt())
            Rewards.add(c, minOf(mins.toInt(), 120))
            Planner.onSessionDone(c, mins.toInt())
            Sfx.event(c, Sfx.END)
            FocusWidget.refresh(c)
            return true
        }
        return false
    }
    fun doneCount(c: Context): Int = sp(c).getInt("done", 0)
    fun doneMins(c: Context): Long = sp(c).getLong("mins", 0L)

    fun strict(c: Context): Boolean = sp(c).getBoolean("strict", false)
    fun setStrict(c: Context, b: Boolean) = sp(c).edit().putBoolean("strict", b).apply()

    private fun hash(salt: String, pw: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pw).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun hasPassword(c: Context): Boolean = sp(c).contains("hash")

    fun setPassword(c: Context, pw: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            .joinToString("") { "%02x".format(it) }
        sp(c).edit().putString("salt", salt).putString("hash", hash(salt, pw)).apply()
    }

    fun check(c: Context, pw: String): Boolean {
        val s = sp(c)
        return hash(s.getString("salt", "") ?: "", pw) == s.getString("hash", "")
    }

    // عقوبة زمنية تتضاعف مع كل محاولة خاطئة (30 ثانية، 60، 120 ... حتى ساعة)
    // العقوبة تُقاس بساعة النظام الداخلية (elapsedRealtime) فلا تفيد معها إزاحة ساعة الهاتف
    fun lockUntil(c: Context): Long {
        val s = sp(c)
        val untilEl = s.getLong("lockEl", 0L)
        val setEl = s.getLong("lockSetEl", 0L)
        val nowEl = SystemClock.elapsedRealtime()
        if (untilEl > 0L && setEl > 0L && setEl <= nowEl) {
            return if (untilEl > nowEl) System.currentTimeMillis() + (untilEl - nowEl) else 0L
        }
        return s.getLong("lockUntil", 0L)
    }

    fun registerFail(c: Context) {
        val n = sp(c).getInt("fails", 0) + 1
        val wait = minOf(30_000L * (1L shl minOf(n - 1, 7)), 3_600_000L)
        val nowEl = SystemClock.elapsedRealtime()
        sp(c).edit().putInt("fails", n).putLong("lockUntil", System.currentTimeMillis() + wait)
            .putLong("lockEl", nowEl + wait).putLong("lockSetEl", nowEl).apply()
    }

    fun clearFails(c: Context) = sp(c).edit().putInt("fails", 0).putLong("lockUntil", 0L)
        .putLong("lockEl", 0L).putLong("lockSetEl", 0L).apply()

    // ---- المظهر واللغة ----
    fun lang(c: Context): String = sp(c).getString("lang", "ar") ?: "ar"
    fun setLang(c: Context, v: String) = sp(c).edit().putString("lang", v).apply()
    fun light(c: Context): Boolean = sp(c).getBoolean("light", false)
    fun setLight(c: Context, b: Boolean) = sp(c).edit().putBoolean("light", b).apply()
    fun preset(c: Context): Int = sp(c).getInt("preset", 0)
    fun setPreset(c: Context, i: Int) = sp(c).edit().putInt("preset", i).apply()
    fun customAccent(c: Context): Int = sp(c).getInt("accent", 0)
    fun setCustomAccent(c: Context, v: Int) = sp(c).edit().putInt("accent", v).apply()
    fun counter(c: Context): String = sp(c).getString("counter", "ring") ?: "ring"
    fun setCounter(c: Context, v: String) = sp(c).edit().putString("counter", v).apply()
    fun bg(c: Context): String = sp(c).getString("bg", "none") ?: "none"
    fun setBg(c: Context, v: String) = sp(c).edit().putString("bg", v).apply()
    fun onlyMine(c: Context): Boolean = sp(c).getBoolean("onlymine", false)
    fun setOnlyMine(c: Context, b: Boolean) = sp(c).edit().putBoolean("onlymine", b).apply()
    fun lastMins(c: Context): Int = sp(c).getInt("lm", 25)
    fun setLastMins(c: Context, m: Int) = sp(c).edit().putInt("lm", m).apply()

    fun raw(c: Context, k: String): String = sp(c).getString(k, "[]") ?: "[]"
    fun putRaw(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
    private fun list(c: Context, k: String): MutableList<String> {
        val a = JSONArray(raw(c, k))
        return MutableList(a.length()) { a.getString(it) }
    }
    private fun putList(c: Context, k: String, l: List<String>) = putRaw(c, k, JSONArray(l).toString())
    fun myQuotes(c: Context): MutableList<String> = list(c, "myq")
    fun setMyQuotes(c: Context, l: List<String>) = putList(c, "myq", l)
    fun customBgs(c: Context): MutableList<String> = list(c, "cbgs")
    fun setCustomBgs(c: Context, l: List<String>) = putList(c, "cbgs", l)

    // ---- المرشد والأصوات والتحديث ----
    fun onboarded(c: Context): Boolean = sp(c).getBoolean("onb", false)
    fun setOnboarded(c: Context, b: Boolean) = sp(c).edit().putBoolean("onb", b).apply()
    fun taskSounds(c: Context): Boolean = sp(c).getBoolean("snd_t", true)
    fun setTaskSounds(c: Context, b: Boolean) = sp(c).edit().putBoolean("snd_t", b).apply()
    fun clickSounds(c: Context): Boolean = sp(c).getBoolean("snd_c", false)
    fun setClickSounds(c: Context, b: Boolean) = sp(c).edit().putBoolean("snd_c", b).apply()
    fun autoUpdate(c: Context): Boolean = sp(c).getBoolean("autoupd", true)
    fun setAutoUpdate(c: Context, b: Boolean) = sp(c).edit().putBoolean("autoupd", b).apply()
    fun lastCheck(c: Context): Long = sp(c).getLong("lastchk", 0L)
    fun setLastCheck(c: Context, t: Long) = sp(c).edit().putLong("lastchk", t).apply()

    // زيادة الوقت فقط، بحد أقصى 12 ساعة من بداية الجلسة
    fun extend(c: Context, mins: Int): Boolean {
        val s = sp(c)
        val end = s.getLong("end", 0L)
        val cap = s.getLong("start", end) + 12 * 3_600_000L
        val ne = minOf(end + mins * 60_000L, cap)
        if (ne <= end) return false
        s.edit().putLong("end", ne).apply()
        return true
    }

    // ---- الإصدار 1.4 ----
    fun soundPack(c: Context): Int = sp(c).getInt("spack", 0)
    fun setSoundPack(c: Context, i: Int) = sp(c).edit().putInt("spack", i).apply()
    fun bgDim(c: Context): Int = sp(c).getInt("bgdim", 60)
    fun setBgDim(c: Context, v: Int) = sp(c).edit().putInt("bgdim", v).apply()
    fun bgOpacity(c: Context): Int = sp(c).getInt("bgop", 100)
    fun setBgOpacity(c: Context, v: Int) = sp(c).edit().putInt("bgop", v).apply()
    fun reduceMotion(c: Context): Boolean = sp(c).getBoolean("calm", false)
    fun setReduceMotion(c: Context, b: Boolean) = sp(c).edit().putBoolean("calm", b).apply()
    fun quoteLang(c: Context): String = sp(c).getString("qlang", "both") ?: "both"
    fun setQuoteLang(c: Context, v: String) = sp(c).edit().putString("qlang", v).apply()
    fun hint(c: Context): String = sp(c).getString("hint", "") ?: ""
    fun setHint(c: Context, v: String) = sp(c).edit().putString("hint", v).apply()
    fun notes(c: Context): MutableList<String> = list(c, "notes")
    fun setNotes(c: Context, l: List<String>) = putList(c, "notes", l.take(300))
    fun notifiedTag(c: Context): String = sp(c).getString("ntag", "") ?: ""
    fun setNotifiedTag(c: Context, v: String) = sp(c).edit().putString("ntag", v).apply()

    // ---- 1.8: مؤقتات التطبيقات، المرشد الذكي، نظم الدراسة ----
    // كل مفاتيح الإجماليات اليومية لبادئة معيّنة (مثل fm_yyyyMMdd). قراءة فقط، تستخدمها الميزة 01 لتمديد السلاسل الزمنية قبل وجود سجل الجلسات
    fun dayTotals(c: Context, k: String): Map<String, Long> {
        val out = HashMap<String, Long>()
        for (e in sp(c).all.entries) {
            val v = e.value
            if (e.key.startsWith(k + "_") && v is Long) out[e.key] = v
        }
        return out
    }
    fun str(c: Context, k: String, d: String): String = sp(c).getString(k, d) ?: d
    fun putStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
    fun longOf(c: Context, k: String): Long = sp(c).getLong(k, 0L)
    fun putLong(c: Context, k: String, v: Long) = sp(c).edit().putLong(k, v).apply()
    fun essentials(c: Context): MutableList<String> = list(c, "ess")
    fun setEssentials(c: Context, l: List<String>) = putList(c, "ess", l)
    fun smart(c: Context): Boolean = sp(c).getBoolean("smart", false)
    fun setSmart(c: Context, b: Boolean) = sp(c).edit().putBoolean("smart", b).apply()
    fun smartFactor(c: Context): Float = sp(c).getFloat("sfac", 1f)
    fun setSmartFactor(c: Context, v: Float) = sp(c).edit().putFloat("sfac", v).apply()
    fun avgSession(c: Context, pkg: String): Float = sp(c).getFloat("avg_" + pkg, 0f)
    fun setAvgSession(c: Context, pkg: String, v: Float) = sp(c).edit().putFloat("avg_" + pkg, v).apply()
    fun resetSmart(c: Context) {
        val e = sp(c).edit()
        sp(c).all.keys.filter { it.startsWith("avg_") }.forEach { e.remove(it) }
        e.putFloat("sfac", 1f).apply()
    }
    fun resetLearning(c: Context) {
        val e = sp(c).edit()
        sp(c).all.keys.filter { it.startsWith("avg_") }.forEach { e.remove(it) }
        e.putFloat("sfac", 1f).apply()
    }

    // ---- 1.9 ----
    fun blockNotifs(c: Context): Boolean = sp(c).getBoolean("blknotif", false)
    fun setBlockNotifs(c: Context, b: Boolean) = sp(c).edit().putBoolean("blknotif", b).apply()
    fun sndStart(c: Context): Boolean = sp(c).getBoolean("snd_start", true)
    fun setSndStart(c: Context, b: Boolean) = sp(c).edit().putBoolean("snd_start", b).apply()
    fun sndEnd(c: Context): Boolean = sp(c).getBoolean("snd_end", true)
    fun setSndEnd(c: Context, b: Boolean) = sp(c).edit().putBoolean("snd_end", b).apply()
    fun sndQuote(c: Context): Boolean = sp(c).getBoolean("snd_quote", true)
    fun setSndQuote(c: Context, b: Boolean) = sp(c).edit().putBoolean("snd_quote", b).apply()
    fun planAuto(c: Context): Boolean = sp(c).getBoolean("planauto", true)
    fun setPlanAuto(c: Context, b: Boolean) = sp(c).edit().putBoolean("planauto", b).apply()
    fun saverPenalty(c: Context): Boolean = sp(c).getBoolean("saverpen", true)
    fun setSaverPenalty(c: Context, b: Boolean) = sp(c).edit().putBoolean("saverpen", b).apply()
    fun autoNext(c: Context): Boolean = sp(c).getBoolean("autonext", true)
    fun setAutoNext(c: Context, b: Boolean) = sp(c).edit().putBoolean("autonext", b).apply()

    // ---- مساعدات عامة (2.0) ----
    fun intOf(c: Context, k: String, d: Int = 0): Int = sp(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun boolOf(c: Context, k: String, d: Boolean = false): Boolean = sp(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun dayKey(ms: Long = System.currentTimeMillis()): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ms))
    fun dayVal(c: Context, k: String, day: String): Long = sp(c).getLong(k + "_" + day, 0L)
    fun todayOf(c: Context, k: String): Long = dayVal(c, k, dayKey())
    fun addDay(c: Context, k: String, amount: Long) {
        val key = k + "_" + dayKey()
        sp(c).edit().putLong(key, sp(c).getLong(key, 0L) + amount).apply()
    }
    fun floatOf(c: Context, k: String, d: Float): Float = sp(c).getFloat(k, d)
    fun putFloat(c: Context, k: String, v: Float) = sp(c).edit().putFloat(k, v).apply()
    // ---- نسخ احتياطي: تصدير واستيراد التقدم والإعدادات (بدون حالة الحماية والجلسة الجارية وكلمة المرور) ----
    private val NO_BACKUP = setOf(
        "end", "start", "bw", "be", "beatW", "beatE", "saverMs", "hash", "salt", "fails", "lockUntil", "lockEl",
        "lockSetEl", "scrOffAt", "flowStart", "breakEnd", "plan", "planPh", "planPaused", "planFEnd", "dlId",
        "sl_open", "ft_arm", "ft_review", "ft_sel", "ft_goal",
        // 2.7 (تقوية): حالة خاصة بالجهاز (طابور المراجعة، التأجيل، التذكيرات المجدولة) ونسخ الاحتفاظ بالبيانات التالفة/السابقة
        "ft_revq", "ft_rv_snooze", "ft_rems", "tasks_corrupt", "sl_log_corrupt", "rb_tasks", "rb_sl_log",
        // 3.0-dev: بصمة التركيز. dna_hist داخل النسخة الاحتياطية (يُدمج عند الاستعادة)، أما نسخ الاحتفاظ فخاصة بالجهاز
        "rb_dna_hist", "dna_hist_bad"
    )

    private fun encValue(v: Any?): JSONObject? {
        val o = JSONObject()
        when (v) {
            is String -> o.put("t", "s").put("v", v)
            is Int -> o.put("t", "i").put("v", v)
            is Long -> o.put("t", "l").put("v", v)
            is Boolean -> o.put("t", "b").put("v", v)
            is Float -> o.put("t", "f").put("v", v.toDouble())
            is Set<*> -> {
                val a = JSONArray()
                for (x in v) a.put(x.toString())
                o.put("t", "set").put("v", a)
            }
            else -> return null
        }
        return o
    }

    fun exportAll(c: Context): String {
        val data = JSONObject()
        for (e in sp(c).all.entries) {
            if (e.key in NO_BACKUP) continue
            val o = encValue(e.value) ?: continue
            data.put(e.key, o)
        }
        return JSONObject().put("app", "vigil").put("v", 1).put("data", data).toString()
    }

    // يرجع عدد القيم المستوردة، أو -1 لو الملف ليس نسخة Vigil
    fun importAll(c: Context, json: String): Int {
        val root = JSONObject(json)
        if (root.optString("app") != "vigil") return -1
        val data = root.getJSONObject("data")
        val ed = sp(c).edit()
        var n = 0
        val keys = data.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (k in NO_BACKUP) continue
            val o = data.getJSONObject(k)
            // المهام وسجل الجلسات نتحقق منهما قبل أن يستبدلا البيانات الحالية: نوع خاطئ أو محتوى غير صالح => نتجاوز المفتاح ونُبقي ما عندك
            if (k in BackupGuard.GUARDED && o.optString("t") != "s") continue
            var ok = true
            when (o.getString("t")) {
                "s" -> {
                    val raw = o.getString("v")
                    val clean = if (k in BackupGuard.GUARDED) BackupGuard.sanitize(k, raw) else raw
                    if (clean == null) ok = false
                    else {
                        if (k in BackupGuard.GUARDED) {
                            // نسخة احتياطية من القيمة الحالية قبل استبدالها، لو احتاج المستخدم الرجوع
                            val cur = sp(c).getString(k, null)
                            if (cur != null && cur.length > 2) ed.putString("rb_$k", cur)
                        }
                        // بصمة التركيز: تاريخ أسبوعي مشتق، يُدمج مع الموجود على الجهاز ولا يستبدله (لا نخسر أسابيع أحدث من النسخة الاحتياطية)
                        ed.putString(k, if (k == "dna_hist") DnaCodec.mergeRaw(sp(c).getString(k, null), clean) else clean)
                    }
                }
                "i" -> ed.putInt(k, o.getInt("v"))
                "l" -> ed.putLong(k, o.getLong("v"))
                "b" -> ed.putBoolean(k, o.getBoolean("v"))
                "f" -> ed.putFloat(k, o.getDouble("v").toFloat())
                "set" -> {
                    val a = o.getJSONArray("v")
                    val st = HashSet<String>()
                    for (j in 0 until a.length()) st.add(a.getString(j))
                    ed.putStringSet(k, st)
                }
                else -> ok = false
            }
            if (ok) n++
        }
        ed.apply()
        return n
    }

    fun hiddenBgs(c: Context): MutableList<String> = list(c, "hbgs")
    fun setHiddenBgs(c: Context, l: List<String>) = putList(c, "hbgs", l)
}
