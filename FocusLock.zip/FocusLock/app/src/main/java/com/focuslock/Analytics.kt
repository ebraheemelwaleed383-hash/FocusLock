package com.focuslock

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

// الأساس التحليلي المشترك بين «تحليل التركيز» (الميزة 01) و«بصمة التركيز» (الميزة 02).
// منطق خالص بلا اعتماد على أندرويد (قابل للاختبار على JVM). لا يكتب أي بيانات ولا يغيّر السجل الأصلي.

object Ax {
    const val DAY_MS = 86_400_000L
    const val MAX_MIN = 720          // أطول جلسة ممكنة: سقف التمديد 12 ساعة (Prefs.extend)
    const val PERIODS = 4
    const val BUCKETS = 5
    val BUCKET_MAX = intArrayOf(15, 25, 40, 60, 120) // الحد الأعلى لكل فئة طول (الأخيرة تعني أكثر من 60)

    // فترات اليوم حسب ساعة البداية المحلية: 0 صباح (5-11)، 1 بعد الظهر (12-16)، 2 مساء (17-21)، 3 ليل (22-4)
    fun periodOf(hour: Int): Int = when {
        hour in 5..11 -> 0
        hour in 12..16 -> 1
        hour in 17..21 -> 2
        else -> 3
    }

    // فئات طول الجلسة بالدقائق: 0 حتى 15، 1 حتى 25، 2 حتى 40، 3 حتى 60، 4 أكثر
    fun bucketOf(mins: Int): Int = when {
        mins <= 15 -> 0
        mins <= 25 -> 1
        mins <= 40 -> 2
        mins <= 60 -> 3
        else -> 4
    }

    // الأسبوع يبدأ الاثنين. اليوم 4 من حقبة 1970 هو أول اثنين
    fun weekStart(day: Long): Long = day - Math.floorMod(day - 4L, 7L)
    fun dowOf(day: Long): Int = Math.floorMod(day - 4L, 7L).toInt() // 0 = الاثنين ... 6 = الأحد
}

enum class Conf { NONE, LOW, MEDIUM, HIGH }

// ثقة وصفية تعتمد على عدد المحاولات والمدة المغطاة فقط (ليست ثقة إحصائية رسمية)
fun confidenceOf(attempted: Int, spanDays: Int): Conf = when {
    attempted < 3 -> Conf.NONE
    attempted < 10 || spanDays < 7 -> Conf.LOW
    attempted < 30 || spanDays < 21 -> Conf.MEDIUM
    else -> Conf.HIGH
}

// جلسة نظيفة وجاهزة للتحليل
class Sess(
    val id: Long, val start: Long, val end: Long,
    val planned: Int,      // الدقائق المخططة (0 = غير معروفة)
    val actual: Int,       // الدقائق الفعلية
    val done: Boolean,     // true = انتهت كاملة، false = خروج مبكر
    val eff: Int,          // الدقائق المعتمدة: للكاملة = actual، وللمبكرة = min(actual, planned) كي لا تتضخم بسجل مغلق متأخرًا
    val taskId: String, val taskTitle: String, val goal: String, val outcome: String,
    val day: Long,         // اليوم المحلي (epoch day) لبداية الجلسة
    val hour: Int,         // الساعة المحلية للبداية 0..23
    val dow: Int,          // 0 = الاثنين
    val endDay: Long       // اليوم المحلي لنهاية الجلسة (يطابق يوم عدّاد fm_ الذي يُكتب عند الإنهاء). = day لو لا نهاية مسجلة
)

// logTruncated: السجل بلغ حدّه (LOG_CAP) فاقتُطعت أقدم الجلسات. عندها يوم أقدم جلسة باقية ناقص، ويكتمل السجل من اليوم التالي له (logCompleteFrom)
class Cleaned(
    val sessions: List<Sess>, val openIgnored: Int, val invalid: Int, val duplicates: Int, val tinyIgnored: Int,
    val logTruncated: Boolean = false, val logCompleteFrom: Long? = null
) {
    val excluded: Int get() = invalid + duplicates + tinyIgnored
}

object SessionAnalytics {
    // قواعد التنظيف (موثقة في DECISIONS.md):
    // - open: جلسة جارية، لا تُحتسب. status غير معروف أو قيم مستحيلة أو بداية في المستقبل البعيد: تُستبعد وتُحصى.
    // - أقل من دقيقة (كاملة أو مبكرة): بدايات عرضية، لا تُحتسب محاولة.
    // - المكررات: نفس المعرّف أو بداية خلال 5 ثوانٍ: تُحسب مرة واحدة (والكاملة تفوز على المبكرة).
    fun clean(recs: List<SessionRec>, zone: ZoneId, nowMs: Long): Cleaned {
        var open = 0
        var invalid = 0
        var tiny = 0
        var dup = 0
        val ok = ArrayList<Sess>()
        for (r in recs) {
            if (r.status == "open") { open++; continue }
            val isDone = r.status == "done"
            val isStop = r.status == "stop"
            val bad = (!isDone && !isStop) || r.start <= 0L || r.planned < 0 || r.actual < 0 ||
                r.actual > Ax.MAX_MIN || (r.end > 0L && r.end < r.start) || r.start > nowMs + Ax.DAY_MS
            if (bad) { invalid++; continue }
            if (r.actual < 1) { tiny++; continue }
            val eff = if (isDone) r.actual else if (r.planned > 0) minOf(r.actual, r.planned) else r.actual
            val z = Instant.ofEpochMilli(r.start).atZone(zone)
            val day = z.toLocalDate().toEpochDay()
            val endDay = if (r.end > 0L) Instant.ofEpochMilli(r.end).atZone(zone).toLocalDate().toEpochDay() else day
            ok.add(
                Sess(
                    r.id, r.start, r.end, r.planned, r.actual, isDone, eff, r.taskId, r.taskTitle, r.goal, r.outcome,
                    day, z.hour, z.dayOfWeek.value - 1, endDay
                )
            )
        }
        val sorted = ok.sortedBy { it.start }
        val out = ArrayList<Sess>()
        val ids = HashSet<Long>()
        for (s in sorted) {
            if (!ids.add(s.id)) { dup++; continue }
            val last = if (out.isEmpty()) null else out[out.size - 1]
            if (last != null && Math.abs(s.start - last.start) <= SessionMath.DUP_WINDOW_MS) {
                dup++
                if (s.done && !last.done) out[out.size - 1] = s
            } else out.add(s)
        }
        // السجل يُقتطع من أقدمه عند 600: لو بلغ الحد فأقدم يوم فيه ناقص غالبًا، ونعدّ السجل كاملًا من اليوم الذي بعده
        val truncated = recs.size >= SessionMath.LOG_CAP
        val first = if (out.isEmpty()) null else out[0].day
        val completeFrom = if (first == null) null else if (truncated) first + 1 else first
        return Cleaned(out, open, invalid, dup, tiny, truncated, completeFrom)
    }
}

object Stats {
    fun median(v: List<Int>): Double? {
        if (v.isEmpty()) return null
        val s = v.sorted()
        val n = s.size
        return if (n % 2 == 1) s[n / 2].toDouble() else (s[n / 2 - 1] + s[n / 2]) / 2.0
    }

    // مئين بالاستيفاء الخطي (p بين 0 و 1)
    fun percentile(v: List<Int>, p: Double): Double? {
        if (v.isEmpty()) return null
        val s = v.sorted()
        val pos = p * (s.size - 1)
        val lo = pos.toInt()
        val hi = minOf(lo + 1, s.size - 1)
        return s[lo] + (s[hi] - s[lo]) * (pos - lo)
    }

    // لا نسبة مع مقام صفر
    fun rate(num: Int, den: Int): Double? = if (den <= 0) null else num.toDouble() / den

    // معامل الاختلاف (الانحراف المعياري للمجتمع / المتوسط). null لو المتوسط صفر
    fun cv(v: List<Int>): Double? {
        if (v.isEmpty()) return null
        val mean = v.sum().toDouble() / v.size
        if (mean <= 0.0) return null
        var sq = 0.0
        for (x in v) sq += (x - mean) * (x - mean)
        return Math.sqrt(sq / v.size) / mean
    }

    fun roundTo5(x: Double): Int = (Math.round(x / 5.0) * 5L).toInt()
}

// دقائق التركيز المكتمل لكل يوم. مصدران:
//  - fm_yyyyMMdd (Prefs.addDay عند كل إنهاء، بلا حد، ومنسوب ليوم الإنهاء): الأكمل تاريخيًا لكنه بلا تفاصيل.
//  - سجل الجلسات (محدود بـ600 جلسة): منسوب هنا إلى يوم نهاية الجلسة ليطابق يوم fm_.
// الدمج لكل يوم بأخذ الأكبر من القيمتين (max لا الجمع)، فلا يُحسب يوم مرتين، ويُستعاد اليوم الذي اقتُطعت جلساته من السجل
// (أو بعضها) من fm_، ويُستعاد اليوم الذي لا قيمة له في fm_ من السجل.
// coverageStart = أقدم يوم تتوفر عنه بيانات موثوقة: أقدم مفتاح fm_ صالح (التطبيق يكتبه عند كل إنهاء فالغياب بعده يعني صفرًا)،
// أو أول يوم مكتمل في السجل. لا نقارن بفترة تسبق ذلك لأنها مجهولة.
class DailyTotals(val byDay: Map<Long, Int>, val coverageStart: Long?) {
    fun mins(day: Long): Int = byDay[day] ?: 0

    fun sum(from: Long, to: Long): Int {
        var s = 0
        var d = from
        while (d <= to) { s += mins(d); d++ }
        return s
    }

    companion object {
        fun build(cl: Cleaned, legacy: Map<Long, Int>): DailyTotals = build(cl.sessions, legacy, cl.logCompleteFrom)

        // logCompleteFrom = null: يُفترض السجل كاملًا من أول جلسة فيه
        fun build(sessions: List<Sess>, legacy: Map<Long, Int>, logCompleteFrom: Long? = null): DailyTotals {
            val m = HashMap<Long, Int>()
            var firstLog: Long? = null
            for (s in sessions) {
                if (firstLog == null || s.day < firstLog) firstLog = s.day
                if (s.done) m[s.endDay] = (m[s.endDay] ?: 0) + s.actual
            }
            var cov: Long? = if (firstLog == null) null else (logCompleteFrom ?: firstLog)
            for ((d, v) in legacy) {
                if (cov == null || d < cov) cov = d      // أي مفتاح صالح (حتى بقيمة 0) دليل على أن التتبع كان يعمل في ذلك اليوم
                if (v > (m[d] ?: 0)) m[d] = v
            }
            return DailyTotals(m, cov)
        }
    }
}

object LegacyDaily {
    // مفاتيح Prefs.addDay("fm"): fm_yyyyMMdd (دقائق التركيز المكتمل لذلك اليوم). أي مفتاح بشكل مختلف أو تاريخ غير صالح يُتجاوز
    fun parse(all: Map<String, Long>): Map<Long, Int> {
        val out = HashMap<Long, Int>()
        for ((k, v) in all) {
            if (k.length != 11 || !k.startsWith("fm_")) continue
            val ds = k.substring(3)
            if (!ds.all { it in '0'..'9' }) continue
            try {
                val day = LocalDate.of(ds.substring(0, 4).toInt(), ds.substring(4, 6).toInt(), ds.substring(6, 8).toInt()).toEpochDay()
                if (v >= 0L) out[day] = v.coerceAtMost(1440L).toInt()  // قيمة سالبة = مفتاح تالف فيُتجاوز
            } catch (_: Exception) { }
        }
        return out
    }
}
