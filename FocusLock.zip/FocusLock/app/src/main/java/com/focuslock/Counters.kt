package com.focuslock

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class Meter(val view: View, val w: Int, val h: Int, val overlay: Boolean, val upd: (Float) -> Unit)

object Counters {
    val styles = listOf("ring", "dash", "bar", "digital", "drops", "pen", "book", "squat", "mind", "eye", "pullup", "pendulum", "hourglass", "desk")

    fun label(c: Context, k: String): String = when (k) {
        "ring" -> c.L("حلقة", "Ring")
        "dash" -> c.L("متقطعة", "Dashed")
        "bar" -> c.L("شريط", "Bar")
        "digital" -> c.L("أرقام", "Digits")
        "drops" -> c.L("قطرات", "Drops")
        "pen" -> c.L("قلم", "Pen")
        "book" -> c.L("كتاب", "Book")
        "mind" -> c.L("خدعة", "Mind")
        "eye" -> c.L("عين", "Eye")
        "pullup" -> c.L("عقلة", "Pull-up")
        "pendulum" -> c.L("بندول", "Pendulum")
        "hourglass" -> c.L("ساعة رملية", "Hourglass")
        "desk" -> c.L("مذاكرة", "Study")
        else -> c.L("سكوات", "Squat")
    }

    // w و h بالـ dp. w = 0 تعني عرض الشاشة. overlay تعني أن الوقت يُكتب فوق الرسم
    fun make(c: Context, style: String, track: Int, fill: Int): Meter? = when (style) {
        "digital" -> null
        "bar" -> BarView(c, track, fill).let { v -> Meter(v, 0, 10, false) { v.fraction = it } }
        "dash" -> DashRing(c, track, fill).let { v -> Meter(v, 250, 250, true) { v.fraction = it } }
        "drops" -> DropsView(c, track, fill).let { v -> Meter(v, 230, 200, false) { v.fraction = it } }
        "pen" -> PenView(c, track, fill).let { v -> Meter(v, 260, 150, false) { v.fraction = it } }
        "book" -> BookView(c, track, fill).let { v -> Meter(v, 260, 170, false) { v.fraction = it } }
        "squat" -> SquatView(c, track, fill).let { v -> Meter(v, 230, 210, false) { v.fraction = it } }
        "pendulum" -> PendulumView(c, track, fill).let { v -> Meter(v, 240, 200, false) { v.fraction = it } }
        "hourglass" -> HourglassView(c, track, fill).let { v -> Meter(v, 200, 230, false) { v.fraction = it } }
        "desk" -> StudyView(c, track, fill).let { v -> Meter(v, 260, 210, false) { v.fraction = it } }
        "mind" -> MindView(c, track, fill).let { v -> Meter(v, 240, 240, false) { v.fraction = it } }
        "eye" -> EyeView(c, track, fill).let { v -> Meter(v, 240, 240, false) { v.fraction = it } }
        "pullup" -> PullUpView(c, track, fill).let { v -> Meter(v, 230, 230, false) { v.fraction = it } }
        else -> RingView(c, track, fill).let { v -> Meter(v, 250, 250, true) { v.fraction = it } }
    }
}

class DashRing(c: Context, private val track: Int, private val arc: Int) : View(c) {
    var fraction = 1f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = c.dp(9).toFloat(); strokeCap = Paint.Cap.BUTT
    }
    override fun onDraw(canvas: Canvas) {
        val sw = p.strokeWidth
        val r = RectF(sw, sw, width - sw, height - sw)
        val n = 60
        val on = (n * fraction + 0.999f).toInt()
        for (i in 0 until n) {
            p.color = if (i < on) arc else track
            canvas.drawArc(r, -90f + i * 6f + 1f, 4f, false, p)
        }
    }
}

abstract class AnimView(c: Context) : View(c) {
    var fraction = 1f
    protected var t = 0f
    private val t0 = System.nanoTime()
    protected val p = Paint(Paint.ANTI_ALIAS_FLAG)
    abstract fun draw2(cv: Canvas, w: Float, h: Float)
    override fun onDraw(canvas: Canvas) {
        t = (System.nanoTime() - t0) / 1e9f
        draw2(canvas, width.toFloat(), height.toFloat())
        postInvalidateDelayed(if (Prefs.reduceMotion(context)) 1000L else 40L)
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) invalidate()
    }
}

class DropsView(c: Context, private val track: Int, private val fill: Int) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val l = w * 0.22f; val r = w * 0.78f; val top = h * 0.16f; val bot = h * 0.96f
        val tank = RectF(l, top, r, bot)
        val level = bot - (bot - top) * (1f - fraction)
        val water = (fill and 0x00FFFFFF) or (200 shl 24)
        cv.save()
        cv.clipPath(Path().apply { addRoundRect(tank, 24f, 24f, Path.Direction.CW) })
        val wave = Path().apply {
            moveTo(l, bot); lineTo(l, level)
            var x = l
            while (x <= r) { lineTo(x, level + sin(x * 0.06f + t * 3f) * 4f); x += 6f }
            lineTo(r, bot); close()
        }
        p.style = Paint.Style.FILL; p.color = water
        cv.drawPath(wave, p)
        cv.restore()
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = track
        cv.drawRoundRect(tank, 24f, 24f, p)
        p.style = Paint.Style.FILL; p.color = fill
        for (k in 0..1) {
            val ph = (t * 0.9f + k * 0.5f) % 1f
            val y = top - 14f + ph * (level - top + 14f)
            if (y < level) cv.drawCircle(w / 2f + (k - 0.5f) * 30f, y, 6f, p)
        }
    }
}

class PenView(c: Context, private val track: Int, private val fill: Int) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val pad = w * 0.08f
        val len = w - 2 * pad
        val e = 1f - fraction
        fun yAt(x: Float) = h * 0.68f + sin((x - pad) / len * 18f) * h * 0.07f
        val full = Path(); val done = Path()
        var x = pad
        full.moveTo(x, yAt(x)); done.moveTo(x, yAt(x))
        while (x < pad + len) {
            x += 4f
            full.lineTo(x, yAt(x))
            if (x <= pad + len * e) done.lineTo(x, yAt(x))
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.strokeCap = Paint.Cap.ROUND
        p.color = track; cv.drawPath(full, p)
        p.color = fill; cv.drawPath(done, p)
        val px = pad + len * e
        val py = yAt(px)
        val s = h / 150f
        cv.save()
        cv.translate(px, py + sin(t * 9f) * 2f)
        cv.rotate(30f + sin(t * 6f) * 4f)
        cv.scale(s, s)
        val pen = Path().apply {
            moveTo(0f, 0f); lineTo(-7f, -16f); lineTo(-7f, -70f); lineTo(7f, -70f); lineTo(7f, -16f); close()
        }
        p.style = Paint.Style.FILL; p.color = fill
        cv.drawPath(pen, p)
        p.color = track
        cv.drawRect(-7f, -70f, 7f, -58f, p)
        cv.restore()
    }
}

class BookView(c: Context, private val track: Int, private val fill: Int) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val cx = w / 2f; val cy = h / 2f
        val pw = w * 0.32f; val ph = h * 0.72f
        val top = cy - ph / 2f; val bot = cy + ph / 2f
        val pageCol = (fill and 0x00FFFFFF) or (0x55 shl 24)
        val flipCol = (fill and 0x00FFFFFF) or (0xB0 shl 24)
        fun page(x1: Float, x2: Float, col: Int) {
            val a = min(x1, x2); val b = max(x1, x2)
            p.style = Paint.Style.FILL; p.color = col
            cv.drawRoundRect(RectF(a, top, b, bot), 8f, 8f, p)
            if (b - a > 24f) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = track
                for (k in 1..6) cv.drawLine(a + 10f, top + ph * k / 7f, b - 10f, top + ph * k / 7f, p)
            }
        }
        page(cx - pw, cx - 2f, pageCol)
        page(cx + 2f, cx + pw, pageCol)
        val ang = ((t * 0.8f) % 1f) * PI.toFloat()
        page(cx, cx + pw * cos(ang), flipCol)
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = fill
        cv.drawLine(cx, top - 4f, cx, bot + 4f, p)
    }
}

class SquatView(c: Context, private val track: Int, private val fill: Int) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val s = h / 200f
        val ground = h * 0.92f
        val cx = w * 0.45f
        val leg = 44f * s; val torso = 52f * s; val hr = 12f * s
        val d = (1f - cos(t * 2.4f)) / 2f
        val ax = cx; val ay = ground
        val hx = cx - d * 0.8f * leg
        val hy = ground - 2f * leg * (1f - 0.5f * d)
        val vx = hx - ax; val vy = hy - ay
        val dist = sqrt(vx * vx + vy * vy)
        val hk = sqrt(max(leg * leg - dist * dist / 4f, 0f))
        val kx = (ax + hx) / 2f + (-vy / dist) * hk
        val ky = (ay + hy) / 2f + (vx / dist) * hk
        val lean = 0.2f + d * 0.7f
        val sx = hx + sin(lean) * torso
        val sy = hy - cos(lean) * torso
        val headx = sx + sin(lean) * hr * 1.7f
        val heady = sy - cos(lean) * hr * 1.7f
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 4f
        p.color = track
        cv.drawLine(cx - 80f * s, ground + 4f, cx + 80f * s, ground + 4f, p)
        p.strokeWidth = 7f * s; p.color = fill
        cv.drawLine(ax, ay, kx, ky, p)
        cv.drawLine(kx, ky, hx, hy, p)
        cv.drawLine(hx, hy, sx, sy, p)
        cv.drawLine(sx, sy, sx + 38f * s, sy + 4f * s, p)
        p.style = Paint.Style.FILL
        cv.drawCircle(headx, heady, hr, p)
    }
}

private const val TAU = 6.2831855f

class MindView(c: Context, private val track: Int, private val fill: Int) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val cx = w / 2f; val cy = h / 2f
        val r = min(w, h) / 2f - 8f
        val rect = RectF(cx - r, cy - r, cx + r, cy + r)
        p.style = Paint.Style.STROKE; p.strokeWidth = 8f; p.strokeCap = Paint.Cap.ROUND
        p.color = track; cv.drawCircle(cx, cy, r, p)
        p.color = fill; cv.drawArc(rect, -90f, 360f * fraction, false, p)
        val maxR = r - 18f
        val tmax = 5f * TAU
        p.strokeWidth = 11f; p.strokeCap = Paint.Cap.BUTT
        for (arm in 0 until 4) {
            val path = Path()
            var th = 0f
            while (th <= tmax) {
                val rr = maxR * th / tmax
                val a = th + arm * (TAU / 4f) + t * 1.6f
                val x = cx + rr * cos(a)
                val y = cy + rr * sin(a)
                if (th == 0f) path.moveTo(x, y) else path.lineTo(x, y)
                th += 0.14f
            }
            p.color = if (arm % 2 == 0) fill else track
            cv.drawPath(path, p)
        }
    }
}

class EyeView(c: Context, private val track: Int, private val fill: Int) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val cx = w / 2f; val cy = h / 2f
        val r = min(w, h) / 2f - 8f
        p.style = Paint.Style.STROKE; p.strokeWidth = 8f; p.strokeCap = Paint.Cap.ROUND
        p.color = track; cv.drawCircle(cx, cy, r, p)
        p.color = fill; cv.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -90f, 360f * fraction, false, p)
        val iris = r - 20f
        p.style = Paint.Style.FILL
        p.color = (fill and 0x00FFFFFF) or (0xD0 shl 24)
        cv.drawCircle(cx, cy, iris, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.strokeCap = Paint.Cap.ROUND
        p.color = 0xFF1B1030.toInt()
        for (k in 1..5) {
            val rr = iris * k / 6f
            val dir = if (k % 2 == 0) 1f else -1f
            val start = t * dir * (35f + k * 14f)
            cv.drawArc(RectF(cx - rr, cy - rr, cx + rr, cy + rr), start, 290f, false, p)
        }
        p.style = Paint.Style.FILL
        p.color = 0xFF0A0614.toInt()
        cv.drawCircle(cx, cy, iris / 6f, p)
        p.color = 0x88FFFFFF.toInt()
        cv.drawCircle(cx - iris / 16f, cy - iris / 16f, iris / 22f, p)
    }
}

class PullUpView(c: Context, private val track: Int, private val fill: Int) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val s = h / 230f
        val cx = w / 2f
        val barY = h * 0.14f
        val ground = h * 0.96f
        val hw = 34f * s
        val armLen = 52f * s
        val up = (1f - cos(t * 2.2f)) / 2f
        val sy = barY + armLen * (1f - up) + 12f * s
        val shw = 16f * s
        val hipY = sy + 54f * s
        val postX = hw + 34f * s
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 6f * s; p.color = track
        cv.drawLine(cx - postX, barY, cx - postX, ground, p)
        cv.drawLine(cx + postX, barY, cx + postX, ground, p)
        cv.drawLine(cx - 90f * s, ground, cx + 90f * s, ground, p)
        p.strokeWidth = 8f * s; p.color = fill
        cv.drawLine(cx - postX, barY, cx + postX, barY, p)
        p.strokeWidth = 7f * s
        for (d in intArrayOf(-1, 1)) {
            val hx = cx + d * hw
            val shx = cx + d * shw
            val ex = (hx + shx) / 2f + d * 16f * s * up
            val ey = (barY + sy) / 2f
            cv.drawLine(hx, barY, ex, ey, p)
            cv.drawLine(ex, ey, shx, sy, p)
            val kx = cx + d * 6f * s
            val ky = hipY + 30f * s
            val fx = cx + d * 8f * s + sin(t * 2.2f) * 4f * s
            cv.drawLine(cx, hipY, kx, ky, p)
            cv.drawLine(kx, ky, fx, hipY + 58f * s, p)
        }
        cv.drawLine(cx - shw, sy, cx + shw, sy, p)
        cv.drawLine(cx, sy, cx, hipY, p)
        p.style = Paint.Style.FILL
        cv.drawCircle(cx, sy - 16f * s, 12f * s, p)
    }
}

class PendulumView(c: Context, private val track: Int, private val fill: Int) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val s = h / 200f
        val px = w / 2f; val py = 16f * s
        val len = 118f * s
        val ang = 0.62f * sin(t * 2.6f)
        val bx = px + len * sin(ang); val by = py + len * cos(ang)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 7f * s; p.color = track
        cv.drawLine(px - 52f * s, py - 6f * s, px + 52f * s, py - 6f * s, p)
        p.strokeWidth = 2f * s
        cv.drawArc(RectF(px - len, py - len, px + len, py + len), 54.5f, 71f, false, p)
        p.strokeWidth = 3f * s; p.color = fill
        cv.drawLine(px, py, bx, by, p)
        p.style = Paint.Style.FILL
        cv.drawCircle(px, py, 5f * s, p)
        cv.drawCircle(bx, by, 17f * s, p)
        p.color = (0x66 shl 24) or 0x00FFFFFF
        cv.drawCircle(bx - 5f * s, by - 5f * s, 5f * s, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f * s; p.color = track
        cv.drawLine(w * 0.2f, h - 8f * s, w * 0.8f, h - 8f * s, p)
        p.color = fill
        cv.drawLine(w * 0.2f, h - 8f * s, w * (0.2f + 0.6f * (1f - fraction)), h - 8f * s, p)
    }
}

class HourglassView(c: Context, private val track: Int, private val fill: Int) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val cx = w / 2f
        val half = min(w * 0.42f, h * 0.30f)
        val top = h * 0.08f; val bot = h * 0.92f
        val mid = (top + bot) / 2f
        val neck = half * 0.12f
        val topBulb = Path().apply { moveTo(cx - half, top); lineTo(cx + half, top); lineTo(cx + neck, mid); lineTo(cx - neck, mid); close() }
        val botBulb = Path().apply { moveTo(cx - neck, mid); lineTo(cx + neck, mid); lineTo(cx + half, bot); lineTo(cx - half, bot); close() }
        val sand = (fill and 0x00FFFFFF) or (0xE0 shl 24)
        val rem = fraction
        p.style = Paint.Style.FILL; p.color = sand
        cv.save(); cv.clipPath(topBulb)
        cv.drawRect(cx - half, mid - (mid - top) * rem, cx + half, mid, p)
        cv.restore()
        val level = bot - (bot - mid) * (1f - rem)
        cv.save(); cv.clipPath(botBulb)
        cv.drawRect(cx - half, level, cx + half, bot, p)
        cv.restore()
        if (rem > 0.01f && level > mid) {
            val span = level - mid
            for (k in 0..3) {
                val y = mid + (t * 90f + k * span / 4f) % span
                cv.drawCircle(cx, y, 2.5f, p)
            }
        }
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 5f; p.color = track
        cv.drawPath(topBulb, p); cv.drawPath(botBulb, p)
        p.strokeWidth = 9f; p.color = fill
        cv.drawLine(cx - half - 10f, top, cx + half + 10f, top, p)
        cv.drawLine(cx - half - 10f, bot, cx + half + 10f, bot, p)
    }
}

class StudyView(c: Context, private val track: Int, private val fill: Int) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val s = h / 200f
        val dy = h * 0.66f
        val warm = 0xFFFFD166.toInt()
        val flick = 0.85f + 0.15f * sin(t * 7f)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        // أرضية ومكتب وكرسي
        p.strokeWidth = 3f * s; p.color = track
        cv.drawLine(w * 0.04f, h * 0.95f, w * 0.96f, h * 0.95f, p)
        p.strokeWidth = 7f * s
        cv.drawLine(w * 0.34f, dy, w * 0.95f, dy, p)
        cv.drawLine(w * 0.90f, dy, w * 0.90f, h * 0.95f, p)
        p.strokeWidth = 4f * s
        cv.drawLine(w * 0.12f, dy - 18f * s, w * 0.12f, dy + 24f * s, p)
        cv.drawLine(w * 0.12f, dy + 24f * s, w * 0.30f, dy + 24f * s, p)
        cv.drawLine(w * 0.21f, dy + 24f * s, w * 0.21f, h * 0.95f, p)
        // الأباجورة وضوؤها
        val hx = w * 0.72f; val hyy = dy - 84f * s
        val cone = Path().apply {
            moveTo(hx - 12f * s, hyy + 8f * s); lineTo(hx + 12f * s, hyy + 8f * s)
            lineTo(hx + 52f * s, dy - 2f * s); lineTo(hx - 70f * s, dy - 2f * s); close()
        }
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(hx, hyy, hx, dy, (warm and 0x00FFFFFF) or ((0x66 * flick).toInt() shl 24), warm and 0x00FFFFFF, Shader.TileMode.CLAMP)
        cv.drawPath(cone, p)
        p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f * s; p.color = track
        cv.drawLine(w * 0.84f, dy, w * 0.84f, dy - 40f * s, p)
        cv.drawLine(w * 0.84f, dy - 40f * s, hx + 10f * s, hyy + 6f * s, p)
        p.style = Paint.Style.FILL; p.color = warm
        val shade = Path().apply {
            moveTo(hx - 14f * s, hyy + 10f * s); lineTo(hx + 14f * s, hyy + 10f * s); lineTo(hx + 8f * s, hyy - 6f * s); lineTo(hx - 8f * s, hyy - 6f * s); close()
        }
        cv.drawPath(shade, p)
        // الدارس: جذع ورأس وذراع تكتب
        p.style = Paint.Style.STROKE; p.strokeWidth = 7f * s; p.color = fill
        val hipX = w * 0.18f; val hipY = dy + 16f * s
        val shX = w * 0.23f; val shY = dy - 42f * s
        cv.drawLine(hipX, hipY, shX, shY, p)
        cv.drawLine(hipX, hipY, w * 0.34f, hipY + 2f * s, p)
        cv.drawLine(w * 0.34f, hipY + 2f * s, w * 0.34f, h * 0.93f, p)
        val hand = w * 0.46f + 6f * s * sin(t * 5f)
        cv.drawLine(shX, shY + 4f * s, w * 0.33f, dy - 14f * s, p)
        cv.drawLine(w * 0.33f, dy - 14f * s, hand, dy - 5f * s, p)
        p.style = Paint.Style.FILL
        cv.drawCircle(shX + 5f * s, shY - 17f * s, 12f * s, p)
        // كتاب على المكتب
        p.color = (fill and 0x00FFFFFF) or (0x88 shl 24)
        cv.drawRoundRect(RectF(w * 0.42f, dy - 6f * s, w * 0.62f, dy - 1f * s), 3f, 3f, p)
        // شريط التقدم
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f * s; p.color = track
        cv.drawLine(w * 0.2f, h - 3f * s, w * 0.8f, h - 3f * s, p)
        p.color = fill
        cv.drawLine(w * 0.2f, h - 3f * s, w * (0.2f + 0.6f * (1f - fraction)), h - 3f * s, p)
    }
}
