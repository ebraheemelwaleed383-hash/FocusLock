package com.focuslock

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class Meter(val view: View, val w: Int, val h: Int, val overlay: Boolean, val upd: (Float) -> Unit)

object Counters {
    val styles = listOf("ring", "dash", "bar", "digital", "drops", "pen", "book", "squat", "mind", "eye")

    fun label(c: Context, k: String): String = when (k) {
        "ring" -> c.L("حلقة", "Ring")
        "dash" -> c.L("متقطعة", "Dashed")
        "bar" -> c.L("شريط", "Bar")
        "digital" -> c.L("أرقام", "Digits")
        "drops" -> c.L("قطرات", "Drops")
        "pen" -> c.L("قلم", "Pen")
        "book" -> c.L("كتاب", "Book")
        "mind" -> c.L("خدعة", "Mind")
        "eye" -> c.L("عين", "Eye")
        else -> c.L("سكوات", "Squat")
    }

    // w و h بالـ dp. w = 0 تعني عرض الشاشة. overlay تعني أن الوقت يُكتب فوق الرسم
    fun make(c: Context, style: String, track: Int, fill: Int): Meter? = when (style) {
        "digital" -> null
        "bar" -> BarView(c, track, fill).let { v -> Meter(v, 0, 10, false) { v.fraction = it } }
        "dash" -> DashRing(c, track, fill).let { v -> Meter(v, 250, 250, true) { v.fraction = it } }
        "drops" -> DropsView(c, track, fill).let { v -> Meter(v, 230, 200, false) { v.fraction = it } }
        "pen" -> PenView(c, track, fill).let { v -> Meter(v, 260, 150, false) { v.fraction = it } }
        "book" -> BookView(c, track, fill).let { v -> Meter(v, 260, 170, false) { v.fraction = it } }
        "squat" -> SquatView(c, track, fill).let { v -> Meter(v, 230, 210, false) { v.fraction = it } }
        "mind" -> MindView(c, track, fill).let { v -> Meter(v, 240, 240, false) { v.fraction = it } }
        "eye" -> EyeView(c, track, fill).let { v -> Meter(v, 240, 240, false) { v.fraction = it } }
        else -> RingView(c, track, fill).let { v -> Meter(v, 250, 250, true) { v.fraction = it } }
    }
}

class DashRing(c: Context, private val track: Int, private val arc: Int) : View(c) {
    var fraction = 1f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = c.dp(9).toFloat(); strokeCap = Paint.Cap.BUTT
    }
    override fun onDraw(canvas: Canvas) {
        val sw = p.strokeWidth
        val r = RectF(sw, sw, width - sw, height - sw)
        val n = 60
        val on = (n * fraction + 0.999f).toInt()
        for (i in 0 until n) {
            p.color = if (i < on) arc else track
            canvas.drawArc(r, -90f + i * 6f + 1f, 4f, false, p)
        }
    }
}

abstract class AnimView(c: Context) : View(c) {
    var fraction = 1f
    protected var t = 0f
    private val t0 = System.nanoTime()
    protected val p = Paint(Paint.ANTI_ALIAS_FLAG)
    abstract fun draw2(cv: Canvas, w: Float, h: Float)
    override fun onDraw(canvas: Canvas) {
        t = (System.nanoTime() - t0) / 1e9f
        draw2(canvas, width.toFloat(), height.toFloat())
        postInvalidateDelayed(if (Prefs.reduceMotion(context)) 1000L else 40L)
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) invalidate()
    }
}

class DropsView(c: Context, private val track: Int, private val fill: Int) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val l = w * 0.22f; val r = w * 0.78f; val top = h * 0.16f; val bot = h * 0.96f
        val tank = RectF(l, top, r, bot)
        val level = bot - (bot - top) * (1f - fraction)
        val water = (fill and 0x00FFFFFF) or (200 shl 24)
        cv.save()
        cv.clipPath(Path().apply { addRoundRect(tank, 24f, 24f, Path.Direction.CW) })
        val wave = Path().apply {
            moveTo(l, bot); lineTo(l, level)
            var x = l
            while (x <= r) { lineTo(x, level + sin(x * 0.06f + t * 3f) * 4f); x += 6f }
            lineTo(r, bot); close()
        }
        p.style = Paint.Style.FILL; p.color = water
        cv.drawPath(wave, p)
        cv.restore()
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = track
        cv.drawRoundRect(tank, 24f, 24f, p)
        p.style = Paint.Style.FILL; p.color = fill
        for (k in 0..1) {
            val ph = (t * 0.9f + k * 0.5f) % 1f
            val y = top - 14f + ph * (level - top + 14f)
            if (y < level) cv.drawCircle(w / 2f + (k - 0.5f) * 30f, y, 6f, p)
        }
    }
}

class PenView(c: Context, private val track: Int, private val fill: Int) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val pad = w * 0.08f
        val len = w - 2 * pad
        val e = 1f - fraction
        fun yAt(x: Float) = h * 0.68f + sin((x - pad) / len * 18f) * h * 0.07f
        val full = Path(); val done = Path()
        var x = pad
        full.moveTo(x, yAt(x)); done.moveTo(x, yAt(x))
        while (x < pad + len) {
            x += 4f
            full.lineTo(x, yAt(x))
            if (x <= pad + len * e) done.lineTo(x, yAt(x))
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.strokeCap = Paint.Cap.ROUND
        p.color = track; cv.drawPath(full, p)
        p.color = fill; cv.drawPath(done, p)
        val px = pad + len * e
        val py = yAt(px)
        val s = h / 150f
        cv.save()
        cv.translate(px, py + sin(t * 9f) * 2f)
        cv.rotate(30f + sin(t * 6f) * 4f)
        cv.scale(s, s)
        val pen = Path().apply {
            moveTo(0f, 0f); lineTo(-7f, -16f); lineTo(-7f, -70f); lineTo(7f, -70f); lineTo(7f, -16f); close()
        }
        p.style = Paint.Style.FILL; p.color = fill
        cv.drawPath(pen, p)
        p.color = track
        cv.drawRect(-7f, -70f, 7f, -58f, p)
        cv.restore()
    }
}

class BookView(c: Context, private val track: Int, private val fill: Int) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val cx = w / 2f; val cy = h / 2f
        val pw = w * 0.32f; val ph = h * 0.72f
        val top = cy - ph / 2f; val bot = cy + ph / 2f
        val pageCol = (fill and 0x00FFFFFF) or (0x55 shl 24)
        val flipCol = (fill and 0x00FFFFFF) or (0xB0 shl 24)
        fun page(x1: Float, x2: Float, col: Int) {
            val a = min(x1, x2); val b = max(x1, x2)
            p.style = Paint.Style.FILL; p.color = col
            cv.drawRoundRect(RectF(a, top, b, bot), 8f, 8f, p)
            if (b - a > 24f) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = track
                for (k in 1..6) cv.drawLine(a + 10f, top + ph * k / 7f, b - 10f, top + ph * k / 7f, p)
            }
        }
        page(cx - pw, cx - 2f, pageCol)
        page(cx + 2f, cx + pw, pageCol)
        val ang = ((t * 0.8f) % 1f) * PI.toFloat()
        page(cx, cx + pw * cos(ang), flipCol)
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = fill
        cv.drawLine(cx, top - 4f, cx, bot + 4f, p)
    }
}

class SquatView(c: Context, private val track: Int, private val fill: Int) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val s = h / 200f
        val ground = h * 0.92f
        val cx = w * 0.45f
        val leg = 44f * s; val torso = 52f * s; val hr = 12f * s
        val d = (1f - cos(t * 2.4f)) / 2f
        val ax = cx; val ay = ground
        val hx = cx - d * 0.8f * leg
        val hy = ground - 2f * leg * (1f - 0.5f * d)
        val vx = hx - ax; val vy = hy - ay
        val dist = sqrt(vx * vx + vy * vy)
        val hk = sqrt(max(leg * leg - dist * dist / 4f, 0f))
        val kx = (ax + hx) / 2f + (-vy / dist) * hk
        val ky = (ay + hy) / 2f + (vx / dist) * hk
        val lean = 0.2f + d * 0.7f
        val sx = hx + sin(lean) * torso
        val sy = hy - cos(lean) * torso
        val headx = sx + sin(lean) * hr * 1.7f
        val heady = sy - cos(lean) * hr * 1.7f
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 4f
        p.color = track
        cv.drawLine(cx - 80f * s, ground + 4f, cx + 80f * s, ground + 4f, p)
        p.strokeWidth = 7f * s; p.color = fill
        cv.drawLine(ax, ay, kx, ky, p)
        cv.drawLine(kx, ky, hx, hy, p)
        cv.drawLine(hx, hy, sx, sy, p)
        cv.drawLine(sx, sy, sx + 38f * s, sy + 4f * s, p)
        p.style = Paint.Style.FILL
        cv.drawCircle(headx, heady, hr, p)
    }
}

private const val TAU = 6.2831855f

class MindView(c: Context, private val track: Int, private val fill: Int) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val cx = w / 2f; val cy = h / 2f
        val r = min(w, h) / 2f - 8f
        val rect = RectF(cx - r, cy - r, cx + r, cy + r)
        p.style = Paint.Style.STROKE; p.strokeWidth = 8f; p.strokeCap = Paint.Cap.ROUND
        p.color = track; cv.drawCircle(cx, cy, r, p)
        p.color = fill; cv.drawArc(rect, -90f, 360f * fraction, false, p)
        val maxR = r - 18f
        val tmax = 5f * TAU
        p.strokeWidth = 11f; p.strokeCap = Paint.Cap.BUTT
        for (arm in 0 until 4) {
            val path = Path()
            var th = 0f
            while (th <= tmax) {
                val rr = maxR * th / tmax
                val a = th + arm * (TAU / 4f) + t * 1.6f
                val x = cx + rr * cos(a)
                val y = cy + rr * sin(a)
                if (th == 0f) path.moveTo(x, y) else path.lineTo(x, y)
                th += 0.14f
            }
            p.color = if (arm % 2 == 0) fill else track
            cv.drawPath(path, p)
        }
    }
}

class EyeView(c: Context, private val track: Int, private val fill: Int) : AnimView(c) {
    override fun draw2(cv: Canvas, w: Float, h: Float) {
        val cx = w / 2f; val cy = h / 2f
        val r = min(w, h) / 2f - 8f
        p.style = Paint.Style.STROKE; p.strokeWidth = 8f; p.strokeCap = Paint.Cap.ROUND
        p.color = track; cv.drawCircle(cx, cy, r, p)
        p.color = fill; cv.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -90f, 360f * fraction, false, p)
        val iris = r - 20f
        p.style = Paint.Style.FILL
        p.color = (fill and 0x00FFFFFF) or (0xD0 shl 24)
        cv.drawCircle(cx, cy, iris, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.strokeCap = Paint.Cap.ROUND
        p.color = 0xFF1B1030.toInt()
        for (k in 1..5) {
            val rr = iris * k / 6f
            val dir = if (k % 2 == 0) 1f else -1f
            val start = t * dir * (35f + k * 14f)
            cv.drawArc(RectF(cx - rr, cy - rr, cx + rr, cy + rr), start, 290f, false, p)
        }
        p.style = Paint.Style.FILL
        p.color = 0xFF0A0614.toInt()
        cv.drawCircle(cx, cy, iris / 6f, p)
        p.color = 0x88FFFFFF.toInt()
        cv.drawCircle(cx - iris / 16f, cy - iris / 16f, iris / 22f, p)
    }
}
