package com.focuslock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object Look {
    private val ids = intArrayOf(R.drawable.bg_1, R.drawable.bg_2, R.drawable.bg_3, R.drawable.bg_4, R.drawable.bg_5, R.drawable.bg_6, R.drawable.bg_7, R.drawable.bg_8, R.drawable.bg_9, R.drawable.bg_10, R.drawable.bg_11, R.drawable.bg_12, R.drawable.bg_13, R.drawable.bg_14, R.drawable.bg_15, R.drawable.bg_16, R.drawable.bg_17, R.drawable.bg_18, R.drawable.bg_19, R.drawable.bg_20, R.drawable.bg_21, R.drawable.bg_22, R.drawable.bg_23, R.drawable.bg_24, R.drawable.bg_25, R.drawable.bg_26, R.drawable.bg_27, R.drawable.bg_28, R.drawable.bg_29, R.drawable.bg_30)

    fun allKeys(c: Context): List<String> = (1..30).map { "b$it" } + Prefs.customBgs(c).map { "c:$it" }

    private fun decode(c: Context, key: String, sample: Int): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        if (key.startsWith("b")) BitmapFactory.decodeResource(c.resources, ids[key.substring(1).toInt() - 1], o)
        else BitmapFactory.decodeFile(File(c.filesDir, key.substring(2)).path, o)
    } catch (e: Exception) { null }

    fun thumb(c: Context, key: String): Bitmap? = decode(c, key, 4)

    fun background(c: Context): Drawable? {
        var key = Prefs.bg(c)
        if (key == "none") return null
        if (key == "random") key = allKeys(c).random()
        val b = decode(c, key, 1) ?: return null
        return BitmapDrawable(c.resources, b)
    }
}

class Task(var t: String, var d: Boolean, var p: Int = 1)

object Tasks {
    fun load(c: Context): MutableList<Task> {
        val a = JSONArray(Prefs.raw(c, "tasks"))
        return MutableList(a.length()) { i ->
            val o = a.getJSONObject(i)
            Task(o.getString("t"), o.getBoolean("d"), o.optInt("p", 1))
        }
    }

    fun save(c: Context, l: List<Task>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("t", it.t).put("d", it.d).put("p", it.p)) }
        Prefs.putRaw(c, "tasks", a.toString())
    }
}
