package com.focuslock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object Look {
    private val ids = intArrayOf(R.drawable.bg_1, R.drawable.bg_2, R.drawable.bg_3, R.drawable.bg_4, R.drawable.bg_5, R.drawable.bg_6, R.drawable.bg_7, R.drawable.bg_8, R.drawable.bg_9, R.drawable.bg_10, R.drawable.bg_11, R.drawable.bg_12, R.drawable.bg_13, R.drawable.bg_14, R.drawable.bg_15, R.drawable.bg_16, R.drawable.bg_17, R.drawable.bg_18, R.drawable.bg_19, R.drawable.bg_20, R.drawable.bg_21, R.drawable.bg_22, R.drawable.bg_23, R.drawable.bg_24, R.drawable.bg_25, R.drawable.bg_26, R.drawable.bg_27, R.drawable.bg_28, R.drawable.bg_29, R.drawable.bg_30)

    fun allKeysRaw(c: Context): List<String> = (1..30).map { "b$it" } + Prefs.customBgs(c).map { "c:$it" }

    fun allKeys(c: Context): List<String> { val h = Prefs.hiddenBgs(c); return allKeysRaw(c).filter { it !in h } }

    private fun decode(c: Context, key: String, sample: Int): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        if (key.startsWith("b")) BitmapFactory.decodeResource(c.resources, ids[key.substring(1).toInt() - 1], o)
        else BitmapFactory.decodeFile(File(c.filesDir, key.substring(2)).path, o)
    } catch (e: Exception) { null }

    fun thumb(c: Context, key: String): Bitmap? = decode(c, key, 4)

    fun background(c: Context): Drawable? {
        var key = Prefs.bg(c)
        if (Prefs.hiddenBgs(c).contains(key)) key = allKeys(c).randomOrNull() ?: "none"
        if (key == "none") return null
        if (key == "random") key = allKeys(c).randomOrNull() ?: return null
        val b = decode(c, key, 1) ?: return null
        return BitmapDrawable(c.resources, b)
    }
}

class Task(var t: String, var d: Boolean, var p: Int = 1) {
    // حقول المهام المرتبطة بالتركيز (الإصدار 2.7): كلها اختيارية ومتوافقة مع البيانات القديمة
    var id: String = ""
    var proj: String = ""
    var steps: MutableList<Step> = ArrayList()
    var focusMins: Int = 0
    var sessions: Int = 0
    var later: Boolean = false
    var notes: String = ""
}

object Tasks {
    // قراءة لا ترمي استثناءً أبدًا: المهمة التالفة تُتجاوز، والنص غير القابل للقراءة يعطي قائمة فارغة.
    // وفي الحالتين نحتفظ بنسخة من النص الأصلي (tasks_corrupt، أول مرة فقط) قبل أن يُكتب أي شيء فوقه
    @Synchronized
    fun load(c: Context): MutableList<Task> {
        val raw = Prefs.raw(c, "tasks")
        val p = TaskSafe.parse(raw)
        if ((p.broken || p.skipped > 0) && Prefs.str(c, "tasks_corrupt", "").isEmpty()) Prefs.putStr(c, "tasks_corrupt", raw)
        val l = p.tasks
        // مهام قديمة بلا معرّف (أو بمعرّف مكرر): نعطيها معرّفًا ثابتًا مرة واحدة (بدون المرور بـ save حتى لا تُحتسب مكافآت)
        if (TaskSafe.normalizeIds(l)) persist(c, l)
        return l
    }

    private fun persist(c: Context, l: List<Task>) {
        Prefs.putRaw(c, "tasks", TaskSafe.encode(l))
    }

    // الحفظ الكامل للقائمة. يفضَّل update لأي تعديل: قائمة قديمة محفوظة بالكامل قد تطمس تغييرات حدثت بعد تحميلها
    @Synchronized
    fun save(c: Context, l: List<Task>) {
        l.forEach { if (it.id.isEmpty()) it.id = TaskCodec.newId() }
        persist(c, l)
        val nowDone = l.count { it.d }
        val prev = Prefs.intOf(c, "tdone_prev", -1)
        if (prev >= 0 && nowDone > prev) Prefs.addDay(c, "td", (nowDone - prev).toLong())
        if (prev >= 0 && nowDone > prev) Rewards.add(c, 15 * (nowDone - prev))
        Prefs.putInt(c, "tdone_prev", nowDone)
    }

    // تحميل ثم تعديل ثم حفظ كعملية واحدة متزامنة على أحدث نسخة محفوظة (يمنع طمس تعديلات المسارات الأخرى).
    // block يُنفَّذ قبل أي كتابة: لو رمى استثناءً لا يُحفظ شيء
    @Synchronized
    fun update(c: Context, block: (MutableList<Task>) -> Unit) {
        val l = load(c)
        block(l)
        save(c, l)
    }
}
