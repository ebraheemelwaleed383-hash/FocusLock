package com.focuslock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object Look {
    private val ids = intArrayOf(R.drawable.bg_1, R.drawable.bg_2, R.drawable.bg_3, R.drawable.bg_4, R.drawable.bg_5, R.drawable.bg_6)

    fun allKeys(c: Context): List<String> = (1..6).map { "b$it" } + Prefs.customBgs(c).map { "c:$it" }

    private fun decode(c: Context, key: String, sample: Int): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        if (key.startsWith("b")) BitmapFactory.decodeResource(c.resources, ids[key.substring(1).toInt() - 1], o)
        else BitmapFactory.decodeFile(File(c.filesDir, key.substring(2)).path, o)
    } catch (e: Exception) { null }

    fun thumb(c: Context, key: String): Bitmap? = decode(c, key, 4)

    fun background(c: Context): Drawable? {
        var key = Prefs.bg(c)
        if (key == "none") return null
        if (key == "random") key = allKeys(c).random()
        val b = decode(c, key, 1) ?: return null
        return BitmapDrawable(c.resources, b)
    }
}

class Task(var t: String, var d: Boolean)

object Tasks {
    fun load(c: Context): MutableList<Task> {
        val a = JSONArray(Prefs.raw(c, "tasks"))
        return MutableList(a.length()) { i ->
            val o = a.getJSONObject(i)
            Task(o.getString("t"), o.getBoolean("d"))
        }
    }

    fun save(c: Context, l: List<Task>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("t", it.t).put("d", it.d)) }
        Prefs.putRaw(c, "tasks", a.toString())
    }
}
