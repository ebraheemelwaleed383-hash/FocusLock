package com.focuslock

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

// فلو تايم: ساعة توقيت مفتوحة بدون قفل. عند الانتهاء تُحسب راحة بقدر خُمس وقت الشغل
class FlowActivity : Activity() {
    private lateinit var timer: TextView
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { update(); h.postDelayed(this, 1000) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applyTheme()
        if (Prefs.longOf(this, "flowStart") == 0L) Prefs.putLong(this, "flowStart", System.currentTimeMillis())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(C.BG); setPadding(dp(24), dp(40), dp(24), dp(24))
        }
        root.addView(tv("🌊", 54f).apply { gravity = Gravity.CENTER })
        root.addView(tv(L("فلو تايم", "Flowtime"), 26f, C.TX, true).apply { gravity = Gravity.CENTER })
        timer = tv("", 52f, C.AC, true).apply { gravity = Gravity.CENTER }
        root.put(timer, 20)
        val tip = card()
        tip.addView(tv(L("اشتغل بحرية بدون ضغط. لما تحس تركيزك بيضعف اضغط «خلصت»، وهنحسب لك راحة بقدر خُمس وقت شغلك.",
            "Work freely with no pressure. When your focus fades, tap Done and we'll give you a rest of one fifth of your work time."), 15f, C.TX).apply { gravity = Gravity.CENTER })
        root.put(tip, 20)
        root.put(btn(L("خلصت، وقت الراحة", "Done, time to rest"), true) { finishFlow() }, 20)
        root.put(btn(L("إلغاء", "Cancel")) { Prefs.putLong(this, "flowStart", 0L); finish() }, 8)
        root.applyDir()
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
        update()
    }

    private fun update() {
        val s = (System.currentTimeMillis() - Prefs.longOf(this, "flowStart")) / 1000
        timer.text = String.format(Locale.US, "%02d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60)
    }

    private fun finishFlow() {
        val el = System.currentTimeMillis() - Prefs.longOf(this, "flowStart")
        val rest = maxOf(1L, el / 60_000L / 5L)
        Prefs.putLong(this, "flowStart", 0L)
        Prefs.putLong(this, "breakEnd", System.currentTimeMillis() + rest * 60_000L)
        startActivity(Intent(this, BreakActivity::class.java).putExtra("mode", "flow"))
        finish()
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }
}
