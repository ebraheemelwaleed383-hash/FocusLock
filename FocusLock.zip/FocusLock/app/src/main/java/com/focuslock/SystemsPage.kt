package com.focuslock

import android.app.Activity
import android.content.Intent
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView

// نظم الدراسة: لكل نظام شرح مختصر وشريط متحرك يوضح كيف يعمل وزر تشغيل
class SystemsPage(
    private val a: Activity,
    private val canStart: () -> Boolean,
    private val goTasks: () -> Unit,
    private val startBox: (Int) -> Unit
) {
    private lateinit var content: LinearLayout

    fun build(): View {
        val col = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(18), a.dp(10), a.dp(18), a.dp(24))
        }
        col.put(a.tv(a.L("نظم الدراسة والتركيز", "Study and focus systems"), 24f, C.TX, true), 0)
        col.put(a.tv(a.L("اختر النظام اللي يناسبك وشغّله بضغطة.", "Pick the system that fits you and run it with one tap."), 13f, C.MU), 4)
        content = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        col.put(content, 12)
        refresh()
        return ScrollView(a).apply { addView(col) }
    }

    fun refresh() {
        content.removeAllViews()
        val how = a.card()
        how.addView(a.tv(a.L("إزاي تشتغل النظم؟", "How do the systems work?"), 16f, C.TX, true))
        how.put(a.tv(a.L("الشريط المتحرك تحت كل نظام يوضح تسلسله: 🔵 تركيز (التطبيقات المحظورة مقفولة)، 🟢 استراحة (كل شيء مفتوح)، ⚪ وقت حر. اضغط «ابدأ» وهنشغّل الجولات واحدة بعد الأخرى، مع إشعار عند كل انتقال.",
            "The moving bar under each system shows its sequence: 🔵 focus (blocked apps locked), 🟢 rest (everything open), ⚪ free time. Tap Start and we run the rounds one after another, with a notification at each switch."),
            13f, C.MU).apply { setLineSpacing(0f, 1.25f) }, 4)
        content.put(how, 0)

        Plans.label(a)?.let { lbl ->
            val run = a.card()
            run.addView(a.tv("▶ " + a.L("نظام شغّال", "Running now"), 14f, C.OK, true))
            run.put(a.tv(lbl, 15f, C.TX), 4)
            run.put(a.btn(a.L("إيقاف النظام", "Stop the plan")) {
                Plans.stop(a); BreakAlarm.cancel(a); refresh()
            }, 10)
            content.put(run, 14)
        }
        Plans.all.forEach { content.put(item(it), 14) }
    }

    private fun summary(s: Sys): String {
        val ph = s.phases ?: return ""
        val f = ph.filter { it.first == 'F' }.sumOf { it.second }
        val b = ph.filter { it.first == 'B' }.sumOf { it.second }
        val rounds = ph.count { it.first == 'F' }
        return a.L("$rounds جولات تركيز: $f د تركيز و$b د راحة", "$rounds focus rounds: $f min focus and $b min rest")
    }

    private fun item(s: Sys): View {
        val c = a.card()
        c.addView(a.tv(a.L(s.ar, s.en), 17f, C.TX, true))
        c.put(a.tv(a.L(s.dAr, s.dEn), 13f, C.MU).apply { setLineSpacing(0f, 1.25f) }, 4)
        c.addView(PhaseBarView(a, s.segs), LinearLayout.LayoutParams(MATCH, a.dp(56)).apply { topMargin = a.dp(10) })
        val sm = summary(s)
        if (sm.isNotEmpty()) c.put(a.tv(sm, 12f, C.AC), 2)
        val label = when {
            s.action == "tasks" -> a.L("افتح قائمة المهام", "Open my tasks")
            s.action == "flow" -> a.L("ابدأ فلو تايم", "Start Flowtime")
            s.action == "box" -> a.L("اختر المدة وابدأ", "Pick a length and start")
            else -> a.L("ابدأ هذا النظام", "Start this system")
        }
        c.put(a.btn(label, true) { start(s) }.apply { textSize = 14f }, 10)
        return c
    }

    private fun start(s: Sys) {
        when {
            s.phases != null -> {
                if (!canStart()) return
                a.dlg().setTitle(a.L(s.ar, s.en))
                    .setMessage(a.L("سيبدأ القفل فورًا ويتكرر حسب النظام، وتقدر تنهيه بكلمة مرور الطوارئ. جاهز؟",
                        "The lock starts now and repeats following the system. You can end it with your emergency password. Ready?"))
                    .setPositiveButton(a.L("ابدأ", "Start")) { _, _ -> Plans.start(a, s); a.finish() }
                    .setNegativeButton(a.L("إلغاء", "Cancel"), null)
                    .show()
            }
            s.action == "box" -> {
                val opts = listOf(15, 25, 45, 60, 90)
                a.dlg().setTitle(a.L("مدة الصندوق الزمني", "Time box length"))
                    .setItems(opts.map { a.fmtDur(it * 60_000L) }.toTypedArray()) { _, i -> startBox(opts[i]) }
                    .show()
            }
            s.action == "flow" -> a.startActivity(Intent(a, FlowActivity::class.java))
            s.action == "tasks" -> goTasks()
        }
    }
}
