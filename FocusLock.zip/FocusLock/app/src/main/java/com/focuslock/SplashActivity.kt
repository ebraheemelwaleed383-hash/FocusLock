package com.focuslock

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout

class SplashActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applyTheme()
        val root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF0F1B4D.toInt(), 0xFF4A5CFF.toInt()))
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            alpha = 0f; scaleX = 0.85f; scaleY = 0.85f
        }
        col.addView(ImageView(this).apply { setImageResource(R.drawable.ic_launcher_foreground) }, LinearLayout.LayoutParams(dp(200), dp(200)))
        col.addView(tv("Stay focused", 28f, 0xFFFFFFFF.toInt(), true).apply { gravity = Gravity.CENTER })
        col.addView(tv(L("ركّز في اللي يهمك", "Protect your focus"), 14f, 0xCCFFFFFF.toInt()).apply { gravity = Gravity.CENTER })
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        col.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(600).start()
        Handler(Looper.getMainLooper()).postDelayed({
            val next = if (Prefs.onboarded(this)) MainActivity::class.java else OnboardingActivity::class.java
            startActivity(Intent(this, next))
            finish()
        }, 1300)
    }
}
