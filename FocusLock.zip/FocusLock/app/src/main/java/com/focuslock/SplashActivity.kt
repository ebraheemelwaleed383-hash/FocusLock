package com.focuslock

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout

class SplashActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applyTheme()
        val root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF0A0C10.toInt(), 0xFF1A202C.toInt()))
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            alpha = 0f; scaleX = 0.85f; scaleY = 0.85f
        }
        col.addView(ImageView(this).apply { setImageResource(R.drawable.ic_launcher_foreground) }, LinearLayout.LayoutParams(dp(200), dp(200)))
        col.addView(tv("VIGIL", 30f, 0xFFFFFFFF.toInt(), true).apply { gravity = Gravity.CENTER; letterSpacing = 0.35f })
        col.addView(tv(L("يقظة تحميك من التشتت", "Stay sharp. Stay locked in."), 14f, 0xCCFFFFFF.toInt()).apply { gravity = Gravity.CENTER })
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        col.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(600).start()
        Handler(Looper.getMainLooper()).postDelayed({
            val next = if (Prefs.onboarded(this)) MainActivity::class.java else OnboardingActivity::class.java
            startActivity(Intent(this, next).putExtras(intent))
            finish()
        }, 1300)
    }
}
