package com.focuslock

import android.app.Activity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

// ---------- أدوات واجهة مشتركة بين شاشتي «تحليل التركيز» و«بصمة التركيز» ----------

internal fun Activity.pctS(x: Double): String = Math.round(x * 100).toString() + L("٪", "%")
internal fun Activity.minS(m: Int): String = fmtDur(m * 60_000L)
internal fun Activity.minD(m: Double): String = minS(Math.round(m).toInt())
internal fun dm(day: Long): String { val d = LocalDate.ofEpochDay(day); return "${d.dayOfMonth}/${d.monthValue}" }
internal fun hh(h: Int): String = String.format(Locale.US, "%02d:00", h)
internal fun Activity.num(x: Double): String = Math.round(x).toString()

internal fun Activity.periodPhrase(p: Int): String = when (p) {
    0 -> L("ساعات الصباح", "morning hours")
    1 -> L("ساعات بعد الظهر", "afternoon hours")
    2 -> L("ساعات المساء", "evening hours")
    else -> L("ساعات الليل", "night hours")
}

internal fun Activity.periodName(p: Int): String = when (p) {
    0 -> L("صباحًا (5–12)", "Morning (5–12)")
    1 -> L("بعد الظهر (12–17)", "Afternoon (12–17)")
    2 -> L("مساءً (17–22)", "Evening (17–22)")
    else -> L("ليلًا (22–5)", "Night (22–5)")
}

internal fun Activity.bucketName(b: Int): String = when (b) {
    0 -> L("حتى 15 د", "up to 15 min")
    1 -> L("16–25 د", "16–25 min")
    2 -> L("26–40 د", "26–40 min")
    3 -> L("41–60 د", "41–60 min")
    else -> L("أكثر من 60 د", "over 60 min")
}

internal fun Activity.dowName(d: Int): String =
    DayOfWeek.of(d + 1).getDisplayName(TextStyle.FULL, Locale(Prefs.lang(this)))

internal fun Activity.dowShort(d: Int): String =
    DayOfWeek.of(d + 1).getDisplayName(TextStyle.SHORT, Locale(Prefs.lang(this)))

internal fun Activity.dateS(day: Long): String =
    LocalDate.ofEpochDay(day).format(DateTimeFormatter.ofPattern("d MMM", Locale(Prefs.lang(this))))

internal fun Activity.confName(c: Conf): String = when (c) {
    Conf.NONE -> L("بيانات غير كافية", "Not enough data")
    Conf.LOW -> L("ثقة منخفضة", "Low confidence")
    Conf.MEDIUM -> L("ثقة متوسطة", "Medium confidence")
    Conf.HIGH -> L("ثقة جيدة", "Good confidence")
}

internal fun Activity.sectionCard(title: String, sub: String?): LinearLayout {
    val c = card()
    c.addView(tv(title, 17f, C.TX, true))
    if (sub != null) c.put(tv(sub, 12f, C.MU).apply { setLineSpacing(0f, 1.15f) }, 2)
    return c
}

internal fun Activity.kv(k: String, v: String): LinearLayout {
    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    row.addView(tv(k, 14f, C.MU), LinearLayout.LayoutParams(0, WRAP, 1f))
    row.addView(tv(v, 14f, C.TX, true).apply { gravity = android.view.Gravity.END })
    return row
}

internal fun Activity.note(t: String, color: Int = C.MU): TextView = tv(t, 13f, color).apply { setLineSpacing(0f, 1.2f) }

internal fun Activity.rateRow(label: String, f: Double, right: String): LinearLayout {
    val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    top.addView(tv(label, 13f, C.TX), LinearLayout.LayoutParams(0, WRAP, 1f))
    top.addView(tv(right, 12f, C.MU))
    row.addView(top)
    row.addView(BarView(this).apply { fraction = f.toFloat() }, LinearLayout.LayoutParams(MATCH, dp(8)).apply { topMargin = dp(4) })
    return row
}

internal fun Activity.chart(values: List<Float>, labels: List<String>): BarChartView = BarChartView(this, values, labels, -1)

internal fun LinearLayout.putChart(a: Activity, v: View, top: Int = 10) {
    addView(v, LinearLayout.LayoutParams(MATCH, a.dp(150)).apply { topMargin = a.dp(top) })
}

internal fun Activity.pageColumn(title: String, sub: String): Pair<ScrollView, LinearLayout> {
    val col = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(26), dp(18), dp(24))
    }
    col.put(tv(title, 24f, C.TX, true), 0)
    col.put(tv(sub, 13f, C.MU), 4)
    val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    col.put(content, 12)
    return Pair(ScrollView(this).apply { addView(col) }, content)
}

// ---------- شاشة تحليل التركيز ----------

class IntelPage(private val a: Activity) {
    private lateinit var content: LinearLayout

    fun build(): View {
        val p = a.pageColumn(
            a.L("تحليل التركيز", "Focus Intelligence"),
            a.L("كيف يسير أداؤك؟ أرقام من جلساتك المسجلة، وتوصيات مبنية عليها.", "How are you doing? Numbers from your recorded sessions, and suggestions based on them.")
        )
        content = p.second
        return p.first
    }

    fun refresh() {
        content.removeAllViews()
        val r = try { FocusData.intel(a) } catch (e: Exception) { null }
        if (r == null) {
            val c = a.card()
            c.addView(a.note(a.L("تعذّر تحليل البيانات الآن. بياناتك لم تُمس.", "Could not analyze the data right now. Your data was not touched.")))
            content.put(c, 0)
            return
        }
        try { render(r) } catch (e: Exception) {
            content.put(a.note(a.L("تعذّر عرض جزء من التحليل.", "Part of the analysis could not be shown.")), 12)
        }
        content.put(a.btn(a.L("كيف تُحسب هذه الأرقام؟", "How are these numbers calculated?")) { showHow() }, 14)
    }

    private fun render(r: IntelReport) {
        val today = FocusData.today()
        if (r.perf.attempted == 0 && r.daily14.sum() == 0 && r.weekly8.sum() == 0) {
            val c = a.sectionCard(a.L("لا بيانات بعد", "No data yet"), null)
            c.put(a.note(a.L(
                "ابدأ جلسة تركيز وأكملها، وستظهر هنا تحليلاتك. لا نخترع أي نشاط: ما لم يُسجَّل لا يظهر.",
                "Start and finish a focus session and your analysis will appear here. Nothing is invented: what is not recorded is not shown."
            )), 8)
            content.put(c, 0)
            return
        }
        content.put(coverageCard(r), 0)
        content.put(perfCard(r), 14)
        content.put(timeCard(r, today), 14)
        content.put(patternCard(r), 14)
        content.put(taskCard(r), 14)
        content.put(insightCard(r), 14)
        content.put(recCard(r), 14)
    }

    private fun coverageCard(r: IntelReport): View {
        val c = a.sectionCard(a.L("أساس التحليل", "Basis of the analysis"), null)
        val f = r.firstDay
        val l = r.lastDay
        val line = if (f != null && l != null)
            a.L("${r.analyzed} جلسة من ${a.dateS(f)} إلى ${a.dateS(l)} (آخر ${Th.WINDOW_DAYS} يومًا).", "${r.analyzed} sessions from ${a.dateS(f)} to ${a.dateS(l)} (last ${Th.WINDOW_DAYS} days).")
        else a.L("لا جلسات مسجلة في آخر ${Th.WINDOW_DAYS} يومًا. تظهر الإجماليات اليومية فقط.", "No sessions recorded in the last ${Th.WINDOW_DAYS} days. Only daily totals are shown.")
        c.put(a.tv(line, 14f, C.TX), 8)
        c.put(a.tv(a.confName(r.conf), 13f, if (r.conf == Conf.HIGH || r.conf == Conf.MEDIUM) C.OK else C.WR, true), 6)
        c.put(a.note(a.L(
            "مستوى الثقة يعكس كمية البيانات فقط، وليس يقينًا إحصائيًا. الأنماط لا تظهر إلا حين تكفي بياناتها.",
            "Confidence reflects how much data there is, not statistical certainty. Patterns only appear when their data is sufficient."
        )), 6)
        if (r.logTruncated) c.put(a.note(a.L(
            "سجل تفاصيل الجلسات يحتفظ بآخر ${SessionMath.LOG_CAP} جلسة فقط. ساعات الأيام والأسابيع تُؤخذ من العدّادات اليومية (الأكبر لكل يوم)، فقد تزيد على الأرقام المبنية على تفاصيل الجلسات.",
            "The session-detail log keeps only the latest ${SessionMath.LOG_CAP} sessions. Daily and weekly hours come from the daily counters (the larger value per day), so they can exceed figures built from session details."
        )), 6)
        if (r.excluded > 0) c.put(a.note(a.L(
            "استُبعد ${r.excluded} سجل (غير صالح أو مكرر أو أقل من دقيقة).",
            "${r.excluded} records were left out (invalid, duplicate or under 1 minute)."
        )), 6)
        return c
    }

    private fun perfCard(r: IntelReport): View {
        val p = r.perf
        val c = a.sectionCard(a.L("الأداء العام", "Overall performance"), a.L("مقاس من جلساتك المسجلة", "Measured from your recorded sessions"))
        c.put(a.kv(a.L("وقت التركيز المكتمل", "Completed focus time"), a.minS(p.completedMins)), 10)
        c.put(a.kv(a.L("الجلسات المكتملة", "Completed sessions"), p.doneCount.toString()), 6)
        c.put(a.kv(a.L("خروج مبكر", "Ended early"), p.stopCount.toString() + (if (p.partialMins > 0) " (" + a.minS(p.partialMins) + ")" else "")), 6)
        val cr = p.completionRate
        c.put(a.kv(a.L("نسبة الإكمال", "Completion rate"), if (cr == null) "—" else a.pctS(cr)), 6)
        val avg = p.avgDone
        c.put(a.kv(a.L("متوسط الجلسة المكتملة", "Average completed session"), if (avg == null) "—" else a.minD(avg)), 6)
        val med = p.medianDone
        val q1 = p.p25
        val q3 = p.p75
        if (med != null) {
            val typical = if (q1 != null && q3 != null) a.minD(med) + "  (" + a.minD(q1) + " – " + a.minD(q3) + ")" else a.minD(med)
            c.put(a.kv(a.L("الجلسة المعتادة (وسيط)", "Typical session (median)"), typical), 6)
        }
        if (p.plannedSum > 0) {
            c.put(a.kv(a.L("المخطط مقابل الفعلي (المكتملة)", "Planned vs actual (completed)"), a.minS(p.plannedSum) + " → " + a.minS(p.actualSum)), 6)
            if (p.extended > 0) c.put(a.note(a.L("مددتَ ${p.extended} جلسة عن خطتها.", "You extended ${p.extended} sessions beyond plan.")), 4)
        }
        val reach = p.stopReach
        if (reach != null) c.put(a.note(a.L("الجلسات المبكرة بلغت في المتوسط ${a.pctS(reach)} من مدتها المخططة.", "Early-ended sessions reached on average ${a.pctS(reach)} of their planned time.")), 4)
        val total = Prefs.doneMins(a)
        if (total > 0L) c.put(a.note(a.L(
            "الإجمالي منذ البداية (العداد العام): ${a.minS(total.coerceAtMost(100_000_000L).toInt())} في ${Prefs.doneCount(a)} جلسة.",
            "All-time (overall counter): ${a.minS(total.coerceAtMost(100_000_000L).toInt())} in ${Prefs.doneCount(a)} sessions."
        )), 8)
        return c
    }

    private fun timeCard(r: IntelReport, today: Long): View {
        val c = a.sectionCard(a.L("الوقت والاتجاه", "Time and trend"), a.L("مقاس. لكل يوم نأخذ الأكبر بين العدّاد اليومي وسجل الجلسات حتى لا يضيع يوم اقتُطعت جلساته ولا يُحسب مرتين.", "Measured. For each day we take the larger of the daily counter and the session log, so a day whose sessions were trimmed is not lost and none is counted twice."))
        c.put(a.tv(a.L("آخر 14 يومًا (ساعات)", "Last 14 days (hours)"), 13f, C.MU), 10)
        val dl = (0 until 14).map { LocalDate.ofEpochDay(today - 13 + it).dayOfMonth.toString() }
        c.putChart(a, a.chart(r.daily14.map { it / 60f }, dl), 4)
        c.put(a.tv(a.L("آخر 8 أسابيع (ساعات)", "Last 8 weeks (hours)"), 13f, C.MU), 12)
        val wl = (0 until 8).map { dm(today - 7L * (7 - it) - 6) }
        c.putChart(a, a.chart(r.weekly8.map { it / 60f }, wl), 4)
        val t = r.weekTrend
        val pct = t.pct()
        val line = when {
            !t.valid -> a.L("المقارنة الأسبوعية تحتاج سجلًا لا يقل عن 14 يومًا.", "The weekly comparison needs at least 14 days of history.")
            pct == null -> a.L("آخر 7 أيام: ${a.minS(t.cur)}. لا نشاط مسجل في الأسبوع الذي قبله.", "Last 7 days: ${a.minS(t.cur)}. No activity recorded in the 7 days before.")
            else -> a.L("آخر 7 أيام: ${a.minS(t.cur)} مقابل ${a.minS(t.prev)} قبلها (${if (pct >= 0) "+" else ""}${a.num(pct)}٪).",
                "Last 7 days: ${a.minS(t.cur)} vs ${a.minS(t.prev)} before (${if (pct >= 0) "+" else ""}${a.num(pct)}%).")
        }
        c.put(a.note(line, C.TX), 10)
        val ct = r.completionTrend
        val cc = ct.cur
        val cp = ct.prev
        c.put(a.note(
            if (ct.valid && cc != null && cp != null)
                a.L("نسبة الإكمال: ${a.pctS(cc)} في آخر أسبوعين مقابل ${a.pctS(cp)} في الأسبوعين قبلها.", "Completion rate: ${a.pctS(cc)} over the last 2 weeks vs ${a.pctS(cp)} in the 2 weeks before.")
            else a.L("مقارنة نسبة الإكمال تحتاج 5 جلسات على الأقل في كل من آخر فترتين (أسبوعان لكل فترة).", "Comparing completion rates needs at least 5 sessions in each of the last two 2-week periods.")
        ), 6)
        return c
    }

    private fun patternCard(r: IntelReport): View {
        val c = a.sectionCard(a.L("الأنماط", "Patterns"), a.L("تقديرات من تاريخك، وتظهر فقط حين تكفي البيانات. ليست قواعد ثابتة.", "Estimates from your history, shown only when there is enough data. Not fixed rules."))
        val maxMins = (r.periods.maxOfOrNull { it.doneMins } ?: 0).coerceAtLeast(1)
        c.put(a.tv(a.L("وقت بدء الجلسات المكتملة", "When completed sessions start"), 13f, C.MU), 10)
        for (p in r.periods) {
            val rate = p.doneRate()
            c.put(a.rateRow(a.periodName(p.period), p.doneMins.toDouble() / maxMins,
                a.minS(p.doneMins) + " · " + p.attempts + a.L(" محاولة", " tries") + (if (rate != null && p.attempts >= Th.MIN_BUCKET) " · " + a.pctS(rate) else "")), 6)
        }
        val ph = r.peakHour
        if (ph != null) c.put(a.note(a.L("أكثر دقائق التركيز تبدأ قرب الساعة ${hh(ph)}.", "Most focus minutes start around ${hh(ph)}.")), 8)
        else if (r.perf.doneCount < Th.MIN_DONE_PATTERN) c.put(a.note(a.L("أنماط الساعات تحتاج ${Th.MIN_DONE_PATTERN} جلسات مكتملة على الأقل (لديك ${r.perf.doneCount}).", "Hour patterns need at least ${Th.MIN_DONE_PATTERN} completed sessions (you have ${r.perf.doneCount}).")), 8)

        c.put(a.tv(a.L("أيام الأسبوع (متوسط الساعات لكل يوم)", "Days of the week (average hours per day)"), 13f, C.MU), 14)
        val dowOk = r.spanDays >= Th.MIN_DAYS_DOW && r.dows.all { it.occurrences >= 2 }
        if (dowOk) {
            c.putChart(a, a.chart(r.dows.map { ((it.avg() ?: 0.0) / 60.0).toFloat() }, r.dows.map { a.dowShort(it.dow) }), 4)
        } else c.put(a.note(a.L("تحتاج أيام الأسبوع إلى ${Th.MIN_DAYS_DOW} يومًا على الأقل من السجل.", "Weekdays need at least ${Th.MIN_DAYS_DOW} days of history.")), 4)

        c.put(a.tv(a.L("نسبة الإكمال حسب طول الجلسة المخطط", "Completion by planned session length"), 13f, C.MU), 14)
        var any = false
        for (b in r.buckets) {
            val rate = b.doneRate()
            if (b.attempts == 0 || rate == null) continue
            any = true
            val few = b.attempts < Th.MIN_BUCKET
            c.put(a.rateRow(a.bucketName(b.bucket), rate, a.pctS(rate) + " (" + b.attempts + (if (few) a.L("، عينة صغيرة" , ", small sample") else "") + ")"), 6)
        }
        if (!any) c.put(a.note(a.L("لا جلسات كافية.", "Not enough sessions.")), 4)

        c.put(a.tv(a.L("الانتظام", "Consistency"), 13f, C.MU), 14)
        val k = r.consistency
        val ar = k.activeRate
        if (ar != null) c.put(a.kv(a.L("أيام نشطة (آخر ${k.spanDays} يومًا)", "Active days (last ${k.spanDays} days)"), "${k.activeDays} / ${k.spanDays}"), 6)
        else c.put(a.note(a.L("قياس الانتظام يحتاج 7 أيام من السجل على الأقل.", "Consistency needs at least 7 days of history.")), 6)
        c.put(a.kv(a.L("السلسلة الحالية / الأطول", "Current / longest streak"), "${k.currentStreak} / ${k.longestStreak} " + a.L("يوم", "days")), 6)
        val st = FocusIntel.steadiness(k.weeklyCv)
        if (st != null) c.put(a.kv(a.L("انتظام الساعات الأسبوعية", "Weekly hours steadiness"),
            when (st) { 0 -> a.L("منتظم", "Steady"); 1 -> a.L("متوسط", "Moderate"); else -> a.L("متفاوت", "Uneven") }), 6)
        return c
    }

    private fun taskCard(r: IntelReport): View {
        val c = a.sectionCard(a.L("أداء المهام", "Task performance"), a.L("من الجلسات المرتبطة بمهام فقط. خروج مبكر من جلسة لا يعني أن المهمة فشلت.", "From task-linked sessions only. An early exit from one session never means the task failed."))
        val t = r.tasks
        if (t.linkedSessions == 0) {
            c.put(a.note(a.L("لا جلسات مرتبطة بمهام بعد. اختر مهمة من بطاقة «تركيز الجلسة» في الرئيسية قبل البدء لتظهر هنا.", "No task-linked sessions yet. Pick a task in the Home “Session focus” card before starting to see it here.")), 8)
            return c
        }
        c.put(a.note(a.L("${t.linkedSessions} جلسة مرتبطة بمهام، و${t.unlinkedSessions} غير مرتبطة.", "${t.linkedSessions} task-linked sessions, ${t.unlinkedSessions} unlinked.")), 8)
        for (p in t.perTask.take(5)) {
            c.put(a.tv(p.title, 15f, C.TX, true), 12)
            val status = when (p.taskDone) {
                true -> a.L("المهمة مكتملة", "Task completed")
                false -> a.L("المهمة مفتوحة", "Task open")
                null -> a.L("المهمة لم تعد موجودة", "Task no longer exists")
            }
            c.put(a.note(a.minS(p.mins) + " · " + p.sessions + a.L(" جلسة", " sessions") + " · " + p.days + a.L(" يوم", " days") + " · " + status), 2)
            if (p.plannedSum > 0) c.put(a.note(a.L("مخطط ${a.minS(p.plannedSum)} مقابل فعلي ${a.minS(p.effSumPlanned)}", "Planned ${a.minS(p.plannedSum)} vs actual ${a.minS(p.effSumPlanned)}")), 2)
            if (p.oDone + p.oPart + p.oLater + p.oSkip > 0)
                c.put(a.note(a.L("نتائج المراجعة: أنجزت ${p.oDone} · جزئيًا ${p.oPart} · لاحقًا ${p.oLater}", "Review outcomes: done ${p.oDone} · partly ${p.oPart} · later ${p.oLater}")), 2)
        }
        if (t.byProject.size >= 1 && t.linkedSessions >= 3) {
            c.put(a.tv(a.L("وقت التركيز حسب المشروع", "Focus time by project"), 13f, C.MU), 16)
            val mx = (t.byProject.maxOf { it.second }).coerceAtLeast(1)
            for (pr in t.byProject.take(5)) {
                val name = if (pr.first.isEmpty()) a.L("بدون مشروع", "No project") else pr.first
                c.put(a.rateRow(name, pr.second.toDouble() / mx, a.minS(pr.second)), 6)
            }
        }
        if (t.goalOnly > 0) c.put(a.note(a.L("${t.goalOnly} جلسة بهدف فقط، دون مهمة.", "${t.goalOnly} sessions had a goal but no task.")), 10)
        return c
    }

    private fun insightCard(r: IntelReport): View {
        val c = a.sectionCard(a.L("رؤى", "Insights"), a.L("كل رؤية مبنية على حساب فعلي، وعدد الجلسات مذكور معها.", "Each insight comes from an actual calculation, with its sample size."))
        if (r.insights.isEmpty()) {
            c.put(a.note(a.L("لا رؤى بعد: تظهر حين تبلغ البيانات الحدود الدنيا (مثل ${Th.MIN_ATTEMPTS} محاولات). هذا أفضل من اختلاق رؤية.", "No insights yet: they appear once data reaches the minimums (for example ${Th.MIN_ATTEMPTS} attempts). That is better than inventing one.")), 8)
            return c
        }
        for (i in r.insights) {
            val tag: String
            val col: Int
            when (i.kind) {
                IK.STRENGTH -> { tag = a.L("نقطة قوة", "Strength"); col = C.OK }
                IK.IMPROVE -> { tag = a.L("للتحسين", "To improve"); col = C.WR }
                IK.TASK -> { tag = a.L("مهام", "Tasks"); col = C.AC }
                else -> { tag = a.L("نمط", "Pattern"); col = C.AC }
            }
            c.put(a.tv(tag, 12f, col, true), 12)
            c.put(a.tv(insightText(i), 14f, C.TX).apply { setLineSpacing(0f, 1.2f) }, 2)
        }
        return c
    }

    private fun recCard(r: IntelReport): View {
        val c = a.sectionCard(a.L("توصيات", "Recommendations"), a.L("اقتراحات فقط. لا يتغير أي إعداد أو جدول إلا بقرارك.", "Suggestions only. No setting or schedule changes unless you change it."))
        if (r.recs.isEmpty()) {
            c.put(a.note(a.L("لا توصية الآن: لا شيء في بياناتك يستدعيها.", "No recommendation right now: nothing in your data calls for one.")), 8)
            return c
        }
        for (x in r.recs) c.put(a.tv("• " + recText(x), 14f, C.TX).apply { setLineSpacing(0f, 1.2f) }, 10)
        return c
    }

    private fun insightText(i: Insight): String {
        val n = i.n
        return when (i.code) {
            IC.PEAK_PERIOD -> a.L("${a.pctS(n[1])} من وقت تركيزك المكتمل يبدأ في ${a.periodPhrase(n[0].toInt())} (${n[2].toInt()} جلسة).",
                "${a.pctS(n[1])} of your completed focus time starts in your ${a.periodPhrase(n[0].toInt())} (${n[2].toInt()} sessions).")
            IC.BEST_DAY -> a.L("${a.dowName(n[0].toInt())} هو أقوى أيامك: متوسط ${a.minD(n[1])} مقابل ${a.minD(n[2])} لكل الأيام.",
                "${a.dowName(n[0].toInt())} is your strongest day: about ${a.minD(n[1])} on average vs ${a.minD(n[2])} across all days.")
            IC.COMPLETION_HIGH -> a.L("تُكمل ${a.pctS(n[0])} من الجلسات التي تبدؤها (${n[1].toInt()} جلسة).", "You finish ${a.pctS(n[0])} of the sessions you start (${n[1].toInt()} sessions).")
            IC.COMPLETION_LOW -> a.L("تُكمل ${a.pctS(n[0])} فقط من الجلسات التي تبدؤها (${n[1].toInt()} جلسة)، والباقي ينتهي مبكرًا.", "You finish ${a.pctS(n[0])} of the sessions you start (${n[1].toInt()} sessions); the rest end early.")
            IC.STOPS_BY_PERIOD -> a.L("الجلسات التي تبدأ في ${a.periodPhrase(n[0].toInt())} تنتهي مبكرًا ${a.pctS(n[1])} من المرات (${n[2].toInt()} جلسة)، أكثر من بقية أوقاتك.",
                "Sessions starting in your ${a.periodPhrase(n[0].toInt())} end early ${a.pctS(n[1])} of the time (${n[2].toInt()} sessions), more than at your other times.")
            IC.LENGTH_GAP -> a.L("الجلسات ${a.bucketName(n[0].toInt())} تُكمل ${a.pctS(n[1])} من المرات، مقابل ${a.pctS(n[3])} للجلسات ${a.bucketName(n[2].toInt())} (${n[4].toInt()} و${n[5].toInt()} جلسة).",
                "Sessions of ${a.bucketName(n[0].toInt())} are finished ${a.pctS(n[1])} of the time, vs ${a.pctS(n[3])} for ${a.bucketName(n[2].toInt())} (${n[4].toInt()} and ${n[5].toInt()} sessions).")
            IC.EXTENDED -> a.L("مددتَ ${n[0].toInt()} من ${n[1].toInt()} جلسة مكتملة عن خطتها.", "You extended ${n[0].toInt()} of your ${n[1].toInt()} completed sessions beyond plan.")
            IC.STOP_REACH -> a.L("حين تنهي جلسة مبكرًا تبلغ عادةً نحو ${a.pctS(n[0])} من وقتها المخطط (${n[1].toInt()} جلسة).", "When you end a session early you typically reach about ${a.pctS(n[0])} of its planned time (${n[1].toInt()} sessions).")
            IC.TREND_UP -> a.L("وقت تركيزك في آخر 7 أيام أعلى بنسبة ${a.num(n[0])}٪ عن الأسبوع قبله (${a.minS(n[1].toInt())} مقابل ${a.minS(n[2].toInt())}).",
                "Your focus time over the last 7 days is ${a.num(n[0])}% higher than the week before (${a.minS(n[1].toInt())} vs ${a.minS(n[2].toInt())}).")
            IC.TREND_DOWN -> a.L("وقت تركيزك في آخر 7 أيام أقل بنسبة ${a.num(-n[0])}٪ عن الأسبوع قبله (${a.minS(n[1].toInt())} مقابل ${a.minS(n[2].toInt())}).",
                "Your focus time over the last 7 days is ${a.num(-n[0])}% lower than the week before (${a.minS(n[1].toInt())} vs ${a.minS(n[2].toInt())}).")
            IC.STOPS_UP -> a.L("ارتفع الخروج المبكر من ${a.pctS(n[1])} إلى ${a.pctS(n[0])} خلال آخر أسبوعين (${n[2].toInt()} مقابل ${n[3].toInt()} جلسة).",
                "Early exits rose from ${a.pctS(n[1])} to ${a.pctS(n[0])} over the last 2 weeks (${n[2].toInt()} vs ${n[3].toInt()} sessions).")
            IC.STOPS_DOWN -> a.L("انخفض الخروج المبكر من ${a.pctS(n[1])} إلى ${a.pctS(n[0])} خلال آخر أسبوعين (${n[2].toInt()} مقابل ${n[3].toInt()} جلسة).",
                "Early exits fell from ${a.pctS(n[1])} to ${a.pctS(n[0])} over the last 2 weeks (${n[2].toInt()} vs ${n[3].toInt()} sessions).")
            IC.STREAK -> a.L("لديك سلسلة تركيز ${n[0].toInt()} أيام متتالية (أطول سلسلة مسجلة ${n[1].toInt()}).", "You are on a ${n[0].toInt()}-day focus streak (longest recorded: ${n[1].toInt()}).")
            IC.CONSIST_HIGH -> a.L("ركّزتَ في ${n[0].toInt()} من آخر ${n[1].toInt()} يومًا.", "You focused on ${n[0].toInt()} of the last ${n[1].toInt()} days.")
            IC.CONSIST_LOW -> a.L("ركّزتَ في ${n[0].toInt()} فقط من آخر ${n[1].toInt()} يومًا.", "You focused on only ${n[0].toInt()} of the last ${n[1].toInt()} days.")
            IC.TASK_TOP -> a.L("«${i.s[0]}» نالت أكثر تركيز مرتبط بمهمة: ${a.minS(n[0].toInt())} (${a.pctS(n[1])} من وقت المهام، ${n[2].toInt()} جلسة).",
                "“${i.s[0]}” got the most task-linked focus: ${a.minS(n[0].toInt())} (${a.pctS(n[1])} of task time, ${n[2].toInt()} sessions).")
            IC.TASK_CARRIED -> a.L("«${i.s[0]}»: اخترتَ «أكمل لاحقًا» في ${n[0].toInt()} جلسات عبر ${n[1].toInt()} أيام، وما زالت مفتوحة.",
                "“${i.s[0]}”: you chose “continue later” in ${n[0].toInt()} sessions across ${n[1].toInt()} days and it is still open.")
        }
    }

    private fun recText(x: Rec): String {
        val n = x.n
        return when (x.code) {
            RC.SHORTER -> a.L("جرّب جلسات حتى ${n[0].toInt()} دقيقة: هذا الطول يُكمل ${a.pctS(n[1])} من المرات مقابل ${a.pctS(n[2])} للأطول.",
                "Try sessions of up to ${n[0].toInt()} minutes: that length is finished ${a.pctS(n[1])} of the time vs ${a.pctS(n[2])} for longer ones.")
            RC.LONGER -> a.L("تمدّد جلساتك كثيرًا (${n[1].toInt()} من ${n[2].toInt()}). جرّب تخطيط جلسات بحدود ${n[0].toInt()} دقيقة.",
                "You often extend sessions (${n[1].toInt()} of ${n[2].toInt()}). Try planning about ${n[0].toInt()} minutes.")
            RC.TIME_OF_DAY -> a.L("إن كان الاختيار لك، ضع جلساتك في ${a.periodPhrase(n[0].toInt())}: تُكمل ${a.pctS(n[1])} منها مقابل ${a.pctS(n[3])} في ${a.periodPhrase(n[2].toInt())}.",
                "If you can choose, schedule sessions in your ${a.periodPhrase(n[0].toInt())}: ${a.pctS(n[1])} get finished vs ${a.pctS(n[3])} in your ${a.periodPhrase(n[2].toInt())}.")
            RC.SPLIT_TASK -> a.L("قسّم «${x.s[0]}» إلى خطوات أصغر: ${n[0].toInt()} من جلساتها الـ${n[1].toInt()} انتهت «جزئيًا» أو «لاحقًا» ولا خطوات محددة لها.",
                "Split “${x.s[0]}” into smaller steps: ${n[0].toInt()} of its ${n[1].toInt()} sessions ended as “partly” or “later” and it has no defined steps.")
            RC.CONSISTENCY -> {
                val base = a.L("ركّزتَ في ${n[0].toInt()} من ${n[1].toInt()} يومًا. اختر يومًا أو يومين ثابتين في الأسبوع للبدء.", "You focused on ${n[0].toInt()} of ${n[1].toInt()} days. Pick one or two fixed days a week to start.")
                if (n[2] >= 0.0) base + a.L(" أقوى أيامك ${a.dowName(n[2].toInt())}.", " Your strongest day is ${a.dowName(n[2].toInt())}.") else base
            }
            RC.REDUCE_STOPS ->
                if (n[0] >= 0.0) a.L("الخروج المبكر يتركز في ${a.periodPhrase(n[0].toInt())} (${a.pctS(n[1])} من ${n[2].toInt()} جلسة). جرّب جلسات أقصر هناك أو انقلها لوقت آخر.",
                    "Early exits concentrate in your ${a.periodPhrase(n[0].toInt())} (${a.pctS(n[1])} of ${n[2].toInt()} sessions). Try shorter sessions then, or move them to another time.")
                else a.L("الخروج المبكر في ارتفاع (${a.pctS(n[1])} من ${n[2].toInt()} جلسة). جرّب جلسات أقصر حتى يستقر.",
                    "Early exits are rising (${a.pctS(n[1])} of ${n[2].toInt()} sessions). Try shorter sessions until it settles.")
        }
    }

    private fun showHow() {
        val msg = a.L(
            "• وقت التركيز المكتمل: مجموع دقائق الجلسات التي انتهت كاملة فقط.\n" +
            "• الخروج المبكر: جلسة أُنهيت قبل موعدها. التطبيق لا يميّز بين «أُلغيت» و«قوطعت»، فكلاهما خروج مبكر.\n" +
            "• تُستبعد الجلسات الجارية والمكررة والسجلات غير الصالحة والجلسات التي أقل من دقيقة.\n" +
            "• نسبة الإكمال = المكتملة ÷ (المكتملة + المبكرة)، ولا تُعرض إن كان المقام صفرًا.\n" +
            "• الأنماط (الساعات، الأيام، الطول) تُحسب من ساعة بداية الجلسة بتوقيت جهازك، ولا تظهر إلا بعد حد أدنى من البيانات.\n" +
            "• الأسابيع تُقارن بالأسابيع السابقة فقط حين تغطي بياناتك الفترتين.\n" +
            "• المقاس = أرقام مسجلة. التقدير = نمط مستنتج وقد يتغير.\n" +
            "• كل الحسابات على جهازك، ولا يُرسل شيء لأي خدمة.",
            "• Completed focus time: minutes of sessions that ran to the end only.\n" +
            "• Ended early: a session ended before its time. The app cannot tell “cancelled” from “interrupted”, so both count as early exits.\n" +
            "• Running sessions, duplicates, invalid records and sessions under 1 minute are excluded.\n" +
            "• Completion rate = completed ÷ (completed + ended early); not shown when the denominator is zero.\n" +
            "• Patterns (hours, days, length) use the session start time on your device clock and appear only after a minimum amount of data.\n" +
            "• Weeks are compared with earlier weeks only when your data covers both periods.\n" +
            "• Measured = recorded numbers. Estimated = an inferred pattern that may change.\n" +
            "• All calculations run on your device; nothing is sent to any service."
        )
        a.dlg().setTitle(a.L("كيف تُحسب الأرقام", "How numbers are calculated")).setMessage(msg).setPositiveButton(a.L("حسنًا", "OK"), null).show()
    }
}
