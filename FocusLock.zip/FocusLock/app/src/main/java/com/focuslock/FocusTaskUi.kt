package com.focuslock

import android.app.Activity
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Paint
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

// بطاقة «تركيز الجلسة» في الشاشة الرئيسية: المهمة والهدف المختاران للجلسة القادمة
class FocusCard(private val a: Activity) {
    val view: LinearLayout = a.card()

    init { refresh() }

    fun refresh() {
        view.removeAllViews()
        view.addView(a.tv(a.L("🎯 تركيز الجلسة", "🎯 Session focus"), 14f, C.MU))
        val t = FocusTasks.current(a)
        if (t == null) {
            val g = FocusTasks.goal(a)
            view.put(a.tv(a.L("لم تختر مهمة. تقدر تبدأ بدونها، أو تختار مهمة وهدفًا للجلسة.", "No task picked. You can start without one, or pick a task and a goal for this session."), 14f, C.TX), 6)
            if (g.isNotEmpty()) view.put(a.tv(a.L("الهدف: ", "Goal: ") + g, 14f, C.AC), 4)
        } else {
            view.put(a.tv(t.t, 18f, C.TX, true), 6)
            FocusTaskUi.meta(a, t).takeIf { it.isNotEmpty() }?.let { view.put(a.tv(it, 12f, C.MU), 2) }
            val g = FocusTasks.goal(a)
            if (g.isNotEmpty()) view.put(a.tv(a.L("هدف الجلسة: ", "Session goal: ") + g, 14f, C.AC), 4)
            if (t.steps.isNotEmpty()) {
                val bar = BarView(a, C.LN, C.AC).apply { fraction = FocusLogic.fraction(t) }
                view.addView(bar, LinearLayout.LayoutParams(MATCH, a.dp(8)).apply { topMargin = a.dp(8) })
            }
        }
        val row = LinearLayout(a)
        row.addView(a.btn(if (t == null) a.L("اختر مهمة أو أنشئ واحدة", "Pick or create a task") else a.L("تعديل", "Edit"), t == null) {
            FocusTaskUi.showPicker(a, t?.id ?: "") { refresh() }
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = a.dp(4) })
        if (t != null || FocusTasks.goal(a).isNotEmpty()) {
            row.addView(a.btn(a.L("إزالة", "Clear")) { FocusTasks.clearSelection(a); refresh() },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = a.dp(4) })
        }
        view.put(row, 10)
    }
}

object FocusTaskUi {
    // النافذة المعروضة حاليًا (مراجع ضعيفة): تمنع ظهور نافذتين من onCreate وonResume، دون حارس ثابت يُسكت المراجعة للأبد
    private var reviewDlg: java.lang.ref.WeakReference<AlertDialog>? = null
    private var reviewOwner: java.lang.ref.WeakReference<Activity>? = null

    private fun reviewOpen(): Boolean {
        val d = reviewDlg?.get() ?: return false
        val o = reviewOwner?.get() ?: return false
        return d.isShowing && !o.isFinishing && !o.isDestroyed
    }

    private fun dot(p: Int) = when (p) { 2 -> "🔴"; 1 -> "🟡"; else -> "🟢" }

    private fun field(a: Activity, hint: String) = EditText(a).apply {
        this.hint = hint
        setTextColor(C.TX); setHintTextColor(C.MU)
        background = a.rounded(C.BG, 12, C.LN)
        setPadding(a.dp(14), a.dp(10), a.dp(14), a.dp(10))
        textSize = 14f
    }

    private fun chip(a: Activity, label: String, on: Boolean, click: () -> Unit) = a.tv(label, 13f, if (on) C.ON else C.TX).apply {
        gravity = Gravity.CENTER
        background = a.rounded(if (on) C.AC else C.BG, 12, C.LN)
        setPadding(a.dp(12), a.dp(8), a.dp(12), a.dp(8))
        setOnClickListener { click() }
    }

    // سطر معلومات المهمة: المشروع، تقدم الخطوات، دقائق التركيز
    fun meta(a: Activity, t: Task): String {
        val parts = ArrayList<String>()
        if (t.proj.isNotEmpty()) parts.add("📁 " + t.proj)
        val (d, n) = FocusLogic.progress(t)
        if (n > 0) parts.add("☑ $d/$n")
        if (t.focusMins > 0) parts.add("⏱ " + a.L("${t.focusMins} د", "${t.focusMins} min"))
        if (t.later) parts.add(a.L("⏭ للاستكمال لاحقًا", "⏭ continue later"))
        return parts.joinToString("  ·  ")
    }

    // نص سطر المهمة في صفحة المهام: العنوان ثم سطر صغير باهت بالمعلومات
    fun rowLabel(a: Activity, t: Task): CharSequence {
        val m = meta(a, t)
        if (m.isEmpty()) return t.t
        val sb = SpannableStringBuilder(t.t)
        val st = sb.length
        sb.append("\n").append(m)
        sb.setSpan(RelativeSizeSpan(0.8f), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(ForegroundColorSpan(C.MU), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sb
    }

    // ---------- قبل الجلسة: اختيار مهمة موجودة أو إنشاء مهمة، مشروع، هدف، قائمة خطوات ----------
    fun showPicker(a: Activity, preselect: String, onDone: () -> Unit) {
        val all = Tasks.load(a)
        var selId = preselect.ifEmpty { FocusTasks.selectedId(a) }
        if (all.none { it.id == selId && !it.d }) selId = ""
        var pri = all.firstOrNull { it.id == selId }?.p ?: 1
        var priTouched = false

        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(18), a.dp(6), a.dp(18), a.dp(4))
        }
        val sv = ScrollView(a).apply { addView(box) }
        val listBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val stepsBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val projChips = LinearLayout(a)
        val priRow = LinearLayout(a)
        val newEt = field(a, a.L("مهمة جديدة (اختياري)", "New task (optional)"))
        val projEt = field(a, a.L("المشروع أو التصنيف (اختياري)", "Project or category (optional)"))
        val goalEt = field(a, a.L("هدف هذه الجلسة (اختياري)", "Goal for this session (optional)")).apply { setText(FocusTasks.goal(a)) }
        val stepEt = field(a, a.L("خطوة جديدة في القائمة", "New checklist step"))

        fun sel(): Task? = all.firstOrNull { it.id == selId && !it.d }

        fun renderSteps() {
            stepsBox.removeAllViews()
            val t = sel() ?: return
            t.steps.forEachIndexed { i, s ->
                val row = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL }
                row.addView(a.tv((if (s.done) "☑ " else "☐ ") + s.text, 14f, if (s.done) C.MU else C.TX), LinearLayout.LayoutParams(0, WRAP, 1f))
                row.addView(a.tv("✕", 15f, C.MU).apply {
                    setPadding(a.dp(12), a.dp(6), a.dp(6), a.dp(6))
                    setOnClickListener { t.steps.removeAt(i); renderSteps() }
                })
                stepsBox.put(row, 2)
            }
        }

        fun renderPri() {
            priRow.removeAllViews()
            listOf(2 to a.L("🔴 عالية", "🔴 High"), 1 to a.L("🟡 متوسطة", "🟡 Medium"), 0 to a.L("🟢 عادية", "🟢 Low")).forEach { (v, n) ->
                priRow.addView(chip(a, n, pri == v) { pri = v; priTouched = true; renderPri() },
                    LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = a.dp(3); marginEnd = a.dp(3) })
            }
        }

        fun renderList() {
            listBox.removeAllViews()
            val pending = all.filter { !it.d }.sortedByDescending { it.p }.take(30)
            if (pending.isEmpty()) listBox.put(a.tv(a.L("لا توجد مهام معلّقة. أنشئ مهمة جديدة بالأسفل.", "No pending tasks. Create one below."), 13f, C.MU), 4)
            pending.forEach { t ->
                val on = t.id == selId
                val row = LinearLayout(a).apply {
                    orientation = LinearLayout.VERTICAL
                    background = a.rounded(if (on) C.BG else C.SF, 12, if (on) C.AC else C.LN)
                    setPadding(a.dp(12), a.dp(8), a.dp(12), a.dp(8))
                    setOnClickListener {
                        selId = if (on) "" else t.id
                        projEt.setText(sel()?.proj ?: "")
                        pri = sel()?.p ?: pri
                        priTouched = false
                        renderList(); renderSteps(); renderPri()
                    }
                }
                row.addView(a.tv(dot(t.p) + " " + t.t, 15f, C.TX, on))
                meta(a, t).takeIf { it.isNotEmpty() }?.let { row.addView(a.tv(it, 12f, C.MU)) }
                listBox.put(row, 6)
            }
        }

        box.addView(a.tv(a.L("اختر مهمة معلّقة", "Pick a pending task"), 13f, C.MU))
        box.put(listBox, 4)
        box.put(a.tv(a.L("أو أنشئ مهمة", "Or create one"), 13f, C.MU), 14)
        box.put(newEt, 4)
        box.put(projEt, 8)
        val projs = FocusTasks.projects(a)
        if (projs.isNotEmpty()) {
            projs.take(12).forEach { p ->
                projChips.addView(chip(a, p, false) { projEt.setText(p) },
                    LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = a.dp(6) })
            }
            box.put(HorizontalScrollView(a).apply { isHorizontalScrollBarEnabled = false; addView(projChips) }, 6)
        }
        box.put(a.tv(a.L("الأولوية", "Priority"), 13f, C.MU), 12)
        box.put(priRow, 4)
        box.put(a.tv(a.L("هدف الجلسة", "Session goal"), 13f, C.MU), 12)
        box.put(goalEt, 4)
        box.put(a.tv(a.L("قائمة الخطوات (تظهر أثناء الجلسة)", "Checklist (shown during the session)"), 13f, C.MU), 12)
        box.put(stepsBox, 4)
        val addRow = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL }
        addRow.addView(stepEt, LinearLayout.LayoutParams(0, WRAP, 1f))
        addRow.addView(a.tv("＋", 24f, C.AC, true).apply {
            setPadding(a.dp(14), a.dp(4), a.dp(6), a.dp(4))
            setOnClickListener {
                val x = stepEt.text.toString().trim()
                val t = sel()
                if (x.isEmpty()) return@setOnClickListener
                if (t == null) Toast.makeText(a, a.L("اختر مهمة أو أنشئها أولًا", "Pick or create a task first"), Toast.LENGTH_SHORT).show()
                else { t.steps.add(Step(x)); stepEt.text.clear(); renderSteps() }
            }
        })
        box.put(addRow, 6)
        projEt.setText(sel()?.proj ?: "")
        renderList(); renderSteps(); renderPri()

        a.dlg().setTitle(a.L("مهمة الجلسة", "Session task")).setView(sv)
            .setPositiveButton(a.L("حفظ", "Save")) { _, _ ->
                val nt = newEt.text.toString().trim()
                val proj = projEt.text.toString().trim()
                val ps = stepEt.text.toString().trim()
                val prevId = sel()?.id ?: ""
                val stepsSnap = sel()?.steps?.map { Step(it.text, it.done) }
                val touched = priTouched
                val priNow = pri
                var targetId = ""
                // التعديلات تُطبَّق على أحدث نسخة محفوظة لا على القائمة التي فُتحت بها النافذة، فلا نطمس ما تغيّر أثناء فتحها
                // (مثل دقائق التركيز المضافة عند انتهاء جلسة)
                Tasks.update(a) { fresh ->
                    val prev = TaskOps.find(fresh, prevId)?.takeIf { !it.d }
                    if (prev != null && stepsSnap != null) prev.steps = stepsSnap.map { Step(it.text, it.done) }.toMutableList()
                    var target: Task? = prev
                    if (nt.isNotEmpty()) {
                        val t = Task(nt, false, priNow)
                        t.id = TaskCodec.newId()
                        t.proj = proj
                        fresh.add(t)
                        target = t
                    } else if (target != null) {
                        target.proj = proj
                        if (touched) target.p = priNow
                    }
                    if (ps.isNotEmpty() && target != null) target.steps.add(Step(ps))
                    targetId = target?.id ?: ""
                }
                FocusTasks.select(a, targetId)
                FocusTasks.setGoal(a, goalEt.text.toString().trim())
                onDone()
            }
            .setNeutralButton(a.L("بدون مهمة", "No task")) { _, _ ->
                FocusTasks.select(a, "")
                FocusTasks.setGoal(a, goalEt.text.toString().trim())
                onDone()
            }
            .setNegativeButton(a.L("إلغاء", "Cancel"), null)
            .show()
    }

    // ---------- أثناء الجلسة: بطاقة في شاشة القفل (المهمة، الهدف، التقدم، الخطوات) ----------
    // لا يرمي استثناءً أبدًا: شاشة القفل تبقى تعمل حتى لو تعذّر رسم بطاقة المهمة
    fun lockCard(a: Activity, dark: Boolean, txc: Int, muc: Int, track: Int): LinearLayout? =
        try { buildLockCard(a, dark, txc, muc, track) } catch (_: Exception) { null }

    private fun buildLockCard(a: Activity, dark: Boolean, txc: Int, muc: Int, track: Int): LinearLayout? {
        val rec = SessionLog.openRec(a) ?: return null
        if (rec.taskId.isEmpty() && rec.goal.isEmpty()) return null
        val tasks = Tasks.load(a)
        val t = tasks.firstOrNull { it.id == rec.taskId }
        val box = a.card()
        if (dark) box.background = a.rounded(0x77000000.toInt(), 16, 0x33FFFFFF)
        box.addView(a.tv(a.L("🎯 تركّز الآن على", "🎯 Focusing on"), 13f, muc))
        val title = t?.t ?: rec.taskTitle.ifEmpty { a.L("جلسة حرّة", "Free session") }
        box.put(a.tv(title, 18f, txc, true), 4)
        if (rec.goal.isNotEmpty()) box.put(a.tv(a.L("الهدف: ", "Goal: ") + rec.goal, 14f, txc), 4)
        if (t != null && t.steps.isNotEmpty()) {
            val bar = BarView(a, track, C.AC).apply { fraction = FocusLogic.fraction(t) }
            val cnt = a.tv("", 12f, muc)
            fun upd() {
                val (d, n) = FocusLogic.progress(t)
                cnt.text = a.L("التقدم: $d من $n", "Progress: $d of $n")
                bar.fraction = FocusLogic.fraction(t)
            }
            upd()
            box.put(cnt, 8)
            box.addView(bar, LinearLayout.LayoutParams(MATCH, a.dp(8)).apply { topMargin = a.dp(4) })
            t.steps.forEach { s ->
                box.addView(CheckBox(a).apply {
                    text = s.text
                    setTextColor(txc)
                    buttonTintList = ColorStateList.valueOf(C.AC)
                    isChecked = s.done
                    if (s.done) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                    setOnCheckedChangeListener { _, on ->
                        s.done = on
                        paintFlags = if (on) paintFlags or Paint.STRIKE_THRU_TEXT_FLAG else paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                        // تحميل وتعديل وحفظ متزامن على أحدث نسخة (نطابق الخطوة بموضعها ونصها قبل التعديل)
                        val idx = t.steps.indexOf(s)
                        Tasks.update(a) { fresh ->
                            val fs = TaskOps.find(fresh, t.id)?.steps?.getOrNull(idx)
                            if (fs != null && fs.text == s.text) fs.done = on
                        }
                        upd()
                    }
                })
            }
        }
        return box
    }

    // ---------- بعد الجلسة: تصنيف النتيجة وتحديث المهمة ----------
    fun maybeReview(a: Activity, onDone: () -> Unit) {
        if (Prefs.active(a) || a.isFinishing || a.isDestroyed || reviewOpen()) return
        val rec = FocusTasks.pendingReview(a) ?: return
        showReview(a, rec, onDone)
    }

    private fun showReview(a: Activity, rec: SessionRec, onDone: () -> Unit) {
        val tasks = Tasks.load(a)
        val t = tasks.firstOrNull { it.id == rec.taskId }
        var pri = t?.p ?: 1
        var priTouched = false
        var remIdx = 0
        var dialog: AlertDialog? = null

        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(18), a.dp(6), a.dp(18), a.dp(4))
        }
        val sv = ScrollView(a).apply { addView(box) }
        val title = t?.t ?: rec.taskTitle.ifEmpty { a.L("الجلسة", "The session") }
        box.addView(a.tv(title, 17f, C.TX, true))
        val minsTxt = if (rec.status == "stop") a.L("خرجت بعد ${rec.actual} د من ${rec.planned} د", "You left after ${rec.actual} of ${rec.planned} min")
        else a.L("${rec.actual} دقيقة تركيز", "${rec.actual} focused minutes")
        box.put(a.tv(minsTxt, 13f, C.MU), 2)
        if (rec.goal.isNotEmpty()) box.put(a.tv(a.L("الهدف: ", "Goal: ") + rec.goal, 14f, C.AC), 6)

        if (t != null && t.steps.isNotEmpty()) {
            box.put(a.tv(a.L("حدّث تقدمك في الخطوات", "Update your steps"), 13f, C.MU), 12)
            t.steps.forEach { s ->
                box.addView(CheckBox(a).apply {
                    text = s.text; setTextColor(C.TX); buttonTintList = ColorStateList.valueOf(C.AC); isChecked = s.done
                    setOnCheckedChangeListener { _, on -> s.done = on }
                })
            }
        }
        val noteEt = field(a, a.L("ملاحظة عن الجلسة (اختياري)", "Note about the session (optional)"))
        box.put(noteEt, 12)

        val priRow = LinearLayout(a)
        fun renderPri() {
            priRow.removeAllViews()
            listOf(2 to a.L("🔴 عالية", "🔴 High"), 1 to a.L("🟡 متوسطة", "🟡 Medium"), 0 to a.L("🟢 عادية", "🟢 Low")).forEach { (v, n) ->
                priRow.addView(chip(a, n, pri == v) { pri = v; priTouched = true; renderPri() },
                    LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = a.dp(3); marginEnd = a.dp(3) })
            }
        }
        val remRow = LinearLayout(a)
        fun renderRem() {
            remRow.removeAllViews()
            listOf(a.L("بدون", "None"), a.L("بعد نصف ساعة", "In 30 min"), a.L("بعد ساعتين", "In 2 h"), a.L("بكرة 9 ص", "Tomorrow 9 am")).forEachIndexed { i, n ->
                remRow.addView(chip(a, n, remIdx == i) { remIdx = i; renderRem() },
                    LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = a.dp(2); marginEnd = a.dp(2) })
            }
        }
        var doneCb: CheckBox? = null
        if (t != null) {
            box.put(a.tv(a.L("أولوية المهمة", "Task priority"), 13f, C.MU), 12)
            box.put(priRow, 4)
            renderPri()
            box.put(a.tv(a.L("جلسة أخرى على نفس المهمة؟ ذكّرني:", "Another session on this task? Remind me:"), 13f, C.MU), 12)
            box.put(remRow, 4)
            renderRem()
            val cb = CheckBox(a).apply {
                text = a.L("أعلّم المهمة كاملة (تأكيد منّي)", "Mark the whole task complete (my confirmation)")
                setTextColor(C.TX); buttonTintList = ColorStateList.valueOf(C.AC)
            }
            doneCb = cb
            box.put(cb, 10)
        }

        fun submit(outcome: String) {
            val now = System.currentTimeMillis()
            val at = when (remIdx) { 1 -> now + 30 * 60_000L; 2 -> now + 2 * 3_600_000L; 3 -> FocusTasks.tomorrowMorning(); else -> 0L }
            val mark = doneCb?.isChecked == true
            // لقطة حالة الخطوات تُدمج في أحدث نسخة محفوظة من المهمة (لا نحفظ القائمة القديمة التي فُتحت بها النافذة)
            val snap = t?.steps?.map { Step(it.text, it.done) }
            FocusTasks.review(a, rec, snap, outcome, mark, noteEt.text.toString(), if (priTouched) pri else null, at)
            if (mark) Sfx.task(a, Sfx.DONE)
            dialog?.dismiss()
            if (at > 0L && !mark) FocusReminders.warnIfBlocked(a)
            onDone()
        }

        box.put(a.tv(a.L("كيف كانت الجلسة؟", "How did it go?"), 14f, C.TX, true), 16)
        val outRow = LinearLayout(a)
        outRow.addView(a.btn(a.L("✅ أنجزت", "✅ Done"), true) { submit(FocusLogic.DONE) }.apply { textSize = 13f; setPadding(a.dp(4), a.dp(12), a.dp(4), a.dp(12)) },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = a.dp(3) })
        outRow.addView(a.btn(a.L("🟡 جزئيًا", "🟡 Partly")) { submit(FocusLogic.PART) }.apply { textSize = 13f; setPadding(a.dp(4), a.dp(12), a.dp(4), a.dp(12)) },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = a.dp(3); marginEnd = a.dp(3) })
        outRow.addView(a.btn(a.L("⏭ أكمل لاحقًا", "⏭ Later")) { submit(FocusLogic.LATER) }.apply { textSize = 13f; setPadding(a.dp(4), a.dp(12), a.dp(4), a.dp(12)) },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = a.dp(3) })
        box.put(outRow, 8)

        val shown = a.dlg().setTitle(a.L("انتهت الجلسة", "Session finished")).setView(sv).setCancelable(false)
            .setNegativeButton(a.L("ليس الآن", "Not now")) { _, _ -> FocusTasks.snoozeReview(a); onDone() }
            .show()
        dialog = shown
        reviewDlg = java.lang.ref.WeakReference(shown)
        reviewOwner = java.lang.ref.WeakReference(a)
    }
}
