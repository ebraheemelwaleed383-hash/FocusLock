package com.focuslock

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class AppLimit(val pkg: String, var allowMin: Int, var usedMs: Long = 0L, var blockedUntil: Long = 0L, var graceUntil: Long = 0L)

// مؤقت لكل تطبيق: لو انتهى الوقت المسموح يُقفل 12 ساعة ثم يُفتح من جديد
object Limits {
    const val BLOCK_MS = 12 * 3_600_000L
    const val GRACE_MS = 10 * 60_000L
    private var cache: MutableList<AppLimit>? = null

    @Synchronized
    fun all(c: Context): MutableList<AppLimit> {
        cache?.let { return it }
        val a = JSONArray(Prefs.raw(c, "limits"))
        val l = MutableList(a.length()) { i ->
            val o = a.getJSONObject(i)
            AppLimit(o.getString("p"), o.getInt("a"), o.optLong("u"), o.optLong("b"), o.optLong("g"))
        }
        cache = l
        return l
    }

    @Synchronized
    fun save(c: Context) {
        val a = JSONArray()
        all(c).forEach { a.put(JSONObject().put("p", it.pkg).put("a", it.allowMin).put("u", it.usedMs).put("b", it.blockedUntil).put("g", it.graceUntil)) }
        Prefs.putRaw(c, "limits", a.toString())
    }

    fun find(c: Context, pkg: String): AppLimit? = all(c).firstOrNull { it.pkg == pkg }

    fun set(c: Context, pkg: String, min: Int) {
        val l = find(c, pkg)
        if (l == null) all(c).add(AppLimit(pkg, min)) else l.allowMin = min
        save(c)
    }

    fun remove(c: Context, pkg: String) { all(c).removeAll { it.pkg == pkg }; save(c) }

    fun remainingMs(l: AppLimit): Long = maxOf(0L, l.allowMin * 60_000L - l.usedMs)

    fun blockedNow(c: Context, pkg: String): Boolean {
        val l = find(c, pkg) ?: return false
        val now = System.currentTimeMillis()
        if (l.graceUntil > now) return false
        if (l.blockedUntil > now) return true
        if (l.blockedUntil != 0L) { l.blockedUntil = 0L; l.usedMs = 0L; save(c) }
        return false
    }

    // يضيف وقت استخدام. يرجع true لو انتهى الوقت المسموح الآن
    fun addUsage(c: Context, pkg: String, ms: Long): Boolean {
        val l = find(c, pkg) ?: return false
        val now = System.currentTimeMillis()
        if (l.graceUntil > now || l.blockedUntil > now) return false
        l.usedMs += ms
        if (l.usedMs >= l.allowMin * 60_000L) { l.blockedUntil = now + BLOCK_MS; save(c); return true }
        save(c)
        return false
    }

    fun grace(c: Context, pkg: String) { find(c, pkg)?.graceUntil = System.currentTimeMillis() + GRACE_MS; save(c) }
}
