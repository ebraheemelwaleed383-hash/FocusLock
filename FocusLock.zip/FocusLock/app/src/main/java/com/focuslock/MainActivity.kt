package com.focuslock

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    companion object {
        var tabKeep = 0
        const val TAB_USAGE = 1
        const val TAB_SYSTEMS = 2
        const val TAB_TASKS = 3
        const val TAB_APPS = 4
        const val TAB_STYLE = 5
        const val TAB_SETTINGS = 6
    }

    private class Row(val pkg: String, val name: String, val cb: CheckBox)

    private val picked = HashSet<String>()
    private val rows = ArrayList<Row>()
    private val refreshers = ArrayList<() -> Unit>()
    private val h = Handler(Looper.getMainLooper())
    private val endTick = object : Runnable {
        override fun run() { if (ready) refreshEnd(); h.postDelayed(this, 20_000) }
    }
    private lateinit var pages: List<View>
    private lateinit var tabs: List<TextView>
    private lateinit var tabScroll: HorizontalScrollView
    private lateinit var usage: UsagePage
    private lateinit var systems: SystemsPage
    private lateinit var minsTv: TextView
    private lateinit var endTv: TextView
    private lateinit var seek: SeekBar
    private lateinit var summaryTv: TextView
    private lateinit var countTv: TextView
    private lateinit var banner: LinearLayout
    private lateinit var bannerTv: TextView
    private lateinit var pwField: EditText
    private lateinit var pwStatus: TextView
    private lateinit var taskBox: LinearLayout
    private lateinit var notesBox: LinearLayout
    private lateinit var hintField: EditText
    private lateinit var quotesBox: LinearLayout
    private var mins = 25
    private var ready = false

    private val common = setOf(
        "com.instagram.android", "com.instagram.lite", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
        "com.google.android.youtube", "com.twitter.android", "com.snapchat.android", "com.facebook.katana",
        "com.facebook.lite", "com.reddit.frontpage", "com.netflix.mediaclient", "com.pinterest"
    )

    private lateinit var planCard: LinearLayout
    private lateinit var planTitle: TextView
    private lateinit var planInfo: TextView
    private lateinit var planTimer: TextView
    private lateinit var planOpen: Button
    private val planTick = object : Runnable {
        override fun run() { if (ready) refreshPlan(); h.postDelayed(this, 1000) }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun lp1() = LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(4); marginEnd = dp(4) }
    private fun tint() = ColorStateList.valueOf(C.AC)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applyTheme()
        if (Prefs.settle(this)) Plans.onFocusEnd(this)
        Plans.sync(this)
        if (Prefs.active(this)) {
            startActivity(Intent(this, LockActivity::class.java)); finish(); return
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        picked.addAll(Prefs.blocked(this))
        mins = Prefs.lastMins(this).coerceIn(5, 240) / 5 * 5

        usage = UsagePage(this)
        systems = SystemsPage(this, { canStartSession() }, { select(TAB_TASKS) }, { m -> startBox(m) })
        pages = listOf(
            homePage(), usage.build(), systems.build(), TasksNotesPage(this).build(),
            AppsPage(this, picked) { refreshSummary() }.build(), stylePage(), settingsPage()
        )
        val content = SwipeFrame(this) { dir ->
            val step = if (Prefs.lang(this) == "en") dir else -dir
            select((tabKeep + step).coerceIn(0, pages.size - 1))
        }
        pages.forEach { content.addView(it) }

        val bar = LinearLayout(this)
        val names = listOf(
            "🏠 " + L("الرئيسية", "Home"), "📊 " + L("الإحصائيات", "Stats"), "📚 " + L("النظم", "Systems"),
            "✅ " + L("مهامي", "Plan"), "📱 " + L("التطبيقات", "Apps"), "🎨 " + L("المظهر", "Style"), "⚙ " + L("الإعدادات", "Settings")
        )
        tabs = names.mapIndexed { i, n ->
            tv(n, 13f, C.MU).apply {
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(15), dp(16), dp(15))
                setOnClickListener { Sfx.click(this@MainActivity); select(i) }
            }
        }
        tabs.forEach { bar.addView(it, LinearLayout.LayoutParams(WRAP, WRAP)) }
        tabScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(C.SF)
            addView(bar)
        }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(tabScroll, LinearLayout.LayoutParams(MATCH, WRAP))
        root.applyDir()
        setContentView(root)
        select(tabKeep.coerceIn(0, pages.size - 1))
        ready = true
        Sfx.warm(this)
        if (intent.getBooleanExtra("update", false)) checkUpdate(false) else autoCheck()
        UpdateJob.schedule(this)
        val q = intent.getIntExtra("quick", 0)
        if (q > 0) { mins = q; seek.progress = (q / 5 - 1).coerceIn(0, 47); showMins(); tryStart() }
    }

    override fun onResume() {
        super.onResume()
        if (!::pages.isInitialized) return
        refreshers.forEach { it() }
        refreshBanner()
        refreshSummary()
        h.post(endTick)
        Plans.sync(this)
        h.post(planTick)
    }

    override fun onPause() { h.removeCallbacks(endTick); h.removeCallbacks(planTick); super.onPause() }

    private fun select(i: Int) {
        tabKeep = i
        pages.forEachIndexed { j, p ->
            if (i == j) {
                p.visibility = View.VISIBLE
                if (ready) { p.alpha = 0f; p.animate().alpha(1f).setDuration(140).start() }
            } else p.visibility = View.GONE
        }
        tabs.forEachIndexed { j, t ->
            t.setTextColor(if (i == j) C.AC else C.MU)
            t.setTypeface(null, if (i == j) Typeface.BOLD else Typeface.NORMAL)
        }
        tabs[i].post { tabScroll.smoothScrollTo(tabs[i].left - (tabScroll.width - tabs[i].width) / 2, 0) }
        if (i == TAB_USAGE) usage.refresh()
        if (i == TAB_SYSTEMS) systems.refresh()
    }

    private fun canStartSession(): Boolean {
        if (!Prefs.hasPassword(this)) { toast(L("اضبط كلمة مرور الخروج الطارئ أولًا", "Set an emergency password first")); select(TAB_SETTINGS); return false }
        if (!Engine.ready(this)) { toast(engineMsg()); select(TAB_SETTINGS); return false }
        if (picked.isEmpty() && !Prefs.strict(this)) { toast(L("اختر تطبيقًا واحدًا على الأقل أو فعّل القفل الكامل", "Pick at least one app or enable full lock")); select(TAB_APPS); return false }
        return true
    }

    private fun startBox(m: Int) {
        mins = m
        seek.progress = (m / 5 - 1).coerceIn(0, 47)
        showMins()
        tryStart()
    }

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(26), dp(18), dp(24))
    }

    private fun scroll(c: View): View = ScrollView(this).apply { addView(c) }

    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText
        setTextColor(C.TX); setHintTextColor(C.MU)
        background = rounded(C.SF, 12, C.LN)
        setPadding(dp(14), dp(12), dp(14), dp(12))
    }

    private fun fmtMins(m: Int): String =
        if (m < 60) L("$m دقيقة", "$m min") else "${m / 60} " + L("س", "h") + (if (m % 60 > 0) " ${m % 60} " + L("د", "m") else "")

    private fun showMins() { minsTv.text = fmtMins(mins); refreshEnd(); Prefs.setLastMins(this, mins) }

    private fun refreshPlan() {
        val st = Plans.state(this)
        if (st == null) { planCard.visibility = View.GONE; return }
        planCard.visibility = View.VISIBLE
        planTitle.text = "▶ " + L("نظام شغّال: ", "Running: ") + L(st.first.ar, st.first.en)
        if (Plans.paused(this)) {
            planInfo.text = L("اتوقف النظام لأنك كنت بعيدًا. تقدر تكمل من الجولة التالية.", "The plan paused while you were away. You can continue with the next round.")
            planTimer.text = "⏸"
            planOpen.text = L("استأنف الجولة التالية", "Resume the next round")
            return
        }
        val onBreak = st.first.phases!![st.second].first == 'B'
        val end = if (onBreak) Prefs.longOf(this, "breakEnd") else Prefs.end(this)
        val left = ((end - System.currentTimeMillis()) / 1000).coerceAtLeast(0L)
        val what = if (onBreak) L("وقت الراحة", "Break time") else L("جولة تركيز", "Focus round")
        planInfo.text = what + " — " + (Plans.label(this) ?: "") + "\n" + L("ينتهي الساعة ", "Ends at ") + clock(end)
        planTimer.text = String.format(java.util.Locale.US, "%02d:%02d", left / 60, left % 60)
        planOpen.text = if (onBreak) L("افتح صفحة الراحة والعداد", "Open the break page") else L("افتح شاشة القفل", "Open the lock screen")
    }

    private fun refreshEnd() {
        endTv.text = L("ينتهي القفل الساعة ", "Unlocks at ") + clock(System.currentTimeMillis() + mins * 60_000L)
    }

    // ---------- الرئيسية ----------
    private fun homePage(): View {
        val col = column()
        col.put(tv("Stay focused", 28f, C.TX, true), 0)
        col.put(tv(L("اختر المدة، ثم أغلق على نفسك.", "Pick a duration, then lock yourself in."), 14f, C.MU), 4)

        banner = card()
        bannerTv = tv("", 14f, C.WR)
        banner.addView(bannerTv)
        banner.put(btn(L("افتح الإعدادات", "Open settings")) { select(TAB_SETTINGS) }, 10)
        col.put(banner, 16)

        planCard = card()
        planTitle = tv("", 14f, C.OK, true)
        planInfo = tv("", 14f, C.MU)
        planTimer = tv("", 34f, C.AC, true)
        planCard.addView(planTitle)
        planCard.put(planInfo, 4)
        planCard.put(planTimer, 4)
        planOpen = btn("") { Plans.openCurrent(this) }
        planCard.put(planOpen, 10)
        planCard.put(btn(L("إيقاف النظام", "Stop the plan")) { Plans.stop(this); refreshPlan() }, 8)
        planCard.visibility = View.GONE
        col.put(planCard, 16)

        val stats = LinearLayout(this)
        fun stat(n: String, l: String) = card().apply { addView(tv(n, 28f, C.AC, true)); addView(tv(l, 12f, C.MU)) }
        stats.addView(stat(Prefs.doneCount(this).toString(), L("جلسة مكتملة", "sessions done")),
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(6) })
        stats.addView(stat(Prefs.doneMins(this).toString(), L("دقيقة تركيز", "focus minutes")),
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(6) })
        col.put(stats, 16)

        val dur = card()
        dur.addView(tv(L("مدة الجلسة", "Session length"), 14f, C.MU))
        minsTv = tv("", 34f, C.TX, true)
        dur.put(minsTv, 4)
        endTv = tv("", 13f, C.AC)
        dur.put(endTv, 2)
        seek = SeekBar(this).apply {
            max = 47
            progress = mins / 5 - 1
            progressTintList = tint()
            thumbTintList = tint()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) { mins = (p + 1) * 5; showMins() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        dur.put(seek, 8)
        val chips = LinearLayout(this)
        listOf(15, 25, 45, 60, 90, 120).forEach { m ->
            val chip = tv("$m", 14f, C.TX).apply {
                gravity = Gravity.CENTER
                background = rounded(C.BG, 12, C.LN)
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { mins = m; seek.progress = m / 5 - 1; showMins() }
            }
            chips.addView(chip, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
        }
        dur.put(chips, 8)
        col.put(dur, 12)
        showMins()

        summaryTv = tv("", 14f, C.MU)
        col.put(summaryTv, 14)
        col.put(btn(L("ابدأ الجلسة", "Start session"), true) { tryStart() }.apply { textSize = 17f }, 10)
        return scroll(col)
    }

    private fun refreshBanner() {
        val m = ArrayList<String>()
        if (!Engine.ready(this)) m.add(L("أذونات الحماية", "Protection permissions"))
        if (!adminOn()) m.add(L("مشرف الجهاز", "Device admin"))
        if (!batteryOn()) m.add(L("استثناء البطارية", "Battery"))
        if (!Prefs.hasPassword(this)) m.add(L("كلمة المرور", "Password"))
        banner.visibility = if (m.isEmpty()) View.GONE else View.VISIBLE
        bannerTv.text = L("أكمل الإعدادات: ", "Finish setup: ") + m.joinToString(L("، ", ", "))
    }

    private fun refreshSummary() {
        summaryTv.text = when {
            Prefs.strict(this) -> L("قفل كامل: كل التطبيقات ممنوعة عدا الاتصال", "Full lock: every app is blocked except calls")
            picked.isEmpty() -> L("لم تختر أي تطبيق بعد. افتح تبويب التطبيقات.", "No apps chosen yet. Open the Apps tab.")
            else -> L("التطبيقات المحظورة: ${picked.size}", "Blocked apps: ${picked.size}")
        }
    }

    private fun tryStart() {
        if (!Prefs.hasPassword(this)) { toast(L("اضبط كلمة مرور الخروج الطارئ أولًا", "Set an emergency password first")); select(TAB_SETTINGS); return }
        if (!Engine.ready(this)) { toast(engineMsg()); select(TAB_SETTINGS); return }
        if (picked.isEmpty() && !Prefs.strict(this)) { toast(L("اختر تطبيقًا واحدًا على الأقل أو فعّل القفل الكامل", "Pick at least one app or enable full lock")); select(TAB_APPS); return }
        val at = clock(System.currentTimeMillis() + mins * 60_000L)
        dlg().setTitle(L("بدء الجلسة", "Start session"))
            .setMessage(L("لن تستطيع الخروج إلا بعد ${fmtMins(mins)} (الساعة $at) أو بكلمة المرور. هل أنت جاهز؟",
                "You can't leave for ${fmtMins(mins)} (until $at) except with your password. Ready?"))
            .setPositiveButton(L("ابدأ", "Start")) { _, _ -> go() }
            .setNegativeButton(L("إلغاء", "Cancel"), null)
            .show()
    }

    private fun go() {
        Prefs.clearFails(this)
        Prefs.setBlocked(this, picked)
        Prefs.begin(this, mins)
        EndAlarm.schedule(this)
        KeepAliveService.start(this)
        startActivity(Intent(this, LockActivity::class.java))
        finish()
    }

    // ---------- المظهر ----------
    private fun stylePage(): View {
        val col = column()
        col.put(tv(L("المظهر", "Appearance"), 24f, C.TX, true), 0)

        val mode = card()
        mode.addView(tv(L("الوضع", "Mode"), 16f, C.TX, true))
        val mr = LinearLayout(this)
        mr.addView(btn(L("داكن", "Dark"), !C.light) { Prefs.setLight(this, false); recreate() }, lp1())
        mr.addView(btn(L("فاتح", "Light"), C.light) { Prefs.setLight(this, true); recreate() }, lp1())
        mode.put(mr, 10)
        col.put(mode, 14)

        val th = card()
        th.addView(tv(L("الثيم", "Theme"), 16f, C.TX, true))
        val trs = (0 until (C.presets.size + 5) / 6).map { LinearLayout(this) }
        C.presets.forEachIndexed { i, p ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setOnClickListener { Prefs.setPreset(this@MainActivity, i); Prefs.setCustomAccent(this@MainActivity, 0); recreate() }
            }
            val on = i == Prefs.preset(this) && Prefs.customAccent(this) == 0
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(p.ac)
                    if (on) setStroke(dp(3), C.TX)
                }
            }
            item.addView(dot, LinearLayout.LayoutParams(dp(38), dp(38)))
            item.addView(tv(L(p.ar, p.en), 11f, C.MU).apply { gravity = Gravity.CENTER })
            trs[i / 6].addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        trs.forEachIndexed { k, r -> th.put(r, if (k == 0) 12 else 8) }
        col.put(th, 14)

        val wc = card()
        wc.addView(tv(L("لون مخصص", "Custom color"), 16f, C.TX, true))
        val sw = View(this).apply { background = rounded(C.AC, 12) }
        val wheel = ColorWheelView(this) { picked2 -> sw.background = rounded(picked2, 12) }
        wheel.setColor(C.AC)
        wc.addView(wheel, LinearLayout.LayoutParams(dp(240), dp(240)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(12) })
        wc.put(tv(L("السطوع", "Brightness"), 13f, C.MU), 8)
        wc.put(SeekBar(this).apply {
            max = 100
            progress = (wheel.value * 100).toInt()
            progressTintList = tint(); thumbTintList = tint()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, pr: Int, u: Boolean) {
                    wheel.value = pr.coerceAtLeast(5) / 100f
                    sw.background = rounded(wheel.color, 12)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }, 4)
        wc.addView(sw, LinearLayout.LayoutParams(MATCH, dp(36)).apply { topMargin = dp(10) })
        wc.put(btn(L("تطبيق اللون", "Apply color"), true) { Prefs.setCustomAccent(this, wheel.color); recreate() }, 10)
        wc.put(btn(L("إعادة لون الثيم", "Reset to theme color")) { Prefs.setCustomAccent(this, 0); recreate() }, 6)
        col.put(wc, 14)

        val cn = card()
        cn.addView(tv(L("شكل العداد", "Timer style"), 16f, C.TX, true))
        val pv = Counters.make(this, Prefs.counter(this), C.LN, C.AC)
        if (pv != null) {
            pv.upd(0.6f)
            cn.addView(pv.view, LinearLayout.LayoutParams(if (pv.w == 0) MATCH else dp(pv.w), dp(pv.h)).apply {
                gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(12)
            })
        }
        Counters.styles.chunked(4).forEach { chunk ->
            val r = LinearLayout(this)
            chunk.forEach { k ->
                r.addView(btn(Counters.label(this, k), Prefs.counter(this) == k) { Prefs.setCounter(this, k); recreate() }
                    .apply { textSize = 13f; setPadding(dp(4), dp(12), dp(4), dp(12)) }, lp1())
            }
            cn.put(r, 8)
        }
        cn.put(CheckBox(this).apply {
            text = L("تقليل الحركة لتوفير البطارية", "Reduce motion to save battery")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.reduceMotion(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setReduceMotion(this@MainActivity, on) }
        }, 12)
        col.put(cn, 14)

        val bg = card()
        bg.addView(tv(L("خلفية شاشة القفل", "Lock screen background"), 16f, C.TX, true))
        val hs = HorizontalScrollView(this)
        val row = LinearLayout(this)
        val keys = listOf("none") + Look.allKeys(this) + listOf("random")
        keys.forEach { key ->
            val sel = Prefs.bg(this) == key
            val tile = FrameLayout(this).apply {
                background = rounded(C.SF, 10, C.LN)
                if (sel) (background as GradientDrawable).setStroke(dp(3), C.AC)
                setPadding(dp(3), dp(3), dp(3), dp(3))
                setOnClickListener { Prefs.setBg(this@MainActivity, key); recreate() }
            }
            if (key == "none" || key == "random") {
                tile.addView(tv(if (key == "none") L("بدون", "None") else L("عشوائي", "Random"), 12f, C.TX).apply { gravity = Gravity.CENTER },
                    FrameLayout.LayoutParams(MATCH, MATCH))
            } else {
                tile.addView(ImageView(this).apply {
                    setImageBitmap(Look.thumb(this@MainActivity, key))
                    scaleType = ImageView.ScaleType.CENTER_CROP
                }, FrameLayout.LayoutParams(MATCH, MATCH))
                if (key.startsWith("c:")) tile.setOnLongClickListener { confirmDeleteBg(key.substring(2)); true }
            }
            row.addView(tile, LinearLayout.LayoutParams(dp(78), dp(138)).apply { marginEnd = dp(8) })
        }
        hs.addView(row)
        bg.put(hs, 12)
        bg.put(btn(L("إضافة صورة من المعرض", "Add image from gallery")) {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 7)
        }, 10)
        bg.put(tv(L("اضغط مطولًا على صورة أضفتها لحذفها.", "Long-press an image you added to delete it."), 12f, C.MU), 6)
        col.put(bg, 14)

        val dm = card()
        dm.addView(tv(L("إضاءة وشفافية الخلفية", "Background brightness and opacity"), 16f, C.TX, true))
        val pk = Prefs.bg(this).let { if (it == "none" || it == "random") "b1" else it }
        val pvImg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setImageBitmap(Look.thumb(this@MainActivity, pk)) }
        val pvScrim = View(this)
        fun applyPv() {
            pvImg.alpha = Prefs.bgOpacity(this) / 100f
            pvScrim.setBackgroundColor(Color.argb((Prefs.bgDim(this) * 2.55f).toInt(), 0, 0, 0))
        }
        val pvFrame = FrameLayout(this).apply { setBackgroundColor(C.BG) }
        pvFrame.addView(pvImg, FrameLayout.LayoutParams(MATCH, MATCH))
        pvFrame.addView(pvScrim, FrameLayout.LayoutParams(MATCH, MATCH))
        dm.addView(pvFrame, LinearLayout.LayoutParams(dp(110), dp(190)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(12) })
        fun slider(label: String, lo: Int, hi: Int, cur: Int, save: (Int) -> Unit) {
            dm.put(tv(label, 13f, C.MU), 10)
            dm.put(SeekBar(this).apply {
                max = hi - lo; progress = cur - lo
                progressTintList = tint(); thumbTintList = tint()
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, pr: Int, u: Boolean) { if (u) { save(pr + lo); applyPv() } }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }, 2)
        }
        slider(L("التعتيم", "Dimming"), 0, 90, Prefs.bgDim(this)) { Prefs.setBgDim(this, it) }
        slider(L("وضوح الصورة", "Image opacity"), 20, 100, Prefs.bgOpacity(this)) { Prefs.setBgOpacity(this, it) }
        applyPv()
        col.put(dm, 14)

        val qc = card()
        qc.addView(tv(L("جملك التحفيزية", "Your motivational quotes"), 16f, C.TX, true))
        val qf = field(L("اكتب جملة", "Write a quote"))
        qc.put(qf, 10)
        qc.put(btn(L("إضافة", "Add")) {
            val t = qf.text.toString().trim()
            if (t.isNotEmpty()) {
                val l = Prefs.myQuotes(this); l.add(t); Prefs.setMyQuotes(this, l)
                qf.text.clear(); renderQuotes()
            }
        }, 8)
        quotesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        qc.put(quotesBox, 8)
        qc.put(tv(L("لغة الجمل الجاهزة", "Built-in quotes language"), 13f, C.MU), 12)
        val ql = LinearLayout(this)
        listOf("both" to L("الاثنين", "Both"), "ar" to L("عربي", "Arabic"), "en" to "English").forEach { (k, n) ->
            ql.addView(btn(n, Prefs.quoteLang(this) == k) { Prefs.setQuoteLang(this, k); recreate() }.apply { textSize = 13f }, lp1())
        }
        qc.put(ql, 6)
        val only = CheckBox(this).apply {
            text = L("اعرض جملي فقط", "Show only my quotes")
            setTextColor(C.TX)
            buttonTintList = tint()
            isChecked = Prefs.onlyMine(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setOnlyMine(this@MainActivity, on) }
        }
        qc.put(only, 8)
        renderQuotes()
        col.put(qc, 14)
        return scroll(col)
    }

    private fun renderQuotes() {
        quotesBox.removeAllViews()
        val l = Prefs.myQuotes(this)
        if (l.isEmpty()) quotesBox.addView(tv(L("لا توجد جمل مضافة. الجمل الجاهزة بالعربي والإنجليزي.", "No custom quotes yet. Built-in quotes come in Arabic and English."), 12f, C.MU))
        l.forEachIndexed { i, q ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(tv(q, 14f, C.TX), LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(tv("✕", 16f, C.MU).apply {
                setPadding(dp(14), dp(10), dp(14), dp(10))
                setOnClickListener { l.removeAt(i); Prefs.setMyQuotes(this@MainActivity, l); renderQuotes() }
            })
            quotesBox.addView(row)
        }
    }

    private fun confirmDeleteBg(name: String) {
        dlg().setMessage(L("حذف هذه الصورة؟", "Delete this image?"))
            .setPositiveButton(L("حذف", "Delete")) { _, _ ->
                val l = Prefs.customBgs(this); l.remove(name); Prefs.setCustomBgs(this, l)
                File(filesDir, name).delete()
                if (Prefs.bg(this) == "c:$name") Prefs.setBg(this, "none")
                recreate()
            }
            .setNegativeButton(L("إلغاء", "Cancel"), null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (req != 7 || res != RESULT_OK) return
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@Thread
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                var s = 1
                while (o.outHeight / s > 1700) s *= 2
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
                    ?: throw Exception("decode")
                val name = "bg_" + System.currentTimeMillis() + ".jpg"
                FileOutputStream(File(filesDir, name)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                runOnUiThread {
                    val l = Prefs.customBgs(this); l.add(name); Prefs.setCustomBgs(this, l)
                    Prefs.setBg(this, "c:$name")
                    recreate()
                }
            } catch (e: Exception) {
                runOnUiThread { toast(L("تعذّر استخدام الصورة", "Couldn't use this image")) }
            }
        }.start()
    }

    // ---------- التحديث ----------
    private fun versionName(): String = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

    private fun autoCheck() {
        if (!Prefs.autoUpdate(this)) return
        if (System.currentTimeMillis() - Prefs.lastCheck(this) < 6 * 3_600_000L) return
        checkUpdate(false)
    }

    private fun checkUpdate(manual: Boolean) {
        Prefs.setLastCheck(this, System.currentTimeMillis())
        Updater.check(this) { ok, info ->
            if (!isFinishing) {
                if (info != null) promptUpdate(info)
                else if (manual && ok) toast(L("أنت على آخر إصدار", "You're on the latest version"))
                else if (manual) toast(L("تعذّر الاتصال، حاول لاحقًا", "Couldn't connect, try again later"))
            }
        }
    }

    private fun promptUpdate(info: Updater.Info) {
        dlg().setTitle(L("نسخة جديدة ${info.tag}", "New version ${info.tag}"))
            .setMessage(L("تقدمك وإعداداتك ستبقى كما هي. تنزيل وتثبيت الآن؟", "Your progress and settings will be kept. Download and install now?"))
            .setPositiveButton(L("حدّث الآن", "Update now")) { _, _ ->
                toast(L("جارٍ التنزيل...", "Downloading..."))
                Updater.download(this, info)
            }
            .setNegativeButton(L("لاحقًا", "Later"), null)
            .show()
    }

    // ---------- الإعدادات ----------
    private fun engineMsg(): String = if (Edition.FULL)
        L("فعّل «بيانات الاستخدام» و«العرض فوق التطبيقات» (أو إمكانية الوصول) من الإعدادات", "Enable Usage access and Display over other apps (or Accessibility) in Settings")
    else L("فعّل «بيانات الاستخدام» و«العرض فوق التطبيقات» من الإعدادات", "Enable Usage access and Display over other apps in Settings")
    private fun notifListenerOn(): Boolean =
        (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)
    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/")
    }
    private fun adminOn(): Boolean =
        getSystemService(DevicePolicyManager::class.java).isAdminActive(ComponentName(this, AdminReceiver::class.java))
    private fun batteryOn(): Boolean =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
    private fun notifOn(): Boolean =
        getSystemService(NotificationManager::class.java).areNotificationsEnabled()

    private fun perm(parent: LinearLayout, title: String, desc: String, on: () -> Boolean, action: () -> Unit) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(tv(title, 15f, C.TX, true))
        info.addView(tv(desc, 12f, C.MU))
        val st = tv(L("مفعّل ✓", "On ✓"), 13f, C.OK)
        val b = btn(L("تفعيل", "Enable")) { action() }.apply { textSize = 13f; setPadding(dp(14), dp(8), dp(14), dp(8)) }
        row.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(st)
        row.addView(b)
        parent.put(row, 14)
        refreshers.add {
            val ok = on()
            st.visibility = if (ok) View.VISIBLE else View.GONE
            b.visibility = if (ok) View.GONE else View.VISIBLE
        }
    }

    private fun settingsPage(): View {
        val col = column()
        col.put(tv(L("الإعدادات", "Settings"), 24f, C.TX, true), 0)

        val lg = card()
        lg.addView(tv(L("اللغة", "Language"), 16f, C.TX, true))
        val lr = LinearLayout(this)
        lr.addView(btn("العربية", Prefs.lang(this) == "ar") { Prefs.setLang(this, "ar"); recreate() }, lp1())
        lr.addView(btn("English", Prefs.lang(this) == "en") { Prefs.setLang(this, "en"); recreate() }, lp1())
        lg.put(lr, 10)
        col.put(lg, 14)

        val perms = card()
        perms.addView(tv(L("الصلاحيات", "Permissions"), 16f, C.TX, true))
        perm(perms, L("بيانات الاستخدام", "Usage access"), L("لاكتشاف التطبيق المفتوح وعرض الإحصائيات", "Detects the open app and shows statistics"), { hasUsageAccess() }) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        perm(perms, L("العرض فوق التطبيقات", "Display over other apps"), L("لإظهار شاشة القفل فوق التطبيق المحظور", "Shows the lock screen over a blocked app"), { Engine.overlayOn(this) }) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        if (Edition.FULL) perm(perms, L("إمكانية الوصول (اختياري، الأقوى)", "Accessibility (optional, strongest)"), L("استجابة فورية وكشف صفحات الحذف", "Instant response and uninstall-page detection"), { a11yOn() }) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        perm(perms, L("مشرف الجهاز", "Device admin"), L("لمنع حذف التطبيق أثناء الجلسة", "Makes uninstalling hard during a session"), { adminOn() }) {
            startActivity(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, getString(R.string.admin_desc))
            )
        }
        perm(perms, L("استثناء البطارية", "Battery"), L("حتى لا يوقف النظام التطبيق", "Stops the system from killing the app"), { batteryOn() }) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        perm(perms, L("الإشعارات", "Notifications"), L("إشعار الجلسة الدائم", "The ongoing session notification"), { notifOn() }) {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
        col.put(perms, 14)

        val pwCard = card()
        pwCard.addView(tv(L("كلمة مرور الخروج الطارئ", "Emergency password"), 16f, C.TX, true))
        pwStatus = tv(if (Prefs.hasPassword(this)) L("تم ضبط كلمة المرور ✓", "Password is set ✓") else L("لم تضبط كلمة مرور بعد", "No password yet"), 13f, C.MU)
        pwCard.put(pwStatus, 4)
        pwField = field(L("8 أحرف على الأقل، حروف وأرقام", "8+ characters, letters and numbers")).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        pwCard.put(pwField, 10)
        hintField = field(L("تلميح للكلمة (اختياري، يظهر على شاشة القفل)", "Password hint (optional, shown on the lock screen)"))
            .apply { setText(Prefs.hint(this@MainActivity)) }
        pwCard.put(hintField, 10)
        pwCard.put(btn(L("حفظ كلمة المرور", "Save password")) { savePassword() }, 10)
        col.put(pwCard, 14)

        val modeCard = card()
        val strictCb = CheckBox(this).apply {
            text = L("قفل كامل للهاتف", "Full phone lock")
            setTextColor(C.TX)
            buttonTintList = tint()
            isChecked = Prefs.strict(this@MainActivity)
            setOnCheckedChangeListener { v, on ->
                if (on && !Prefs.strict(this@MainActivity)) {
                    dlg().setMessage(L("القفل الكامل يمنع كل التطبيقات أثناء الجلسة عدا الاتصال. متأكد؟", "Full lock blocks every app during a session except calls. Sure?"))
                        .setPositiveButton(L("نعم", "Yes")) { _, _ -> Prefs.setStrict(this@MainActivity, true); refreshSummary() }
                        .setNegativeButton(L("إلغاء", "Cancel")) { _, _ -> v.isChecked = false }
                        .setOnCancelListener { v.isChecked = false }
                        .show()
                } else { Prefs.setStrict(this@MainActivity, on); refreshSummary() }
            }
        }
        modeCard.addView(strictCb)
        modeCard.addView(tv(L("يمنع كل التطبيقات أثناء الجلسة عدا الاتصال والطوارئ.", "Blocks every app during a session except calls and emergency."), 12f, C.MU))
        col.put(modeCard, 14)

        val snd = card()
        snd.addView(tv(L("الأصوات", "Sounds"), 16f, C.TX, true))
        snd.put(CheckBox(this).apply {
            text = L("أصوات المهام", "Task sounds")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.taskSounds(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setTaskSounds(this@MainActivity, on); if (on) Sfx.task(this@MainActivity, Sfx.DONE) }
        }, 8)
        snd.put(CheckBox(this).apply {
            text = L("أصوات الأزرار", "Button sounds")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.clickSounds(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setClickSounds(this@MainActivity, on); if (on) Sfx.click(this@MainActivity) }
        }, 4)
        fun sndBox(label: String, get: () -> Boolean, set: (Boolean) -> Unit, kind: Int) = snd.put(CheckBox(this).apply {
            text = label; setTextColor(C.TX); buttonTintList = tint(); isChecked = get()
            setOnCheckedChangeListener { _, on -> set(on); if (on) Sfx.playKind(this@MainActivity, kind) }
        }, 4)
        sndBox(L("صوت بداية الحظر", "Sound when a lock starts"), { Prefs.sndStart(this) }, { Prefs.setSndStart(this, it) }, Sfx.START)
        sndBox(L("صوت نهاية الحظر", "Sound when a lock ends"), { Prefs.sndEnd(this) }, { Prefs.setSndEnd(this, it) }, Sfx.END)
        sndBox(L("صوت الجمل التحفيزية والتنبيهات", "Sound for quotes and alerts"), { Prefs.sndQuote(this) }, { Prefs.setSndQuote(this, it) }, Sfx.QUOTE)
        snd.put(tv(L("حزمة الأصوات", "Sound pack"), 13f, C.MU), 12)
        val sr = LinearLayout(this)
        listOf(L("كلاسيك", "Classic"), L("ناعم", "Soft"), L("فقاعة", "Pop"), L("ريترو", "Retro")).forEachIndexed { k, n ->
            sr.addView(btn(n, Prefs.soundPack(this) == k) {
                Prefs.setSoundPack(this, k); Sfx.playKind(this, Sfx.ADD); recreate()
            }.apply { textSize = 13f; setPadding(dp(4), dp(12), dp(4), dp(12)) }, lp1())
        }
        snd.put(sr, 6)
        col.put(snd, 14)

        val upd = card()
        upd.addView(tv(L("التحديثات", "Updates"), 16f, C.TX, true))
        upd.put(tv(L("يتحدث التطبيق من GitHub وتقدمك يبقى محفوظًا. يستخدم الإنترنت لفحص النسخ فقط.",
            "The app updates from GitHub and keeps your progress. It uses the internet only to check versions."), 12f, C.MU), 4)
        upd.put(CheckBox(this).apply {
            text = L("فحص التحديثات تلقائيًا", "Check for updates automatically")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.autoUpdate(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setAutoUpdate(this@MainActivity, on); UpdateJob.schedule(this@MainActivity) }
        }, 8)
        upd.put(btn(L("افحص التحديثات الآن", "Check for updates now")) { checkUpdate(true) }, 8)
        col.put(upd, 14)

        val adv = card()
        adv.addView(tv(L("حماية متقدمة", "Advanced protection"), 16f, C.TX, true))
        adv.put(CheckBox(this).apply {
            text = L("زيادة وقت الجلسة أثناء توفير الطاقة", "Extend the session while power saver is on")
            setTextColor(C.TX); buttonTintList = tint(); isChecked = Prefs.saverPenalty(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setSaverPenalty(this@MainActivity, on) }
        }, 8)
        adv.put(tv(L("وضع توفير الطاقة الفائق قد يوقف الحماية. كل دقيقة يبقى فيها تُضاف لجلستك حتى لا يفيد التحايل به.",
            "Extreme power saving can pause protection. Every minute spent in it is added to your session, so it can't be used to dodge a lock."), 12f, C.MU), 4)
        if (Edition.FULL) {
            adv.put(CheckBox(this).apply {
                text = L("حظر إشعارات التطبيقات المحظورة", "Mute notifications of blocked apps")
                setTextColor(C.TX); buttonTintList = tint(); isChecked = Prefs.blockNotifs(this@MainActivity)
                setOnCheckedChangeListener { _, on ->
                    Prefs.setBlockNotifs(this@MainActivity, on)
                    if (on && !notifListenerOn()) startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
            }, 12)
            adv.put(tv(L("يحتاج «الوصول إلى الإشعارات». متاح في النسخة الكاملة فقط.", "Needs Notification access. Available in the Full edition only."), 12f, C.MU), 4)
        } else {
            adv.put(tv(L("حظر إشعارات التطبيقات المحظورة متاح في النسخة الكاملة فقط، لأنه يحتاج إذنًا تمنعه جوجل عند التثبيت من المتصفح.",
                "Muting notifications of blocked apps is in the Full edition only: it needs a permission Google blocks for browser installs."), 12f, C.MU), 12)
        }
        col.put(adv, 14)

        val oem = card()
        oem.addView(tv(L("لو التطبيق بيتوقف لوحده", "If the app keeps stopping"), 16f, C.TX, true))
        oem.put(tv(L("هاتفك (${Build.MANUFACTURER}) ممكن يوقف الخدمات الخلفية. فعّل التشغيل التلقائي، وخلّي البطارية «بدون قيود»، وثبّت التطبيق في قائمة التطبيقات الأخيرة.",
            "Your phone (${Build.MANUFACTURER}) may stop background services. Enable auto-start, set battery to Unrestricted, and lock the app in Recents."), 12f, C.MU), 4)
        oem.put(btn(L("افتح التشغيل التلقائي", "Open auto-start settings")) { openAutostart() }, 10)
        col.put(oem, 14)

        val coach = card()
        coach.addView(tv(L("المرشد الذكي (اختياري)", "Smart guide (optional)"), 16f, C.TX, true))
        coach.put(tv(L("لو قعدت وقت طويل في تطبيق مشتّت، يسألك بلطف أولًا، ثم يذكّرك بمهامك، ثم يقترح استراحة قصيرة. يتعلم من مدة استخدامك على هاتفك فقط، ويخفف التنبيهات لو تجاوبت معه. ما بيتدخلش في أي تطبيق آخر، كل ما يفعله إشعار أو شاشة تذكير تقدر تتجاهلها.",
            "If you stay long in a distracting app, it first asks gently, then reminds you of your tasks, then suggests a short break. It learns only from your usage on this phone and eases off if you respond. It never touches other apps: it only shows a notification or a reminder screen you can dismiss."), 12f, C.MU).apply { setLineSpacing(0f, 1.2f) }, 4)
        coach.put(CheckBox(this).apply {
            text = L("تفعيل المرشد الذكي", "Enable the smart guide")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.smart(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setSmart(this@MainActivity, on) }
        }, 8)
        coach.put(btn(L("إعادة ضبط ما تعلّمه", "Reset what it learned")) { Prefs.resetSmart(this); toast(L("تمت إعادة الضبط", "Reset done")) }, 8)
        col.put(coach, 14)

        val about = card()
        about.addView(tv("Stay focused " + versionName() + (if (Edition.FULL) " Full" else " Lite"), 16f, C.TX, true))
        about.put(tv(L("القائم على التطبيق: Ibrahim Elwaleed", "Maintained by Ibrahim Elwaleed"), 13f, C.MU), 4)
        about.put(btn(L("عرض المرشد", "Show the guide")) {
            startActivity(Intent(this, OnboardingActivity::class.java).putExtra("replay", true))
        }, 10)
        about.put(btn(L("سياسة الخصوصية", "Privacy policy")) {
            dlg().setTitle(L("سياسة الخصوصية", "Privacy policy"))
                .setMessage(L(
                    "- يستخدم التطبيق الإنترنت لفحص وتنزيل التحديثات من GitHub فقط، ولا يرسل أي بيانات شخصية من هاتفك.\n" +
                    "- خدمة إمكانية الوصول تقرأ اسم التطبيق المفتوح فقط لمنع ما اخترته، ولا تقرأ محتوى الشاشة.\n" +
                    "- مشرف الجهاز يُستخدم فقط لتصعيب الحذف أثناء جلسة بدأتها بنفسك.\n" +
                    "- الإعدادات والمهام والصور والإحصائيات تُحفظ على هاتفك فقط.\n" +
                    "- إحصائيات الاستخدام تُقرأ من نظام أندرويد على هاتفك (بإذن «بيانات الاستخدام» الذي تمنحه بنفسك) لعرض الرسوم، ولا تغادر هاتفك.\n" +
                    "- حدود التطبيقات والمرشد الذكي يعملان محليًا ويتعلمان من مدة استخدامك على هاتفك فقط. تقدر توقفهما وتعيد ضبط تعلّمهما في أي وقت.\n" +
                    "- القائم على التطبيق: Ibrahim Elwaleed.",
                    "- The app uses the internet only to check for and download updates from GitHub. It sends no personal data from your phone.\n" +
                    "- The accessibility service reads only the name of the app being opened, to block what you chose. It never reads screen content.\n" +
                    "- Device admin is used only to make uninstalling harder during a session you started.\n" +
                    "- Settings, tasks, images and stats stay on your phone.\n" +
                    "- Usage statistics are read from Android on your phone (with the Usage access permission you grant) to draw the charts, and never leave the phone.\n" +
                    "- App limits and the smart guide run locally and learn only from your usage on this phone. You can turn them off and reset their learning anytime.\n" +
                    "- Maintained by Ibrahim Elwaleed."))
                .setPositiveButton(L("حسنًا", "OK"), null)
                .show()
        }, 8)
        col.put(about, 14)
        return scroll(col)
    }

    private fun openAutostart() {
        val tries = listOf(
            "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.oplus.safecenter" to "com.oplus.safecenter.permission.startup.StartupAppListActivity",
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"
        )
        for ((pkg, cls) in tries) {
            try { startActivity(Intent().setComponent(ComponentName(pkg, cls))); return } catch (e: Exception) { }
        }
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun savePassword() {
        val pw = pwField.text.toString()
        Prefs.setHint(this, hintField.text.toString().trim())
        if (pw.isEmpty() && Prefs.hasPassword(this)) { toast(L("تم حفظ التلميح", "Hint saved")); return }
        if (pw.length < 8 || !pw.any { it.isDigit() } || !pw.any { it.isLetter() }) {
            toast(L("كلمة المرور يجب أن تكون 8 أحرف على الأقل وتحتوي على حروف وأرقام", "Password needs 8+ characters with letters and numbers")); return
        }
        Prefs.setPassword(this, pw)
        pwField.text.clear()
        pwStatus.text = L("تم ضبط كلمة المرور ✓", "Password is set ✓")
        refreshBanner()
        toast(L("تم الحفظ. احتفظ بها في مكان آمن.", "Saved. Keep it somewhere safe."))
    }
}
