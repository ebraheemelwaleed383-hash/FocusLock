package com.focuslock

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.*
import java.io.File
import java.util.Calendar
import java.io.FileOutputStream

class MainActivity : Activity() {
    companion object {
        var tabKeep = 0
        const val TAB_USAGE = 1
        const val TAB_SYSTEMS = 2
        const val TAB_TASKS = 3
        const val TAB_APPS = 4
        const val TAB_STYLE = 5
        const val TAB_SETTINGS = 6
        const val TAB_SCHEDULE = 7
        const val TAB_GOALS = 8
        const val TAB_DISC = 9
        const val TAB_INTEL = 10
        const val TAB_DNA = 11
    }

    private class Row(val pkg: String, val name: String, val cb: CheckBox)

    private val picked = HashSet<String>()
    private val rows = ArrayList<Row>()
    private val refreshers = ArrayList<() -> Unit>()
    private val h = Handler(Looper.getMainLooper())
    private val endTick = object : Runnable {
        override fun run() { if (ready) refreshEnd(); h.postDelayed(this, 20_000) }
    }
    private lateinit var pages: List<View>
    private lateinit var tabs: List<TextView>
    private lateinit var mainViews: List<LinearLayout>
    private lateinit var rootView: LinearLayout
    private lateinit var focusPage: ScrollView
    private lateinit var focusCol: LinearLayout
    private lateinit var fab: TextView
    private var fabFrame: FrameLayout? = null
    private val subBtn = HashMap<Int, TextView>()
    private val lastSub = intArrayOf(0, 4, 3, 1, 9)
    private var prevMain = 0
    private lateinit var schedule: SchedulePage
    private lateinit var goalsPage: GoalsPage
    private lateinit var discipline: DisciplinePage
    private val groups = listOf(listOf(0), listOf(4, 2), listOf(3, 7, 8), listOf(1, 10, 11), listOf(9, 5, 6))
    private lateinit var usage: UsagePage
    private lateinit var intel: IntelPage
    private lateinit var dna: DnaPage
    private lateinit var systems: SystemsPage
    private lateinit var minsTv: TextView
    private lateinit var endTv: TextView
    private lateinit var seek: SeekBar
    private lateinit var summaryTv: TextView
    private lateinit var countTv: TextView
    private lateinit var banner: LinearLayout
    private lateinit var bannerTv: TextView
    private lateinit var pwField: EditText
    private lateinit var pwStatus: TextView
    private lateinit var taskBox: LinearLayout
    private lateinit var notesBox: LinearLayout
    private lateinit var hintField: EditText
    private lateinit var quotesBox: LinearLayout
    private var mins = 25
    private var ready = false

    private val common = setOf(
        "com.instagram.android", "com.instagram.lite", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
        "com.google.android.youtube", "com.twitter.android", "com.snapchat.android", "com.facebook.katana",
        "com.facebook.lite", "com.reddit.frontpage", "com.netflix.mediaclient", "com.pinterest"
    )

    private lateinit var planCard: LinearLayout
    private lateinit var planTitle: TextView
    private lateinit var planInfo: TextView
    private lateinit var planTimer: TextView
    private lateinit var planOpen: Button
    private lateinit var focusCard: FocusCard
    private var singleCard: FocusCard? = null
    private fun refreshCards() { focusCard.refresh(); singleCard?.refresh() }
    private val planTick = object : Runnable {
        override fun run() { if (ready) refreshPlan(); h.postDelayed(this, 1000) }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun lp1() = LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(4); marginEnd = dp(4) }
    private fun tint() = ColorStateList.valueOf(C.AC)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applyTheme()
        if (Prefs.settle(this)) Plans.onFocusEnd(this)
        Plans.sync(this)
        if (Prefs.active(this)) {
            startActivity(Intent(this, LockActivity::class.java)); finish(); return
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        picked.addAll(Prefs.blocked(this))
        mins = Prefs.lastMins(this).coerceIn(5, 240) / 5 * 5

        usage = UsagePage(this)
        systems = SystemsPage(this, { canStartSession() }, { select(TAB_TASKS) }, { m -> startBox(m) })
        schedule = SchedulePage(this) { m, t -> Prefs.putStr(this, "activeBlock", t); startBox(m) }
        goalsPage = GoalsPage(this)
        discipline = DisciplinePage(this)
        intel = IntelPage(this)
        dna = DnaPage(this)
        pages = listOf(
            homePage(), usage.build(), systems.build(), TasksNotesPage(this) { select(0); refreshCards() }.build(),
            AppsPage(this, picked) { refreshSummary() }.build(), stylePage(), settingsPage(),
            schedule.build(), goalsPage.build(), discipline.build(),
            intel.build(), dna.build()
        )
        val content = SwipeFrame(this) { dir ->
            val step = if (Prefs.lang(this) == "en") dir else -dir
            selectMain((mainOf(tabKeep) + step).coerceIn(0, groups.size - 1))
        }
        val mains = ArrayList<LinearLayout>()
        groups.forEach { g ->
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            if (g.size > 1) {
                val seg = LinearLayout(this).apply { setPadding(dp(14), dp(12), dp(14), dp(4)) }
                g.forEach { leg ->
                    val bt = tv(subLabel(leg), 13f, C.MU).apply {
                        gravity = Gravity.CENTER
                        setPadding(dp(8), dp(9), dp(8), dp(9))
                        setOnClickListener { Sfx.click(this@MainActivity); select(leg) }
                    }
                    subBtn[leg] = bt
                    seg.addView(bt, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
                }
                box.addView(seg)
            }
            val host = FrameLayout(this)
            g.forEach { leg -> host.addView(pages[leg]) }
            box.addView(host, LinearLayout.LayoutParams(MATCH, 0, 1f))
            content.addView(box, FrameLayout.LayoutParams(MATCH, MATCH))
            mains.add(box)
        }
        mainViews = mains

        val bar = LinearLayout(this).apply { setBackgroundColor(C.SF) }
        val names = listOf(
            "🏠\n" + L("الرئيسية", "Home"), "🎯\n" + L("التركيز", "Focus"), "🗓\n" + L("الخطة", "Plan"),
            "📊\n" + L("إحصائيات", "Stats"), "☰\n" + L("المزيد", "More")
        )
        tabs = names.mapIndexed { i, n ->
            tv(n, 11f, C.MU).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { Sfx.click(this@MainActivity); selectMain(i) }
            }
        }
        tabs.forEach { bar.addView(it, LinearLayout.LayoutParams(0, WRAP, 1f)) }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        rootView = root
        root.applyDir()
        focusCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(30), dp(18), dp(110)) }
        focusPage = ScrollView(this).apply { setBackgroundColor(C.BG); addView(focusCol); visibility = View.GONE }
        focusPage.applyDir()
        fab = tv("◎", 22f, C.ON, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C.AC) }
            elevation = dp(6).toFloat()
        }
        val frame = FrameLayout(this)
        frame.addView(root, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(focusPage, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(fab, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.LEFT or Gravity.TOP))
        fabFrame = frame
        setupFab(frame)
        setContentView(frame)
        if (intent.getBooleanExtra("focusMode", false)) Prefs.putBool(this, "single", true)
        select(tabKeep.coerceIn(0, pages.size - 1))
        setSingle(Prefs.boolOf(this, "single", false), false)
        ready = true
        Sfx.warm(this)
        if (intent.getBooleanExtra("update", false)) checkUpdate(false) else autoCheck()
        UpdateJob.schedule(this)
        Disc.autoEval(this)
        DiscAlarm.schedule(this)
        Planner.maybeRoll(this)
        PlanAlarms.rescan(this)
        try { FocusReminders.rescheduleAll(this) } catch (_: Exception) { }
        WhatsNew.check(this)
        intent.getStringExtra("qt")?.let { Prefs.putStr(this, "activeBlock", it) }
        // فتح من إشعار نهاية الجلسة: نلغي التأجيل ليظهر تصنيف النتيجة فورًا
        if (intent.hasExtra("review")) FocusTasks.clearSnooze(this)
        intent.getStringExtra("ft")?.let { FocusTasks.select(this, it); refreshCards() }
        val q = intent.getIntExtra("quick", 0)
        if (q > 0) { mins = q; seek.progress = (q / 5 - 1).coerceIn(0, 47); showMins(); tryStart() }
        else FocusTaskUi.maybeReview(this) { refreshCards() }
    }

    override fun onResume() {
        super.onResume()
        if (!::pages.isInitialized) return
        // لو بدأت جلسة والتطبيق مفتوح في الخلفية (مثلًا جولة جديدة في نظام دراسة) نرجع لشاشة القفل ولا نترك الإعدادات متاحة
        if (Prefs.active(this)) { startActivity(Intent(this, LockActivity::class.java)); finish(); return }
        FloatingFab.appVisible = true
        FloatingFab.sync(this)
        if (intent.getIntExtra("quick", 0) == 0) FocusTaskUi.maybeReview(this) { refreshCards() }
        refreshCards()
        AutoSched.schedule(this)
        WeeklyReport.schedule(this)
        Updater.resumePending(this)
        refreshers.forEach { it() }
        refreshBanner()
        refreshSummary()
        h.post(endTick)
        Plans.sync(this)
        h.post(planTick)
        if (Prefs.boolOf(this, "single", false)) renderFocus()
        if (Prefs.intOf(this, "pl_just", 0) == 1) { Prefs.putInt(this, "pl_just", 0); select(TAB_SCHEDULE) }
        when (tabKeep) {
            TAB_SCHEDULE -> schedule.refresh()
            TAB_GOALS -> goalsPage.refresh()
            TAB_DISC -> discipline.refresh()
            TAB_INTEL -> intel.refresh()
            TAB_DNA -> dna.refresh()
        }
    }

    override fun onPause() {
        FloatingFab.appVisible = false
        h.removeCallbacks(endTick); h.removeCallbacks(planTick)
        super.onPause()
    }

    // ---------- جلسات تلقائية ونسخ احتياطي ----------
    private fun addRule(done: () -> Unit) {
        Sheets.time(this, L("متى تبدأ الجلسة؟", "When should the session start?"), 18 * 60) { tt ->
            val h = tt / 60
            val m = tt % 60
            val names = arrayOf(L("الأحد", "Sun"), L("الإثنين", "Mon"), L("الثلاثاء", "Tue"), L("الأربعاء", "Wed"),
                L("الخميس", "Thu"), L("الجمعة", "Fri"), L("السبت", "Sat"))
            val checked = BooleanArray(7) { true }
            dlg().setTitle(L("الأيام", "Days"))
                .setMultiChoiceItems(names, checked) { _, i, on -> checked[i] = on }
                .setPositiveButton(L("التالي", "Next")) { _, _ ->
                    var mask = 0
                    for (d in 0..6) if (checked[d]) mask = mask or (1 shl d)
                    if (mask == 0) {
                        toast(L("اختر يومًا واحدًا على الأقل", "Pick at least one day"))
                    } else {
                        val lens = intArrayOf(15, 25, 45, 60, 90)
                        val labels = Array(lens.size) { lens[it].toString() + L(" دقيقة", " min") }
                        Sheets.options(this, L("مدة الجلسة", "Session length"), labels.toList()) { w ->
                            val cur = AutoSched.rules(this)
                            cur.add(AutoSched.Rule(mask, h * 60 + m, lens[w]))
                            AutoSched.save(this, cur)
                            done()
                        }
                    }
                }
                .setNegativeButton(L("إلغاء", "Cancel"), null)
                .show()
        }
    }

    private fun startExport() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("application/json")
            .putExtra(Intent.EXTRA_TITLE, "vigil-backup.json")
        startActivityForResult(i, 8)
    }

    private fun startImport() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
        startActivityForResult(i, 9)
    }

    private fun confirmImport(text: String) {
        if (Prefs.active(this)) return
        val needPw = Prefs.hasPassword(this)
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        et.hint = L("كلمة المرور", "Password")
        val b = dlg().setTitle(L("استيراد التقدم", "Import progress"))
            .setMessage(L("سيستبدل التقدم والإعدادات الحالية بما في الملف.", "This replaces your current progress and settings with the file's."))
        if (needPw) b.setView(et)
        b.setPositiveButton(L("استيراد", "Import")) { _, _ ->
            if (needPw && !Prefs.check(this, et.text.toString())) {
                toast(L("كلمة المرور غير صحيحة", "Wrong password"))
            } else {
                val n = try { Prefs.importAll(this, text) } catch (e: Exception) { -1 }
                if (n < 0) {
                    toast(L("ملف غير صالح", "Invalid file"))
                } else {
                    AutoSched.schedule(this)
                    WeeklyReport.schedule(this)
                    FloatingFab.sync(this)
                    FocusWidget.refresh(this)
                    toast(L("تم استيراد $n عنصر", "Imported $n item(s)"))
                    recreate()
                }
            }
        }
        b.setNegativeButton(L("إلغاء", "Cancel"), null)
        b.show()
    }

    // ---------- الزر العائم: يُسحب لأي مكان ويُحفظ موضعه ----------
    private fun fabSize() = dp(52)

    private fun placeFab(frame: FrameLayout) {
        val sz = fabSize()
        val availW = (frame.width - sz).coerceAtLeast(1)
        val availH = (frame.height - sz).coerceAtLeast(1)
        val fx = Prefs.floatOf(this, "fabX", -1f)
        val fy = Prefs.floatOf(this, "fabY", -1f)
        // الموضع الافتراضي: أسفل اليمين فوق شريط التبويبات
        val x = (if (fx < 0f) availW - dp(16) else (fx.coerceIn(0f, 1f) * availW).toInt()).coerceIn(0, availW)
        val y = (if (fy < 0f) availH - dp(86) else (fy.coerceIn(0f, 1f) * availH).toInt()).coerceIn(0, availH)
        val lp = fab.layoutParams as FrameLayout.LayoutParams
        val g = Gravity.LEFT or Gravity.TOP
        if (lp.leftMargin != x || lp.topMargin != y || lp.gravity != g) {
            lp.gravity = g
            lp.leftMargin = x
            lp.topMargin = y
            fab.layoutParams = lp
        }
    }

    private fun saveFab(frame: FrameLayout) {
        val sz = fabSize()
        val lp = fab.layoutParams as FrameLayout.LayoutParams
        Prefs.putFloat(this, "fabX", lp.leftMargin.toFloat() / maxOf(1, frame.width - sz))
        Prefs.putFloat(this, "fabY", lp.topMargin.toFloat() / maxOf(1, frame.height - sz))
    }

    private fun setupFab(frame: FrameLayout) {
        frame.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, oR, ob ->
            if (r - l != oR - ol || b - t != ob - ot) placeFab(frame)
        }
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startL = 0
        var startT = 0
        var moved = false
        fab.setOnTouchListener { v, e ->
            val lp = v.layoutParams as FrameLayout.LayoutParams
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startL = lp.leftMargin
                    startT = lp.topMargin
                    moved = false
                    v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) moved = true
                    if (moved) {
                        val sz = fabSize()
                        lp.leftMargin = (startL + dx).toInt().coerceIn(0, maxOf(0, frame.width - sz))
                        lp.topMargin = (startT + dy).toInt().coerceIn(0, maxOf(0, frame.height - sz))
                        v.layoutParams = lp
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    if (moved) saveFab(frame)
                    else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        Sfx.click(this)
                        setSingle(!Prefs.boolOf(this, "single", false))
                    }
                    true
                }
                else -> false
            }
        }
    }

    // ---------- وضع الصفحة الواحدة ----------
    private fun setSingle(on: Boolean, animate: Boolean = true) {
        Prefs.putBool(this, "single", on)
        if (on) renderFocus()
        rootView.visibility = if (on) View.GONE else View.VISIBLE
        focusPage.visibility = if (on) View.VISIBLE else View.GONE
        fab.text = if (on) "✕" else "◎"
        if (animate) {
            val v: View = if (on) focusPage else rootView
            v.alpha = 0f
            v.animate().alpha(1f).setDuration(240).start()
        }
    }

    private fun nextBlock(): Block? {
        val plan = Planner.loadPlan(this) ?: return null
        val today = Planner.dayStart(System.currentTimeMillis())
        val cal = Calendar.getInstance()
        val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return plan.blocks.firstOrNull { it.day == today && it.end > nowMin }
    }

    private fun renderFocus() {
        focusCol.removeAllViews()
        focusCol.put(tv(L("وضع التركيز", "Focus mode"), 26f, C.TX, true), 0)
        focusCol.put(tv(L("كل ما تحتاجه الآن في صفحة واحدة. اضغط ✕ للعودة للتطبيق الكامل.", "Everything you need right now on one page. Tap ✕ to return to the full app."), 13f, C.MU), 4)

        // وضع الشاشة الواحدة: نفس بطاقة «تركيز الجلسة» ليرى المستخدم المهمة المرتبطة ويختارها أو يزيلها قبل البدء
        val fc = FocusCard(this)
        singleCard = fc
        focusCol.put(fc.view, 12)

        val s = card()
        s.addView(tv(L("جلسة تركيز", "Focus session"), 14f, C.MU))
        s.put(tv(fmtMins(mins), 34f, C.TX, true), 4)
        s.put(tv(L("ينتهي القفل الساعة ", "Unlocks at ") + clock(System.currentTimeMillis() + mins * 60_000L), 13f, C.AC), 2)
        val chips = LinearLayout(this)
        listOf(15, 25, 45, 60, 90).forEach { v ->
            chips.addView(tv("$v", 14f, if (v == mins) C.ON else C.TX).apply {
                gravity = Gravity.CENTER
                background = rounded(if (v == mins) C.AC else C.BG, 12, C.LN)
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { mins = v; seek.progress = v / 5 - 1; showMins(); renderFocus() }
            }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
        }
        s.put(chips, 10)
        s.put(btn(L("ابدأ الجلسة", "Start session"), true) { tryStart() }.apply { textSize = 17f }, 12)
        focusCol.put(s, 16)

        val nb = nextBlock()
        if (nb != null) {
            val k = card()
            k.addView(tv(L("التالي في جدولك", "Next in your schedule"), 14f, C.MU))
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
            row.addView(tv(Planner.fmt(nb.start) + "–" + Planner.fmt(nb.end) + "  " + nb.title, 15f, C.TX, true), LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(tv("▶", 20f, C.AC).apply {
                setPadding(dp(14), dp(6), dp(6), dp(6))
                setOnClickListener { Prefs.putStr(this@MainActivity, "activeBlock", nb.title); mins = (nb.end - nb.start).coerceIn(5, 240); showMins(); tryStart() }
            })
            k.addView(row)
            focusCol.put(k, 12)
        }

        val all = Tasks.load(this)
        val top = all.filter { !it.d }.sortedBy { it.p }.take(3)
        val tk = card()
        tk.addView(tv(L("أهم مهامك", "Your top tasks"), 14f, C.MU))
        if (top.isEmpty()) tk.put(tv(L("لا توجد مهام معلّقة. أحسنت!", "No pending tasks. Well done!"), 14f, C.OK), 6)
        top.forEach { t ->
            tk.put(CheckBox(this).apply {
                text = t.t; setTextColor(C.TX); buttonTintList = tint()
                setOnCheckedChangeListener { _, on ->
                    if (on) { t.d = true; Tasks.update(this@MainActivity) { l -> TaskOps.find(l, t.id)?.let { it.d = true } }; Sfx.task(this@MainActivity, Sfx.DONE); renderFocus() }
                }
            }, 4)
        }
        focusCol.put(tk, 12)

        val lv = Disc.level(this)
        focusCol.put(tv(L("محظور الآن: ${Prefs.blocked(this).size} تطبيق", "Blocked: ${Prefs.blocked(this).size} apps") + (if (lv != null) "  |  " + L("المراقب: ${lv.ar}", "Overseer: ${lv.en}") else ""), 12f, C.MU), 16)
    }

    private fun mainOf(i: Int): Int = groups.indexOfFirst { i in it }.coerceAtLeast(0)

    private fun subLabel(leg: Int): String = when (leg) {
        TAB_USAGE -> L("الاستخدام", "Usage")
        TAB_INTEL -> L("التحليل", "Insights")
        TAB_DNA -> L("البصمة", "DNA")
        TAB_APPS -> L("التطبيقات", "Apps")
        TAB_SYSTEMS -> L("الأنظمة", "Systems")
        TAB_TASKS -> L("المهام", "Tasks")
        TAB_SCHEDULE -> L("الجدول", "Schedule")
        TAB_GOALS -> L("الأهداف", "Goals")
        TAB_DISC -> L("المراقب", "Overseer")
        TAB_STYLE -> L("المظهر", "Style")
        TAB_SETTINGS -> L("الإعدادات", "Settings")
        else -> ""
    }

    private fun selectMain(m: Int) = select(lastSub[m.coerceIn(0, groups.size - 1)])

    private fun select(i: Int) {
        val idx = i.coerceIn(0, pages.size - 1)
        tabKeep = idx
        val m = mainOf(idx)
        lastSub[m] = idx
        mainViews.forEachIndexed { j, v ->
            if (j == m) {
                v.visibility = View.VISIBLE
                if (ready && m != prevMain) { v.alpha = 0f; v.translationY = dp(14).toFloat(); v.animate().alpha(1f).translationY(0f).setDuration(180).start() }
            } else v.visibility = View.GONE
        }
        prevMain = m
        groups[m].forEach { leg ->
            val p = pages[leg]
            if (leg == idx) {
                p.visibility = View.VISIBLE
                if (ready) staggerPage(p)
            } else p.visibility = View.GONE
            subBtn[leg]?.let { bt ->
                val on = leg == idx
                bt.setTextColor(if (on) C.ON else C.MU)
                bt.background = rounded(if (on) C.AC else C.SF, 12, C.LN)
                bt.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
            }
        }
        tabs.forEachIndexed { j, t ->
            t.setTextColor(if (m == j) C.AC else C.MU)
            t.animate().scaleX(if (m == j) 1.12f else 1f).scaleY(if (m == j) 1.12f else 1f).setDuration(160).start()
            t.setTypeface(null, if (m == j) Typeface.BOLD else Typeface.NORMAL)
        }
        if (idx == TAB_USAGE) usage.refresh()
        if (idx == TAB_SYSTEMS) systems.refresh()
        if (idx == TAB_SCHEDULE) schedule.refresh()
        if (idx == TAB_GOALS) goalsPage.refresh()
        if (idx == TAB_DISC) discipline.refresh()
        if (idx == TAB_INTEL) intel.refresh()
        if (idx == TAB_DNA) dna.refresh()
    }

    override fun onBackPressed() {
        if (Prefs.boolOf(this, "single", false)) setSingle(false) else if (tabKeep != 0) select(0) else super.onBackPressed()
    }

    private fun canStartSession(): Boolean {
        if (!Prefs.hasPassword(this)) { toast(L("اضبط كلمة مرور الخروج الطارئ أولًا", "Set an emergency password first")); select(TAB_SETTINGS); return false }
        if (!Engine.ready(this)) { toast(engineMsg()); select(TAB_SETTINGS); return false }
        if (picked.isEmpty() && !Prefs.strict(this)) { toast(L("اختر تطبيقًا واحدًا على الأقل أو فعّل القفل الكامل", "Pick at least one app or enable full lock")); select(TAB_APPS); return false }
        if ((Disc.level(this)?.id ?: 0) >= 3 && getSystemService(PowerManager::class.java).isPowerSaveMode) {
            toast(L("أطفئ وضع توفير الطاقة أولًا (مستوى المراقب لا يسمح ببدء جلسة وهو مفعّل).", "Turn off battery saver first (your overseer level doesn't allow starting a session while it is on)."))
            return false
        }
        return true
    }

    private fun startBox(m: Int) {
        mins = m
        seek.progress = (m / 5 - 1).coerceIn(0, 47)
        showMins()
        tryStart()
    }

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(26), dp(18), dp(24))
    }

    private fun scroll(c: View): View = ScrollView(this).apply { addView(c) }

    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText
        setTextColor(C.TX); setHintTextColor(C.MU)
        background = rounded(C.SF, 12, C.LN)
        setPadding(dp(14), dp(12), dp(14), dp(12))
    }

    private fun fmtMins(m: Int): String =
        if (m < 60) L("$m دقيقة", "$m min") else "${m / 60} " + L("س", "h") + (if (m % 60 > 0) " ${m % 60} " + L("د", "m") else "")

    private fun showMins() { minsTv.text = fmtMins(mins); refreshEnd(); Prefs.setLastMins(this, mins) }

    private fun refreshPlan() {
        val st = Plans.state(this)
        if (st == null) { planCard.visibility = View.GONE; return }
        planCard.visibility = View.VISIBLE
        planTitle.text = "▶ " + L("نظام شغّال: ", "Running: ") + L(st.first.ar, st.first.en)
        if (Plans.paused(this)) {
            planInfo.text = L("اتوقف النظام لأنك كنت بعيدًا. تقدر تكمل من الجولة التالية.", "The plan paused while you were away. You can continue with the next round.")
            planTimer.text = "⏸"
            planOpen.text = L("استأنف الجولة التالية", "Resume the next round")
            return
        }
        val onBreak = st.first.phases!![st.second].first == 'B'
        val end = if (onBreak) Prefs.longOf(this, "breakEnd") else Prefs.end(this)
        val left = ((end - System.currentTimeMillis()) / 1000).coerceAtLeast(0L)
        val what = if (onBreak) L("وقت الراحة", "Break time") else L("جولة تركيز", "Focus round")
        planInfo.text = what + " — " + (Plans.label(this) ?: "") + "\n" + L("ينتهي الساعة ", "Ends at ") + clock(end)
        planTimer.text = String.format(java.util.Locale.US, "%02d:%02d", left / 60, left % 60)
        planOpen.text = if (onBreak) L("افتح صفحة الراحة والعداد", "Open the break page") else L("افتح شاشة القفل", "Open the lock screen")
    }

    private fun refreshEnd() {
        endTv.text = L("ينتهي القفل الساعة ", "Unlocks at ") + clock(System.currentTimeMillis() + mins * 60_000L)
    }

    // ---------- الرئيسية ----------
    private fun homePage(): View {
        val col = column()
        col.put(tv("Vigil", 28f, C.TX, true), 0)
        col.put(tv(L("اختر المدة، ثم أغلق على نفسك.", "Pick a duration, then lock yourself in."), 14f, C.MU), 4)

        banner = card()
        bannerTv = tv("", 14f, C.WR)
        banner.addView(bannerTv)
        banner.put(btn(L("افتح الإعدادات", "Open settings")) { select(TAB_SETTINGS) }, 10)
        col.put(banner, 16)

        planCard = card()
        planTitle = tv("", 14f, C.OK, true)
        planInfo = tv("", 14f, C.MU)
        planTimer = tv("", 34f, C.AC, true)
        planCard.addView(planTitle)
        planCard.put(planInfo, 4)
        planCard.put(planTimer, 4)
        planOpen = btn("") { Plans.openCurrent(this) }
        planCard.put(planOpen, 10)
        planCard.put(btn(L("إيقاف النظام", "Stop the plan")) { Plans.stop(this); refreshPlan() }, 8)
        planCard.visibility = View.GONE
        col.put(planCard, 16)

        val stats = LinearLayout(this)
        fun stat(n: String, l: String) = card().apply { addView(tv(n, 28f, C.AC, true)); addView(tv(l, 12f, C.MU)) }
        stats.addView(stat(Prefs.doneCount(this).toString(), L("جلسة مكتملة", "sessions done")),
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(6) })
        stats.addView(stat(Prefs.doneMins(this).toString(), L("دقيقة تركيز", "focus minutes")),
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(6) })
        col.put(stats, 16)

        focusCard = FocusCard(this)
        col.put(focusCard.view, 12)

        val dur = card()
        dur.addView(tv(L("مدة الجلسة", "Session length"), 14f, C.MU))
        minsTv = tv("", 34f, C.TX, true)
        dur.put(minsTv, 4)
        endTv = tv("", 13f, C.AC)
        dur.put(endTv, 2)
        seek = SeekBar(this).apply {
            max = 47
            progress = mins / 5 - 1
            progressTintList = tint()
            thumbTintList = tint()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) { mins = (p + 1) * 5; showMins() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        dur.put(seek, 8)
        val chips = LinearLayout(this)
        listOf(15, 25, 45, 60, 90, 120).forEach { m ->
            val chip = tv("$m", 14f, C.TX).apply {
                gravity = Gravity.CENTER
                background = rounded(C.BG, 12, C.LN)
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { mins = m; seek.progress = m / 5 - 1; showMins() }
            }
            chips.addView(chip, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
        }
        dur.put(chips, 8)
        col.put(dur, 12)
        showMins()

        summaryTv = tv("", 14f, C.MU)
        col.put(summaryTv, 14)
        col.put(btn(L("ابدأ الجلسة", "Start session"), true) { tryStart() }.apply { textSize = 17f }, 10)
        return scroll(col)
    }

    private fun refreshBanner() {
        val m = ArrayList<String>()
        if (!Engine.ready(this)) m.add(L("أذونات الحماية", "Protection permissions"))
        if (!adminOn()) m.add(L("مشرف الجهاز", "Device admin"))
        if (!batteryOn()) m.add(L("استثناء البطارية", "Battery"))
        if (!Prefs.hasPassword(this)) m.add(L("كلمة المرور", "Password"))
        banner.visibility = if (m.isEmpty()) View.GONE else View.VISIBLE
        bannerTv.text = L("أكمل الإعدادات: ", "Finish setup: ") + m.joinToString(L("، ", ", "))
    }

    private fun refreshSummary() {
        summaryTv.text = when {
            Prefs.strict(this) -> L("قفل كامل: كل التطبيقات ممنوعة عدا الاتصال", "Full lock: every app is blocked except calls")
            picked.isEmpty() -> L("لم تختر أي تطبيق بعد. افتح تبويب التطبيقات.", "No apps chosen yet. Open the Apps tab.")
            else -> L("التطبيقات المحظورة: ${picked.size}", "Blocked apps: ${picked.size}")
        }
    }

    private fun tryStart() {
        if (!canStartSession()) return
        val at = clock(System.currentTimeMillis() + mins * 60_000L)
        val ft = FocusTasks.current(this)?.let { "\n\n🎯 " + it.t } ?: ""
        dlg().setTitle(L("بدء الجلسة", "Start session"))
            .setMessage(L("لن تستطيع الخروج إلا بعد ${fmtMins(mins)} (الساعة $at) أو بكلمة المرور. هل أنت جاهز؟$ft",
                "You can't leave for ${fmtMins(mins)} (until $at) except with your password. Ready?$ft"))
            .setPositiveButton(L("ابدأ", "Start")) { _, _ -> go() }
            .setNegativeButton(L("إلغاء", "Cancel"), null)
            .show()
    }

    private fun go() {
        Prefs.clearFails(this)
        Prefs.setBlocked(this, picked)
        FocusTasks.arm(this)
        Prefs.begin(this, mins)
        EndAlarm.schedule(this)
        KeepAliveService.start(this)
        startActivity(Intent(this, LockActivity::class.java))
        finish()
    }

    // ---------- المظهر ----------
    private fun stylePage(): View {
        val col = column()
        col.put(tv(L("المظهر", "Appearance"), 24f, C.TX, true), 0)

        val mode = card()
        mode.addView(tv(L("الوضع", "Mode"), 16f, C.TX, true))
        val mr = LinearLayout(this)
        mr.addView(btn(L("داكن", "Dark"), !C.light) { Prefs.setLight(this, false); recreate() }, lp1())
        mr.addView(btn(L("فاتح", "Light"), C.light) { Prefs.setLight(this, true); recreate() }, lp1())
        mode.put(mr, 10)
        col.put(mode, 14)

        val th = card()
        th.addView(tv(L("الثيم", "Theme"), 16f, C.TX, true))
        val trs = (0 until (C.presets.size + 5) / 6).map { LinearLayout(this) }
        C.presets.forEachIndexed { i, p ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setOnClickListener { Prefs.setPreset(this@MainActivity, i); Prefs.setCustomAccent(this@MainActivity, 0); recreate() }
            }
            val on = i == Prefs.preset(this) && Prefs.customAccent(this) == 0
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(p.ac)
                    if (on) setStroke(dp(3), C.TX)
                }
            }
            item.addView(dot, LinearLayout.LayoutParams(dp(38), dp(38)))
            item.addView(tv(L(p.ar, p.en), 11f, C.MU).apply { gravity = Gravity.CENTER })
            trs[i / 6].addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        trs.forEachIndexed { k, r -> th.put(r, if (k == 0) 12 else 8) }
        col.put(th, 14)

        val wc = card()
        wc.addView(tv(L("لون مخصص", "Custom color"), 16f, C.TX, true))
        val sw = View(this).apply { background = rounded(C.AC, 12) }
        val wheel = ColorWheelView(this) { picked2 -> sw.background = rounded(picked2, 12) }
        wheel.setColor(C.AC)
        wc.addView(wheel, LinearLayout.LayoutParams(dp(240), dp(240)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(12) })
        wc.put(tv(L("السطوع", "Brightness"), 13f, C.MU), 8)
        wc.put(SeekBar(this).apply {
            max = 100
            progress = (wheel.value * 100).toInt()
            progressTintList = tint(); thumbTintList = tint()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, pr: Int, u: Boolean) {
                    wheel.value = pr.coerceAtLeast(5) / 100f
                    sw.background = rounded(wheel.color, 12)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }, 4)
        wc.addView(sw, LinearLayout.LayoutParams(MATCH, dp(36)).apply { topMargin = dp(10) })
        wc.put(btn(L("تطبيق اللون", "Apply color"), true) { Prefs.setCustomAccent(this, wheel.color); recreate() }, 10)
        wc.put(btn(L("إعادة لون الثيم", "Reset to theme color")) { Prefs.setCustomAccent(this, 0); recreate() }, 6)
        col.put(wc, 14)

        val cn = card()
        cn.addView(tv(L("شكل العداد", "Timer style"), 16f, C.TX, true))
        val pv = Counters.make(this, Prefs.counter(this), C.LN, C.AC)
        if (pv != null) {
            pv.upd(0.6f)
            cn.addView(pv.view, LinearLayout.LayoutParams(if (pv.w == 0) MATCH else dp(pv.w), dp(pv.h)).apply {
                gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(12)
            })
        }
        Counters.styles.chunked(4).forEach { chunk ->
            val r = LinearLayout(this)
            chunk.forEach { k ->
                r.addView(btn(Counters.label(this, k), Prefs.counter(this) == k) { Prefs.setCounter(this, k); recreate() }
                    .apply { textSize = 13f; setPadding(dp(4), dp(12), dp(4), dp(12)) }, lp1())
            }
            cn.put(r, 8)
        }
        cn.put(CheckBox(this).apply {
            text = L("تقليل الحركة لتوفير البطارية", "Reduce motion to save battery")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.reduceMotion(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setReduceMotion(this@MainActivity, on) }
        }, 12)
        col.put(cn, 14)

        val bg = card()
        bg.addView(tv(L("خلفية شاشة القفل", "Lock screen background"), 16f, C.TX, true))
        val hs = HorizontalScrollView(this)
        val row = LinearLayout(this)
        val keys = listOf("none") + Look.allKeys(this) + listOf("random")
        keys.forEach { key ->
            val sel = Prefs.bg(this) == key
            val tile = FrameLayout(this).apply {
                background = rounded(C.SF, 10, C.LN)
                if (sel) (background as GradientDrawable).setStroke(dp(3), C.AC)
                setPadding(dp(3), dp(3), dp(3), dp(3))
                setOnClickListener { Prefs.setBg(this@MainActivity, key); recreate() }
            }
            if (key == "none" || key == "random") {
                tile.addView(tv(if (key == "none") L("بدون", "None") else L("عشوائي", "Random"), 12f, C.TX).apply { gravity = Gravity.CENTER },
                    FrameLayout.LayoutParams(MATCH, MATCH))
            } else {
                tile.addView(ImageView(this).apply {
                    setImageBitmap(Look.thumb(this@MainActivity, key))
                    scaleType = ImageView.ScaleType.CENTER_CROP
                }, FrameLayout.LayoutParams(MATCH, MATCH))
                if (key.startsWith("c:")) tile.setOnLongClickListener { confirmDeleteBg(key.substring(2)); true }
            }
            row.addView(tile, LinearLayout.LayoutParams(dp(78), dp(138)).apply { marginEnd = dp(8) })
        }
        hs.addView(row)
        bg.put(hs, 12)
        bg.put(btn(L("إضافة صور من المعرض (عدة صور مرة واحدة)", "Add images from gallery (several at once)")) {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true), 7)
        }, 10)
        bg.put(btn(L("إدارة الخلفيات: أيها يظهر وأيها يختفي", "Manage backgrounds: which show and which hide")) { manageBgs() }, 8)
        bg.put(tv(L("اضغط مطولًا على صورة أضفتها لحذفها.", "Long-press an image you added to delete it."), 12f, C.MU), 6)
        col.put(bg, 14)

        val dm = card()
        dm.addView(tv(L("إضاءة وشفافية الخلفية", "Background brightness and opacity"), 16f, C.TX, true))
        val pk = Prefs.bg(this).let { if (it == "none" || it == "random") "b1" else it }
        val pvImg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setImageBitmap(Look.thumb(this@MainActivity, pk)) }
        val pvScrim = View(this)
        fun applyPv() {
            pvImg.alpha = Prefs.bgOpacity(this) / 100f
            pvScrim.setBackgroundColor(Color.argb((Prefs.bgDim(this) * 2.55f).toInt(), 0, 0, 0))
        }
        val pvFrame = FrameLayout(this).apply { setBackgroundColor(C.BG) }
        pvFrame.addView(pvImg, FrameLayout.LayoutParams(MATCH, MATCH))
        pvFrame.addView(pvScrim, FrameLayout.LayoutParams(MATCH, MATCH))
        dm.addView(pvFrame, LinearLayout.LayoutParams(dp(110), dp(190)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(12) })
        fun slider(label: String, lo: Int, hi: Int, cur: Int, save: (Int) -> Unit) {
            dm.put(tv(label, 13f, C.MU), 10)
            dm.put(SeekBar(this).apply {
                max = hi - lo; progress = cur - lo
                progressTintList = tint(); thumbTintList = tint()
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, pr: Int, u: Boolean) { if (u) { save(pr + lo); applyPv() } }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }, 2)
        }
        slider(L("التعتيم", "Dimming"), 0, 90, Prefs.bgDim(this)) { Prefs.setBgDim(this, it) }
        slider(L("وضوح الصورة", "Image opacity"), 20, 100, Prefs.bgOpacity(this)) { Prefs.setBgOpacity(this, it) }
        applyPv()
        col.put(dm, 14)

        val qc = card()
        qc.addView(tv(L("جملك التحفيزية", "Your motivational quotes"), 16f, C.TX, true))
        val qf = field(L("اكتب جملة", "Write a quote"))
        qc.put(qf, 10)
        qc.put(btn(L("إضافة", "Add")) {
            val t = qf.text.toString().trim()
            if (t.isNotEmpty()) {
                val l = Prefs.myQuotes(this); l.add(t); Prefs.setMyQuotes(this, l)
                qf.text.clear(); renderQuotes()
            }
        }, 8)
        quotesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        qc.put(quotesBox, 8)
        qc.put(tv(L("لغة الجمل الجاهزة", "Built-in quotes language"), 13f, C.MU), 12)
        val ql = LinearLayout(this)
        listOf("both" to L("الاثنين", "Both"), "ar" to L("عربي", "Arabic"), "en" to "English").forEach { (k, n) ->
            ql.addView(btn(n, Prefs.quoteLang(this) == k) { Prefs.setQuoteLang(this, k); recreate() }.apply { textSize = 13f }, lp1())
        }
        qc.put(ql, 6)
        val only = CheckBox(this).apply {
            text = L("اعرض جملي فقط", "Show only my quotes")
            setTextColor(C.TX)
            buttonTintList = tint()
            isChecked = Prefs.onlyMine(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setOnlyMine(this@MainActivity, on) }
        }
        qc.put(only, 8)
        renderQuotes()
        col.put(qc, 14)
        return scroll(col)
    }

    private fun renderQuotes() {
        quotesBox.removeAllViews()
        val l = Prefs.myQuotes(this)
        if (l.isEmpty()) quotesBox.addView(tv(L("لا توجد جمل مضافة. الجمل الجاهزة بالعربي والإنجليزي.", "No custom quotes yet. Built-in quotes come in Arabic and English."), 12f, C.MU))
        l.forEachIndexed { i, q ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(tv(q, 14f, C.TX), LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(tv("✕", 16f, C.MU).apply {
                setPadding(dp(14), dp(10), dp(14), dp(10))
                setOnClickListener { l.removeAt(i); Prefs.setMyQuotes(this@MainActivity, l); renderQuotes() }
            })
            quotesBox.addView(row)
        }
    }

    private fun confirmDeleteBg(name: String) {
        dlg().setMessage(L("حذف هذه الصورة؟", "Delete this image?"))
            .setPositiveButton(L("حذف", "Delete")) { _, _ ->
                val l = Prefs.customBgs(this); l.remove(name); Prefs.setCustomBgs(this, l)
                File(filesDir, name).delete()
                if (Prefs.bg(this) == "c:$name") Prefs.setBg(this, "none")
                recreate()
            }
            .setNegativeButton(L("إلغاء", "Cancel"), null)
            .show()
    }

    private fun manageBgs() {
        val keys = Look.allKeysRaw(this)
        val hidden = Prefs.hiddenBgs(this).toMutableSet()
        val labels = ArrayList<String>()
        var mine = 0
        keys.forEach { k ->
            if (k.startsWith("c:")) { mine++; labels.add(L("صورتي $mine", "My image $mine")) }
            else labels.add(L("خلفية ${k.substring(1)}", "Wallpaper ${k.substring(1)}"))
        }
        val checked = BooleanArray(keys.size) { keys[it] !in hidden }
        dlg().setTitle(L("اختر الخلفيات التي تظهر", "Choose which backgrounds appear"))
            .setMultiChoiceItems(labels.toTypedArray(), checked) { _, which, on -> if (on) hidden.remove(keys[which]) else hidden.add(keys[which]) }
            .setPositiveButton(L("حفظ", "Save")) { _, _ -> Prefs.setHiddenBgs(this, hidden.toList()); recreate() }
            .setNeutralButton(L("إخفاء الكل", "Hide all")) { _, _ -> Prefs.setHiddenBgs(this, keys); recreate() }
            .setNegativeButton(L("إلغاء", "Cancel"), null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 8 && res == RESULT_OK) {
            val u = data?.data ?: return
            try {
                contentResolver.openOutputStream(u)?.use { it.write(Prefs.exportAll(this).toByteArray(Charsets.UTF_8)) }
                toast(L("تم حفظ النسخة الاحتياطية", "Backup saved"))
            } catch (e: Exception) {
                toast(L("تعذّر حفظ الملف", "Couldn't save the file"))
            }
            return
        }
        if (req == 9 && res == RESULT_OK) {
            val u = data?.data ?: return
            val text = try { contentResolver.openInputStream(u)?.use { it.readBytes().toString(Charsets.UTF_8) } } catch (e: Exception) { null }
            if (text == null) toast(L("تعذّرت قراءة الملف", "Couldn't read the file")) else confirmImport(text)
            return
        }
        if (req != 7 || res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.clipData?.let { cd -> for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        if (uris.isEmpty()) return
        toast(L("جارٍ إضافة ${uris.size} صورة...", "Adding ${uris.size} image(s)..."))
        Thread {
            val saved = ArrayList<String>()
            for (uri in uris) {
                try {
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: continue
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                    var s = 1
                    while (o.outHeight / s > 1700) s *= 2
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s }) ?: continue
                    val name = "bg_" + System.currentTimeMillis() + "_" + saved.size + ".jpg"
                    FileOutputStream(File(filesDir, name)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                    saved.add(name)
                } catch (e: Exception) { }
            }
            runOnUiThread {
                if (saved.isEmpty()) toast(L("تعذّر استخدام الصور", "Couldn't use these images"))
                else {
                    val l = Prefs.customBgs(this); l.addAll(saved); Prefs.setCustomBgs(this, l)
                    if (saved.size == 1) Prefs.setBg(this, "c:" + saved[0])
                    toast(L("تمت إضافة ${saved.size} صورة", "Added ${saved.size} image(s)"))
                    recreate()
                }
            }
        }.start()
    }

    // ---------- التحديث ----------
    private fun versionName(): String = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

    private fun autoCheck() {
        if (!Prefs.autoUpdate(this)) return
        if (System.currentTimeMillis() - Prefs.lastCheck(this) < 6 * 3_600_000L) return
        checkUpdate(false)
    }

    private fun checkUpdate(manual: Boolean) {
        Prefs.setLastCheck(this, System.currentTimeMillis())
        Updater.check(this) { ok, info ->
            if (!isFinishing) {
                if (info != null) promptUpdate(info)
                else if (manual && ok) toast(L("أنت على آخر إصدار", "You're on the latest version"))
                else if (manual) toast(L("تعذّر الاتصال، حاول لاحقًا", "Couldn't connect, try again later"))
            }
        }
    }

    private fun promptUpdate(info: Updater.Info) {
        dlg().setTitle(L("نسخة جديدة ${info.tag}", "New version ${info.tag}"))
            .setMessage((if (info.notes.isNotBlank()) L("ما الجديد:\n", "What's new:\n") + info.notes.take(700) + "\n\n" else "") + L("تقدمك وإعداداتك ستبقى كما هي. تنزيل وتثبيت الآن؟", "Your progress and settings will be kept. Download and install now?"))
            .setPositiveButton(L("حدّث الآن", "Update now")) { _, _ ->
                toast(L("جارٍ التنزيل...", "Downloading..."))
                Updater.download(this, info)
            }
            .setNegativeButton(L("لاحقًا", "Later"), null)
            .show()
    }

    // ---------- الإعدادات ----------
    private fun engineMsg(): String = if (Edition.FULL)
        L("فعّل «بيانات الاستخدام» و«العرض فوق التطبيقات» (أو إمكانية الوصول) من الإعدادات", "Enable Usage access and Display over other apps (or Accessibility) in Settings")
    else L("فعّل «بيانات الاستخدام» و«العرض فوق التطبيقات» من الإعدادات", "Enable Usage access and Display over other apps in Settings")
    private fun notifListenerOn(): Boolean =
        (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)
    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/")
    }
    private fun adminOn(): Boolean =
        getSystemService(DevicePolicyManager::class.java).isAdminActive(ComponentName(this, AdminReceiver::class.java))
    private fun batteryOn(): Boolean =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
    private fun notifOn(): Boolean =
        getSystemService(NotificationManager::class.java).areNotificationsEnabled()

    private fun perm(parent: LinearLayout, title: String, desc: String, on: () -> Boolean, action: () -> Unit) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(tv(title, 15f, C.TX, true))
        info.addView(tv(desc, 12f, C.MU))
        val st = tv(L("مفعّل ✓", "On ✓"), 13f, C.OK)
        val b = btn(L("تفعيل", "Enable")) { action() }.apply { textSize = 13f; setPadding(dp(14), dp(8), dp(14), dp(8)) }
        row.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(st)
        row.addView(b)
        parent.put(row, 14)
        refreshers.add {
            val ok = on()
            st.visibility = if (ok) View.VISIBLE else View.GONE
            b.visibility = if (ok) View.GONE else View.VISIBLE
        }
    }

    private fun settingsPage(): View {
        val col = column()
        col.put(tv(L("الإعدادات", "Settings"), 24f, C.TX, true), 0)

        val lg = card()
        lg.addView(tv(L("اللغة", "Language"), 16f, C.TX, true))
        val lr = LinearLayout(this)
        lr.addView(btn("العربية", Prefs.lang(this) == "ar") { Prefs.setLang(this, "ar"); recreate() }, lp1())
        lr.addView(btn("English", Prefs.lang(this) == "en") { Prefs.setLang(this, "en"); recreate() }, lp1())
        lg.put(lr, 10)
        col.put(lg, 14)

        val fabCard = card()
        fabCard.addView(tv(L("الزر العائم ◎", "Floating button ◎"), 16f, C.TX, true))
        fabCard.put(tv(L("زر ◎ يحوّل التطبيق إلى صفحة واحدة فيها الأساسيات. اسحبه بإصبعك وحطّه في أي مكان تحبه.",
            "The ◎ button turns the app into one essentials page. Drag it with your finger and put it anywhere you like."), 12f, C.MU).apply { setLineSpacing(0f, 1.2f) }, 4)
        fabCard.put(CheckBox(this).apply {
            text = L("إبقاء الزر عائمًا فوق كل التطبيقات طوال الوقت", "Keep the button floating over all apps at all times")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.boolOf(this@MainActivity, "fabAll", false)
            setOnCheckedChangeListener { _, on ->
                Prefs.putBool(this@MainActivity, "fabAll", on)
                if (on && !Engine.overlayOn(this@MainActivity)) {
                    toast(L("فعّل «العرض فوق التطبيقات» ثم ارجع للتطبيق", "Enable Display over other apps, then come back"))
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
                FloatingFab.sync(this@MainActivity)
            }
        }, 8)
        fabCard.put(tv(L("يختفي أثناء الجلسة وعندما يكون التطبيق مفتوحًا أمامك.", "It hides during a session and while the app is open in front of you."), 12f, C.MU), 4)
        fabCard.put(btn(L("إعادة الزر لمكانه الأصلي", "Reset the button position")) {
            FloatingFab.resetPosition(this)
            fabFrame?.let { placeFab(it) }
            toast(L("تمت إعادة الزر لمكانه", "Button position reset"))
        }, 8)
        col.put(fabCard, 14)

        val autoCard = card()
        autoCard.addView(tv(L("جلسات تلقائية", "Scheduled sessions"), 16f, C.TX, true))
        autoCard.put(tv(L("تبدأ جلسة التركيز لوحدها في الأيام والوقت اللي تحددهم. محتاجة كلمة مرور وتطبيقات محجوبة (أو القفل الكامل) وأذونات الحماية جاهزة.",
            "A focus session starts by itself on the days and time you choose. It needs a password, blocked apps (or full lock) and the protection permissions ready."), 12f, C.MU).apply { setLineSpacing(0f, 1.2f) }, 4)
        val rulesBox = LinearLayout(this)
        rulesBox.orientation = LinearLayout.VERTICAL
        fun renderRules() {
            rulesBox.removeAllViews()
            val rs = AutoSched.rules(this)
            if (rs.isEmpty()) rulesBox.addView(tv(L("لا توجد جلسات مجدولة", "No scheduled sessions"), 13f, C.MU))
            for (r in rs) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.addView(tv(AutoSched.describe(this, r), 14f, C.TX), LinearLayout.LayoutParams(0, WRAP, 1f))
                val del = tv("✕", 18f, C.MU, true)
                del.setPadding(dp(12), dp(8), dp(12), dp(8))
                del.setOnClickListener {
                    val cur = AutoSched.rules(this)
                    cur.removeAll { x -> x.days == r.days && x.min == r.min && x.len == r.len }
                    AutoSched.save(this, cur)
                    renderRules()
                }
                row.addView(del)
                rulesBox.addView(row)
            }
        }
        renderRules()
        autoCard.put(rulesBox, 8)
        autoCard.put(btn(L("+ إضافة جلسة مجدولة", "+ Add scheduled session")) { addRule { renderRules() } }, 8)
        col.put(autoCard, 14)

        val weekCard = card()
        weekCard.addView(tv(L("التقرير الأسبوعي", "Weekly report"), 16f, C.TX, true))
        weekCard.put(CheckBox(this).apply {
            text = L("إشعار كل جمعة بملخص تركيزك مقارنةً بالأسبوع الماضي", "A notification every Friday with your focus summary vs last week")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.boolOf(this@MainActivity, "weekly", true)
            setOnCheckedChangeListener { _, on ->
                Prefs.putBool(this@MainActivity, "weekly", on)
                WeeklyReport.schedule(this@MainActivity)
            }
        }, 8)
        col.put(weekCard, 14)

        val bkCard = card()
        bkCard.addView(tv(L("نسخة احتياطية", "Backup"), 16f, C.TX, true))
        bkCard.put(tv(L("احفظ تقدمك وإعداداتك في ملف واستورده على أي جهاز. لا يشمل الصور الخلفية المرفوعة ولا كلمة المرور.",
            "Save your progress and settings to a file and import it on any device. It does not include uploaded background images or the password."), 12f, C.MU).apply { setLineSpacing(0f, 1.2f) }, 4)
        bkCard.put(btn(L("تصدير التقدم", "Export progress")) { startExport() }, 8)
        bkCard.put(btn(L("استيراد التقدم", "Import progress")) { startImport() }, 8)
        col.put(bkCard, 14)

        val perms = card()
        perms.addView(tv(L("الصلاحيات", "Permissions"), 16f, C.TX, true))
        perm(perms, L("بيانات الاستخدام", "Usage access"), L("لاكتشاف التطبيق المفتوح وعرض الإحصائيات", "Detects the open app and shows statistics"), { hasUsageAccess() }) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        perm(perms, L("العرض فوق التطبيقات", "Display over other apps"), L("لإظهار شاشة القفل فوق التطبيق المحظور", "Shows the lock screen over a blocked app"), { Engine.overlayOn(this) }) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        if (Edition.FULL) perm(perms, L("إمكانية الوصول (اختياري، الأقوى)", "Accessibility (optional, strongest)"), L("استجابة فورية وكشف صفحات الحذف", "Instant response and uninstall-page detection"), { a11yOn() }) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        perm(perms, L("مشرف الجهاز", "Device admin"), L("لمنع حذف التطبيق أثناء الجلسة", "Makes uninstalling hard during a session"), { adminOn() }) {
            startActivity(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, getString(R.string.admin_desc))
            )
        }
        perm(perms, L("استثناء البطارية", "Battery"), L("حتى لا يوقف النظام التطبيق", "Stops the system from killing the app"), { batteryOn() }) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        perm(perms, L("الإشعارات", "Notifications"), L("إشعار الجلسة الدائم", "The ongoing session notification"), { notifOn() }) {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
        col.put(perms, 14)

        val pwCard = card()
        pwCard.addView(tv(L("كلمة مرور الخروج الطارئ", "Emergency password"), 16f, C.TX, true))
        pwStatus = tv(if (Prefs.hasPassword(this)) L("تم ضبط كلمة المرور ✓", "Password is set ✓") else L("لم تضبط كلمة مرور بعد", "No password yet"), 13f, C.MU)
        pwCard.put(pwStatus, 4)
        pwField = field(L("8 أحرف على الأقل، حروف وأرقام", "8+ characters, letters and numbers")).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        pwCard.put(pwField, 10)
        hintField = field(L("تلميح للكلمة (اختياري، يظهر على شاشة القفل)", "Password hint (optional, shown on the lock screen)"))
            .apply { setText(Prefs.hint(this@MainActivity)) }
        pwCard.put(hintField, 10)
        pwCard.put(btn(L("حفظ كلمة المرور", "Save password")) { savePassword() }, 10)
        col.put(pwCard, 14)

        val modeCard = card()
        val strictCb = CheckBox(this).apply {
            text = L("قفل كامل للهاتف", "Full phone lock")
            setTextColor(C.TX)
            buttonTintList = tint()
            isChecked = Prefs.strict(this@MainActivity)
            setOnCheckedChangeListener { v, on ->
                if (on && !Prefs.strict(this@MainActivity)) {
                    dlg().setMessage(L("القفل الكامل يمنع كل التطبيقات أثناء الجلسة عدا الاتصال. متأكد؟", "Full lock blocks every app during a session except calls. Sure?"))
                        .setPositiveButton(L("نعم", "Yes")) { _, _ -> Prefs.setStrict(this@MainActivity, true); refreshSummary() }
                        .setNegativeButton(L("إلغاء", "Cancel")) { _, _ -> v.isChecked = false }
                        .setOnCancelListener { v.isChecked = false }
                        .show()
                } else { Prefs.setStrict(this@MainActivity, on); refreshSummary() }
            }
        }
        modeCard.addView(strictCb)
        modeCard.addView(tv(L("يمنع كل التطبيقات أثناء الجلسة عدا الاتصال والطوارئ.", "Blocks every app during a session except calls and emergency."), 12f, C.MU))
        col.put(modeCard, 14)

        val snd = card()
        snd.addView(tv(L("الأصوات", "Sounds"), 16f, C.TX, true))
        snd.put(CheckBox(this).apply {
            text = L("أصوات المهام", "Task sounds")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.taskSounds(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setTaskSounds(this@MainActivity, on); if (on) Sfx.task(this@MainActivity, Sfx.DONE) }
        }, 8)
        snd.put(CheckBox(this).apply {
            text = L("أصوات الأزرار", "Button sounds")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.clickSounds(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setClickSounds(this@MainActivity, on); if (on) Sfx.click(this@MainActivity) }
        }, 4)
        fun sndBox(label: String, get: () -> Boolean, set: (Boolean) -> Unit, kind: Int) = snd.put(CheckBox(this).apply {
            text = label; setTextColor(C.TX); buttonTintList = tint(); isChecked = get()
            setOnCheckedChangeListener { _, on -> set(on); if (on) Sfx.playKind(this@MainActivity, kind) }
        }, 4)
        sndBox(L("صوت بداية الحظر", "Sound when a lock starts"), { Prefs.sndStart(this) }, { Prefs.setSndStart(this, it) }, Sfx.START)
        sndBox(L("صوت نهاية الحظر", "Sound when a lock ends"), { Prefs.sndEnd(this) }, { Prefs.setSndEnd(this, it) }, Sfx.END)
        sndBox(L("صوت الجمل التحفيزية والتنبيهات", "Sound for quotes and alerts"), { Prefs.sndQuote(this) }, { Prefs.setSndQuote(this, it) }, Sfx.QUOTE)
        snd.put(tv(L("حزمة الأصوات", "Sound pack"), 13f, C.MU), 12)
        val sr = LinearLayout(this)
        listOf(L("كلاسيك", "Classic"), L("ناعم", "Soft"), L("فقاعة", "Pop"), L("ريترو", "Retro")).forEachIndexed { k, n ->
            sr.addView(btn(n, Prefs.soundPack(this) == k) {
                Prefs.setSoundPack(this, k); Sfx.playKind(this, Sfx.ADD); recreate()
            }.apply { textSize = 13f; setPadding(dp(4), dp(12), dp(4), dp(12)) }, lp1())
        }
        snd.put(sr, 6)
        col.put(snd, 14)

        val upd = card()
        upd.addView(tv(L("التحديثات", "Updates"), 16f, C.TX, true))
        upd.put(tv(L("يتحدث التطبيق من GitHub وتقدمك يبقى محفوظًا. يستخدم الإنترنت لفحص النسخ فقط.",
            "The app updates from GitHub and keeps your progress. It uses the internet only to check versions."), 12f, C.MU), 4)
        upd.put(CheckBox(this).apply {
            text = L("فحص التحديثات تلقائيًا", "Check for updates automatically")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.autoUpdate(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setAutoUpdate(this@MainActivity, on); UpdateJob.schedule(this@MainActivity) }
        }, 8)
        upd.put(btn(L("افحص التحديثات الآن", "Check for updates now")) { checkUpdate(true) }, 8)
        col.put(upd, 14)

        val adv = card()
        adv.addView(tv(L("حماية متقدمة", "Advanced protection"), 16f, C.TX, true))
        adv.put(CheckBox(this).apply {
            text = L("زيادة وقت الجلسة أثناء توفير الطاقة", "Extend the session while power saver is on")
            setTextColor(C.TX); buttonTintList = tint(); isChecked = Prefs.saverPenalty(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setSaverPenalty(this@MainActivity, on) }
        }, 8)
        adv.put(tv(L("وضع توفير الطاقة الفائق قد يوقف الحماية. كل دقيقة يبقى فيها تُضاف لجلستك حتى لا يفيد التحايل به.",
            "Extreme power saving can pause protection. Every minute spent in it is added to your session, so it can't be used to dodge a lock."), 12f, C.MU), 4)
        if (Edition.FULL) {
            adv.put(CheckBox(this).apply {
                text = L("حظر إشعارات التطبيقات المحظورة", "Mute notifications of blocked apps")
                setTextColor(C.TX); buttonTintList = tint(); isChecked = Prefs.blockNotifs(this@MainActivity)
                setOnCheckedChangeListener { _, on ->
                    Prefs.setBlockNotifs(this@MainActivity, on)
                    if (on && !notifListenerOn()) startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
            }, 12)
            adv.put(tv(L("يحتاج «الوصول إلى الإشعارات». متاح في النسخة الكاملة فقط.", "Needs Notification access. Available in the Full edition only."), 12f, C.MU), 4)
        } else {
            adv.put(tv(L("حظر إشعارات التطبيقات المحظورة متاح في النسخة الكاملة فقط، لأنه يحتاج إذنًا تمنعه جوجل عند التثبيت من المتصفح.",
                "Muting notifications of blocked apps is in the Full edition only: it needs a permission Google blocks for browser installs."), 12f, C.MU), 12)
        }
        col.put(adv, 14)

        val oem = card()
        oem.addView(tv(L("لو التطبيق بيتوقف لوحده", "If the app keeps stopping"), 16f, C.TX, true))
        oem.put(tv(L("هاتفك (${Build.MANUFACTURER}) ممكن يوقف الخدمات الخلفية. فعّل التشغيل التلقائي، وخلّي البطارية «بدون قيود»، وثبّت التطبيق في قائمة التطبيقات الأخيرة.",
            "Your phone (${Build.MANUFACTURER}) may stop background services. Enable auto-start, set battery to Unrestricted, and lock the app in Recents."), 12f, C.MU), 4)
        oem.put(btn(L("افتح التشغيل التلقائي", "Open auto-start settings")) { openAutostart() }, 10)
        col.put(oem, 14)

        val coach = card()
        coach.addView(tv(L("المرشد الذكي (اختياري)", "Smart guide (optional)"), 16f, C.TX, true))
        coach.put(tv(L("لو قعدت وقت طويل في تطبيق مشتّت، يسألك بلطف أولًا، ثم يذكّرك بمهامك، ثم يقترح استراحة قصيرة. يتعلم من مدة استخدامك على هاتفك فقط، ويخفف التنبيهات لو تجاوبت معه. ما بيتدخلش في أي تطبيق آخر، كل ما يفعله إشعار أو شاشة تذكير تقدر تتجاهلها.",
            "If you stay long in a distracting app, it first asks gently, then reminds you of your tasks, then suggests a short break. It learns only from your usage on this phone and eases off if you respond. It never touches other apps: it only shows a notification or a reminder screen you can dismiss."), 12f, C.MU).apply { setLineSpacing(0f, 1.2f) }, 4)
        coach.put(CheckBox(this).apply {
            text = L("تفعيل المرشد الذكي", "Enable the smart guide")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.smart(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setSmart(this@MainActivity, on) }
        }, 8)
        coach.put(btn(L("إعادة ضبط ما تعلّمه", "Reset what it learned")) { Prefs.resetSmart(this); toast(L("تمت إعادة الضبط", "Reset done")) }, 8)
        col.put(coach, 14)

        val ecoCard = card()
        ecoCard.addView(tv(L("وضع توفير البطارية", "Battery-saving mode"), 16f, C.TX, true))
        ecoCard.put(tv(L("يقلّل وتيرة المراقبة والحركة ولا يُبقي الشاشة مضاءة أثناء الجلسة. تبقى الحماية شغالة.", "Lowers monitoring and animation rates and doesn't keep the screen on during a session. Protection stays active."), 12f, C.MU), 4)
        ecoCard.put(CheckBox(this).apply {
            text = L("تفعيل دائم", "Always on")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.boolOf(this@MainActivity, "eco", false)
            setOnCheckedChangeListener { _, on -> Prefs.putBool(this@MainActivity, "eco", on) }
        }, 8)
        ecoCard.put(CheckBox(this).apply {
            text = L("تفعيل تلقائي عند بطارية 20% أو أقل", "Switch on automatically at 20% battery or less")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.boolOf(this@MainActivity, "ecoAuto", true)
            setOnCheckedChangeListener { _, on -> Prefs.putBool(this@MainActivity, "ecoAuto", on) }
        }, 4)
        col.put(ecoCard, 14)

        val about = card()
        about.addView(tv("Vigil " + versionName() + (if (Edition.FULL) " Full" else " Lite"), 16f, C.TX, true))
        about.put(tv(L("القائم على التطبيق: Ibrahim Elwaleed", "Maintained by Ibrahim Elwaleed"), 13f, C.MU), 4)
        about.put(btn(L("عرض المرشد", "Show the guide")) {
            startActivity(Intent(this, OnboardingActivity::class.java).putExtra("replay", true))
        }, 10)
        about.put(btn(L("سياسة الخصوصية", "Privacy policy")) {
            dlg().setTitle(L("سياسة الخصوصية", "Privacy policy"))
                .setMessage(L(
                    "- يستخدم التطبيق الإنترنت لفحص وتنزيل التحديثات من GitHub فقط، ولا يرسل أي بيانات شخصية من هاتفك.\n" +
                    "- خدمة إمكانية الوصول تقرأ اسم التطبيق المفتوح فقط لمنع ما اخترته، ولا تقرأ محتوى الشاشة.\n" +
                    "- مشرف الجهاز يُستخدم فقط لتصعيب الحذف أثناء جلسة بدأتها بنفسك.\n" +
                    "- الإعدادات والمهام والصور والإحصائيات تُحفظ على هاتفك فقط.\n" +
                    "- إحصائيات الاستخدام تُقرأ من نظام أندرويد على هاتفك (بإذن «بيانات الاستخدام» الذي تمنحه بنفسك) لعرض الرسوم، ولا تغادر هاتفك.\n" +
                    "- حدود التطبيقات والمرشد الذكي يعملان محليًا ويتعلمان من مدة استخدامك على هاتفك فقط. تقدر توقفهما وتعيد ضبط تعلّمهما في أي وقت.\n" +
                    "- المراقب والجدولة والأهداف واليوميات تُحفظ على هاتفك فقط ولا تُرسل لأي جهة. والمراقب لا يعمل إلا بعد موافقتك الصريحة على المستوى الذي تختاره.\n" +
                    "- لا تُحظر المكالمات والطوارئ والبنوك والتطبيقات المالية أبدًا.\n" +
                    "- القائم على التطبيق: Ibrahim Elwaleed.",
                    "- The app uses the internet only to check for and download updates from GitHub. It sends no personal data from your phone.\n" +
                    "- The accessibility service reads only the name of the app being opened, to block what you chose. It never reads screen content.\n" +
                    "- Device admin is used only to make uninstalling harder during a session you started.\n" +
                    "- Settings, tasks, images and stats stay on your phone.\n" +
                    "- Usage statistics are read from Android on your phone (with the Usage access permission you grant) to draw the charts, and never leave the phone.\n" +
                    "- App limits and the smart guide run locally and learn only from your usage on this phone. You can turn them off and reset their learning anytime.\n" +
                    "- The Overseer, planner, goals and journal stay on your phone only and are sent nowhere. The Overseer only works after you explicitly agree to the level you choose.\n" +
                    "- Calls, emergency, banks and finance apps are never blocked.\n" +
                    "- Maintained by Ibrahim Elwaleed."))
                .setPositiveButton(L("حسنًا", "OK"), null)
                .show()
        }, 8)
        col.put(about, 14)
        return scroll(col)
    }

    private fun openAutostart() {
        val tries = listOf(
            "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.oplus.safecenter" to "com.oplus.safecenter.permission.startup.StartupAppListActivity",
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"
        )
        for ((pkg, cls) in tries) {
            try { startActivity(Intent().setComponent(ComponentName(pkg, cls))); return } catch (e: Exception) { }
        }
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun savePassword() {
        val pw = pwField.text.toString()
        Prefs.setHint(this, hintField.text.toString().trim())
        if (pw.isEmpty() && Prefs.hasPassword(this)) { toast(L("تم حفظ التلميح", "Hint saved")); return }
        if (pw.length < 8 || !pw.any { it.isDigit() } || !pw.any { it.isLetter() }) {
            toast(L("كلمة المرور يجب أن تكون 8 أحرف على الأقل وتحتوي على حروف وأرقام", "Password needs 8+ characters with letters and numbers")); return
        }
        Prefs.setPassword(this, pw)
        pwField.text.clear()
        pwStatus.text = L("تم ضبط كلمة المرور ✓", "Password is set ✓")
        refreshBanner()
        toast(L("تم الحفظ. احتفظ بها في مكان آمن.", "Saved. Keep it somewhere safe."))
    }
}
