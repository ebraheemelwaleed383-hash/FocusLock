package com.focuslock

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private val checks = LinkedHashMap<String, CheckBox>()
    private lateinit var pwField: EditText
    private lateinit var minsField: EditText
    private lateinit var strict: CheckBox

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.settle(this)
        if (Prefs.active(this)) {
            startActivity(Intent(this, LockActivity::class.java)); finish(); return
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(32))
        }
        fun label(t: String, size: Float = 14f) = TextView(this).apply { text = t; textSize = size; setPadding(0, dp(14), 0, dp(6)) }
        fun button(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        col.addView(label("قفل التركيز", 26f))
        col.addView(label("جلسات مكتملة: ${Prefs.doneCount(this)}، دقائق تركيز: ${Prefs.doneMins(this)}"))
        col.addView(label("اضبط الصلاحيات مرة واحدة:"))
        col.addView(button("1) تفعيل خدمة إمكانية الوصول") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("2) تفعيل مشرف الجهاز (منع الحذف)") {
            startActivity(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, getString(R.string.admin_desc))
            )
        })
        col.addView(button("3) استثناء من توفير البطارية") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        })

        col.addView(label("كلمة مرور الخروج الطارئ (8 أحرف على الأقل، حروف وأرقام)"))
        pwField = EditText(this).apply {
            hint = if (Prefs.hasPassword(this@MainActivity)) "اتركها فارغة للإبقاء على الحالية" else "كلمة المرور"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        col.addView(pwField)

        col.addView(label("مدة الجلسة بالدقائق (من 1 إلى 720)"))
        minsField = EditText(this).apply { setText("25"); inputType = InputType.TYPE_CLASS_NUMBER }
        col.addView(minsField)
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(15, 25, 45, 60, 90).forEach { m ->
            quick.addView(
                Button(this).apply { text = "$m"; setOnClickListener { minsField.setText(m.toString()) } },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
        }
        col.addView(quick)

        strict = CheckBox(this).apply {
            text = "قفل كامل: كل التطبيقات ممنوعة عدا الاتصال"
            isChecked = Prefs.strict(this@MainActivity)
        }
        col.addView(strict)

        col.addView(label("التطبيقات المحظورة"))
        val saved = Prefs.blocked(this)
        val pm = packageManager
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
            .forEach { (pkg, name) ->
                val cb = CheckBox(this).apply { text = name; isChecked = pkg in saved }
                checks[pkg] = cb; col.addView(cb)
            }

        col.addView(button("ابدأ الجلسة") { startSession() }.apply { setPadding(0, dp(18), 0, dp(18)) })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/")
    }

    private fun startSession() {
        val pw = pwField.text.toString()
        if (pw.isNotEmpty()) {
            if (pw.length < 8 || !pw.any { it.isDigit() } || !pw.any { it.isLetter() }) {
                toast("كلمة المرور يجب أن تكون 8 أحرف على الأقل وتحتوي على حروف وأرقام"); return
            }
            Prefs.setPassword(this, pw)
        }
        if (!Prefs.hasPassword(this)) { toast("اختر كلمة مرور أولًا"); return }
        val mins = minsField.text.toString().toIntOrNull() ?: 0
        if (mins !in 1..720) { toast("المدة بين 1 و720 دقيقة"); return }
        if (!a11yOn()) { toast("فعّل خدمة إمكانية الوصول أولًا (الخطوة 1)"); return }
        val sel = checks.filter { it.value.isChecked }.keys
        if (sel.isEmpty() && !strict.isChecked) { toast("اختر تطبيقًا واحدًا على الأقل أو فعّل القفل الكامل"); return }

        Prefs.clearFails(this)
        Prefs.setBlocked(this, sel)
        Prefs.setStrict(this, strict.isChecked)
        Prefs.begin(this, mins)
        KeepAliveService.start(this)
        startActivity(Intent(this, LockActivity::class.java))
        finish()
    }
}
