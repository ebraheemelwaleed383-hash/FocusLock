package com.focuslock

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    companion object { var tabKeep = 0 }

    private class Row(val pkg: String, val name: String, val cb: CheckBox)

    private val picked = HashSet<String>()
    private val rows = ArrayList<Row>()
    private val refreshers = ArrayList<() -> Unit>()
    private val h = Handler(Looper.getMainLooper())
    private val endTick = object : Runnable {
        override fun run() { if (ready) refreshEnd(); h.postDelayed(this, 20_000) }
    }
    private lateinit var pages: List<View>
    private lateinit var tabs: List<TextView>
    private lateinit var minsTv: TextView
    private lateinit var endTv: TextView
    private lateinit var seek: SeekBar
    private lateinit var summaryTv: TextView
    private lateinit var countTv: TextView
    private lateinit var banner: LinearLayout
    private lateinit var bannerTv: TextView
    private lateinit var pwField: EditText
    private lateinit var pwStatus: TextView
    private lateinit var taskBox: LinearLayout
    private lateinit var quotesBox: LinearLayout
    private var mins = 25
    private var ready = false

    private val common = setOf(
        "com.instagram.android", "com.instagram.lite", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
        "com.google.android.youtube", "com.twitter.android", "com.snapchat.android", "com.facebook.katana",
        "com.facebook.lite", "com.reddit.frontpage", "com.netflix.mediaclient", "com.pinterest"
    )

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun lp1() = LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(4); marginEnd = dp(4) }
    private fun tint() = ColorStateList.valueOf(C.AC)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applyTheme()
        Prefs.settle(this)
        if (Prefs.active(this)) {
            startActivity(Intent(this, LockActivity::class.java)); finish(); return
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        picked.addAll(Prefs.blocked(this))
        mins = Prefs.lastMins(this).coerceIn(5, 240) / 5 * 5

        pages = listOf(homePage(), tasksPage(), appsPage(), stylePage(), settingsPage())
        val content = FrameLayout(this)
        pages.forEach { content.addView(it) }

        val bar = LinearLayout(this).apply { setBackgroundColor(C.SF) }
        val names = listOf(L("الرئيسية", "Home"), L("المهام", "Tasks"), L("التطبيقات", "Apps"), L("المظهر", "Style"), L("الإعدادات", "Settings"))
        tabs = names.mapIndexed { i, n ->
            tv(n, 12f, C.MU).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(15), 0, dp(15))
                setOnClickListener { Sfx.click(this@MainActivity); select(i) }
            }
        }
        tabs.forEach { bar.addView(it, LinearLayout.LayoutParams(0, WRAP, 1f)) }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        root.applyDir()
        setContentView(root)
        select(tabKeep.coerceIn(0, 4))
        ready = true
        Sfx.warm(this)
        autoCheck()
    }

    override fun onResume() {
        super.onResume()
        if (!::pages.isInitialized) return
        refreshers.forEach { it() }
        refreshBanner()
        refreshSummary()
        h.post(endTick)
    }

    override fun onPause() { h.removeCallbacks(endTick); super.onPause() }

    private fun select(i: Int) {
        tabKeep = i
        pages.forEachIndexed { j, p -> p.visibility = if (i == j) View.VISIBLE else View.GONE }
        tabs.forEachIndexed { j, t ->
            t.setTextColor(if (i == j) C.AC else C.MU)
            t.setTypeface(null, if (i == j) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(26), dp(18), dp(24))
    }

    private fun scroll(c: View): View = ScrollView(this).apply { addView(c) }

    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText
        setTextColor(C.TX); setHintTextColor(C.MU)
        background = rounded(C.SF, 12, C.LN)
        setPadding(dp(14), dp(12), dp(14), dp(12))
    }

    private fun fmtMins(m: Int): String =
        if (m < 60) L("$m دقيقة", "$m min") else "${m / 60} " + L("س", "h") + (if (m % 60 > 0) " ${m % 60} " + L("د", "m") else "")

    private fun showMins() { minsTv.text = fmtMins(mins); refreshEnd(); Prefs.setLastMins(this, mins) }

    private fun refreshEnd() {
        endTv.text = L("ينتهي القفل الساعة ", "Unlocks at ") + clock(System.currentTimeMillis() + mins * 60_000L)
    }

    // ---------- الرئيسية ----------
    private fun homePage(): View {
        val col = column()
        col.put(tv("Stay focused", 28f, C.TX, true), 0)
        col.put(tv(L("اختر المدة، ثم أغلق على نفسك.", "Pick a duration, then lock yourself in."), 14f, C.MU), 4)

        banner = card()
        bannerTv = tv("", 14f, C.WR)
        banner.addView(bannerTv)
        banner.put(btn(L("افتح الإعدادات", "Open settings")) { select(4) }, 10)
        col.put(banner, 16)

        val stats = LinearLayout(this)
        fun stat(n: String, l: String) = card().apply { addView(tv(n, 28f, C.AC, true)); addView(tv(l, 12f, C.MU)) }
        stats.addView(stat(Prefs.doneCount(this).toString(), L("جلسة مكتملة", "sessions done")),
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(6) })
        stats.addView(stat(Prefs.doneMins(this).toString(), L("دقيقة تركيز", "focus minutes")),
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(6) })
        col.put(stats, 16)

        val dur = card()
        dur.addView(tv(L("مدة الجلسة", "Session length"), 14f, C.MU))
        minsTv = tv("", 34f, C.TX, true)
        dur.put(minsTv, 4)
        endTv = tv("", 13f, C.AC)
        dur.put(endTv, 2)
        seek = SeekBar(this).apply {
            max = 47
            progress = mins / 5 - 1
            progressTintList = tint()
            thumbTintList = tint()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) { mins = (p + 1) * 5; showMins() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        dur.put(seek, 8)
        val chips = LinearLayout(this)
        listOf(15, 25, 45, 60, 90, 120).forEach { m ->
            val chip = tv("$m", 14f, C.TX).apply {
                gravity = Gravity.CENTER
                background = rounded(C.BG, 12, C.LN)
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { mins = m; seek.progress = m / 5 - 1; showMins() }
            }
            chips.addView(chip, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
        }
        dur.put(chips, 8)
        col.put(dur, 12)
        showMins()

        summaryTv = tv("", 14f, C.MU)
        col.put(summaryTv, 14)
        col.put(btn(L("ابدأ الجلسة", "Start session"), true) { tryStart() }.apply { textSize = 17f }, 10)
        return scroll(col)
    }

    private fun refreshBanner() {
        val m = ArrayList<String>()
        if (!a11yOn()) m.add(L("إمكانية الوصول", "Accessibility"))
        if (!adminOn()) m.add(L("مشرف الجهاز", "Device admin"))
        if (!batteryOn()) m.add(L("استثناء البطارية", "Battery"))
        if (!Prefs.hasPassword(this)) m.add(L("كلمة المرور", "Password"))
        banner.visibility = if (m.isEmpty()) View.GONE else View.VISIBLE
        bannerTv.text = L("أكمل الإعدادات: ", "Finish setup: ") + m.joinToString(L("، ", ", "))
    }

    private fun refreshSummary() {
        summaryTv.text = when {
            Prefs.strict(this) -> L("قفل كامل: كل التطبيقات ممنوعة عدا الاتصال", "Full lock: every app is blocked except calls")
            picked.isEmpty() -> L("لم تختر أي تطبيق بعد. افتح تبويب التطبيقات.", "No apps chosen yet. Open the Apps tab.")
            else -> L("التطبيقات المحظورة: ${picked.size}", "Blocked apps: ${picked.size}")
        }
        countTv.text = L("المحدد: ${picked.size}", "Selected: ${picked.size}")
    }

    private fun tryStart() {
        if (!Prefs.hasPassword(this)) { toast(L("اضبط كلمة مرور الخروج الطارئ أولًا", "Set an emergency password first")); select(4); return }
        if (!a11yOn()) { toast(L("فعّل خدمة إمكانية الوصول أولًا", "Enable the accessibility service first")); select(4); return }
        if (picked.isEmpty() && !Prefs.strict(this)) { toast(L("اختر تطبيقًا واحدًا على الأقل أو فعّل القفل الكامل", "Pick at least one app or enable full lock")); select(2); return }
        val at = clock(System.currentTimeMillis() + mins * 60_000L)
        dlg().setTitle(L("بدء الجلسة", "Start session"))
            .setMessage(L("لن تستطيع الخروج إلا بعد ${fmtMins(mins)} (الساعة $at) أو بكلمة المرور. هل أنت جاهز؟",
                "You can't leave for ${fmtMins(mins)} (until $at) except with your password. Ready?"))
            .setPositiveButton(L("ابدأ", "Start")) { _, _ -> go() }
            .setNegativeButton(L("إلغاء", "Cancel"), null)
            .show()
    }

    private fun go() {
        Prefs.clearFails(this)
        Prefs.setBlocked(this, picked)
        Prefs.begin(this, mins)
        KeepAliveService.start(this)
        startActivity(Intent(this, LockActivity::class.java))
        finish()
    }

    // ---------- المهام ----------
    private fun tasksPage(): View {
        val col = column()
        col.put(tv(L("المهام", "Tasks"), 24f, C.TX, true), 0)
        col.put(tv(L("المهام غير المكتملة تظهر على شاشة القفل، وتقدر تنجزها من هناك.", "Pending tasks show on the lock screen, so you can tick them off there."), 13f, C.MU), 4)
        val inp = field(L("أضف مهمة", "Add a task"))
        col.put(inp, 12)
        col.put(btn(L("إضافة", "Add")) {
            val t = inp.text.toString().trim()
            if (t.isNotEmpty()) {
                val l = Tasks.load(this); l.add(Task(t, false)); Tasks.save(this, l); Sfx.task(this, R.raw.sfx_add)
                inp.text.clear(); renderTasks()
            }
        }, 8)
        taskBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.put(taskBox, 12)
        col.put(btn(L("حذف المكتمل", "Clear completed")) {
            Tasks.save(this, Tasks.load(this).filter { !it.d }); renderTasks()
        }, 8)
        renderTasks()
        return scroll(col)
    }

    private fun renderTasks() {
        taskBox.removeAllViews()
        val l = Tasks.load(this)
        if (l.isEmpty()) taskBox.addView(tv(L("لا توجد مهام بعد.", "No tasks yet."), 14f, C.MU))
        l.forEachIndexed { i, t ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            val cb = CheckBox(this).apply {
                text = t.t
                setTextColor(if (t.d) C.MU else C.TX)
                if (t.d) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                buttonTintList = tint()
                isChecked = t.d
                setOnCheckedChangeListener { _, on -> t.d = on; Tasks.save(this@MainActivity, l); if (on) Sfx.task(this@MainActivity, R.raw.sfx_done); renderTasks() }
            }
            val x = tv("✕", 16f, C.MU).apply {
                setPadding(dp(14), dp(10), dp(14), dp(10))
                setOnClickListener { Sfx.task(this@MainActivity, R.raw.sfx_delete); l.removeAt(i); Tasks.save(this@MainActivity, l); renderTasks() }
            }
            row.addView(cb, LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(x)
            taskBox.addView(row)
        }
    }

    // ---------- التطبيقات ----------
    private fun appsPage(): View {
        val col = column()
        col.put(tv(L("التطبيقات المحظورة", "Blocked apps"), 24f, C.TX, true), 0)
        countTv = tv("", 13f, C.MU)
        col.put(countTv, 4)

        val search = field(L("ابحث عن تطبيق", "Search apps")).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) {
                    val q = e?.toString().orEmpty().trim().lowercase()
                    rows.forEach { it.cb.visibility = if (q.isEmpty() || it.name.contains(q)) View.VISIBLE else View.GONE }
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        col.put(search, 12)
        col.put(btn(L("اختر التطبيقات المشتتة الشائعة", "Select common distracting apps")) {
            rows.filter { it.pkg in common }.forEach { it.cb.isChecked = true }
        }, 10)

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val pm = packageManager
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
            .forEach { (pkg, name) ->
                val cb = CheckBox(this).apply {
                    text = name
                    setTextColor(C.TX)
                    buttonTintList = tint()
                    setPadding(dp(8), dp(12), dp(8), dp(12))
                    isChecked = pkg in picked
                    setOnCheckedChangeListener { _, on ->
                        if (on) picked.add(pkg) else picked.remove(pkg)
                        Prefs.setBlocked(this@MainActivity, picked)
                        refreshSummary()
                    }
                }
                rows.add(Row(pkg, name.lowercase(), cb))
                list.addView(cb)
            }
        col.put(list, 8)
        return scroll(col)
    }

    // ---------- المظهر ----------
    private fun stylePage(): View {
        val col = column()
        col.put(tv(L("المظهر", "Appearance"), 24f, C.TX, true), 0)

        val mode = card()
        mode.addView(tv(L("الوضع", "Mode"), 16f, C.TX, true))
        val mr = LinearLayout(this)
        mr.addView(btn(L("داكن", "Dark"), !C.light) { Prefs.setLight(this, false); recreate() }, lp1())
        mr.addView(btn(L("فاتح", "Light"), C.light) { Prefs.setLight(this, true); recreate() }, lp1())
        mode.put(mr, 10)
        col.put(mode, 14)

        val th = card()
        th.addView(tv(L("الثيم", "Theme"), 16f, C.TX, true))
        val tr = LinearLayout(this)
        C.presets.forEachIndexed { i, p ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setOnClickListener { Prefs.setPreset(this@MainActivity, i); Prefs.setCustomAccent(this@MainActivity, 0); recreate() }
            }
            val on = i == Prefs.preset(this) && Prefs.customAccent(this) == 0
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(p.ac)
                    if (on) setStroke(dp(3), C.TX)
                }
            }
            item.addView(dot, LinearLayout.LayoutParams(dp(38), dp(38)))
            item.addView(tv(L(p.ar, p.en), 11f, C.MU).apply { gravity = Gravity.CENTER })
            tr.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        th.put(tr, 12)
        th.put(tv(L("لون مخصص", "Custom color"), 13f, C.MU), 14)
        val hex = field("#RRGGBB")
        th.put(hex, 6)
        th.put(btn(L("تطبيق اللون", "Apply color")) {
            try {
                Prefs.setCustomAccent(this, Color.parseColor(hex.text.toString().trim()))
                recreate()
            } catch (e: Exception) { toast(L("اكتب اللون بصيغة مثل #FF8800", "Use a format like #FF8800")) }
        }, 8)
        col.put(th, 14)

        val cn = card()
        cn.addView(tv(L("شكل العداد", "Timer style"), 16f, C.TX, true))
        val pv = Counters.make(this, Prefs.counter(this), C.LN, C.AC)
        if (pv != null) {
            pv.upd(0.6f)
            cn.addView(pv.view, LinearLayout.LayoutParams(if (pv.w == 0) MATCH else dp(pv.w), dp(pv.h)).apply {
                gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(12)
            })
        }
        Counters.styles.chunked(4).forEach { chunk ->
            val r = LinearLayout(this)
            chunk.forEach { k ->
                r.addView(btn(Counters.label(this, k), Prefs.counter(this) == k) { Prefs.setCounter(this, k); recreate() }
                    .apply { textSize = 13f; setPadding(dp(4), dp(12), dp(4), dp(12)) }, lp1())
            }
            cn.put(r, 8)
        }
        col.put(cn, 14)

        val bg = card()
        bg.addView(tv(L("خلفية شاشة القفل", "Lock screen background"), 16f, C.TX, true))
        val hs = HorizontalScrollView(this)
        val row = LinearLayout(this)
        val keys = listOf("none") + Look.allKeys(this) + listOf("random")
        keys.forEach { key ->
            val sel = Prefs.bg(this) == key
            val tile = FrameLayout(this).apply {
                background = rounded(C.SF, 10, C.LN)
                if (sel) (background as GradientDrawable).setStroke(dp(3), C.AC)
                setPadding(dp(3), dp(3), dp(3), dp(3))
                setOnClickListener { Prefs.setBg(this@MainActivity, key); recreate() }
            }
            if (key == "none" || key == "random") {
                tile.addView(tv(if (key == "none") L("بدون", "None") else L("عشوائي", "Random"), 12f, C.TX).apply { gravity = Gravity.CENTER },
                    FrameLayout.LayoutParams(MATCH, MATCH))
            } else {
                tile.addView(ImageView(this).apply {
                    setImageBitmap(Look.thumb(this@MainActivity, key))
                    scaleType = ImageView.ScaleType.CENTER_CROP
                }, FrameLayout.LayoutParams(MATCH, MATCH))
                if (key.startsWith("c:")) tile.setOnLongClickListener { confirmDeleteBg(key.substring(2)); true }
            }
            row.addView(tile, LinearLayout.LayoutParams(dp(78), dp(138)).apply { marginEnd = dp(8) })
        }
        hs.addView(row)
        bg.put(hs, 12)
        bg.put(btn(L("إضافة صورة من المعرض", "Add image from gallery")) {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 7)
        }, 10)
        bg.put(tv(L("اضغط مطولًا على صورة أضفتها لحذفها.", "Long-press an image you added to delete it."), 12f, C.MU), 6)
        col.put(bg, 14)

        val qc = card()
        qc.addView(tv(L("جملك التحفيزية", "Your motivational quotes"), 16f, C.TX, true))
        val qf = field(L("اكتب جملة", "Write a quote"))
        qc.put(qf, 10)
        qc.put(btn(L("إضافة", "Add")) {
            val t = qf.text.toString().trim()
            if (t.isNotEmpty()) {
                val l = Prefs.myQuotes(this); l.add(t); Prefs.setMyQuotes(this, l)
                qf.text.clear(); renderQuotes()
            }
        }, 8)
        quotesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        qc.put(quotesBox, 8)
        val only = CheckBox(this).apply {
            text = L("اعرض جملي فقط", "Show only my quotes")
            setTextColor(C.TX)
            buttonTintList = tint()
            isChecked = Prefs.onlyMine(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setOnlyMine(this@MainActivity, on) }
        }
        qc.put(only, 8)
        renderQuotes()
        col.put(qc, 14)
        return scroll(col)
    }

    private fun renderQuotes() {
        quotesBox.removeAllViews()
        val l = Prefs.myQuotes(this)
        if (l.isEmpty()) quotesBox.addView(tv(L("لا توجد جمل مضافة. الجمل الافتراضية بالإنجليزية.", "No custom quotes yet. Built-in quotes are in English."), 12f, C.MU))
        l.forEachIndexed { i, q ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(tv(q, 14f, C.TX), LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(tv("✕", 16f, C.MU).apply {
                setPadding(dp(14), dp(10), dp(14), dp(10))
                setOnClickListener { l.removeAt(i); Prefs.setMyQuotes(this@MainActivity, l); renderQuotes() }
            })
            quotesBox.addView(row)
        }
    }

    private fun confirmDeleteBg(name: String) {
        dlg().setMessage(L("حذف هذه الصورة؟", "Delete this image?"))
            .setPositiveButton(L("حذف", "Delete")) { _, _ ->
                val l = Prefs.customBgs(this); l.remove(name); Prefs.setCustomBgs(this, l)
                File(filesDir, name).delete()
                if (Prefs.bg(this) == "c:$name") Prefs.setBg(this, "none")
                recreate()
            }
            .setNegativeButton(L("إلغاء", "Cancel"), null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (req != 7 || res != RESULT_OK) return
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@Thread
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                var s = 1
                while (o.outHeight / s > 1700) s *= 2
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
                    ?: throw Exception("decode")
                val name = "bg_" + System.currentTimeMillis() + ".jpg"
                FileOutputStream(File(filesDir, name)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                runOnUiThread {
                    val l = Prefs.customBgs(this); l.add(name); Prefs.setCustomBgs(this, l)
                    Prefs.setBg(this, "c:$name")
                    recreate()
                }
            } catch (e: Exception) {
                runOnUiThread { toast(L("تعذّر استخدام الصورة", "Couldn't use this image")) }
            }
        }.start()
    }

    // ---------- التحديث ----------
    private fun versionName(): String = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

    private fun autoCheck() {
        if (!Prefs.autoUpdate(this)) return
        if (System.currentTimeMillis() - Prefs.lastCheck(this) < 6 * 3_600_000L) return
        checkUpdate(false)
    }

    private fun checkUpdate(manual: Boolean) {
        Prefs.setLastCheck(this, System.currentTimeMillis())
        Updater.check(this) { ok, info ->
            if (!isFinishing) {
                if (info != null) promptUpdate(info)
                else if (manual && ok) toast(L("أنت على آخر إصدار", "You're on the latest version"))
                else if (manual) toast(L("تعذّر الاتصال، حاول لاحقًا", "Couldn't connect, try again later"))
            }
        }
    }

    private fun promptUpdate(info: Updater.Info) {
        dlg().setTitle(L("نسخة جديدة ${info.tag}", "New version ${info.tag}"))
            .setMessage(L("تقدمك وإعداداتك ستبقى كما هي. تنزيل وتثبيت الآن؟", "Your progress and settings will be kept. Download and install now?"))
            .setPositiveButton(L("حدّث الآن", "Update now")) { _, _ ->
                toast(L("جارٍ التنزيل...", "Downloading..."))
                Updater.download(this, info)
            }
            .setNegativeButton(L("لاحقًا", "Later"), null)
            .show()
    }

    // ---------- الإعدادات ----------
    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/")
    }
    private fun adminOn(): Boolean =
        getSystemService(DevicePolicyManager::class.java).isAdminActive(ComponentName(this, AdminReceiver::class.java))
    private fun batteryOn(): Boolean =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
    private fun notifOn(): Boolean =
        getSystemService(NotificationManager::class.java).areNotificationsEnabled()

    private fun perm(parent: LinearLayout, title: String, desc: String, on: () -> Boolean, action: () -> Unit) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(tv(title, 15f, C.TX, true))
        info.addView(tv(desc, 12f, C.MU))
        val st = tv(L("مفعّل ✓", "On ✓"), 13f, C.OK)
        val b = btn(L("تفعيل", "Enable")) { action() }.apply { textSize = 13f; setPadding(dp(14), dp(8), dp(14), dp(8)) }
        row.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(st)
        row.addView(b)
        parent.put(row, 14)
        refreshers.add {
            val ok = on()
            st.visibility = if (ok) View.VISIBLE else View.GONE
            b.visibility = if (ok) View.GONE else View.VISIBLE
        }
    }

    private fun settingsPage(): View {
        val col = column()
        col.put(tv(L("الإعدادات", "Settings"), 24f, C.TX, true), 0)

        val lg = card()
        lg.addView(tv(L("اللغة", "Language"), 16f, C.TX, true))
        val lr = LinearLayout(this)
        lr.addView(btn("العربية", Prefs.lang(this) == "ar") { Prefs.setLang(this, "ar"); recreate() }, lp1())
        lr.addView(btn("English", Prefs.lang(this) == "en") { Prefs.setLang(this, "en"); recreate() }, lp1())
        lg.put(lr, 10)
        col.put(lg, 14)

        val perms = card()
        perms.addView(tv(L("الصلاحيات", "Permissions"), 16f, C.TX, true))
        perm(perms, L("إمكانية الوصول", "Accessibility"), L("لاكتشاف فتح التطبيقات المحظورة", "Detects blocked apps being opened"), { a11yOn() }) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        perm(perms, L("مشرف الجهاز", "Device admin"), L("لمنع حذف التطبيق أثناء الجلسة", "Makes uninstalling hard during a session"), { adminOn() }) {
            startActivity(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, getString(R.string.admin_desc))
            )
        }
        perm(perms, L("استثناء البطارية", "Battery"), L("حتى لا يوقف النظام التطبيق", "Stops the system from killing the app"), { batteryOn() }) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        perm(perms, L("الإشعارات", "Notifications"), L("إشعار الجلسة الدائم", "The ongoing session notification"), { notifOn() }) {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
        col.put(perms, 14)

        val pwCard = card()
        pwCard.addView(tv(L("كلمة مرور الخروج الطارئ", "Emergency password"), 16f, C.TX, true))
        pwStatus = tv(if (Prefs.hasPassword(this)) L("تم ضبط كلمة المرور ✓", "Password is set ✓") else L("لم تضبط كلمة مرور بعد", "No password yet"), 13f, C.MU)
        pwCard.put(pwStatus, 4)
        pwField = field(L("8 أحرف على الأقل، حروف وأرقام", "8+ characters, letters and numbers")).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        pwCard.put(pwField, 10)
        pwCard.put(btn(L("حفظ كلمة المرور", "Save password")) { savePassword() }, 10)
        col.put(pwCard, 14)

        val modeCard = card()
        val strictCb = CheckBox(this).apply {
            text = L("قفل كامل للهاتف", "Full phone lock")
            setTextColor(C.TX)
            buttonTintList = tint()
            isChecked = Prefs.strict(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setStrict(this@MainActivity, on); refreshSummary() }
        }
        modeCard.addView(strictCb)
        modeCard.addView(tv(L("يمنع كل التطبيقات أثناء الجلسة عدا الاتصال والطوارئ.", "Blocks every app during a session except calls and emergency."), 12f, C.MU))
        col.put(modeCard, 14)

        val snd = card()
        snd.addView(tv(L("الأصوات", "Sounds"), 16f, C.TX, true))
        snd.put(CheckBox(this).apply {
            text = L("أصوات المهام", "Task sounds")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.taskSounds(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setTaskSounds(this@MainActivity, on); if (on) Sfx.task(this@MainActivity, R.raw.sfx_done) }
        }, 8)
        snd.put(CheckBox(this).apply {
            text = L("أصوات الأزرار", "Button sounds")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.clickSounds(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setClickSounds(this@MainActivity, on); if (on) Sfx.click(this@MainActivity) }
        }, 4)
        col.put(snd, 14)

        val upd = card()
        upd.addView(tv(L("التحديثات", "Updates"), 16f, C.TX, true))
        upd.put(tv(L("يتحدث التطبيق من GitHub وتقدمك يبقى محفوظًا. يستخدم الإنترنت لفحص النسخ فقط.",
            "The app updates from GitHub and keeps your progress. It uses the internet only to check versions."), 12f, C.MU), 4)
        upd.put(CheckBox(this).apply {
            text = L("فحص التحديثات تلقائيًا", "Check for updates automatically")
            setTextColor(C.TX); buttonTintList = tint()
            isChecked = Prefs.autoUpdate(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setAutoUpdate(this@MainActivity, on) }
        }, 8)
        upd.put(btn(L("افحص التحديثات الآن", "Check for updates now")) { checkUpdate(true) }, 8)
        col.put(upd, 14)

        val about = card()
        about.addView(tv("Stay focused " + versionName(), 16f, C.TX, true))
        about.put(tv(L("القائم على التطبيق: Ibrahim Elwaleed", "Maintained by Ibrahim Elwaleed"), 13f, C.MU), 4)
        about.put(btn(L("عرض المرشد", "Show the guide")) {
            startActivity(Intent(this, OnboardingActivity::class.java).putExtra("replay", true))
        }, 10)
        about.put(btn(L("سياسة الخصوصية", "Privacy policy")) {
            dlg().setTitle(L("سياسة الخصوصية", "Privacy policy"))
                .setMessage(L(
                    "- يستخدم التطبيق الإنترنت لفحص وتنزيل التحديثات من GitHub فقط، ولا يرسل أي بيانات شخصية من هاتفك.\n" +
                    "- خدمة إمكانية الوصول تقرأ اسم التطبيق المفتوح فقط لمنع ما اخترته، ولا تقرأ محتوى الشاشة.\n" +
                    "- مشرف الجهاز يُستخدم فقط لتصعيب الحذف أثناء جلسة بدأتها بنفسك.\n" +
                    "- الإعدادات والمهام والصور والإحصائيات تُحفظ على هاتفك فقط.\n" +
                    "- القائم على التطبيق: Ibrahim Elwaleed.",
                    "- The app uses the internet only to check for and download updates from GitHub. It sends no personal data from your phone.\n" +
                    "- The accessibility service reads only the name of the app being opened, to block what you chose. It never reads screen content.\n" +
                    "- Device admin is used only to make uninstalling harder during a session you started.\n" +
                    "- Settings, tasks, images and stats stay on your phone.\n" +
                    "- Maintained by Ibrahim Elwaleed."))
                .setPositiveButton(L("حسنًا", "OK"), null)
                .show()
        }, 8)
        col.put(about, 14)
        return scroll(col)
    }

    private fun savePassword() {
        val pw = pwField.text.toString()
        if (pw.length < 8 || !pw.any { it.isDigit() } || !pw.any { it.isLetter() }) {
            toast(L("كلمة المرور يجب أن تكون 8 أحرف على الأقل وتحتوي على حروف وأرقام", "Password needs 8+ characters with letters and numbers")); return
        }
        Prefs.setPassword(this, pw)
        pwField.text.clear()
        pwStatus.text = L("تم ضبط كلمة المرور ✓", "Password is set ✓")
        refreshBanner()
        toast(L("تم الحفظ. احتفظ بها في مكان آمن.", "Saved. Keep it somewhere safe."))
    }
}
