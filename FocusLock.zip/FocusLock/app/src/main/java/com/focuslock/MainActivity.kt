package com.focuslock

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private class Row(val pkg: String, val name: String, val cb: CheckBox)

    private val picked = HashSet<String>()
    private val rows = ArrayList<Row>()
    private val refreshers = ArrayList<() -> Unit>()
    private lateinit var pages: List<View>
    private lateinit var tabs: List<TextView>
    private lateinit var minsTv: TextView
    private lateinit var seek: SeekBar
    private lateinit var summaryTv: TextView
    private lateinit var countTv: TextView
    private lateinit var banner: LinearLayout
    private lateinit var bannerTv: TextView
    private lateinit var pwField: EditText
    private lateinit var pwStatus: TextView
    private var mins = 25

    private val common = setOf(
        "com.instagram.android", "com.instagram.lite", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
        "com.google.android.youtube", "com.twitter.android", "com.snapchat.android", "com.facebook.katana",
        "com.facebook.lite", "com.reddit.frontpage", "com.netflix.mediaclient", "com.pinterest"
    )

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.settle(this)
        if (Prefs.active(this)) {
            startActivity(Intent(this, LockActivity::class.java)); finish(); return
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        picked.addAll(Prefs.blocked(this))

        pages = listOf(homePage(), appsPage(), settingsPage())
        val content = FrameLayout(this)
        pages.forEach { content.addView(it) }

        val bar = LinearLayout(this).apply { setBackgroundColor(C.SF) }
        val names = listOf("الرئيسية", "التطبيقات", "الإعدادات")
        tabs = names.mapIndexed { i, n ->
            tv(n, 14f, C.MU).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(15), 0, dp(15))
                setOnClickListener { select(i) }
            }
        }
        tabs.forEach { bar.addView(it, LinearLayout.LayoutParams(0, WRAP, 1f)) }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
        select(0)
    }

    override fun onResume() {
        super.onResume()
        if (!::pages.isInitialized) return
        refreshers.forEach { it() }
        refreshBanner()
        refreshSummary()
    }

    private fun select(i: Int) {
        pages.forEachIndexed { j, p -> p.visibility = if (i == j) View.VISIBLE else View.GONE }
        tabs.forEachIndexed { j, t ->
            t.setTextColor(if (i == j) C.AC else C.MU)
            t.setTypeface(null, if (i == j) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(26), dp(18), dp(24))
    }

    private fun scroll(c: View): View = ScrollView(this).apply { addView(c) }

    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText
        setTextColor(C.TX); setHintTextColor(C.MU)
        background = rounded(C.SF, 12, C.LN)
        setPadding(dp(14), dp(12), dp(14), dp(12))
    }

    private fun fmtMins(m: Int): String =
        if (m < 60) "$m دقيقة" else "${m / 60} س" + (if (m % 60 > 0) " و${m % 60} د" else "")

    // ---------- الرئيسية ----------
    private fun homePage(): View {
        val col = column()
        col.put(tv("قفل التركيز", 28f, C.TX, true), 0)
        col.put(tv("اختر المدة، ثم أغلق على نفسك.", 14f, C.MU), 4)

        banner = card()
        bannerTv = tv("", 14f, C.WR)
        banner.addView(bannerTv)
        banner.put(btn("افتح الإعدادات") { select(2) }, 10)
        col.put(banner, 16)

        val stats = LinearLayout(this)
        fun stat(n: String, l: String) = card().apply { addView(tv(n, 28f, C.AC, true)); addView(tv(l, 12f, C.MU)) }
        stats.addView(stat(Prefs.doneCount(this).toString(), "جلسة مكتملة"),
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(6) })
        stats.addView(stat(Prefs.doneMins(this).toString(), "دقيقة تركيز"),
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(6) })
        col.put(stats, 16)

        val dur = card()
        dur.addView(tv("مدة الجلسة", 14f, C.MU))
        minsTv = tv(fmtMins(mins), 34f, C.TX, true)
        dur.put(minsTv, 4)
        seek = SeekBar(this).apply {
            max = 47
            progress = mins / 5 - 1
            progressTintList = ColorStateList.valueOf(C.AC)
            thumbTintList = ColorStateList.valueOf(C.AC)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) { mins = (p + 1) * 5; minsTv.text = fmtMins(mins) }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        dur.put(seek, 8)
        val chips = LinearLayout(this)
        listOf(15, 25, 45, 60, 90, 120).forEach { m ->
            val chip = tv("$m", 14f, C.TX).apply {
                gravity = Gravity.CENTER
                background = rounded(C.BG, 12, C.LN)
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { mins = m; seek.progress = m / 5 - 1; minsTv.text = fmtMins(m) }
            }
            chips.addView(chip, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
        }
        dur.put(chips, 8)
        col.put(dur, 12)

        summaryTv = tv("", 14f, C.MU)
        col.put(summaryTv, 14)
        col.put(btn("ابدأ الجلسة", true) { tryStart() }.apply { textSize = 17f }, 10)
        return scroll(col)
    }

    private fun refreshBanner() {
        val m = ArrayList<String>()
        if (!a11yOn()) m.add("إمكانية الوصول")
        if (!adminOn()) m.add("مشرف الجهاز")
        if (!batteryOn()) m.add("استثناء البطارية")
        if (!Prefs.hasPassword(this)) m.add("كلمة المرور")
        banner.visibility = if (m.isEmpty()) View.GONE else View.VISIBLE
        bannerTv.text = "أكمل الإعدادات: " + m.joinToString("، ")
    }

    private fun refreshSummary() {
        summaryTv.text = when {
            Prefs.strict(this) -> "قفل كامل: كل التطبيقات ممنوعة عدا الاتصال"
            picked.isEmpty() -> "لم تختر أي تطبيق بعد. افتح تبويب التطبيقات."
            else -> "التطبيقات المحظورة: ${picked.size}"
        }
        countTv.text = "المحدد: ${picked.size}"
    }

    private fun tryStart() {
        if (!Prefs.hasPassword(this)) { toast("اضبط كلمة مرور الخروج الطارئ أولًا"); select(2); return }
        if (!a11yOn()) { toast("فعّل خدمة إمكانية الوصول أولًا"); select(2); return }
        if (picked.isEmpty() && !Prefs.strict(this)) { toast("اختر تطبيقًا واحدًا على الأقل أو فعّل القفل الكامل"); select(1); return }
        AlertDialog.Builder(this)
            .setTitle("بدء الجلسة")
            .setMessage("لن تستطيع الخروج إلا بعد ${fmtMins(mins)} أو بكلمة المرور. هل أنت جاهز؟")
            .setPositiveButton("ابدأ") { _, _ -> go() }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun go() {
        Prefs.clearFails(this)
        Prefs.setBlocked(this, picked)
        Prefs.begin(this, mins)
        KeepAliveService.start(this)
        startActivity(Intent(this, LockActivity::class.java))
        finish()
    }

    // ---------- التطبيقات ----------
    private fun appsPage(): View {
        val col = column()
        col.put(tv("التطبيقات المحظورة", 24f, C.TX, true), 0)
        countTv = tv("", 13f, C.MU)
        col.put(countTv, 4)

        val search = field("ابحث عن تطبيق").apply {
            inputType = InputType.TYPE_CLASS_TEXT
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) {
                    val q = e?.toString().orEmpty().trim().lowercase()
                    rows.forEach { it.cb.visibility = if (q.isEmpty() || it.name.contains(q)) View.VISIBLE else View.GONE }
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        col.put(search, 12)
        col.put(btn("اختر التطبيقات المشتتة الشائعة") {
            rows.filter { it.pkg in common }.forEach { it.cb.isChecked = true }
        }, 10)

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val pm = packageManager
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
            .forEach { (pkg, name) ->
                val cb = CheckBox(this).apply {
                    text = name
                    setTextColor(C.TX)
                    buttonTintList = ColorStateList.valueOf(C.AC)
                    setPadding(dp(8), dp(12), dp(8), dp(12))
                    isChecked = pkg in picked
                    setOnCheckedChangeListener { _, on ->
                        if (on) picked.add(pkg) else picked.remove(pkg)
                        Prefs.setBlocked(this@MainActivity, picked)
                        refreshSummary()
                    }
                }
                rows.add(Row(pkg, name.lowercase(), cb))
                list.addView(cb)
            }
        col.put(list, 8)
        return scroll(col)
    }

    // ---------- الإعدادات ----------
    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/")
    }
    private fun adminOn(): Boolean =
        getSystemService(DevicePolicyManager::class.java).isAdminActive(ComponentName(this, AdminReceiver::class.java))
    private fun batteryOn(): Boolean =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
    private fun notifOn(): Boolean =
        getSystemService(NotificationManager::class.java).areNotificationsEnabled()

    private fun perm(parent: LinearLayout, title: String, desc: String, on: () -> Boolean, action: () -> Unit) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(tv(title, 15f, C.TX, true))
        info.addView(tv(desc, 12f, C.MU))
        val st = tv("مفعّل ✓", 13f, C.OK)
        val b = btn("تفعيل") { action() }.apply { textSize = 13f; setPadding(dp(14), dp(8), dp(14), dp(8)) }
        row.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(st)
        row.addView(b)
        parent.put(row, 14)
        refreshers.add {
            val ok = on()
            st.visibility = if (ok) View.VISIBLE else View.GONE
            b.visibility = if (ok) View.GONE else View.VISIBLE
        }
    }

    private fun settingsPage(): View {
        val col = column()
        col.put(tv("الإعدادات", 24f, C.TX, true), 0)

        val perms = card()
        perms.addView(tv("الصلاحيات", 16f, C.TX, true))
        perm(perms, "إمكانية الوصول", "لاكتشاف فتح التطبيقات المحظورة", { a11yOn() }) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        perm(perms, "مشرف الجهاز", "لمنع حذف التطبيق أثناء الجلسة", { adminOn() }) {
            startActivity(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, getString(R.string.admin_desc))
            )
        }
        perm(perms, "استثناء البطارية", "حتى لا يوقف النظام التطبيق", { batteryOn() }) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        perm(perms, "الإشعارات", "إشعار الجلسة الدائم", { notifOn() }) {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
        col.put(perms, 14)

        val pwCard = card()
        pwCard.addView(tv("كلمة مرور الخروج الطارئ", 16f, C.TX, true))
        pwStatus = tv(if (Prefs.hasPassword(this)) "تم ضبط كلمة المرور ✓" else "لم تضبط كلمة مرور بعد", 13f, C.MU)
        pwCard.put(pwStatus, 4)
        pwField = field("8 أحرف على الأقل، حروف وأرقام").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        pwCard.put(pwField, 10)
        pwCard.put(btn("حفظ كلمة المرور") { savePassword() }, 10)
        col.put(pwCard, 14)

        val modeCard = card()
        val strictCb = CheckBox(this).apply {
            text = "قفل كامل للهاتف"
            setTextColor(C.TX)
            buttonTintList = ColorStateList.valueOf(C.AC)
            isChecked = Prefs.strict(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setStrict(this@MainActivity, on); refreshSummary() }
        }
        modeCard.addView(strictCb)
        modeCard.addView(tv("يمنع كل التطبيقات أثناء الجلسة عدا الاتصال والطوارئ.", 12f, C.MU))
        col.put(modeCard, 14)

        val about = card()
        about.addView(tv("قفل التركيز 1.1", 16f, C.TX, true))
        about.put(btn("سياسة الخصوصية") {
            AlertDialog.Builder(this)
                .setTitle("سياسة الخصوصية")
                .setMessage(
                    "- التطبيق لا يملك إذن الإنترنت، ولا يرسل أي بيانات من هاتفك.\n" +
                    "- خدمة إمكانية الوصول تقرأ اسم التطبيق المفتوح فقط لمنع ما اخترته، ولا تقرأ محتوى الشاشة.\n" +
                    "- مشرف الجهاز يُستخدم فقط لتصعيب الحذف أثناء جلسة بدأتها بنفسك.\n" +
                    "- الإعدادات والإحصائيات تُحفظ على هاتفك فقط."
                )
                .setPositiveButton("حسنًا", null)
                .show()
        }, 10)
        col.put(about, 14)
        return scroll(col)
    }

    private fun savePassword() {
        val pw = pwField.text.toString()
        if (pw.length < 8 || !pw.any { it.isDigit() } || !pw.any { it.isLetter() }) {
            toast("كلمة المرور يجب أن تكون 8 أحرف على الأقل وتحتوي على حروف وأرقام"); return
        }
        Prefs.setPassword(this, pw)
        pwField.text.clear()
        pwStatus.text = "تم ضبط كلمة المرور ✓"
        refreshBanner()
        toast("تم الحفظ. احتفظ بها في مكان آمن.")
    }
}
