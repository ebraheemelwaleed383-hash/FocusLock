package com.focuslock

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Parse {
    fun digits(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            sb.append(
                when (ch) {
                    in '٠'..'٩' -> '0' + (ch - '٠')
                    in '۰'..'۹' -> '0' + (ch - '۰')
                    '٫' -> '.'
                    '،' -> ','
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    private fun norm(s: String): String =
        s.lowercase().replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ة', 'ه').replace('ى', 'ي').trim()

    fun time(raw: String): Int? {
        val s = norm(digits(raw))
        val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?").find(s) ?: return null
        var h = m.groupValues[1].toInt()
        val mi = if (m.groupValues[2].isEmpty()) 0 else m.groupValues[2].toInt()
        if (h > 24 || mi > 59) return null
        val pm = listOf("م", "مساء", "pm", "ليلا", "عصرا", "بعد الظهر").any { Regex("(^|\\s|\\d)" + it + "(\\s|$)").containsMatchIn(s) }
        val am = listOf("ص", "صباحا", "am", "فجرا").any { Regex("(^|\\s|\\d)" + it + "(\\s|$)").containsMatchIn(s) }
        if (pm && h < 12) h += 12
        if (am && h == 12) h = 0
        if (h == 24) h = 0
        return h * 60 + mi
    }

    fun number(raw: String): Float? =
        Regex("(\\d+(?:[.,]\\d+)?)").find(digits(raw))?.value?.replace(',', '.')?.toFloatOrNull()

    fun yesNo(raw: String): Boolean? {
        val t = norm(raw)
        val yes = listOf("ايوه", "ايوا", "اه", "نعم", "yes", "y", "تمام", "اكيد", "ok", "اوكي", "طبعا", "عندي", "ابني", "ابدا", "build")
        val no = listOf("لا", "no", "n", "مفيش", "خلاص", "لسه", "مش", "ما عنديش", "لاء")
        if (yes.any { t == it || t.startsWith("$it ") }) return true
        if (no.any { t == it || t.startsWith("$it ") }) return false
        return null
    }

    fun isTitle(raw: String): Boolean {
        val t = raw.trim()
        if (t.length < 3 || t.length > 60) return false
        if (t.contains('?') || t.contains('؟')) return false
        val letters = t.count { it.isLetter() }
        if (letters < 3 || letters.toFloat() / t.length < 0.5f) return false
        if (t.toSet().size < 3) return false
        val low = norm(t)
        val chatter = listOf("اهلا", "مرحبا", "السلام", "شكرا", "صباح الخير", "مساء الخير", "hello", "hi ", "thanks", "how are", "who are", "what is", "نكت", "joke", "كلمني", "احكيلي", "عامل ايه", "ازيك")
        if (chatter.any { low.startsWith(it) }) return false
        val qw = listOf("مين", "ايه", "ليه", "كيف", "ازاي", "فين", "امتي", "هل ", "what", "who", "why", "how", "when", "where")
        if (qw.any { low.startsWith(it) }) return false
        return true
    }

    // 0 = بدون ميعاد، 1..7 = Calendar.DAY_OF_WEEK، null = غير مفهوم
    fun weekday(raw: String): Int? {
        val t = norm(raw)
        if (listOf("بدون", "لا يوجد", "مفيش", "none", "no", "لا").any { t == it }) return 0
        val cal = Calendar.getInstance()
        if (t.contains("النهارده") || t.contains("اليوم") || t.contains("today")) return cal.get(Calendar.DAY_OF_WEEK)
        if (t.contains("بكره") || t.contains("غدا") || t.contains("tomorrow")) { cal.add(Calendar.DAY_OF_YEAR, 1); return cal.get(Calendar.DAY_OF_WEEK) }
        val map = listOf("سبت" to 7, "sat" to 7, "احد" to 1, "sun" to 1, "اثنين" to 2, "اتنين" to 2, "mon" to 2, "ثلاث" to 3, "تلات" to 3, "tue" to 3, "اربع" to 4, "wed" to 4, "خميس" to 5, "thu" to 5, "جمع" to 6, "fri" to 6)
        for ((k, v) in map) if (t.contains(k)) return v
        return null
    }

    fun days(raw: String): Int? {
        val n = number(raw) ?: return null
        val t = norm(raw)
        val mult = when {
            t.contains("اسبوع") || t.contains("week") -> 7
            t.contains("شهر") || t.contains("month") -> 30
            t.contains("سنه") || t.contains("year") -> 365
            else -> 1
        }
        val d = (n * mult).toInt()
        return if (d in 3..730) d else null
    }

    fun peak(raw: String): Int? {
        val t = norm(raw)
        return when {
            t.contains("صباح") || t.contains("morning") -> 0
            t.contains("ظهر") || t.contains("عصر") || t.contains("afternoon") -> 1
            t.contains("مساء") || t.contains("evening") -> 2
            t.contains("ليل") || t.contains("night") -> 3
            else -> null
        }
    }
}

object FixedForm {
    private val order = intArrayOf(6, 0, 1, 2, 3, 4, 5)

    fun show(a: Activity, onSaved: (Fixed) -> Unit, onCancel: () -> Unit) {
        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(18), a.dp(10), a.dp(18), a.dp(4)) }
        val label = EditText(a).apply {
            hint = a.L("اسم الالتزام (شغل، جامعة، تمرين...)", "Commitment name (work, class, gym...)")
            setTextColor(C.TX); setHintTextColor(C.MU)
        }
        box.addView(label)
        val checks = ArrayList<CheckBox>()
        val row1 = LinearLayout(a)
        val row2 = LinearLayout(a)
        order.forEachIndexed { idx, d ->
            val cb = CheckBox(a).apply { text = Planner.dayName(a, d); textSize = 11f; setTextColor(C.TX); buttonTintList = ColorStateList.valueOf(C.AC) }
            checks.add(cb)
            (if (idx < 4) row1 else row2).addView(cb, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        box.put(row1, 8)
        box.addView(row2)
        val times = intArrayOf(540, 900)
        val sBtn = a.btn("") { }
        val eBtn = a.btn("") { }
        fun paint() {
            sBtn.text = a.L("من ", "From ") + Planner.fmt(times[0])
            eBtn.text = a.L("إلى ", "To ") + Planner.fmt(times[1])
        }
        paint()
        sBtn.setOnClickListener { TimePickerDialog(a, { _, h, m -> times[0] = h * 60 + m; paint() }, times[0] / 60, times[0] % 60, true).show() }
        eBtn.setOnClickListener { TimePickerDialog(a, { _, h, m -> times[1] = h * 60 + m; paint() }, times[1] / 60, times[1] % 60, true).show() }
        val tr = LinearLayout(a)
        tr.addView(sBtn, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = a.dp(4) })
        tr.addView(eBtn, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = a.dp(4) })
        box.put(tr, 10)
        val presets = LinearLayout(a)
        listOf(
            Triple(a.L("مدرسة", "School"), 8 * 60 to 14 * 60, 31), Triple(a.L("جامعة", "University"), 9 * 60 to 15 * 60, 31),
            Triple(a.L("شغل", "Work"), 9 * 60 to 17 * 60, 31), Triple(a.L("تمرين", "Gym"), 18 * 60 to 19 * 60, 31)
        ).forEach { (name, tm, mask) ->
            presets.addView(a.tv(name, 13f, C.TX).apply {
                gravity = Gravity.CENTER
                background = a.rounded(C.SF, 12, C.LN)
                setPadding(0, a.dp(8), 0, a.dp(8))
                setOnClickListener {
                    label.setText(name); times[0] = tm.first; times[1] = tm.second; paint()
                    checks.forEachIndexed { i, cb -> cb.isChecked = ((mask shr order[i]) and 1) == 1 }
                }
            }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = a.dp(3); marginEnd = a.dp(3) })
        }
        box.addView(presets, 0)
        val d = a.dlg().setTitle(a.L("التزام ثابت", "Fixed commitment")).setView(box)
            .setPositiveButton(a.L("حفظ", "Save"), null)
            .setNegativeButton(a.L("إلغاء", "Cancel")) { _, _ -> onCancel() }
            .setOnCancelListener { onCancel() }
            .create()
        d.setOnShowListener {
            d.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                var mask = 0
                checks.forEachIndexed { i, cb -> if (cb.isChecked) mask = mask or (1 shl order[i]) }
                val name = label.text.toString().trim()
                val msg = when {
                    !Parse.isTitle(name) -> a.L("اكتب اسم الالتزام نفسه (مثل: جامعة).", "Enter the commitment's name (e.g. class).")
                    mask == 0 -> a.L("اختر يومًا واحدًا على الأقل.", "Pick at least one day.")
                    times[1] <= times[0] -> a.L("وقت النهاية لازم يكون بعد البداية.", "The end time must be after the start.")
                    else -> ""
                }
                if (msg.isNotEmpty()) Toast.makeText(a, msg, Toast.LENGTH_LONG).show()
                else { d.setOnCancelListener(null); d.dismiss(); onSaved(Fixed(name, mask, times[0], times[1])) }
            }
        }
        d.show()
    }
}

class PlannerActivity : Activity() {
    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var chips: LinearLayout
    private var step = 0
    private var strikes = 0
    private var dead = false
    private val prof = Prof()
    private val fixed = ArrayList<Fixed>()
    private val tasks = ArrayList<PTask>()
    private val goals = ArrayList<Goal>()
    private var tTitle = ""
    private var tHours = 0f
    private var tDl = 0
    private var tEnd = 0L
    private var gTitle = ""
    private var gTotal = 0f

    private companion object {
        const val S_WAKE = 0; const val S_SLEEP = 1; const val S_FIXED = 2; const val S_FIXED_MORE = 3
        const val S_PEAK = 4; const val S_MAXH = 5; const val S_BLK = 6
        const val S_T_TITLE = 7; const val S_T_HOURS = 8; const val S_T_DL = 9; const val S_T_PRI = 10; const val S_T_MORE = 11
        const val S_G_ASK = 12; const val S_G_TITLE = 13; const val S_G_HOURS = 14; const val S_G_WHEN = 15
        const val S_REST = 16; const val S_CONFIRM = 17; const val S_DONE = 18
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applyTheme()
        val old = Planner.profile(this)
        prof.wake = old.wake; prof.sleep = old.sleep; prof.peak = old.peak; prof.maxH = old.maxH; prof.blk = old.blk; prof.brk = old.brk; prof.rest = old.rest
        fixed.addAll(Planner.fixed(this))
        goals.addAll(Planner.goals(this))

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(20), dp(18), dp(8)) }
        head.addView(tv(L("مساعد الجدولة", "Planner assistant"), 20f, C.TX, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(tv("✕", 20f, C.MU).apply { setPadding(dp(12), dp(6), dp(12), dp(6)); setOnClickListener { finish() } })
        root.addView(head)
        scroll = ScrollView(this)
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(4), dp(14), dp(10)) }
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val chipScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        chips = LinearLayout(this).apply { setPadding(dp(12), dp(6), dp(12), dp(4)) }
        chipScroll.addView(chips)
        root.addView(chipScroll)
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(4), dp(12), dp(12)) }
        input = EditText(this).apply {
            hint = L("اكتب إجابتك هنا", "Type your answer here")
            setTextColor(C.TX); setHintTextColor(C.MU)
            background = rounded(C.SF, 14, C.LN)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            inputType = InputType.TYPE_CLASS_TEXT
        }
        bar.addView(input, LinearLayout.LayoutParams(0, WRAP, 1f))
        bar.addView(btn(L("إرسال", "Send"), true) { submit(input.text.toString()) }.apply { textSize = 14f }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) })
        root.addView(bar)
        root.applyDir()
        setContentView(root)

        bubble(L("أهلًا. أنا مساعد الجدولة. هسألك أسئلة قصيرة عن يومك ومهامك وأهدافك، وبعدها أبني لك جدولًا أسبوعيًا وأشرح لك نتائجه. هذا سيستبدل جدولك الحالي.", "Hi. I'm the planner assistant. I'll ask a few short questions about your day, tasks and goals, then build a weekly schedule and explain what it means. This will replace your current schedule."), false)
        ask()
    }

    private fun bubble(text: String, user: Boolean) {
        val v = tv(text, 15f, if (user) C.ON else C.TX).apply {
            background = rounded(if (user) C.AC else C.SF, 16, if (user) 0 else C.LN)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        chat.addView(v, LinearLayout.LayoutParams(WRAP, WRAP).apply {
            topMargin = dp(8)
            gravity = if (user) Gravity.END else Gravity.START
        })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun setChips(items: List<String>) {
        chips.removeAllViews()
        items.forEach { t ->
            chips.addView(tv(t, 14f, C.TX).apply {
                background = rounded(C.SF, 14, C.LN)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setOnClickListener { submit(t) }
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(6) })
        }
    }

    private fun timeChips(list: List<String>) {
        setChips(list)
        chips.addView(tv("🕒 " + L("اختر", "Pick"), 14f, C.TX).apply {
            background = rounded(C.SF, 14, C.LN)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { TimePickerDialog(this@PlannerActivity, { _, h, m -> submit(Planner.fmt(h * 60 + m)) }, 8, 0, true).show() }
        })
    }

    private fun yesNoChips() = setChips(listOf(L("نعم", "Yes"), L("لا", "No")))

    private fun submit(raw: String) {
        if (dead) return
        val t = raw.trim()
        if (t.isEmpty()) return
        bubble(t, true)
        input.text.clear()
        handle(t)
    }

    private fun reject(need: String) {
        strikes++
        if (strikes >= 3) {
            dead = true
            chips.removeAllViews()
            bubble(L("مقدرش أساعدك من غير هذه المعلومة. ارجع لما تكون جاهز، وهنكمل من البداية.", "I can't help without this information. Come back when you're ready and we'll start again."), false)
        } else {
            bubble(L("أنا مساعد الجدولة، ومهمتي أجهّز لك جدولك. محتاج منك: ", "I'm the planner assistant and my job is to prepare your schedule. I need from you: ") + need, false)
        }
    }

    private fun good() { strikes = 0 }

    private fun go(next: Int) { good(); step = next; ask() }

    private fun ask() {
        chips.removeAllViews()
        when (step) {
            S_WAKE -> { bubble(L("إيه ميعاد صحيانك المعتاد؟ (مثال: 7:00 أو 7 ص)", "What time do you usually wake up? (e.g. 7:00 or 7 am)"), false); timeChips(listOf("06:00", "07:00", "08:00")) }
            S_SLEEP -> { bubble(L("وميعاد نومك؟ (مثال: 23:00 أو 11 م)", "And when do you go to sleep? (e.g. 23:00 or 11 pm)"), false); timeChips(listOf("22:00", "23:00", "00:00")) }
            S_FIXED -> { bubble(if (fixed.isEmpty()) L("عندك التزامات ثابتة بتاخد وقتك (شغل، جامعة، تمرين...)؟", "Do you have fixed commitments (work, class, gym...)?") else L("عندك ${fixed.size} التزامات محفوظة. تضيف التزامًا جديدًا؟", "You have ${fixed.size} saved commitments. Add a new one?"), false); yesNoChips() }
            S_FIXED_MORE -> { bubble(L("في التزام ثابت تاني؟", "Another fixed commitment?"), false); yesNoChips() }
            S_PEAK -> { bubble(L("أنهي وقت تحس فيه إنك أكثر تركيزًا؟", "When do you feel most focused?"), false); setChips(listOf(L("صباحًا", "Morning"), L("ظهرًا", "Afternoon"), L("مساءً", "Evening"), L("ليلًا", "Night"))) }
            S_MAXH -> { bubble(L("كام ساعة تركيز عميق تقدر تتحملها يوميًا؟ (من 1 إلى 10)", "How many hours of deep focus can you handle per day? (1 to 10)"), false); setChips(listOf("2", "3", "4", "5", "6")) }
            S_BLK -> { bubble(L("تفضّل جلسة التركيز تبقى كام دقيقة؟", "How long do you prefer each focus session to be (minutes)?"), false); setChips(listOf("25", "45", "60", "90")) }
            S_REST -> { bubble(L("أنهي يوم تحب يكون خفيفًا للراحة؟ الراحة جزء من الخطة وليست كسلًا. (مثال: الجمعة، أو «مفيش»)", "Which day should be a light rest day? Rest is part of the plan, not laziness. (e.g. Friday, or \"none\")"), false); setChips(listOf(L("الجمعة", "Friday"), L("السبت", "Saturday"), L("الأحد", "Sunday"), L("مفيش", "None"))) }
            S_T_TITLE -> { bubble(if (tasks.isEmpty()) L("اكتب اسم أول مهمة عليك هذا الأسبوع (أو اكتب «مفيش»).", "Write the first task you have this week (or type \"none\").") else L("اكتب اسم المهمة التالية.", "Write the next task."), false); setChips(listOf(L("مفيش", "None"))) }
            S_T_HOURS -> { bubble(L("كام ساعة تقريبًا تحتاجها لـ «$tTitle»؟ (مثال: 2 أو 1.5)", "About how many hours will \"$tTitle\" take? (e.g. 2 or 1.5)"), false); setChips(listOf("1", "2", "3", "5")) }
            S_T_DL -> { bubble(L("آخر ميعاد لها؟ اكتب اسم اليوم، أو «بعد 20 يوم» لو بعيد، أو «بدون».", "What's its deadline? Type a weekday, or \"in 20 days\" if it's far, or \"none\"."), false); setChips(listOf(L("بدون", "None"), L("السبت", "Saturday"), L("الأحد", "Sunday"), L("الاثنين", "Monday"), L("الثلاثاء", "Tuesday"), L("الأربعاء", "Wednesday"), L("الخميس", "Thursday"), L("الجمعة", "Friday"))) }
            S_T_PRI -> { bubble(L("أهميتها؟ عالية أم متوسطة أم منخفضة؟", "How important is it? High, medium or low?"), false); setChips(listOf(L("عالية", "High"), L("متوسطة", "Medium"), L("منخفضة", "Low"))) }
            S_T_MORE -> { bubble(L("في مهمة تانية؟", "Another task?"), false); yesNoChips() }
            S_G_ASK -> { bubble(if (goals.isEmpty()) L("عندك هدف طويل المدى (مثل: إنهاء كورس، تحضير امتحان، مشروع)؟", "Do you have a long-term goal (a course, an exam, a project)?") else L("عندك ${goals.size} أهداف محفوظة. تضيف هدفًا جديدًا؟", "You have ${goals.size} saved goals. Add a new one?"), false); yesNoChips() }
            S_G_TITLE -> { bubble(L("اسم الهدف؟", "What's the goal called?"), false) }
            S_G_HOURS -> { bubble(L("كام ساعة إجمالًا تقدّر إنك محتاجها للوصول له؟ (مثال: 60)", "Roughly how many hours in total will it take? (e.g. 60)"), false); setChips(listOf("20", "40", "60", "100")) }
            S_G_WHEN -> { bubble(L("عايز توصله بعد كام؟ (مثال: 30 يوم أو 8 أسابيع أو 3 شهور)", "When do you want to reach it? (e.g. 30 days, 8 weeks, 3 months)"), false); setChips(listOf(L("30 يوم", "30 days"), L("8 أسابيع", "8 weeks"), L("3 شهور", "3 months"))) }
            S_CONFIRM -> {
                bubble(L("تمام. المعلومات اللي عندي: صحيان ${Planner.fmt(prof.wake)} ونوم ${Planner.fmt(prof.sleep)}، ${fixed.size} التزامات ثابتة، ${tasks.size} مهام، ${goals.size} أهداف، وحد أقصى ${prof.maxH} ساعة تركيز يوميًا. أبني الجدول؟", "Here's what I have: wake ${Planner.fmt(prof.wake)}, sleep ${Planner.fmt(prof.sleep)}, ${fixed.size} fixed commitments, ${tasks.size} tasks, ${goals.size} goals, and up to ${prof.maxH} focus hours a day. Shall I build the schedule?"), false)
                setChips(listOf(L("ابني الجدول", "Build it"), L("ابدأ من جديد", "Start over")))
            }
            S_DONE -> { setChips(listOf(L("عرض الجدول", "Show my schedule"))) }
        }
    }

    private fun showFixed() {
        FixedForm.show(this, { f -> fixed.add(f); bubble(L("تمت إضافة «${f.label}».", "Added \"${f.label}\"."), false); go(S_FIXED_MORE) }, { go(S_PEAK) })
    }

    private fun handle(t: String) {
        when (step) {
            S_WAKE -> { val m = Parse.time(t); if (m == null) reject(L("ميعاد صحيانك (مثال 7:00)", "your wake-up time (e.g. 7:00)")) else { prof.wake = m; go(S_SLEEP) } }
            S_SLEEP -> { val m = Parse.time(t); if (m == null) reject(L("ميعاد نومك (مثال 23:00)", "your bedtime (e.g. 23:00)")) else { prof.sleep = m; go(S_FIXED) } }
            S_FIXED -> when (Parse.yesNo(t)) { true -> { good(); showFixed() }; false -> go(S_PEAK); null -> reject(L("نعم أو لا: عندك التزامات ثابتة؟", "yes or no: do you have fixed commitments?")) }
            S_FIXED_MORE -> when (Parse.yesNo(t)) { true -> { good(); showFixed() }; false -> go(S_PEAK); null -> reject(L("نعم أو لا", "yes or no")) }
            S_PEAK -> { val p = Parse.peak(t); if (p == null) reject(L("صباحًا أو ظهرًا أو مساءً أو ليلًا", "morning, afternoon, evening or night")) else { prof.peak = p; go(S_MAXH) } }
            S_MAXH -> { val n = Parse.number(t); if (n == null || n < 1f || n > 10f) reject(L("رقم من 1 إلى 10 (ساعات التركيز اليومية)", "a number from 1 to 10 (daily focus hours)")) else { prof.maxH = n; go(S_BLK) } }
            S_BLK -> {
                val n = Parse.number(t)
                if (n == null || n < 15f || n > 120f) reject(L("مدة الجلسة بالدقائق (مثال 25 أو 45 أو 60)", "session length in minutes (e.g. 25, 45, 60)"))
                else { prof.blk = n.toInt(); prof.brk = if (n <= 30f) 5 else if (n <= 50f) 10 else 15; go(S_REST) }
            }
            S_REST -> {
                val d = Parse.weekday(t)
                if (d == null) reject(L("اسم يوم الراحة أو «مفيش»", "your rest day or \"none\""))
                else { prof.rest = if (d == 0) -1 else d - 1; go(S_T_TITLE) }
            }
            S_T_TITLE -> {
                if (Parse.yesNo(t) == false) go(S_G_ASK)
                else if (Parse.isTitle(t)) { tTitle = t; go(S_T_HOURS) }
                else reject(L("اسم المهمة نفسها، مثل: مراجعة الفصل الثالث. أو اكتب «مفيش».", "the task's name itself, like \"review chapter 3\", or type \"none\"."))
            }
            S_T_HOURS -> { val n = Parse.number(t); if (n == null || n < 0.25f || n > 40f) reject(L("عدد الساعات (مثال 2 أو 1.5)", "number of hours (e.g. 2 or 1.5)")) else { tHours = n; go(S_T_DL) } }
            S_T_DL -> {
                val d = Parse.weekday(t)
                if (d != null) { tDl = d; tEnd = 0L; go(S_T_PRI) }
                else {
                    val dd = Parse.days(t)
                    if (dd == null) reject(L("اسم يوم من الأسبوع، أو «بعد 20 يوم»، أو «بدون»", "a weekday name, \"in 20 days\", or \"none\""))
                    else { tDl = 0; tEnd = System.currentTimeMillis() + dd * 86_400_000L; go(S_T_PRI) }
                }
            }
            S_T_PRI -> {
                val low = t.lowercase()
                val p = when {
                    low.contains("عالي") || low.contains("high") || low.contains("مهم") -> 0
                    low.contains("متوسط") || low.contains("medium") -> 1
                    low.contains("منخفض") || low.contains("low") || low.contains("عادي") -> 2
                    else -> -1
                }
                if (p < 0) reject(L("عالية أو متوسطة أو منخفضة", "high, medium or low")) else { tasks.add(PTask(tTitle, tHours, tDl, p, tEnd)); tEnd = 0L; go(S_T_MORE) }
            }
            S_T_MORE -> when (Parse.yesNo(t)) { true -> go(S_T_TITLE); false -> go(S_G_ASK); null -> reject(L("نعم أو لا", "yes or no")) }
            S_G_ASK -> when (Parse.yesNo(t)) { true -> go(S_G_TITLE); false -> go(S_CONFIRM); null -> reject(L("نعم أو لا: عندك هدف طويل المدى؟", "yes or no: do you have a long-term goal?")) }
            S_G_TITLE -> { if (Parse.isTitle(t)) { gTitle = t; go(S_G_HOURS) } else reject(L("اسم الهدف نفسه، مثل: إنهاء كورس البرمجة", "the goal's name itself, like \"finish the programming course\"")) }
            S_G_HOURS -> { val n = Parse.number(t); if (n == null || n < 1f || n > 5000f) reject(L("إجمالي الساعات (مثال 60)", "total hours (e.g. 60)")) else { gTotal = n; go(S_G_WHEN) } }
            S_G_WHEN -> {
                val d = Parse.days(t)
                if (d == null) reject(L("المدة (مثال 30 يوم أو 8 أسابيع أو 3 شهور)", "the time frame (e.g. 30 days, 8 weeks, 3 months)"))
                else { goals.add(Goal(gTitle, System.currentTimeMillis() + d * 86_400_000L, gTotal, 0f)); bubble(L("تمت إضافة الهدف «$gTitle».", "Goal \"$gTitle\" added."), false); go(S_G_ASK) }
            }
            S_CONFIRM -> {
                val low = t.lowercase()
                if (low.contains("جديد") || low.contains("start over")) {
                    tasks.clear(); step = S_WAKE; strikes = 0; ask()
                } else if (Parse.yesNo(t) == true || low.contains("ابني") || low.contains("build")) {
                    if (tasks.isEmpty() && goals.isEmpty()) {
                        bubble(L("مفيش مهام ولا أهداف أبني عليها جدولًا. اكتب مهمة واحدة على الأقل.", "There are no tasks or goals to schedule. Add at least one task."), false)
                        go(S_T_TITLE)
                    } else finalizeBuild()
                } else reject(L("«ابني الجدول» أو «ابدأ من جديد»", "\"Build it\" or \"Start over\""))
            }
            S_DONE -> finish()
        }
    }

    private fun finalizeBuild() {
        Planner.saveProfile(this, prof)
        Planner.saveFixed(this, fixed)
        tasks.forEach { Planner.resetDone(this, it.title) }
        Planner.saveTasks(this, tasks)
        Planner.saveGoals(this, goals)
        val plan = Planner.build(this)
        Planner.savePlan(this, plan)
        PlanAlarms.rescan(this)
        Prefs.putInt(this, "pl_just", 1)
        step = S_DONE
        bubble(L("جدولك جاهز.", "Your schedule is ready.") + "\n\n" + Planner.explain(this), false)
        ask()
    }
}

class SchedulePage(private val a: Activity, private val onStart: (Int, String) -> Unit) {
    private lateinit var col: LinearLayout
    private var hz = 1

    fun build(): View {
        col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(18), a.dp(26), a.dp(18), a.dp(24)) }
        render()
        return ScrollView(a).apply { addView(col) }
    }

    fun refresh() { Planner.maybeRoll(a); render() }

    private fun blockRow(b: Block): View {
        val row = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, a.dp(8), 0, a.dp(2)) }
        row.addView(a.tv(Planner.fmt(b.start) + "–" + Planner.fmt(b.end), 13f, C.MU), LinearLayout.LayoutParams(a.dp(96), WRAP))
        row.addView(a.tv((if (b.kind == 1) "🎯 " else "") + b.title, 14f, C.TX), LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(a.tv("▶", 16f, C.AC).apply { setPadding(a.dp(12), a.dp(6), a.dp(6), a.dp(6)); setOnClickListener { onStart(b.end - b.start, b.title) } })
        return row
    }

    private fun render() {
        col.removeAllViews()
        col.put(a.tv(a.L("جدولي", "My schedule"), 24f, C.TX, true), 0)
        col.put(a.tv(a.L("خطة مرنة تتجدد كل يوم: ما فاتك يُعاد ترتيبه بلا ذنب، وحملها يتكيف مع طاقتك والتزامك.", "A flexible plan that renews every day: what you miss is rescheduled without guilt, and its load adapts to your energy and consistency."), 13f, C.MU), 4)
        val plan = Planner.loadPlan(a)
        if (plan == null || plan.blocks.isEmpty()) {
            val k = a.card()
            k.addView(a.tv(a.L("لسه ما عملتش جدول.", "No schedule yet."), 15f, C.TX, true))
            k.put(a.tv(a.L("المساعد هيسألك أسئلة بسيطة عن يومك ومهامك، ثم يبني لك الجدول ويشرح لك نتائجه.", "The assistant asks a few simple questions about your day and tasks, then builds the schedule and explains its results."), 13f, C.MU), 6)
            k.put(a.btn(a.L("ابدأ مساعد الجدولة", "Start the planner"), true) { a.startActivity(Intent(a, PlannerActivity::class.java)) }, 12)
            col.put(k, 16)
            return
        }
        val seg = LinearLayout(a)
        listOf(a.L("اليوم", "Today"), a.L("الأسبوع", "Week"), a.L("الشهر", "Month")).forEachIndexed { i, n ->
            seg.addView(a.tv(n, 13f, if (hz == i) C.ON else C.MU).apply {
                gravity = Gravity.CENTER
                background = a.rounded(if (hz == i) C.AC else C.SF, 12, C.LN)
                setPadding(0, a.dp(9), 0, a.dp(9))
                setOnClickListener { hz = i; render() }
            }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = a.dp(3); marginEnd = a.dp(3) })
        }
        col.put(seg, 14)

        if (hz < 2) energyCard()
        val todayMs = Planner.dayStart(System.currentTimeMillis())
        when (hz) {
            0 -> {
                val list = plan.blocks.filter { it.day == todayMs }
                val k = a.card()
                k.addView(a.tv(a.L("خطة اليوم", "Today's plan"), 15f, C.AC, true))
                if (list.isEmpty()) k.put(a.tv(a.L("لا شيء مجدول لما تبقى من اليوم. استرح أو اختر مهمة من التبويب التالي.", "Nothing is scheduled for the rest of today. Rest, or pick a task from the next tab."), 13f, C.MU), 6)
                list.forEach { k.addView(blockRow(it)) }
                col.put(k, 10)
            }
            2 -> monthView()
            else -> weekView(plan)
        }
        col.put(a.btn(a.L("عدّل في المساعد", "Edit in the assistant")) { a.startActivity(Intent(a, PlannerActivity::class.java)) }, 16)
        col.put(a.btn(a.L("أعد بناء الجدول من بياناتي الحالية", "Rebuild from my current data")) { Planner.replan(a); render() }, 8)
        col.put(a.btn(a.L("احذف الجدول", "Delete the schedule")) {
            a.dlg().setMessage(a.L("حذف الجدول والتذكيرات؟", "Delete the schedule and its reminders?"))
                .setPositiveButton(a.L("حذف", "Delete")) { _, _ -> Planner.clearPlan(a); render() }
                .setNegativeButton(a.L("إلغاء", "Cancel"), null).show()
        }, 8)
    }

    private fun energyCard() {
        val k = a.card()
        k.addView(a.tv(a.L("كيف طاقتك اليوم؟", "How's your energy today?"), 14f, C.TX, true))
        val row = LinearLayout(a)
        val cur = Planner.energy(a)
        for (v in 1..5) {
            row.addView(a.tv("$v", 15f, if (cur == v) C.ON else C.TX).apply {
                gravity = Gravity.CENTER
                background = a.rounded(if (cur == v) C.AC else C.BG, 12, C.LN)
                setPadding(0, a.dp(10), 0, a.dp(10))
                setOnClickListener { Planner.setEnergy(a, v); Planner.replan(a); render() }
            }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = a.dp(3); marginEnd = a.dp(3) })
        }
        k.put(row, 8)
        k.put(a.btn(a.L("يوم صعب؟ خفّف خطة اليوم", "Rough day? Lighten today's plan")) {
            Planner.setEnergy(a, 1); Planner.replan(a)
            Toast.makeText(a, a.L("خففتها: الأهم فقط اليوم، والباقي اتأجل بلا مشكلة.", "Done: only the essentials today, the rest moved without any issue."), Toast.LENGTH_LONG).show()
            render()
        }, 10)
        col.put(k, 12)
    }

    private fun weekView(plan: Plan) {
        val ex = a.card()
        ex.addView(a.tv(a.L("شرح الخطة", "Plan summary"), 15f, C.AC, true))
        ex.put(a.tv(Planner.explain(a), 13f, C.TX), 6)
        col.put(ex, 14)
        col.put(CheckBox(a).apply {
            text = a.L("ذكّرني عند بداية كل مهمة", "Remind me when each task starts")
            setTextColor(C.TX); buttonTintList = ColorStateList.valueOf(C.AC)
            isChecked = Prefs.boolOf(a, "pl_remind", true)
            setOnCheckedChangeListener { _, on -> Prefs.putBool(a, "pl_remind", on); PlanAlarms.rescan(a) }
        }, 10)
        val df = SimpleDateFormat("d/M", Locale.US)
        plan.blocks.groupBy { it.day }.toSortedMap().forEach { (day, list) ->
            val k = a.card()
            val mins = list.sumOf { it.end - it.start }
            k.addView(a.tv(Planner.dayName(a, Planner.dow(day)) + "  " + df.format(Date(day)) + "  (" + String.format(Locale.US, "%.1f", mins / 60f) + a.L(" س)", " h)"), 14f, C.AC, true))
            list.forEach { k.addView(blockRow(it)) }
            col.put(k, 10)
        }
    }

    private fun monthView() {
        val k = a.card()
        k.addView(a.tv(a.L("الشهر القادم", "The month ahead"), 15f, C.AC, true))
        k.put(a.tv(a.L("نفصّل أول أسبوع فقط ونعيد الترتيب كل يوم، فلا داعي للمثالية. الأسابيع التالية تقدير مرن لحمل أهدافك.", "Only the first week is detailed and everything is re-planned daily, so there's no need for perfection. Later weeks are a flexible estimate of your goal load."), 12f, C.MU), 4)
        val df = SimpleDateFormat("d/M", Locale.US)
        Planner.weekLoads(a).forEachIndexed { i, w ->
            val pct = if (w.capacity <= 0) 0 else (w.planned * 100 / w.capacity).coerceIn(0, 100)
            k.put(a.tv(a.L("أسبوع ${i + 1} (من ${df.format(Date(w.start))}): ", "Week ${i + 1} (from ${df.format(Date(w.start))}): ") + String.format(Locale.US, "%.1f", w.planned / 60f) + a.L(" ساعة", " h"), 13f, C.TX), 10)
            k.put(ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100; progress = pct
                progressTintList = ColorStateList.valueOf(if (pct > 95) C.WR else C.AC)
            }, 4)
        }
        col.put(k, 10)
    }
}

class GoalsPage(private val a: Activity) {
    private lateinit var col: LinearLayout

    fun build(): View {
        col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(18), a.dp(26), a.dp(18), a.dp(24)) }
        render()
        return ScrollView(a).apply { addView(col) }
    }

    fun refresh() = render()

    private fun render() {
        col.removeAllViews()
        col.put(a.tv(a.L("الأهداف والروتين", "Goals and routine"), 24f, C.TX, true), 0)
        col.put(a.tv(a.L("أهدافك الكبيرة وروتينك الثابت. مساعد الجدولة يحوّلهم إلى خطة أسبوعية.", "Your big goals and fixed routine. The planner turns them into a weekly plan."), 13f, C.MU), 4)

        val goals = Planner.goals(a)
        if (goals.isEmpty()) col.put(a.tv(a.L("لا توجد أهداف بعد.", "No goals yet."), 14f, C.MU), 16)
        goals.forEachIndexed { i, g ->
            val k = a.card()
            val pct = if (g.total <= 0f) 0 else ((g.done / g.total) * 100f).toInt().coerceIn(0, 100)
            val daysLeft = ((g.endMs - System.currentTimeMillis()) / 86_400_000L).toInt()
            k.addView(a.tv(g.title, 16f, C.TX, true))
            k.put(ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = pct; progressTintList = ColorStateList.valueOf(C.AC) }, 8)
            k.put(a.tv(String.format(Locale.US, "%.1f / %.1f", g.done, g.total) + a.L(" ساعة، باقي $daysLeft يوم", " h, $daysLeft days left"), 12f, C.MU), 4)
            k.put(a.tv(Planner.goalLine(a, g), 12f, C.TX), 6)
            val r = LinearLayout(a)
            r.addView(a.btn("+1 " + a.L("س", "h")) { g.done += 1f; Planner.saveGoals(a, goals); render() }.apply { textSize = 13f }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = a.dp(4) })
            r.addView(a.btn("+5 " + a.L("س", "h")) { g.done += 5f; Planner.saveGoals(a, goals); render() }.apply { textSize = 13f }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = a.dp(4); marginEnd = a.dp(4) })
            r.addView(a.btn(a.L("حذف", "Delete")) { goals.removeAt(i); Planner.saveGoals(a, goals); render() }.apply { textSize = 13f }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = a.dp(4) })
            k.put(r, 10)
            col.put(k, 12)
        }
        col.put(a.btn(a.L("أضف هدفًا", "Add a goal"), true) { addGoal(goals) }, 14)

        col.put(a.tv(a.L("روتيني الثابت", "My fixed routine"), 18f, C.TX, true), 26)
        val fixed = Planner.fixed(a)
        if (fixed.isEmpty()) col.put(a.tv(a.L("أضف التزاماتك الثابتة (شغل، جامعة، تمرين...) ليبني الجدول حولها.", "Add your fixed commitments (work, class, gym...) so the schedule is built around them."), 13f, C.MU), 6)
        fixed.forEachIndexed { i, f ->
            val row = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL; background = a.rounded(C.SF, 12, C.LN); setPadding(a.dp(12), a.dp(8), a.dp(4), a.dp(8)) }
            val days = (0..6).filter { ((f.days shr it) and 1) == 1 }.joinToString("، ") { Planner.dayName(a, it).take(3) }
            row.addView(a.tv(f.label + "\n" + Planner.fmt(f.start) + "–" + Planner.fmt(f.end) + "  " + days, 13f, C.TX), LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(a.tv("✕", 16f, C.MU).apply { setPadding(a.dp(14), a.dp(10), a.dp(14), a.dp(10)); setOnClickListener { fixed.removeAt(i); Planner.saveFixed(a, fixed); render() } })
            col.put(row, 8)
        }
        col.put(a.btn(a.L("أضف التزامًا ثابتًا", "Add a fixed commitment")) {
            FixedForm.show(a, { f -> val l = Planner.fixed(a); l.add(f); Planner.saveFixed(a, l); render() }, { })
        }, 12)
        col.put(a.btn(a.L("ابنِ جدولي من المساعد", "Build my schedule with the assistant")) { a.startActivity(Intent(a, PlannerActivity::class.java)) }, 18)
    }

    private fun addGoal(goals: MutableList<Goal>) {
        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(18), a.dp(10), a.dp(18), a.dp(4)) }
        fun field(h: String, num: Boolean) = EditText(a).apply {
            hint = h; setTextColor(C.TX); setHintTextColor(C.MU)
            inputType = if (num) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL else InputType.TYPE_CLASS_TEXT
        }
        val t = field(a.L("اسم الهدف", "Goal name"), false)
        val h = field(a.L("إجمالي الساعات المطلوبة", "Total hours needed"), true)
        val d = field(a.L("خلال كم يوم؟", "Within how many days?"), true)
        box.addView(t); box.addView(h); box.addView(d)
        val dlg = a.dlg().setTitle(a.L("هدف جديد", "New goal")).setView(box)
            .setPositiveButton(a.L("حفظ", "Save"), null).setNegativeButton(a.L("إلغاء", "Cancel"), null).create()
        dlg.setOnShowListener {
            dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val name = t.text.toString().trim()
                val hours = Parse.number(h.text.toString())
                val days = Parse.number(d.text.toString())
                if (!Parse.isTitle(name) || hours == null || hours <= 0f || days == null || days < 3f) {
                    Toast.makeText(a, a.L("اكتب اسم الهدف، وإجمالي الساعات، وعدد الأيام (3 فأكثر).", "Enter a goal name, total hours and days (3 or more)."), Toast.LENGTH_LONG).show()
                } else {
                    goals.add(Goal(name, System.currentTimeMillis() + (days * 86_400_000L).toLong(), hours, 0f))
                    Planner.saveGoals(a, goals)
                    dlg.dismiss()
                    render()
                }
            }
        }
        dlg.show()
    }
}
