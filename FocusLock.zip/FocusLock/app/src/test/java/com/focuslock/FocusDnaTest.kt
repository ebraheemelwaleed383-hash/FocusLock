package com.focuslock

import java.time.ZoneId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// اختبارات JVM للميزة 02 (بصمة التركيز). لم تُشغَّل في بيئة التطوير (لا Gradle ولا مترجم Kotlin هناك):
// تُشغَّل عبر `gradle testLiteDebugUnitTest` في GitHub Actions
class FocusDnaTest {
    private val TODAY = 20000L                  // الأسبوع الجاري يبدأ 19996
    private val CUR = Ax.weekStart(TODAY)

    private fun wk(ws: Long, done: Int, stop: Int = 0, active: Int = 3, hour: Int = 9, mins: Int = 25, linked: Int = 0): WeekAgg {
        val w = WeekAgg(ws)
        w.done = done; w.stop = stop; w.doneMins = done * mins; w.activeDays = active; w.firstDay = ws; w.linked = linked
        w.hm[hour] = done * mins
        w.wd[0] = done * mins
        w.ab[Ax.bucketOf(mins)] = done
        w.pa[Ax.bucketOf(mins)] = done + stop
        w.pd[Ax.bucketOf(mins)] = done
        return w
    }

    // ---------- الأسبوع والترميز ----------
    @Test fun weekStartIsMondayAndDowMatches() {
        assertEquals(0, Ax.dowOf(CUR))
        assertEquals(CUR, Ax.weekStart(CUR + 6))
        assertEquals(CUR + 7, Ax.weekStart(CUR + 7))
        assertEquals(java.time.DayOfWeek.MONDAY, java.time.LocalDate.ofEpochDay(CUR).dayOfWeek)
    }

    @Test fun codecRoundTripKeepsEveryField() {
        val w = wk(CUR, 5, 2, 4, 14, 30, 3)
        val back = DnaCodec.parse(DnaCodec.encode(listOf(w)))
        assertFalse(back.broken)
        val x = back.weeks[0]
        assertEquals(CUR, x.ws); assertEquals(5, x.done); assertEquals(2, x.stop); assertEquals(150, x.doneMins)
        assertEquals(4, x.activeDays); assertEquals(3, x.linked); assertEquals(150, x.hm[14]); assertEquals(5, x.ab[2])
    }

    @Test fun parseTreatsBlankAsEmptyAndGarbageAsBroken() {
        assertFalse(DnaCodec.parse("").broken)
        assertTrue(DnaCodec.parse("not json").broken)
        assertTrue(DnaCodec.parse("""{"v":99,"w":[]}""").broken)
        assertTrue(DnaCodec.parse("""{"v":1}""").broken)
    }

    @Test fun parseSkipsBadItemsAndClampsValues() {
        val p = DnaCodec.parse("""{"v":1,"w":[{"d":3},{"w":19996,"d":-5,"ad":99,"hm":[1,2]},"x"]}""")
        assertFalse(p.broken)
        assertEquals(2, p.skipped)
        assertEquals(1, p.weeks.size)
        assertEquals(0, p.weeks[0].done); assertEquals(7, p.weeks[0].activeDays); assertEquals(2, p.weeks[0].hm[1])
    }

    // ---------- الدمج والحفظ والاستعادة ----------
    @Test fun mergeNeverLosesAWeekWhenTheLogWasTrimmed() {
        val stored = listOf(wk(CUR - 70, 10, 2), wk(CUR - 63, 8))
        val fresh = listOf(wk(CUR - 63, 3))                       // السجل اقتُطع فبقي 3 فقط من 8
        val m = DnaCodec.merge(stored, fresh)
        assertEquals(2, m.size)
        assertEquals(8, m.first { it.ws == CUR - 63 }.done)
    }

    @Test fun mergeTakesNewerWhenItHasMoreOrEqualSessions() {
        val m = DnaCodec.merge(listOf(wk(CUR, 3)), listOf(wk(CUR, 4)))
        assertEquals(4, m[0].done)
        val eq = DnaCodec.merge(listOf(wk(CUR, 3, active = 1)), listOf(wk(CUR, 3, active = 2)))
        assertEquals(2, eq[0].activeDays)
    }

    @Test fun mergeCapsOldestWeeksOnly() {
        val many = (0 until 110).map { wk(CUR - 7L * (109 - it), 1) }
        val m = DnaCodec.merge(many, emptyList())
        assertEquals(DTh.CAP_WEEKS, m.size)
        assertEquals(CUR, m.last().ws)
    }

    @Test fun restoreGuardRejectsGarbageAndAcceptsValid() {
        assertTrue("dna_hist" in BackupGuard.GUARDED)
        assertNull(BackupGuard.sanitize("dna_hist", "garbage"))
        assertNull(BackupGuard.sanitize("dna_hist", """{"v":1,"w":[{"x":1},{"y":2}]}"""))   // عناصر كلها غير صالحة: لا نطمس الحالي
        assertNotNull(BackupGuard.sanitize("dna_hist", DnaCodec.encode(listOf(wk(CUR, 2)))))
    }

    @Test fun restoreMergesWithCurrentHistoryInsteadOfReplacing() {
        val cur = DnaCodec.encode(listOf(wk(CUR, 6), wk(CUR - 7, 2)))
        val bak = DnaCodec.encode(listOf(wk(CUR, 3), wk(CUR - 14, 5)))
        val m = DnaCodec.parse(DnaCodec.mergeRaw(cur, bak)).weeks
        assertEquals(3, m.size)
        assertEquals(6, m.first { it.ws == CUR }.done)
        assertEquals(5, m.first { it.ws == CUR - 14 }.done)
        assertEquals(1, DnaCodec.parse(DnaCodec.mergeRaw(null, DnaCodec.encode(listOf(wk(CUR, 1))))).weeks.size)
        assertEquals(1, DnaCodec.parse(DnaCodec.mergeRaw("garbage", DnaCodec.encode(listOf(wk(CUR, 1))))).weeks.size)
    }

    // ---------- من الجلسات إلى الملخصات ----------
    @Test fun weeklyAggregateFromSessions() {
        val utc = ZoneId.of("UTC")
        val DAY = 86_400_000L
        fun r(id: Long, day: Long, hour: Int, planned: Int, actual: Int, st: String, task: String = ""): SessionRec {
            val s = SessionRec(id, day * DAY + hour * 3_600_000L, planned)
            s.actual = actual; s.status = st; s.end = s.start + actual * 60_000L; s.taskId = task
            return s
        }
        val l = listOf(
            r(1, CUR, 9, 25, 25, "done", "t"), r(2, CUR, 20, 25, 10, "stop"), r(3, CUR + 1, 9, 50, 50, "done"),
            r(4, CUR - 7, 9, 25, 25, "done")
        )
        val ws = WeekAgg.fromSessions(SessionAnalytics.clean(l, utc, (CUR + 3) * DAY))
        assertEquals(2, ws.size)
        val w = ws.first { it.ws == CUR }
        assertEquals(2, w.done); assertEquals(1, w.stop); assertEquals(75, w.doneMins); assertEquals(10, w.stopMins)
        assertEquals(2, w.activeDays); assertEquals(1, w.linked)
        assertEquals(75, w.hm[9]); assertEquals(0, w.hm[20]); assertEquals(1, w.ab[1]); assertEquals(1, w.ab[3])
        assertEquals(2, w.pa[1]); assertEquals(1, w.pd[1]); assertEquals(CUR, w.firstDay)
    }

    // ---------- بناء البصمة والتسميات ----------
    @Test fun noDataGivesEmptyProfile() {
        val p = FocusDna.build(emptyList(), TODAY)
        assertEquals(Conf.NONE, p.conf); assertTrue(p.labels.isEmpty()); assertFalse(p.evolutionOk); assertNull(p.periodFrom)
    }

    @Test fun tooLittleDataAssignsNoLabels() {
        val p = FocusDna.build(listOf(wk(CUR, 3, active = 2)), TODAY)
        assertTrue(p.labels.isEmpty())
        assertTrue(p.conf == Conf.LOW || p.conf == Conf.NONE)
        assertFalse(p.evolutionOk)
        assertEquals(3, p.analyzed)
    }

    @Test fun morningShortConsistentProfileGetsExpectedLabels() {
        val weeks = (0..3).map { wk(CUR - 7L * (3 - it), 6, 0, 5, 9, 25) }
        val p = FocusDna.build(weeks, TODAY)
        assertTrue(DL.MORNING_FOCUS in p.labels)
        assertTrue(DL.SHORT_SESSIONS in p.labels)
        assertTrue(DL.CONSISTENT_HABIT in p.labels)
        assertTrue(DL.FINISHES_SESSIONS in p.labels)
        assertFalse(DL.EVENING_FOCUS in p.labels)
    }

    @Test fun eveningAndLongSessionsLabels() {
        val weeks = (0..3).map { wk(CUR - 7L * (3 - it), 4, 0, 3, 20, 50) }
        val p = FocusDna.build(weeks, TODAY)
        assertTrue(DL.EVENING_FOCUS in p.labels)
        assertTrue(DL.LONG_SESSIONS in p.labels)
        assertTrue(DL.REGULAR_HABIT in p.labels)
    }

    @Test fun oneUnusualSessionDoesNotChangeTheMainLabel() {
        val weeks = ArrayList<WeekAgg>((0..2).map { wk(CUR - 7L * (3 - it), 6, 0, 4, 9, 25) })
        val now = wk(CUR, 5, 0, 3, 9, 25)
        now.done += 1; now.doneMins += 25; now.hm[19] = 25; now.ab[1] += 1; now.pa[1] += 1; now.pd[1] += 1   // جلسة مسائية شاذة
        weeks.add(now)
        val p = FocusDna.build(weeks, TODAY)
        assertTrue(DL.MORNING_FOCUS in p.labels)
        assertFalse(DL.EVENING_FOCUS in p.labels)
        assertFalse(DL.VARIED_TIMING in p.labels)
    }

    @Test fun hysteresisKeepsAHeldLabelJustBelowEntryThreshold() {
        val w = WeekAgg(CUR - 7)
        w.done = 10; w.doneMins = 1000; w.hm[9] = 470; w.hm[19] = 300; w.hm[14] = 230
        val m = FocusDna.metrics(listOf(w), 28, emptyList())
        assertEquals(0.47, m.shares!![0], 1e-9)
        assertFalse(DL.MORNING_FOCUS in FocusDna.labelsFor(m, null))
        assertTrue(DL.VARIED_TIMING in FocusDna.labelsFor(m, null))
        assertTrue(DL.MORNING_FOCUS in FocusDna.labelsFor(m, setOf(DL.MORNING_FOCUS)))
        val lower = WeekAgg(CUR - 7)
        lower.done = 10; lower.doneMins = 1000; lower.hm[9] = 400; lower.hm[19] = 350; lower.hm[14] = 250
        assertFalse(DL.MORNING_FOCUS in FocusDna.labelsFor(FocusDna.metrics(listOf(lower), 28, emptyList()), setOf(DL.MORNING_FOCUS)))
    }

    @Test fun peakWindowAndConsistentDays() {
        val weeks = (1..3).map { wk(CUR - 7L * it, 6, 0, 4, 10, 25) }
        val m = FocusDna.metrics(weeks, 21, weeks.map { it.ws })
        assertEquals(8, m.peakStart)                 // نافذة 8-11 تضم الساعة 10
        assertEquals(1.0, m.presence!![0], 1e-9)     // الاثنين نشط في الأسابيع الثلاثة
        assertEquals(0.0, m.presence!![3], 1e-9)
        assertNull(FocusDna.metrics(weeks, 21, listOf(weeks[0].ws)).presence)   // أقل من 3 أسابيع كاملة
    }

    @Test fun completionByLengthNeedsTwoRangesWithEnoughSamples() {
        val a = wk(CUR - 7, 8, 0, 3, 9, 25)           // قصيرة: 8/8
        val b = WeekAgg(CUR - 14); b.done = 3; b.stop = 5; b.doneMins = 150; b.pa[3] = 8; b.pd[3] = 3; b.ab[3] = 3; b.hm[9] = 150
        val m = FocusDna.metrics(listOf(a, b), 28, emptyList())
        assertEquals(1, m.bestBucket)
        assertEquals(1.0, m.bestBucketRate!!, 1e-9)
        val single = FocusDna.metrics(listOf(a), 28, emptyList())
        assertNull(single.bestBucket)
    }

    // ---------- التطور ----------
    @Test fun improvingConsistencyIsDetectedAgainstTheBaseline() {
        val base = (0..3).map { wk(CUR - 49 + 7L * it, 3, 0, 2, 9, 25) }
        val recent = (0..3).map { wk(CUR - 21 + 7L * it, 4, 0, 4, 9, 25) }
        val p = FocusDna.build(base + recent, TODAY)
        assertTrue(p.evolutionOk)
        assertTrue(p.changes.any { it.code == CH.CONSIST_UP })
        assertTrue(DL.IMPROVING_CONSISTENCY in p.labels)
        assertEquals(8, p.timeline.size)
    }

    @Test fun noEvolutionWithoutEnoughBaselineHistory() {
        val p = FocusDna.build((0..3).map { wk(CUR - 21 + 7L * it, 4, 0, 4, 9, 25) }, TODAY)
        assertFalse(p.evolutionOk)
        assertTrue(p.changes.isEmpty())
    }

    @Test fun rhythmShiftIsReported() {
        val base = (0..3).map { wk(CUR - 49 + 7L * it, 3, 0, 3, 9, 25) }
        val recent = (0..3).map { wk(CUR - 21 + 7L * it, 4, 0, 3, 20, 25) }
        val p = FocusDna.build(base + recent, TODAY)
        val ch = p.changes.firstOrNull { it.code == CH.RHYTHM_SHIFT }
        assertNotNull(ch)
        assertEquals(0.0, ch!!.from, 1e-9); assertEquals(2.0, ch.to, 1e-9)
    }

    @Test fun profileReadsHistoryBeyondTheTrimmedLog() {
        // الأسابيع القديمة موجودة في التاريخ المحفوظ فقط (اقتُطعت من السجل) ومع ذلك تدخل في التطور
        val stored = (0..3).map { wk(CUR - 49 + 7L * it, 3, 0, 2, 9, 25) }
        val fresh = (0..3).map { wk(CUR - 21 + 7L * it, 4, 0, 4, 9, 25) }
        val merged = DnaCodec.merge(stored, fresh)
        assertEquals(8, merged.size)
        assertTrue(FocusDna.build(merged, TODAY).evolutionOk)
    }

    @Test fun taskLinkedAndEarlyExitLabels() {
        val weeks = (0..3).map { wk(CUR - 7L * (3 - it), 2, 3, 3, 9, 25, linked = 3) }
        val p = FocusDna.build(weeks, TODAY)
        assertTrue(DL.ENDS_EARLY in p.labels)
        assertTrue(DL.TASK_LINKED in p.labels)
        assertFalse(DL.FINISHES_SESSIONS in p.labels)
    }
}
