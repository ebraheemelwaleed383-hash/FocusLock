package com.focuslock

import java.time.ZoneId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// اختبارات انحدار لدمج الإجماليات اليومية (fm_) مع سجل الجلسات المحدود بـ600. لم تُشغَّل في بيئة التطوير (لا Gradle ولا مترجم Kotlin):
// تُشغَّل عبر `gradle testLiteDebugUnitTest` في GitHub Actions
class DailyTotalsTest {
    private val utc = ZoneId.of("UTC")
    private val DAY = 86_400_000L
    private val HOUR = 3_600_000L
    private val TODAY = 20000L
    private val now = TODAY * DAY + 12 * HOUR
    private var nextId = 1L

    private fun rec(day: Long, hour: Int, planned: Int, actual: Int, status: String = "done", minute: Int = 0): SessionRec {
        val start = day * DAY + hour * HOUR + minute * 60_000L
        val r = SessionRec(start + nextId, start + nextId, planned)
        r.actual = actual; r.end = r.start + actual * 60_000L; r.status = status
        nextId++
        return r
    }

    private fun clean(l: List<SessionRec>) = SessionAnalytics.clean(l, utc, now)
    private fun totals(l: List<SessionRec>, legacy: Map<Long, Int>): DailyTotals = DailyTotals.build(clean(l), legacy)

    // ---------- تداخل المصدرين ----------
    @Test fun overlappingLogAndCountersAreNotDoubleCounted() {
        val l = listOf(rec(TODAY - 1, 9, 25, 25), rec(TODAY - 1, 11, 25, 25), rec(TODAY, 9, 30, 30))
        val t = totals(l, mapOf(TODAY - 1 to 50, TODAY to 30))
        assertEquals(50, t.mins(TODAY - 1)); assertEquals(30, t.mins(TODAY))
        assertEquals(80, t.sum(TODAY - 1, TODAY))
    }

    @Test fun counterLowerThanLogKeepsTheLogValue() {
        val t = totals(listOf(rec(TODAY, 9, 25, 25), rec(TODAY, 11, 25, 25)), mapOf(TODAY to 25))
        assertEquals(50, t.mins(TODAY))
    }

    @Test fun stoppedSessionsNeverAddCompletedMinutes() {
        val t = totals(listOf(rec(TODAY, 9, 25, 10, "stop")), emptyMap<Long, Int>())
        assertEquals(0, t.mins(TODAY))
    }

    // ---------- سجل ناقص أو مقتطع ----------
    @Test fun dayPartiallyTrimmedFromTheLogIsRestoredFromTheCounter() {
        // اليوم كان فيه 4 جلسات (100 د) لكن بقيت جلسة واحدة في السجل
        val t = totals(listOf(rec(TODAY - 5, 20, 25, 25), rec(TODAY - 4, 9, 25, 25)), mapOf(TODAY - 5 to 100, TODAY - 4 to 25))
        assertEquals(100, t.mins(TODAY - 5))
        assertEquals(25, t.mins(TODAY - 4))
    }

    @Test fun daysFullyTrimmedFromTheLogComeFromCountersAndExtendCoverage() {
        val legacy = HashMap<Long, Int>()
        for (d in (TODAY - 40)..(TODAY - 11)) legacy[d] = 30
        val t = totals(listOf(rec(TODAY - 3, 9, 25, 25)), legacy)
        assertEquals(30, t.mins(TODAY - 40)); assertEquals(30, t.mins(TODAY - 11))
        assertEquals(0, t.mins(TODAY - 8))                // داخل التغطية ولا نشاط: صفر معروف
        assertEquals(TODAY - 40, t.coverageStart)
    }

    @Test fun logOnlyDaysWithoutCounterAreKept() {
        val t = totals(listOf(rec(TODAY - 2, 9, 25, 25)), emptyMap<Long, Int>())
        assertEquals(25, t.mins(TODAY - 2))
        assertEquals(TODAY - 2, t.coverageStart)
    }

    @Test fun truncatedLogMarksItsOldestDayAsIncomplete() {
        val l = (0 until SessionMath.LOG_CAP).map { rec(TODAY - 30 + it / 24, it % 24, 25, 25) }
        val c = clean(l)
        assertTrue(c.logTruncated)
        assertEquals(TODAY - 29, c.logCompleteFrom)
        assertEquals(TODAY - 29, DailyTotals.build(c, emptyMap<Long, Int>()).coverageStart)             // لا نعتمد اليوم الأقدم الناقص
        assertEquals(TODAY - 40, DailyTotals.build(c, mapOf(TODAY - 40 to 10)).coverageStart) // العدّاد الأقدم يوسّع التغطية
        assertFalse(clean(l.take(10)).logTruncated)
        assertEquals(TODAY - 30, clean(l.take(10)).logCompleteFrom)
    }

    @Test fun dayWithLostSessionsTakesTheCounterValueNotTheSum() {
        val l = (0 until SessionMath.LOG_CAP).map { rec(TODAY - 30 + it / 24, it % 24, 25, 25) }.drop(20)   // اقتُطعت 20 جلسة من أول يوم
        val c = clean(l + rec(TODAY, 9, 25, 25))
        val firstDay = c.sessions[0].day
        val t = DailyTotals.build(c, mapOf(firstDay to 600))     // العدّاد يعرف أن اليوم كان 24×25
        assertEquals(600, t.mins(firstDay))                      // max: لا 600 + الباقي
    }

    // ---------- نسب الجلسات عبر منتصف الليل ----------
    @Test fun sessionCrossingMidnightIsAttributedToItsEndDayLikeTheCounter() {
        val s = rec(TODAY - 1, 23, 30, 30, minute = 50)          // 23:50 -> 00:20
        val t = totals(listOf(s), mapOf(TODAY to 30))             // fm_ يُكتب يوم الإنهاء
        assertEquals(30, t.mins(TODAY)); assertEquals(0, t.mins(TODAY - 1))
        assertEquals(30, t.sum(TODAY - 1, TODAY))
    }

    // ---------- مفاتيح ناقصة أو تالفة ----------
    @Test fun malformedAndNegativeCounterKeysAreIgnoredZeroKeyOnlyExtendsCoverage() {
        val m = LegacyDaily.parse(mapOf("fm_20240105" to -5L, "fm_bad" to 10L, "fm_20240106" to 0L, "fm_20240107" to 20L, "fm_20240230" to 5L))
        val d6 = java.time.LocalDate.of(2024, 1, 6).toEpochDay()
        assertEquals(2, m.size)
        assertEquals(0, m[d6]); assertEquals(20, m[java.time.LocalDate.of(2024, 1, 7).toEpochDay()])
        val t = DailyTotals.build(emptyList<Sess>(), m)
        assertEquals(0, t.mins(d6)); assertEquals(d6, t.coverageStart)
        assertNull(DailyTotals.build(emptyList<Sess>(), emptyMap<Long, Int>()).coverageStart)
    }

    // ---------- أثر التصحيح على التحليل ----------
    private fun scenarioTrimmedLog(): IntelReport {
        // العدّادات تغطي آخر 28 يومًا (30 د يوميًا)، والسجل بقي فيه آخر 8 أيام فقط
        val legacy = HashMap<Long, Int>()
        for (d in (TODAY - 27)..TODAY) legacy[d] = 30
        val l = (0..7).map { rec(TODAY - it, 9, 30, 30, minute = it) }
        val c = clean(l)
        return FocusIntel.build(c, DailyTotals.build(c, legacy), emptyList(), TODAY)
    }

    @Test fun last14DaysAndLast8WeeksUseMergedTotals() {
        val r = scenarioTrimmedLog()
        assertEquals(14, r.daily14.size); assertTrue(r.daily14.all { it == 30 })
        assertEquals(8, r.weekly8.size)
        assertEquals(listOf(0, 0, 0, 0, 210, 210, 210, 210), r.weekly8)     // الأسابيع الأربعة الأقدم قبل أول بيانات = 0 معروفة التغطية
    }

    @Test fun weeklyTrendUsesOlderCounterDaysThatTheLogLost() {
        val r = scenarioTrimmedLog()
        assertTrue(r.weekTrend.valid)                                       // التغطية (من العدّادات) تبدأ قبل 28 يومًا
        assertEquals(210, r.weekTrend.cur); assertEquals(210, r.weekTrend.prev)
        assertEquals(0.0, r.weekTrend.pct()!!, 1e-9)
    }

    @Test fun consistencyUsesMergedDaysAndStreakSpansLostLogDays() {
        val k = scenarioTrimmedLog().consistency
        assertEquals(28, k.spanDays); assertEquals(28, k.activeDays)
        assertEquals(1.0, k.activeRate!!, 1e-9)
        assertEquals(28, k.currentStreak); assertEquals(28, k.longestStreak)
        assertEquals(0.0, k.weeklyCv!!, 1e-9)
    }

    @Test fun sessionBasedRateTrendIsNotComputedOverTheLostLogPeriod() {
        val r = scenarioTrimmedLog()
        assertFalse(r.completionTrend.valid)       // السجل مكتمل من قبل 7 أيام فقط
        assertFalse(r.stopTrend.valid)
    }

    @Test fun trendNotClaimedBeforeAnyKnownData() {
        val c = clean(listOf(rec(TODAY - 3, 9, 25, 25)))
        val r = FocusIntel.build(c, DailyTotals.build(c, mapOf(TODAY - 5 to 25)), emptyList(), TODAY)
        assertFalse(r.weekTrend.valid)
        assertNull(r.weekTrend.pct())
        assertEquals(6, r.consistency.spanDays)   // 6 أيام مغطاة فقط، فلا نسبة انتظام
        assertNull(r.consistency.activeRate)
    }
}
