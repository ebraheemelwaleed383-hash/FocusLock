package com.focuslock

import java.time.ZoneId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// اختبارات JVM للميزة 01 (الأساس التحليلي وتحليل التركيز). لم تُشغَّل في بيئة التطوير (لا Gradle ولا مترجم Kotlin هناك):
// تُشغَّل عبر `gradle testLiteDebugUnitTest` في GitHub Actions
class AnalyticsTest {
    private val utc = ZoneId.of("UTC")
    private val DAY = 86_400_000L
    private val HOUR = 3_600_000L
    private val TODAY = 20000L                       // يوم ثابت (epoch day)
    private val now = TODAY * DAY + 12 * HOUR

    private var nextId = 1L
    private fun rec(day: Long, hour: Int, planned: Int, actual: Int, status: String, task: String = "", outcome: String = "", minute: Int = 0): SessionRec {
        val start = day * DAY + hour * HOUR + minute * 60_000L
        val r = SessionRec(start + nextId, start + nextId, planned) // معرّف فريد وبدايات متباعدة
        r.actual = actual
        r.end = start + actual * 60_000L
        r.status = status
        r.taskId = task
        r.taskTitle = if (task.isEmpty()) "" else "مهمة $task"
        r.outcome = outcome
        nextId++
        return r
    }

    private fun spaced(day: Long, hour: Int, planned: Int, actual: Int, status: String, k: Int, task: String = "", outcome: String = ""): SessionRec =
        rec(day, hour, planned, actual, status, task, outcome, minute = k % 50)

    private fun clean(l: List<SessionRec>) = SessionAnalytics.clean(l, utc, now)

    // ---------- تصنيف الجلسات والمدد ----------
    @Test fun doneAndStopClassifiedWithEffectiveMinutes() {
        val c = clean(listOf(rec(TODAY, 9, 25, 25, "done"), rec(TODAY, 11, 25, 10, "stop")))
        assertEquals(2, c.sessions.size)
        val p = FocusIntel.perfOf(c.sessions)
        assertEquals(1, p.doneCount); assertEquals(1, p.stopCount)
        assertEquals(25, p.completedMins); assertEquals(10, p.partialMins)
        assertEquals(0.5, p.completionRate!!, 1e-9)
        assertEquals(25.0, p.avgDone!!, 1e-9)
        assertEquals(10.0 / 25.0, p.stopReach!!, 1e-9)
    }

    @Test fun stoppedSessionTimeNeverExceedsPlan() {
        val c = clean(listOf(rec(TODAY, 9, 25, 300, "stop")))
        assertEquals(25, c.sessions[0].eff)
    }

    @Test fun openInvalidTinyAndFutureRecordsAreExcludedAndCounted() {
        val l = listOf(
            rec(TODAY, 8, 25, 0, "open"),
            rec(TODAY, 9, 25, 25, "weird"),
            rec(TODAY, 10, 25, 0, "stop"),              // أقل من دقيقة
            rec(TODAY, 11, 25, -5, "done"),             // سالب
            rec(TODAY, 12, 25, 9999, "done"),           // أكبر من 12 ساعة
            rec(TODAY + 5, 9, 25, 25, "done"),          // مستقبل بعيد
            rec(TODAY, 13, 25, 25, "done")
        )
        val c = clean(l)
        assertEquals(1, c.sessions.size)
        assertEquals(1, c.openIgnored)
        assertEquals(1, c.tinyIgnored)
        assertEquals(4, c.invalid)
    }

    @Test fun endBeforeStartIsInvalid() {
        val r = rec(TODAY, 9, 25, 25, "done"); r.end = r.start - 1000
        assertEquals(0, clean(listOf(r)).sessions.size)
    }

    @Test fun duplicatesAreCountedOnceAndDoneBeatsStop() {
        val a = rec(TODAY, 9, 25, 10, "stop")
        val b = SessionRec(a.id + 1, a.start + 2000, 25); b.actual = 25; b.end = b.start + 25 * 60_000L; b.status = "done"
        val same = SessionRec(a.id, a.start, 25); same.actual = 10; same.status = "stop"; same.end = a.end
        val c = clean(listOf(a, b, same))
        assertEquals(1, c.sessions.size)
        assertTrue(c.sessions[0].done)
        assertEquals(2, c.duplicates)
    }

    @Test fun localHourAndWeekdayUseTheGivenZone() {
        val r = rec(TODAY, 23, 25, 25, "done")
        val s = SessionAnalytics.clean(listOf(r), ZoneId.of("Asia/Riyadh"), now).sessions[0] // UTC+3: الساعة 23 UTC = 02 صباح اليوم التالي
        assertEquals(2, s.hour)
        assertEquals(TODAY + 1, s.day)
        assertEquals(Ax.dowOf(TODAY + 1), s.dow)
    }

    // ---------- النسب والمقامات ----------
    @Test fun emptyDataHasNoRateAndNoInsights() {
        val c = clean(emptyList())
        val rep = FocusIntel.build(c, DailyTotals.build(c.sessions, emptyMap<Long, Int>()), emptyList(), TODAY)
        assertNull(rep.perf.completionRate); assertNull(rep.perf.avgDone); assertNull(rep.perf.medianDone)
        assertTrue(rep.insights.isEmpty()); assertTrue(rep.recs.isEmpty())
        assertEquals(Conf.NONE, rep.conf)
        assertNull(Stats.rate(3, 0))
    }

    @Test fun fewSessionsProduceNoPatternInsights() {
        val l = (0 until 6).map { spaced(TODAY - it, 9, 25, 25, "done", it) }
        val c = clean(l)
        val rep = FocusIntel.build(c, DailyTotals.build(c.sessions, emptyMap<Long, Int>()), emptyList(), TODAY)
        assertTrue(rep.insights.none { it.code == IC.PEAK_PERIOD || it.code == IC.BEST_DAY || it.code == IC.COMPLETION_HIGH })
    }

    @Test fun medianAndPercentile() {
        assertEquals(3.0, Stats.median(listOf(5, 1, 3))!!, 1e-9)
        assertEquals(2.5, Stats.median(listOf(1, 2, 3, 4))!!, 1e-9)
        assertNull(Stats.median(emptyList()))
        assertEquals(2.0, Stats.percentile(listOf(1, 2, 3), 0.5)!!, 1e-9)
        assertEquals(1.5, Stats.percentile(listOf(1, 2, 3), 0.25)!!, 1e-9)
        assertNull(Stats.cv(listOf(0, 0)))
    }

    // ---------- الأنماط ----------
    @Test fun morningPeakIsDetectedWithEnoughData() {
        val l = ArrayList<SessionRec>()
        for (i in 0 until 12) l.add(spaced(TODAY - i, 9, 25, 25, "done", i))
        for (i in 0 until 2) l.add(spaced(TODAY - i, 20, 25, 25, "done", i + 20))
        val c = clean(l)
        val rep = FocusIntel.build(c, DailyTotals.build(c.sessions, emptyMap<Long, Int>()), emptyList(), TODAY)
        val pk = rep.insights.firstOrNull { it.code == IC.PEAK_PERIOD }
        assertNotNull(pk)
        assertEquals(0.0, pk!!.n[0], 1e-9)
        assertEquals(9, rep.peakHour)
    }

    @Test fun lengthGapInsightAndShorterRecommendation() {
        val l = ArrayList<SessionRec>()
        for (i in 0 until 6) l.add(spaced(TODAY - i, 9, 25, 25, "done", i))          // قصيرة: 6/6
        for (i in 0 until 3) l.add(spaced(TODAY - i, 14, 50, 50, "done", i + 10))    // طويلة: 3 مكتملة
        for (i in 0 until 3) l.add(spaced(TODAY - i - 3, 14, 50, 12, "stop", i + 20)) // و3 مبكرة
        val c = clean(l)
        val rep = FocusIntel.build(c, DailyTotals.build(c.sessions, emptyMap<Long, Int>()), emptyList(), TODAY)
        assertTrue(rep.insights.any { it.code == IC.LENGTH_GAP })
        val r = rep.recs.firstOrNull { it.code == RC.SHORTER }
        assertNotNull(r)
        assertEquals(25.0, r!!.n[0], 1e-9)
    }

    @Test fun periodWithManyEarlyExitsIsFlagged() {
        val l = ArrayList<SessionRec>()
        for (i in 0 until 6) l.add(spaced(TODAY - i, 9, 25, 25, "done", i))
        for (i in 0 until 6) l.add(spaced(TODAY - i, 21, 25, 8, "stop", i + 10))
        val c = clean(l)
        val rep = FocusIntel.build(c, DailyTotals.build(c.sessions, emptyMap<Long, Int>()), emptyList(), TODAY)
        val s = rep.insights.firstOrNull { it.code == IC.STOPS_BY_PERIOD }
        assertNotNull(s)
        assertEquals(2.0, s!!.n[0], 1e-9) // المساء
        assertTrue(rep.recs.any { it.code == RC.REDUCE_STOPS })
    }

    // ---------- الاتجاهات والتجميع التاريخي ----------
    @Test fun weeklyTrendNotClaimedWithoutCoverage() {
        val l = (0 until 3).map { spaced(TODAY - it, 9, 25, 25, "done", it) }
        val c = clean(l)
        val rep = FocusIntel.build(c, DailyTotals.build(c.sessions, emptyMap<Long, Int>()), emptyList(), TODAY)
        assertFalse(rep.weekTrend.valid)
        assertNull(rep.weekTrend.pct())
        assertFalse(rep.completionTrend.valid)
    }

    @Test fun weeklyTrendComparesWhenCovered() {
        val l = ArrayList<SessionRec>()
        for (i in 0 until 7) l.add(spaced(TODAY - 7 - i, 9, 25, 25, "done", i))          // الأسبوع السابق: 175
        for (i in 0 until 7) { l.add(spaced(TODAY - i, 9, 25, 25, "done", i)); l.add(spaced(TODAY - i, 15, 25, 25, "done", i + 10)) } // الحالي: 350
        val c = clean(l)
        val t = DailyTotals.build(c.sessions, emptyMap<Long, Int>())
        val rep = FocusIntel.build(c, t, emptyList(), TODAY)
        assertTrue(rep.weekTrend.valid)
        assertEquals(350, rep.weekTrend.cur); assertEquals(175, rep.weekTrend.prev)
        assertEquals(100.0, rep.weekTrend.pct()!!, 1e-9)
        assertTrue(rep.insights.any { it.code == IC.TREND_UP })
        assertEquals(8, rep.weekly8.size); assertEquals(14, rep.daily14.size)
    }

    @Test fun dailyTotalsTakeTheLargerValuePerDayAndAreNeverSummed() {
        val l = listOf(spaced(TODAY - 2, 9, 25, 25, "done", 0))
        val c = clean(l)
        val legacy = mapOf(TODAY - 10 to 60, TODAY - 2 to 40, TODAY - 1 to 30)
        val t = DailyTotals.build(c.sessions, legacy)
        assertEquals(60, t.mins(TODAY - 10))    // قبل السجل: من fm_
        assertEquals(40, t.mins(TODAY - 2))     // max(25 سجل، 40 fm_) وليس 65
        assertEquals(30, t.mins(TODAY - 1))     // يوم بلا سجل لكن له fm_
        assertEquals(TODAY - 10, t.coverageStart)
    }

    @Test fun legacyParseIgnoresMalformedKeys() {
        val m = LegacyDaily.parse(mapOf("fm_20240105" to 45L, "fm_2024" to 5L, "fm_20241399" to 9L, "xx_20240105" to 3L, "fm_abcdefgh" to 1L, "fm_20240106" to 99999L))
        assertEquals(2, m.size)
        assertEquals(45, m[java.time.LocalDate.of(2024, 1, 5).toEpochDay()])
        assertEquals(1440, m[java.time.LocalDate.of(2024, 1, 6).toEpochDay()])
    }

    @Test fun streakIsNotBrokenByTodayWithoutSessionYet() {
        val l = listOf(1L, 2L, 3L).map { spaced(TODAY - it, 9, 25, 25, "done", it.toInt()) }
        val c = clean(l)
        val rep = FocusIntel.build(c, DailyTotals.build(c.sessions, emptyMap<Long, Int>()), emptyList(), TODAY)
        assertEquals(3, rep.consistency.currentStreak)
        assertEquals(3, rep.consistency.longestStreak)
        assertNull(rep.consistency.activeRate) // أقل من 7 أيام: لا نسبة
    }

    // ---------- المهام ----------
    @Test fun interruptedSessionsNeverMarkTaskCarriedOrFailed() {
        val l = (0 until 4).map { spaced(TODAY - it, 9, 25, 5, "stop", it, task = "A") }
        val c = clean(l)
        val rep = FocusIntel.build(c, DailyTotals.build(c.sessions, emptyMap<Long, Int>()), listOf(TaskInfo("A", "A", false, "", 0, 0)), TODAY)
        val t = rep.tasks.perTask[0]
        assertFalse(t.carried)
        assertEquals(4, t.sessions)
        assertTrue(rep.insights.none { it.code == IC.TASK_CARRIED })
    }

    @Test fun carriedAndSplitFlagsNeedExplicitOutcomes() {
        val l = (0 until 3).map { spaced(TODAY - it, 9, 25, 25, "done", it, task = "A", outcome = "later") }
        val c = clean(l)
        val open = FocusIntel.build(c, DailyTotals.build(c.sessions, emptyMap<Long, Int>()), listOf(TaskInfo("A", "A", false, "p", 0, 0)), TODAY)
        assertTrue(open.tasks.perTask[0].carried); assertTrue(open.tasks.perTask[0].split)
        assertTrue(open.recs.any { it.code == RC.SPLIT_TASK })
        val finished = FocusIntel.build(c, DailyTotals.build(c.sessions, emptyMap<Long, Int>()), listOf(TaskInfo("A", "A", true, "p", 0, 0)), TODAY)
        assertFalse(finished.tasks.perTask[0].carried)
        val withSteps = FocusIntel.build(c, DailyTotals.build(c.sessions, emptyMap<Long, Int>()), listOf(TaskInfo("A", "A", false, "p", 3, 1)), TODAY)
        assertFalse(withSteps.tasks.perTask[0].split)
        val removed = FocusIntel.build(c, DailyTotals.build(c.sessions, emptyMap<Long, Int>()), emptyList(), TODAY)
        assertNull(removed.tasks.perTask[0].taskDone)
        assertFalse(removed.tasks.perTask[0].carried)
    }

    @Test fun taskTimePlannedVsActualAndProjects() {
        val l = listOf(
            spaced(TODAY, 9, 25, 25, "done", 0, task = "A"),
            spaced(TODAY - 1, 9, 30, 10, "stop", 1, task = "A"),
            spaced(TODAY - 2, 9, 20, 20, "done", 2, task = "B")
        )
        val c = clean(l)
        val rep = FocusIntel.build(c, DailyTotals.build(c.sessions, emptyMap<Long, Int>()), listOf(TaskInfo("A", "A", false, "عمل", 0, 0), TaskInfo("B", "B", true, "", 0, 0)), TODAY)
        val a = rep.tasks.perTask.first { it.id == "A" }
        assertEquals(35, a.mins); assertEquals(55, a.plannedSum); assertEquals(35, a.effSumPlanned)
        assertEquals("A", rep.tasks.perTask[0].id)
        assertEquals(35, rep.tasks.byProject.first { it.first == "عمل" }.second)
    }

    @Test fun malformedRecordsDoNotCrashAnalysis() {
        val bad = SessionRec(0L, 0L, -5); bad.status = ""; bad.actual = Int.MAX_VALUE
        val c = clean(listOf(bad, rec(TODAY, 9, 0, 25, "done")))
        val rep = FocusIntel.build(c, DailyTotals.build(c.sessions, emptyMap<Long, Int>()), emptyList(), TODAY)
        assertEquals(1, rep.perf.doneCount)
        assertEquals(1, c.invalid)
    }
}
