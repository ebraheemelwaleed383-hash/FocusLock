package com.focuslock

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

// اختبارات JVM للمنطق الخالص. لم تُشغَّل في بيئة التطوير (لا يوجد Gradle هناك): شغّلها عبر `gradle testLiteDebugUnitTest`
class FocusLogicTest {

    @Test fun legacyTaskJsonStillLoads() {
        val t = TaskCodec.decode(JSONObject("""{"t":"اقرأ","d":false,"p":2}"""))
        assertEquals("اقرأ", t.t); assertFalse(t.d); assertEquals(2, t.p)
        assertEquals("", t.id); assertTrue(t.steps.isEmpty()); assertEquals(0, t.focusMins)
    }

    @Test fun legacyTaskWithoutPriorityDefaultsToMedium() {
        val t = TaskCodec.decode(JSONObject("""{"t":"x","d":true}"""))
        assertEquals(1, t.p); assertTrue(t.d)
    }

    @Test fun plainTaskEncodesToOldShape() {
        val o = TaskCodec.encode(Task("x", false, 1))
        assertEquals(setOf("t", "d", "p"), o.keys().asSequence().toSet())
    }

    @Test fun taskRoundTripKeepsAllFields() {
        val t = Task("Physics", false, 2)
        t.id = "abc"; t.proj = "Exam"; t.focusMins = 75; t.sessions = 3; t.later = true; t.notes = "n"
        t.steps.add(Step("Ch1", true)); t.steps.add(Step("Ch2", false))
        val r = TaskCodec.decode(TaskCodec.encode(t))
        assertEquals("abc", r.id); assertEquals("Exam", r.proj); assertEquals(75, r.focusMins); assertEquals(3, r.sessions)
        assertTrue(r.later); assertEquals("n", r.notes)
        assertEquals(listOf("Ch1" to true, "Ch2" to false), r.steps.map { it.text to it.done })
    }

    @Test fun newIdsAreDistinct() {
        assertNotEquals(TaskCodec.newId(), TaskCodec.newId())
        assertEquals(10, TaskCodec.newId().length)
    }

    @Test fun progressAndFraction() {
        val t = Task("x", false)
        assertEquals(0f, FocusLogic.fraction(t), 0.001f)
        t.steps.add(Step("a", true)); t.steps.add(Step("b", false)); t.steps.add(Step("c", false)); t.steps.add(Step("d", true))
        assertEquals(2 to 4, FocusLogic.progress(t))
        assertEquals(0.5f, FocusLogic.fraction(t), 0.001f)
    }

    @Test fun finishedTimerNeverCompletesTaskByItself() {
        for (o in listOf(FocusLogic.DONE, FocusLogic.PART, FocusLogic.LATER)) {
            val t = Task("x", false)
            FocusLogic.applyOutcome(t, o, false, "", null)
            assertFalse("outcome $o must not complete the task", t.d)
        }
    }

    @Test fun explicitConfirmationCompletesTask() {
        val t = Task("x", false)
        FocusLogic.applyOutcome(t, FocusLogic.DONE, true, "", null)
        assertTrue(t.d)
    }

    @Test fun laterFlagFollowsOutcome() {
        val t = Task("x", false)
        FocusLogic.applyOutcome(t, FocusLogic.LATER, false, "", null)
        assertTrue(t.later)
        FocusLogic.applyOutcome(t, FocusLogic.PART, false, "", null)
        assertFalse(t.later)
    }

    @Test fun notesAppendAndPriorityClamps() {
        val t = Task("x", false, 1)
        FocusLogic.applyOutcome(t, FocusLogic.PART, false, " first ", 5)
        FocusLogic.applyOutcome(t, FocusLogic.PART, false, "second", null)
        assertEquals("first\nsecond", t.notes)
        assertEquals(2, t.p)
    }

    @Test fun focusMinutesIgnoreSubMinuteSessions() {
        val t = Task("x", false)
        FocusLogic.addFocus(t, 0)
        assertEquals(0, t.sessions)
        FocusLogic.addFocus(t, 25)
        assertEquals(25, t.focusMins); assertEquals(1, t.sessions)
    }

    @Test fun actualMinutesRoundDownAndNeverNegative() {
        assertEquals(25, SessionMath.actualMins(0L, 25 * 60_000L + 59_000L))
        assertEquals(0, SessionMath.actualMins(10_000L, 5_000L))
    }

    @Test fun sessionRecRoundTrip() {
        val r = SessionRec(1000L, 1000L, 25)
        r.end = 2000L; r.actual = 24; r.status = "stop"; r.taskId = "t1"; r.taskTitle = "T"; r.goal = "g"; r.outcome = "part"
        val b = SessionRec.fromJson(r.toJson())
        assertEquals(1000L, b.id); assertEquals(25, b.planned); assertEquals(24, b.actual); assertEquals("stop", b.status)
        assertEquals("t1", b.taskId); assertEquals("T", b.taskTitle); assertEquals("g", b.goal); assertEquals("part", b.outcome)
    }

    @Test fun logTrimKeepsNewest() {
        val l = MutableList(10) { SessionRec(it.toLong(), it.toLong(), 25) }
        SessionMath.trim(l, 4)
        assertEquals(listOf(6L, 7L, 8L, 9L), l.map { it.id })
    }

    @Test fun corruptLogEntriesAreSkippedNotFatal() {
        val raw = JSONArray().put(JSONObject().put("id", 1L)).put("garbage").put(JSONObject().put("x", 1)).toString()
        val l = SessionMath.parseLog(raw)
        assertEquals(1, l.size)
        assertEquals(0, SessionMath.parseLog("not json").size)
    }

    @Test fun logEncodeParseRoundTrip() {
        val l = listOf(SessionRec(1L, 1L, 10), SessionRec(2L, 2L, 20))
        assertEquals(listOf(1L, 2L), SessionMath.parseLog(SessionMath.encodeLog(l)).map { it.id })
    }

    // ======== مرحلة التقوية (لم تُشغَّل بعد) ========

    @Test fun malformedTasksAreSkippedNotFatal() {
        val raw = """[{"t":"ok","d":false,"p":1},"junk",{"d":true},{"t":"  "},{"t":"two","p":9}]"""
        val p = TaskSafe.parse(raw)
        assertEquals(listOf("ok", "two"), p.tasks.map { it.t })
        assertEquals(3, p.skipped); assertFalse(p.broken)
        assertEquals(2, p.tasks[1].p) // الأولوية تُقيَّد بين 0 و2
    }

    @Test fun unreadableTaskTextIsFlaggedBrokenWithoutThrowing() {
        val p = TaskSafe.parse("not json")
        assertTrue(p.broken); assertTrue(p.tasks.isEmpty())
        assertFalse(TaskSafe.parse("").broken)
    }

    @Test fun duplicateAndMissingTaskIdsAreNormalized() {
        val a = Task("a", false); a.id = "x"
        val b = Task("b", false); b.id = "x"
        val c = Task("c", false)
        val l = listOf(a, b, c)
        assertTrue(TaskSafe.normalizeIds(l))
        assertEquals(3, l.map { it.id }.toSet().size)
        assertEquals("x", a.id)
        assertFalse(TaskSafe.normalizeIds(l))
    }

    @Test fun restoreRejectsUnusableTasksButAcceptsEmptyList() {
        assertEquals(null, TaskSafe.sanitizeForRestore("garbage"))
        assertEquals(null, TaskSafe.sanitizeForRestore("""["x",{"d":true}]"""))
        assertEquals("[]", TaskSafe.sanitizeForRestore("[]"))
        val clean = TaskSafe.sanitizeForRestore("""[{"t":"keep","d":false},"bad"]""")!!
        assertEquals(listOf("keep"), TaskSafe.parse(clean).tasks.map { it.t })
    }

    @Test fun restoreRejectsUnusableSessionLog() {
        assertEquals(null, BackupGuard.sanitize("sl_log", "garbage"))
        assertEquals(null, BackupGuard.sanitize("sl_log", """["x"]"""))
        assertEquals("abc", BackupGuard.sanitize("theme", "abc"))
        val ok = BackupGuard.sanitize("sl_log", SessionMath.encodeLog(listOf(SessionRec(5L, 5L, 25))))!!
        assertEquals(1, SessionMath.parseLog(ok).size)
    }

    @Test fun duplicateSessionNeverReplacesExistingRecord() {
        val l = mutableListOf<SessionRec>()
        val first = SessionRec(1000L, 1000L, 25)
        first.taskId = "t1"; first.taskTitle = "T"; first.goal = "g"; first.status = "done"; first.actual = 25
        assertTrue(SessionMath.addOrMerge(l, first))
        val dup = SessionRec(1000L, 1000L, 25) // settle مكرر بلا ربط بمهمة
        dup.status = "done"; dup.actual = 25
        assertFalse(SessionMath.addOrMerge(l, dup))
        assertEquals(1, l.size)
        assertEquals("t1", l[0].taskId); assertEquals("g", l[0].goal)
    }

    @Test fun duplicateDetectedByNearbyStartEvenWithDifferentId() {
        val l = mutableListOf(SessionRec(1000L, 1000L, 25).also { it.status = "done" })
        assertTrue(SessionMath.hasStart(l, 3_000L))
        assertFalse(SessionMath.hasStart(l, 60_000L))
        assertFalse(SessionMath.addOrMerge(l, SessionRec(1001L, 1001L, 25)))
        assertEquals(1, l.size)
    }

    @Test fun mergeFillsBlankFieldsOnly() {
        val ex = SessionRec(1L, 1L, 25).also { it.status = "done"; it.outcome = "part" }
        val l = mutableListOf(ex)
        val r = SessionRec(1L, 1L, 25).also { it.taskId = "t"; it.outcome = "done" }
        SessionMath.addOrMerge(l, r)
        assertEquals("t", ex.taskId)
        assertEquals("part", ex.outcome) // الموجود لا يُستبدل
    }

    @Test fun uniqueIdSkipsUsedIds() {
        val l = listOf(SessionRec(5L, 5L, 1), SessionRec(6L, 6L, 1))
        assertEquals(7L, SessionMath.uniqueId(l, 5L))
        assertEquals(9L, SessionMath.uniqueId(l, 9L))
    }

    @Test fun parseMergesSameIdOnly() {
        val raw = SessionMath.encodeLog(listOf(SessionRec(1L, 1L, 10), SessionRec(2L, 2L, 20), SessionRec(2L, 2L, 20)))
        assertEquals(listOf(1L, 2L), SessionMath.parseLog(raw).map { it.id })
    }

    @Test fun stepMergeAppliesDoneStateByTextOnly() {
        val t = Task("x", false)
        t.steps.add(Step("a", false)); t.steps.add(Step("b", false)); t.focusMins = 40
        TaskOps.mergeSteps(t, listOf(Step("b", true), Step("gone", true)))
        assertEquals(listOf(false, true), t.steps.map { it.done })
        assertEquals(40, t.focusMins)
    }

    @Test fun reorderByIdsKeepsUnlistedTasks() {
        val l = mutableListOf("a", "b", "c", "d").map { n -> Task(n, false).also { it.id = n } }.toMutableList()
        TaskOps.reorder(l, listOf("c", "a"))
        assertEquals(listOf("c", "a", "b", "d"), l.map { it.id })
    }

    @Test fun moveSwapsNeighborAndStopsAtEdges() {
        val l = mutableListOf("a", "b", "c").map { n -> Task(n, false).also { it.id = n } }.toMutableList()
        assertTrue(TaskOps.move(l, "b", -1))
        assertEquals(listOf("b", "a", "c"), l.map { it.id })
        assertFalse(TaskOps.move(l, "b", -1))
        assertFalse(TaskOps.move(l, "zzz", 1))
    }

    @Test fun reviewQueueDedupesAndCaps() {
        val q = ReviewQueue.parse("[3,3,0,\"x\",4]")
        assertEquals(listOf(3L, 4L), q)
        assertTrue(ReviewQueue.add(q, 4L).isEmpty())
        var dropped: List<Long> = emptyList()
        for (i in 10L..30L) dropped = dropped + ReviewQueue.add(q, i)
        assertEquals(ReviewQueue.CAP, q.size)
        assertEquals(30L, q.last())
        assertTrue(dropped.contains(3L))
        assertEquals(q, ReviewQueue.parse(ReviewQueue.encode(q)))
        assertTrue(ReviewQueue.parse("garbage").isEmpty())
    }

    @Test fun reminderStoreSupportsManyAndReplacesPerTask() {
        val l = mutableListOf<Rem>()
        RemLogic.upsert(l, RemLogic.make(l, "a", "A", 25, 100L))
        RemLogic.upsert(l, RemLogic.make(l, "b", "B", 30, 200L))
        assertEquals(2, l.size)
        assertNotEquals(l[0].rc, l[1].rc)
        val rcA = l.first { it.taskId == "a" }.rc
        RemLogic.upsert(l, RemLogic.make(l, "a", "A2", 45, 300L))
        assertEquals(2, l.size)
        val a = l.first { it.taskId == "a" }
        assertEquals(rcA, a.rc); assertEquals(300L, a.at); assertEquals(45, a.mins)
    }

    @Test fun reminderStoreCapsAndRoundTrips() {
        val l = mutableListOf<Rem>()
        val dropped = ArrayList<Rem>()
        for (i in 1..(RemLogic.CAP + 3)) dropped.addAll(RemLogic.upsert(l, RemLogic.make(l, "t$i", "T$i", 25, i * 1000L)))
        assertEquals(RemLogic.CAP, l.size); assertEquals(3, dropped.size)
        val back = RemLogic.parse(RemLogic.encode(l))
        assertEquals(l.map { it.taskId }, back.map { it.taskId })
        assertEquals(l.map { it.rc }, back.map { it.rc })
        assertEquals(l.map { it.rc }.toSet().size, l.size)
    }

    @Test fun corruptReminderStoreIsSkippedNotFatal() {
        val raw = """[{"k":"a","at":5,"rc":1},"x",{"k":"","at":5,"rc":2},{"k":"b","at":0,"rc":3},{"k":"a","at":9,"rc":4}]"""
        val l = RemLogic.parse(raw)
        assertEquals(listOf("a"), l.map { it.taskId })
        assertTrue(RemLogic.parse("garbage").isEmpty())
    }
}
