package com.focuslock

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

// اختياري: يخفي إشعارات التطبيقات المحظورة أثناء الجلسة أو بعد انتهاء حد التطبيق
class NotifBlocker : NotificationListenerService() {
    private fun muted(p: String): Boolean {
        if (!Prefs.blockNotifs(this) || p == packageName) return false
        if (p in Prefs.essentials(this)) return false
        return (Prefs.active(this) && p in Prefs.blocked(this)) || Limits.blockedNow(this, p)
    }

    private fun check(sbn: StatusBarNotification) {
        if (muted(sbn.packageName)) {
            try { cancelNotification(sbn.key) } catch (_: Exception) { }
        }
    }

    override fun onListenerConnected() {
        try { activeNotifications?.forEach { check(it) } } catch (_: Exception) { }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) { check(sbn) }
}
