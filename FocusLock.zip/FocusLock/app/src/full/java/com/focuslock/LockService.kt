package com.focuslock

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class LockService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            Guard.commit(this@LockService)
            Guard.beat(this@LockService)
            h.postDelayed(this, 10_000L)
        }
    }

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF) { Guard.screenOff(c); return }
            if (Prefs.active(c)) Guard.showLock(c, null)
        }
    }

    override fun onServiceConnected() {
        Engine.a11yAlive = true
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenRx, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(screenRx, f)
        h.removeCallbacks(ticker)
        h.postDelayed(ticker, 10_000L)
        if (Prefs.active(this)) {
            KeepAliveService.start(this)
            EndAlarm.schedule(this)
            Guard.beat(this)
            Guard.showLock(this, null)
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val type = e.eventType
        val pkg = e.packageName?.toString() ?: return
        if (type == AccessibilityEvent.TYPE_VIEW_SCROLLED) { Guard.scroll(this, pkg); return }
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        Guard.onForeground(this, pkg, e.className?.toString() ?: "")
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        Engine.a11yAlive = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        Engine.a11yAlive = false
        h.removeCallbacks(ticker)
        try { unregisterReceiver(screenRx) } catch (_: Exception) {}
        super.onDestroy()
    }
}
