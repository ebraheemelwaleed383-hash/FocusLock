# FocusLock — Decisions

## Public releases are explicit only (Hardening, H1)
- `build.yml` builds on every push (artifact only). Reason: `Updater.kt` reads `/releases/latest`, so any release reaches all users.
- **Review-fix pass (supersedes the earlier `v*` tag rule):** there is NO tag trigger any more. Publishing lives in a separate `publish` job, the only job with `contents: write` (the workflow and the `build` job are `contents: read`; signing secrets exist only in the `build` job). `publish` runs only when ALL hold: manual `workflow_dispatch`, `publish_release=true`, `confirm=PUBLISH`, repository variable `ALLOW_PUBLIC_RELEASE=true`, unit tests passed, and (inside the job) no release `v<versionName>` exists yet. The variable is unset by default, so publishing stays closed until deliberately enabled.
- **Re-enabling for the final release (deliberate, in this order):** (1) finish the audit, build, tests and device verification; (2) bump `versionName`/`versionCode` and update `RELEASE_NOTES.txt` / `WhatsNew.kt`; (3) in GitHub: Settings > Secrets and variables > Actions > Variables, add `ALLOW_PUBLIC_RELEASE` = `true`; (4) Actions > Build APK > Run workflow with `publish_release` checked and `confirm` = `PUBLISH`; (5) afterwards delete or set the variable to anything else. Optionally put the `publish` job behind a GitHub Environment with required reviewers.

## One synchronized write path for tasks (M2)
- Every task change goes through `Tasks.update` (load fresh, change by id, save). `Tasks.save(list)` remains only as its internal step. Never save a list that was loaded earlier in a dialog or page.

## Corrupt data is skipped, never fatal, and never silently destroyed (M1)
- Bad items are skipped; the original raw text is kept once (`tasks_corrupt`, `sl_log_corrupt`). Restore validates guarded keys (`tasks`, `sl_log`) and keeps current data if the backup value is unusable; replaced values go to `rb_*`.

## Reminders (M3)
- State in `ft_rems` (device-specific, excluded from backup). One per task, max 20, inexact alarm (no exact-alarm permission), rescheduled on boot/update/app start, validated when fired.

## Session review (M4)
- Queue `ft_revq` (max 10, oldest first). Notification at session end. "Not now" snoozes 10 minutes. After 7 days the session gets outcome `skip` (not silently dropped). Sessions under 1 minute that were stopped early are not queued.

## Session log duplicates (L1)
- An existing session record is never replaced; duplicates are merged by filling blank fields. Start times within 5 s count as the same session for new inserts only.

## Shared analytics foundation (Features 01 and 02)
- One pure-Kotlin layer (`Analytics.kt`): `SessionAnalytics.clean` turns `SessionRec` into `Sess`; both features use it plus the same period/length buckets (`Ax`). No second session store.
- Cleaning rules: `open` ignored; unknown status, negative/impossible values (> 720 min), end before start, start more than 1 day in the future -> excluded and counted; stop or done under 1 minute -> ignored (accidental); duplicates (same id or start within 5 s) counted once, `done` beats `stop`.
- Definitions: completed focus time = minutes of `done` sessions only. Early exit = `stop`; no cancelled/interrupted split exists in the data. Completion rate = done / (done + stop), null if 0. Effective minutes of a `stop` session = min(actual, planned) so a late-closed record cannot inflate time.
- Daily/weekly time (review-fix pass; replaces the earlier "legacy only before the first logged session" rule): `Prefs.settle` writes `fm_<settle day>` for EVERY completed session, uncapped, while the log keeps only the latest 600 sessions. Per day, completed minutes = `max(fm_ value, completed minutes of log sessions attributed to their END day)`. Max (never a sum) cannot double count a day; it restores days whose sessions were trimmed from the log (fm_ larger) and days with no fm_ value (log larger). End-day attribution matches the day `fm_` uses; a session that ends before midnight but is settled after midnight (app not running) can appear on both days (known, rare).
- Coverage (`DailyTotals.coverageStart`) = earliest valid `fm_` key (even value 0: proves tracking was running; absent days after it are real zeros) or the log's first COMPLETE day. If the log is at its cap (`recs.size >= 600`, `Cleaned.logTruncated`) its oldest day is treated as partial and the log is complete from the next day (`logCompleteFrom`). Weekly/14-day trends compare only when the previous window lies inside coverage; the session-based completion/early-exit trends use `logCompleteFrom`, never the counters (they carry no outcome).
- `LegacyDaily.parse` ignores keys that are not exactly `fm_` + 8 digits, invalid dates, and negative values (corrupt); values above 1440 are clamped.
- Analysis window for Feature 01: last 90 days.
- Minimums (`Th`): 10 attempts for rate claims; 5 attempts per bucket for comparisons; 10 completed sessions for hour patterns; 21 days and all 7 weekdays seen twice for weekday patterns; peak period share >= 45%; 20-point gap for length/period comparisons; best weekday >= 1.3x the weekday average; weekly trend >= 20% with >= 60 min total; early-exit change >= 15 points with >= 5 sessions per 2-week window.
- Confidence (`confidenceOf`) is descriptive: attempts and days covered only (NONE <3, LOW <10 or <7 days, MEDIUM <30 or <21 days, else HIGH). It is not statistical confidence.
- Insights/recommendations are produced as codes plus evidence numbers (`IC`, `RC`); the UI renders text. Recommendations never change settings.

## Focus DNA storage and profile (Feature 02)
- Weekly summaries (`WeekAgg`, week = Monday start) in `dna_hist`: counts, minutes by start hour and weekday, length buckets, active days, first day. No titles or goals (privacy, size).
- Merge rule: per week keep the copy with more attempts (ties: newer). Trimming of the 600-session log therefore cannot erase history. Cap 104 weeks.
- Backup/restore: `dna_hist` is in `BackupGuard.GUARDED` (validated) and restore MERGES it with local history. Corrupt local content is copied once to `dna_hist_bad` before being overwritten.
- Window: last 3 full weeks + current week (updates with each session); baseline = 4 full weeks before. Evolution needs >= 8 attempts and >= 14 days in both.
- Labels (entry / exit threshold): period labels 50% / 45% of completed minutes; short sessions 60% / 55% of completed sessions <= 25 min; long 50% / 45% > 40 min; consistent habit >= 4.0 / 3.5 active days per week, regular >= 2.0 / 1.75, otherwise occasional; finishes >= 85% / 80% completion, ends early < 60% / 65% (>= 10 attempts); task-linked >= 40% / 35%; improving consistency = +0.75 active days/week vs baseline. A label held in the baseline uses its exit threshold (hysteresis), so one unusual session cannot flip it. Minimum samples: 6 completed sessions (rhythm/length), 10 (varied timing), 14 days (habit), 10 attempts (behavior).
- No psychological or medical claims; labels describe behavior and show their rule in the UI.

## Navigation and workflow notes (Features 01/02)
- The Stats tab became a group `[Usage, Insights, DNA]` (`TAB_USAGE=1`, `TAB_INTEL=10`, `TAB_DNA=11`).
- The `.github/workflows/build.yml` inside `FocusLock.zip` is now the hardened workflow (it previously contained the old publish-on-push version).
- Version stays 2.7 (versionCode 18): no release is being made.

## Still open
- Pause in sessions (would weaken strict lock): needs an explicit decision.
