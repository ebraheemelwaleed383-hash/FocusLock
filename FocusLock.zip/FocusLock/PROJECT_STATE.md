# FocusLock — Project State

## Project Overview

Android productivity and focus timer application.

- Package: `com.focuslock`
- Previous stable version: 2.6
- Previous version code: 17
- Target versions: Lite and Full
- Language: Kotlin
- Build system: Gradle Kotlin DSL

## Original Architecture

- `MainActivity.kt`: Main application activity.
- `Engine.kt`: Focus timer engine.
- `Prefs.kt`: SharedPreferences storage.
- `Planner.kt`: Planning system.
- `TasksNotesPage.kt`: Tasks and notes.
- `Plans.kt`: Focus modes.
- `Limits.kt` and `Protect.kt`: App protection.
- `UsagePage.kt` and `Charts.kt`: Statistics.
- `Rewards.kt`: Achievements and rewards.
- `Sfx.kt`: Sound system.

### Storage

Existing user data is stored using SharedPreferences in the `fl` preferences file.

**Important:** Preserve existing data and backward compatibility. Do not replace the existing storage architecture without a justified migration plan.

## Development Progress

### Version 2.6

Existing stable project before the latest development changes.

### Version 2.7 — Stage 0, Feature 03 and Hardening Stage

All of it is **implemented but NOT COMPILED OR VERIFIED**. No Gradle build, unit test or device test has been run.

#### Stage 0 — Session Log
- Session start and end tracking, planned and actual duration, completed or interrupted status, linked task and goal.
- Up to 600 stored sessions, included in backup and restore.
- Duplicate settle events are merged/skipped and never replace an existing record.

#### Feature 03 — Focus Tasks
- Session focus card on Home (and in single-screen mode), task selection and creation, projects, goals, checklists.
- Task checklist on the lock screen, post-session review, optional reminders.

#### Hardening Stage (after code review of Stage 0 and Feature 03)
Fixes H1, M1–M5, L1 (details and files in `CHECKLIST.md`):
- Public releases only on explicit trigger (`build.yml`).
- Tolerant task parsing, guarded restore, safe lock-screen card.
- `Tasks.update` synchronized load-modify-save used by every task writer.
- Persistent multi-task reminders rescheduled after reboot/update, validated when fired, notification-settings warning.
- Review queue with end-of-session notification, snooze and expiry (`skip`) instead of silent loss.
- Task card in single-screen mode.

#### New files
`FocusLogic.kt`, `FocusTasks.kt`, `FocusTaskUi.kt`, `FocusLogicTest.kt`, `CHECKLIST.md`, plus in hardening: `FocusSafe.kt`, `FocusReminders.kt`, `DECISIONS.md`.

#### Modified files
`Look.kt`, `Prefs.kt`, `MainActivity.kt`, `LockActivity.kt`, `TasksNotesPage.kt`, `WhatsNew.kt`, `AndroidManifest.xml`, `app/build.gradle.kts`, `RELEASE_NOTES.txt`; hardening also touched `FocusLogic.kt`, `FocusTasks.kt`, `FocusTaskUi.kt`, `BootReceiver.kt`, `BuilderActivity.kt`, `Screens.kt`, and the workflow `build.yml`. `Engine.kt`, `Protect.kt`, `Limits.kt` were not modified.

#### Remaining limitations
See "Remaining limitations" in `CHECKLIST.md` (inexact reminders, task editing gaps, unlinked plan sessions, safety copies without restore UI, no pause).

#### Important
- Push the new `build.yml` in the same commit as (or before) the new zip, otherwise an old workflow could publish 2.7 publicly.

### Features 01 and 02 — Focus Intelligence and Focus DNA (version 2.7, unreleased)

Implemented but **NOT COMPILED OR VERIFIED** (no Kotlin compiler/Gradle was available; static review only). 59 unit tests written, none run.

- Feature 01: `IntelPage` + `FocusIntel.kt`: performance, daily/weekly time and trends, patterns, task performance, insights, recommendations.
- Feature 02: `DnaPage` + `FocusDna.kt`: rhythm, length, consistency, behavior, evolution, labels by documented rules, coverage/confidence; weekly history in `dna_hist`.
- Shared foundation: `Analytics.kt` (cleaning, definitions, buckets, statistics, daily totals); Android glue `FocusData.kt` (`FocusData`, `DnaStore`).
- Data structures and calculations: see DECISIONS.md ("Shared analytics foundation", "Focus DNA storage and profile").

#### New files
`Analytics.kt`, `FocusIntel.kt`, `FocusDna.kt`, `FocusData.kt`, `FocusIntelUi.kt`, `FocusDnaUi.kt`, tests `AnalyticsTest.kt`, `DailyTotalsTest.kt`, `FocusDnaTest.kt`.

#### Modified files
`MainActivity.kt` (two sub-tabs under Stats), `Prefs.kt` (`dayTotals`, `NO_BACKUP` additions, restore merge for `dna_hist`), `FocusSafe.kt` (`dna_hist` guarded), `FocusTasks.kt` (`DnaStore.update` after a session is logged, in try/catch), `.github/workflows/build.yml` inside the zip (replaced with the hardened workflow), `CHECKLIST.md`, `PROJECT_STATE.md`, `DECISIONS.md`. `Engine.kt`, `Protect.kt`, `Limits.kt`, timer and lock code were not modified. No new permission or dependency.

#### Review-fix pass (workflow and daily totals)
- `build.yml`: no tag trigger; separate `publish` job is the only writer and needs manual run + `confirm=PUBLISH` + repo variable `ALLOW_PUBLIC_RELEASE=true` + passing tests. Re-enable steps: DECISIONS.md.
- Daily totals: per-day max of `fm_` counters and the (capped) session log; coverage and truncation handled; see DECISIONS.md. Modified: `build.yml`, `Analytics.kt`, `FocusIntel.kt`, `FocusData.kt`, `FocusIntelUi.kt`; tests: new `DailyTotalsTest.kt`, updated `AnalyticsTest.kt`. Still not compiled or run (92 tests total, 59 for Features 01/02 and the fix).

#### First CI result
Run 1 failed to compile (`FocusDna.kt:254`, fixed). Run 2 (#43): Lite and Full release builds SUCCEEDED; the unit-test compilation failed in `FocusDnaTest.kt:114` (fixed, awaiting a new run). Runs 3-4: tests ran: 92, 1 failed (`AnalyticsTest.openInvalidTinyAndFutureRecordsAreExcludedAndCounted`), caused by a test-helper bug (fixed, awaiting re-run). 91 tests passed in CI. The `publish` job is skipped by design (no release).

#### Lite and Full
Both features live in `src/main` (shared by both editions); no edition-specific code was added or changed. The workflow still builds both editions.

#### Remaining limitations
See "Features 01/02 — Remaining limitations" in `CHECKLIST.md`.

## Next Development Stage

1. Build 2.7 (now including Features 01 and 02) with GitHub Actions (no release), fix compile errors, report test results.
2. After the review is accepted, choose the next features (for example 05 and 14).

Before implementing:

- Inspect the actual latest project files.
- Confirm the Stage 0, Feature 03 and Hardening implementation exists.
- Do not assume reported changes are verified.
- Preserve all existing functionality.

## Main Development Goal

Implement all 15 planned features, then perform comprehensive testing and prepare a stable Android release.

Never mark an implementation as verified without actual test evidence.
